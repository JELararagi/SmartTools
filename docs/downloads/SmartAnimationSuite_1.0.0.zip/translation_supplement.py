# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

SUPPLEMENTAL_UI_JA_TRANSLATIONS = {'1.85:1 - Academy Flat': '1.85:1 - アカデミーフラット',
 '1.85:1 aspect ratio (1.850)': '1.85:1 のアスペクト比 (1.850)',
 '16:10 - Computer Monitor': '16:10 - コンピューターモニター',
 '16:10 aspect ratio (1.600)': '16:10 のアスペクト比 (1.600)',
 '16:9': '16:9',
 '16:9 - Widescreen': '16:9 - ワイドスクリーン',
 '16:9 aspect ratio (1.778)': '16:9 のアスペクト比 (1.778)',
 '16:9 format (20 x 11.25)': '16:9 形式 (20 x 11.25)',
 '1:1 - Square': '1:1 - 正方形',
 '2.35:1 - CinemaScope': '2.35:1 - シネマスコープ',
 '2.35:1 aspect ratio (2.350)': '2.35:1 のアスペクト比 (2.350)',
 '3:2 - 35mm Film': '3:2 - 35mm フィルム',
 '3:2 aspect ratio (1.500)': '3:2 のアスペクト比 (1.500)',
 '3D View': '3Dビュー',
 '4:3 - Standard TV': '4:3 - 標準テレビ',
 '4:3 aspect ratio (1.333)': '4:3 のアスペクト比 (1.333)',
 '9:16 - Portrait': '9:16 - 縦長',
 'A4 Landscape': 'A4 横',
 'A4 Portrait': 'A4 縦',
 'About': '説明',
 'Accessible': 'アクセス可能',
 'Action / NLA Workflow': 'アクション / NLA ワークフロー',
 'Add Current': '現在を追加',
 'Add Layer': 'レイヤー追加',
 'Add a timeline marker on the current frame using the marker name field.': 'マーカー名フィールドの内容で、現在フレームにタイムラインマーカーを追加します。',
 'Add layered camera shake, wobble, and captured handheld motion patterns to cameras through reusable shake actions and controls.': '再利用可能なシェイクアクションを使い、カメラへ揺れ・手持ち風モーション・ワブルを重ね掛けできるカメラ演出ツールです。',
 'Add or refresh a non-destructive Cycles modifier on the selected or active curves. This is useful for looping motion, repeat-offset actions, and ping-pong previews inspired by Track View or Signal-style workflows.': '選択または対象 '
                                                                                                                                                                                                                          'F '
                                                                                                                                                                                                                          'カーブに、非破壊の '
                                                                                                                                                                                                                          'Cycles '
                                                                                                                                                                                                                          'モディファイアを追加または更新します。ループモーション、オフセット繰り返し、Track '
                                                                                                                                                                                                                          'View '
                                                                                                                                                                                                                          'や '
                                                                                                                                                                                                                          'Signal '
                                                                                                                                                                                                                          '風のピンポンプレビューに便利です。',
 'All keyframe types': 'すべてのキーフレームタイプ',
 'Already in camera view': 'すでにカメラビューです',
 'Always Active': '常時有効',
 'Always active but last load failed': '常時有効だが前回読込失敗',
 'Always active in Smart Animation': 'Smart Animation で常時有効',
 'Always active; automatic initialization': '常時有効・自動初期化',
 'Always active; state will update after runtime initializes.': '常時有効・実行時初期化後に状態が更新されます。',
 'Amplitude': '振幅',
 'Analyze the current action and report how many keys or channels would be simplified, removed as duplicates, or deleted as static, without changing any data.': '現在のアクションを解析し、データを変更せずに、どれだけのキーやチャンネルが簡略化・重複削除・静的削除の対象になるかを報告します。',
 'Angle': '角度',
 'Animate mesh, curve, lattice, UV, attribute, bevel, crease, and other element-level data that standard object transforms do not cover.': '通常のオブジェクト変形では扱えない頂点・UV・属性・ベベル・クリースなど、要素単位データへキーフレームを打てるツールです。',
 'Animatic Resolution X': 'アニマティック解像度 X',
 'Animatic:': 'アニマティック:',
 'Animation data could not be created on the active object.': 'アクティブオブジェクトにアニメーションデータを作成できませんでした。',
 'Antic + Over': '予備+オーバー',
 'Application Handlers': 'アプリケーションハンドラー',
 'Apply a baked overlap pass that pulls later targets toward earlier motion. This is useful for drag, follow-through, tails, ropes, props, and mechanical chain offsets.': '後続ターゲットを少し前の動きへ引き寄せるベイク済みオーバーラップ処理を適用します。ドラッグ、フォロースルー、しっぽ、ロープ、小物、機械チェーンの遅れ表現に便利です。',
 'Apply a camera-friendly procedural noise setup to the active camera or scene camera. This gives a quick GorillaCam-style handheld pass without destroying the base animation.': 'アクティブカメラまたはシーンカメラへ、カメラ向けのプロシージャルノイズ設定を適用します。ベースアニメーションを壊さずに、GorillaCam '
                                                                                                                                                                                  '的な手持ち風揺れを素早く追加できます。',
 'Apply a non-destructive stepped interpolation modifier to the selected or active curves. Use 2 for animation on twos and 4 for fours.': '選択または対象カーブに、非破壊の段階補間モディファイアを適用します。2 '
                                                                                                                                          'で '
                                                                                                                                          '2 '
                                                                                                                                          'コマ打ち、4 '
                                                                                                                                          'で '
                                                                                                                                          '4 '
                                                                                                                                          'コマ打ちのプレビューに使えます。',
 'Apply a procedural noise modifier to the selected or active curves. This is useful for handheld camera shake, subtle breathing, cloth flutter, and procedural motion design.': '選択または対象カーブにプロシージャルなノイズモディファイアを適用します。手持ちカメラの揺れ、呼吸、布の微振動、モーショングラフィックスに便利です。',
 'Apply a tangent or interpolation preset to selected or active curves. Use Flat for planted contacts, Broken for discontinuity-style direction changes, Auto / Auto Clamped to restore smoothing, Vector for sharp changes, Linear for even timing, and Constant for blocking.': '選択または対象カーブへ、接線または補間のプリセットを適用します。Flat '
                                                                                                                                                                                                                                                                                  'は接地や停止、Broken '
                                                                                                                                                                                                                                                                                  'は不連続風の鋭い方向転換、Auto '
                                                                                                                                                                                                                                                                                  '/ '
                                                                                                                                                                                                                                                                                  'Auto '
                                                                                                                                                                                                                                                                                  'Clamped '
                                                                                                                                                                                                                                                                                  'は滑らかさの復元、Vector '
                                                                                                                                                                                                                                                                                  'は鋭い変化、Linear '
                                                                                                                                                                                                                                                                                  'は均等タイミング、Constant '
                                                                                                                                                                                                                                                                                  'はブロッキングに向いています。',
 'Apply curated easing presets to selected animation keyframes from icon-based controls in the Graph Editor or related animation editors.': 'グラフエディターなどで選択したキーフレームへ、アイコン付きプリセットから各種イージングを素早く適用できるツールです。',
 'Apply saved pose snapshots from compact buttons, similar to a lightweight pose library palette.': '保存済みポーズスナップショットを、軽量なポーズライブラリ風のコンパクトボタンから適用します。',
 'Apply saved selection sets from compact buttons for faster control picking.': '保存した選択セットをコンパクトなボタンから適用して、コントロール選択を素早く行えます。',
 'Apply the currently highlighted pose snapshot to matching pose bones on the active armature.': '現在ハイライトされているポーズスナップショットを、アクティブアーマチュアの一致するポーズボーンへ適用します。',
 'Assign': '割り当て',
 'Assign Mode': '割り当て方式',
 'Assign a scene camera first.': '先にシーンカメラを設定してください。',
 'Assign or push saved motions from compact buttons for faster shot assembly.': '保存済みモーションをコンパクトなボタンから割り当てたり NLA '
                                                                                'へ積んだりして、ショット組み立てを高速化します。',
 'Assign the highlighted library action to the active object, either as a linked original or as a duplicated editable copy.': 'ハイライト中のライブラリアクションを、元データのままリンクするか編集用複製コピーとして、アクティブオブジェクトへ割り当てます。',
 'Audio Scrub': '音声スクラブ',
 'Auto Backup': '自動バックアップ',
 'Auto Backup is off. Consider enabling it before destructive cleanup.': '自動バックアップがオフです。破壊的整理の前に有効化を推奨します。',
 'Auto Flip': '自動反転',
 'Auto Key': 'オートキー',
 'Auto-Fix Basics found nothing to repair.': '基本自動修復で修正対象は見つかりませんでした。',
 'Axis': '軸',
 'Background Callbacks': '常駐コールバック',
 'Background Timers': 'バックグラウンドタイマー',
 'Background callback groups run only when enabled in the Always-on Toggles section. They are disabled by default after installation.': '常駐コールバックは「常時起動切り替え」セクションで有効にした場合のみ動作します。インストール直後はデフォルトで無効です。',
 'Background transparency:': '背景の透明度:',
 'Bake / FX Hub': 'ベイク / FX ハブ',
 'Bake the active Smart Animation live retarget preview on the target rig into regular keys over the chosen frame range.': '有効な '
                                                                                                                                 'Smart '
                                                                                                                                 'Animation '
                                                                                                                                 'Toolset '
                                                                                                                                 'ライブリターゲットプレビューを、選択したフレーム範囲で通常キーとしてターゲットリグへベイクします。',
 'Bake the current selection over the chosen frame range using visual keying. This is useful after constraints or drivers create a result you want to convert into regular keys.': '選択したフレーム範囲に対して、現在の選択をビジュアルキーでベイクします。コンストレイントやドライバーの結果を通常キーに変換したいときに便利です。',
 'Bake the predicted ballistic arc back into editable location keys on the current object or active pose bone. Use Ballistic Blend below 1.0 for a lighter AutoPhysics-style correction instead of a full replacement.': '予測した弾道アークを、現在のオブジェクトまたはアクティブポーズボーンの編集可能な位置キーへベイクします。Ballistic '
                                                                                                                                                                                                                         'Blend '
                                                                                                                                                                                                                         'を '
                                                                                                                                                                                                                         '1.0 '
                                                                                                                                                                                                                         '未満にすると、完全置換ではなく軽い '
                                                                                                                                                                                                                         'AutoPhysics '
                                                                                                                                                                                                                         '風の補正として使えます。',
 'Batch renaming completed': '一括の名前変更が終わりました',
 'Blend Snapshot': 'スナップショットブレンド',
 'Blend the highlighted pose snapshot onto the current pose using the Pose Blend slider. This behaves like a compact pose-morph helper for animation blocking and polish.': '選択中のポーズスナップショットを、ポーズブレンドの値で現在ポーズへ重ねます。ブロッキングや詰めの作業で使える、コンパクトなポーズモーフ補助です。',
 'Bone map exported to Blender text data and clipboard.': 'ボーン対応表を Blender テキストデータとクリップボードへ書き出しました。',
 'Bone map rebuild did not complete.': 'ボーン対応の再作成が完了しませんでした。',
 'Bottom': '下',
 'Breakdown': 'ブレークダウン',
 'Brush': 'ブラシ',
 'Brushes': 'ブラシ',
 'Build Stack': 'スタック作成',
 'Build a practical name-based preview map from the source rig to the target rig. This inspects naming compatibility before you commit to a fuller retarget pipeline.': 'ソースリグからターゲットリグへの実用的な名前ベース対応表を作成します。本格的なリターゲット作業の前に命名互換性を確認できます。',
 'Calculate motion paths for the selected bones or objects over the chosen frame range so you can inspect arcs and spacing visually.': '選択ボーンまたはオブジェクトのモーションパスを指定範囲で計算し、アークやスペーシングを視覚的に確認できるようにします。',
 'Calculate or clear motion paths for quick arc review.': 'モーションパスを計算または解除してアーク確認に使います。',
 'Camera Exclusion Auto Update': 'カメラ除外の自動更新',
 "Can't display this panel here!": 'このパネルはここに表示できません！',
 'Canvas': 'キャンバス',
 'Capture a reference pose, then propagate the transform delta to keyed pose-bone channels inside the selected Action and slot frame range.': '基準ポーズを記録し、変更後の差分を選択中 '
                                                                                                                                              'Action '
                                                                                                                                              '/ '
                                                                                                                                              'スロットの指定フレーム範囲へ一括反映するポーズ補正ツールです。',
 'Cat': '猫',
 'Category': 'カテゴリ',
 'Category of the new pose': '新しいポーズのカテゴリ',
 'Center Text': '中央テキスト',
 'Center footer text': 'フッターテキストを中央揃えにします',
 'Center header text': 'ヘッダーテキストを中央揃えにします',
 'Choose a collision collection, enable a collider object, or switch Collision to Floor/None.': '衝突コレクションを選ぶか、コライダーオブジェクトを有効にするか、Collision '
                                                                                                'を Floor または None '
                                                                                                'に変更してください。',
 'Cleanup Hub': '整理ハブ',
 'Cleanup Summary': '整理概要',
 'Clear': 'クリア',
 'Clear After Bake': 'ベイク後解除',
 'Clear Existing Range': '既存範囲を消去',
 'Clear Older SAS': '古いSAS整理',
 'Clear SAS': '旧SAS削除',
 'Clear the in-panel operation log so you can start a fresh review.': 'パネル内の操作ログを消去して、新しい確認を始められるようにします。',
 'Clear visible motion paths from the current selection.': '現在の選択に表示されているモーションパスをクリアします。',
 'Click to switch this feature between enabled and disabled.': 'クリックすると、この機能の有効 / 無効を切り替えます。',
 'Cmd': 'コマンド',
 'Collider': 'コライダー',
 'Collision': '衝突',
 'Columns': '列',
 'Common aspect ratio presets': '一般的なアスペクト比プリセット',
 'Compress': '圧縮',
 'Confirm': '確認',
 'Confirm source and target rigs before live retarget or bake.': 'ライブリターゲットやベイクの前にソースとターゲットを確認してください。',
 'Convert': '変換',
 'Convert animation to a stepped stop-motion look by thinning keys, forcing constant interpolation, and optionally adding jitter noise.': 'キーの間引き、コンスタント補間化、任意のジッターノイズ付与により、アニメーションをストップモーション風に変換するツールです。',
 'Convert dense baked curves into a sparser editable result by removing in-betweens that stay within the unbake tolerance. Extremes can be preserved so the result remains animator-friendly.': '高密度にベイクされたカーブを、アンベイク許容値内の中間キーを削除して、編集しやすい疎な状態へ変換します。極値を保持できるため、アニメーターが扱いやすい結果を残せます。',
 'Convert the current action into real held step keys on the chosen frame interval. When keyframes are selected, their first and last frames define the conversion span automatically.': '現在のアクションを、指定したコマ間隔の実ステップキーへ変換します。キーフレームが選択されている場合は、その最初と最後のフレームを変換範囲として自動使用します。',
 'Converter': '変換ツール',
 'Copy or paste the active world transform for hand-offs and space matching.': '受け渡しやスペース合わせのためにワールド変形をコピーまたは貼り付けます。',
 "Copy the active object's or active pose bone's world-space transform. This is useful when you want to snap another control to the same placement later without guessing offsets.": 'アクティブオブジェクト、またはアクティブポーズボーンのワールド変形をコピーします。あとで別のコントロールを同じ位置にスナップしたいときに、オフセットを推測せず使えます。',
 'Coverage (%)': 'カバレッジ (%)',
 'Create Action': 'アクション作成',
 'Create a compact camera-shot marker sequence from the selected cameras, or the scene camera when nothing else is selected. This gives Blender a practical Camera Animator / shot-board style setup without hand-placing every cut marker.': '選択カメラ、または未選択時はシーンカメラから、コンパクトなカメラショット用マーカー列を作成します。すべてのカットマーカーを手で置かなくても、Blender '
                                                                                                                                                                                                                                              'で実用的な '
                                                                                                                                                                                                                                              'Camera '
                                                                                                                                                                                                                                              'Animator '
                                                                                                                                                                                                                                              '/ '
                                                                                                                                                                                                                                              'ショットボード風セットアップを作れます。',
 'Create a compact reveal animation by offsetting selected objects from an axis and keying them back into place with per-object stagger. This is a Blender-friendly transform-board helper inspired by batch motion tools used in motion graphics and previs workflows.': '選択オブジェクトを指定軸方向へオフセットした状態から、段差付きで元位置へ戻すコンパクトなリビールアニメーションを作成します。モーショングラフィックスやプリビズで使われる一括モーション系ツールを、Blender '
                                                                                                                                                                                                                                                                          'で扱いやすく寄せた '
                                                                                                                                                                                                                                                                          'Transform '
                                                                                                                                                                                                                                                                          'ボード補助です。',
 'Create a fresh empty action and assign it to the active object.': '新しい空のアクションを作成し、アクティブオブジェクトへ割り当てます。',
 'Create a modifier-based reveal on the selected mesh objects. Build mode gives a compact Transform-style reveal, Roll mode adds a scroll or rolled-sheet reveal using editable Bend keys, and Unfold mode adds a lighter bend-based opening pass for cards and panels.': '選択メッシュオブジェクトへモディファイアベースのリビールを作成します。Build '
                                                                                                                                                                                                                                                                          'モードは '
                                                                                                                                                                                                                                                                          'Transform '
                                                                                                                                                                                                                                                                          '系のコンパクトなリビール、Roll '
                                                                                                                                                                                                                                                                          'モードは編集可能な '
                                                                                                                                                                                                                                                                          'Bend '
                                                                                                                                                                                                                                                                          'キーで巻物やロール状のリビール、Unfold '
                                                                                                                                                                                                                                                                          'モードはカードやパネル向けの軽量な折り開き風リビールを作ります。',
 'Create a new NLA strip on the active object from the highlighted motion library action.': 'ハイライト中のモーションライブラリアクションから、アクティブオブジェクトに新しい '
                                                                                            'NLA ストリップを作成します。',
 'Create a new NLA track and convert the active action into a strip on that track, then clear the active action slot.': '新しい '
                                                                                                                        'NLA '
                                                                                                                        'トラックを作成し、アクティブアクションをそのトラック上のストリップへ変換した後、アクティブアクションスロットを空にします。',
 'Create a predicted ballistic arc from the current object or active pose bone using the current scene gravity and initial motion. This is useful for jump and throw checks inspired by Cascadeur-style trajectory tools.': '現在のオブジェクトまたはアクティブポーズボーンの初速とシーン重力を使って、予測弾道アークを作成します。Cascadeur '
                                                                                                                                                                                                                            '風のジャンプや投擲の軌道確認に便利です。',
 'Create live copy-transform constraints on the target rig from the current bone map so you can preview retargeting before baking.': '現在のボーン対応表を使ってターゲットリグにライブの '
                                                                                                                                     'Copy '
                                                                                                                                     'Transforms '
                                                                                                                                     '拘束を作成し、ベイク前にリターゲット結果をプレビューできるようにします。',
 'Create modifier-based Build, Roll, or Unfold reveals for mesh objects. This gives Blender a compact answer to Transform, Scroll Roll, and lighter Unfolder style reveal workflows without building a heavy rig.': 'メッシュオブジェクトへ '
                                                                                                                                                                                                                    'Build、Roll、または '
                                                                                                                                                                                                                    'Unfold '
                                                                                                                                                                                                                    'のモディファイアリビールを作成します。重い専用リグを作らず、Transform '
                                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                                    'Scroll '
                                                                                                                                                                                                                    'Roll '
                                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                                    '軽量な '
                                                                                                                                                                                                                    'Unfolder '
                                                                                                                                                                                                                    '系リビールワークフローへコンパクトに対応できます。',
 'Create or reuse a timeline marker on the current frame and bind a camera to it. This gives you a compact camera-cut workflow inspired by camera animator and story tools.': '現在フレームにタイムラインマーカーを作成または再利用し、カメラをバインドします。Camera '
                                                                                                                                                                              'Animator '
                                                                                                                                                                              'や '
                                                                                                                                                                              'Story '
                                                                                                                                                                              'Tool '
                                                                                                                                                                              'に近い、コンパクトなカメラカット作業を行えます。',
 'Create or switch a Child Of-based dynamic parent while preserving the current transform. In Pose Mode, the active bone becomes the child and another selected bone becomes the parent target.': '今の変形を保ったまま、チャイルドオブによる動的な親を作成または切り替えます。ポーズモードでは、アクティブなボーンが子に、もう 1 つの選択ボーンが親になります。',
 'Create or update a key on the current frame by blending between the previous and next keys. Values outside 0 to 1 create anticipation and overshoot like advanced tween tools.': '前後のキーをブレンドして、現在フレームにキーを作成または更新します。0 '
                                                                                                                                                                                   'から '
                                                                                                                                                                                   '1 '
                                                                                                                                                                                   'の範囲外を使うと、高度なトゥイーンツールのように予備動作やオーバーシュートを作れます。',
 'Create timeline markers on the frames of selected keyframes. This is useful for contact beats, lip-sync notes, camera cuts, or review checkpoints.': '選択中キーフレームのフレーム位置にタイムラインマーカーを作成します。接地タイミング、リップシンクのメモ、カメラカット、レビュー用チェックポイント作成に便利です。',
 'Create viewport ghost objects on past and future frames for the current selection. This gives a BH Ghost / Ghostool style silhouette and spacing preview without altering the source animation.': '現在の選択に対して、過去と未来フレームにビューポート用ゴーストオブジェクトを生成します。元のアニメーションを壊さずに、BH '
                                                                                                                                                                                                    'Ghost '
                                                                                                                                                                                                    '/ '
                                                                                                                                                                                                    'Ghostool '
                                                                                                                                                                                                    '風のシルエットとスペーシング確認を行えます。',
 'Created a dual review layout with a camera view and a free view.': 'カメラビューと自由ビューの 2 画面レビューを作成しました。',
 'Current Findings': '現在の検出結果',
 'Curve Simplify': 'カーブ簡略化',
 'Data I/O Hub': 'データ入出力ハブ',
 'Decay': '減衰',
 'Defaults': 'デフォルト',
 'Degree': '次数',
 'Degree of new curve': '新しいカーブの次数',
 'Delay': '遅延',
 'Delete F-Curves whose key values stay flat inside the threshold. This is useful to clean imported animation that contains unnecessary channels.': 'キー値がしきい値内で変化しない '
                                                                                                                                                    'F '
                                                                                                                                                    'カーブを削除します。不要なチャンネルを多く含む読み込みアニメーションの整理に便利です。',
 'Delete Smart Animation ballistic guide curves from the file.': 'Smart Animation '
                                                                       'が生成した弾道ガイドカーブをファイルから削除します。',
 'Delete Smart Animation ghost preview objects from the file.': 'Smart Animation '
                                                                      'が生成したゴーストプレビューオブジェクトをファイルから削除します。',
 'Delete Smart Animation trail-curve objects from the file.': 'Smart Animation '
                                                                    'が生成したトレイルカーブオブジェクトをファイルから削除します。',
 'Delete the currently highlighted pose snapshot from the list.': '現在ハイライトされているポーズスナップショットを一覧から削除します。',
 'Depth': '深さ',
 'Description': '説明',
 'Detect low-motion spans across the current timing range and convert them into planted holds. This is a practical Fulcrum / foot-slide cleanup helper for translation curves when you want contacts to stay locked without manually setting every hold range.': '現在のタイミング範囲内で低移動スパンを検出し、接地ホールドへ変換します。毎回手動で保持範囲を設定しなくても、平行移動カーブのコンタクトをロックしやすくする、実用的な '
                                                                                                                                                                                                                                                                 'Fulcrum '
                                                                                                                                                                                                                                                                 '/ '
                                                                                                                                                                                                                                                                 '足滑りクリーンアップ補助です。',
 'Dilate': '拡張',
 'Direction to push the markers': 'マーカーを押し出す方向',
 'Disable the scene preview range and return playback to the full scene frame range.': 'シーンのプレビュー範囲を無効化し、再生範囲をシーン全体へ戻します。',
 'Disabled': '無効',
 'Display an overlay editor for selected keyframe handles so you can adjust Bezier easing directly with an on-screen curve widget.': '選択キーフレームのハンドルをオーバーレイ上で直接編集し、ベジェ補間のイージング形状を視覚的に調整できるツールです。',
 'Do Nothing': '何もしない',
 'Do not set any tools': 'ツールを設定しません',
 'Down': '下へ',
 'Draw': '描画',
 'Drawings': '描画',
 'Duplicate': '複製',
 'Duplicate the active action and assign the copy to the active object. Useful for safe non-destructive editing.': 'アクティブアクションを複製し、そのコピーをアクティブオブジェクトへ割り当てます。安全な非破壊編集に便利です。',
 'Duration': '時間',
 'Dynamic parent switched and keyed the preserved transform.': '動的親を切り替え、保持した変形をキー化しました。',
 'Dynamic parent switched.': '動的親を切り替えました。',
 'Easy Out': 'イージーアウト',
 'Edges': '辺',
 'Edit': '編集',
 'Enable Sakura PoseLib timer/msgbus maintenance for linked armature proxy upkeep, action maintenance, and bone-rename tracking.': 'Sakura '
                                                                                                                                   'PoseLib '
                                                                                                                                   'のタイマー '
                                                                                                                                   '/ '
                                                                                                                                   'msgbus '
                                                                                                                                   '保守を有効化し、リンクアーマチュア用プロキシ維持、アクション保守、ボーン名変更追跡を行います。',
 'Enable Storytools background msgbus/timer callbacks that keep Grease Pencil layer and material sync updated while you work.': 'Storytools '
                                                                                                                                'のバックグラウンド '
                                                                                                                                'msgbus '
                                                                                                                                '/ '
                                                                                                                                'タイマー処理を有効化し、Grease '
                                                                                                                                'Pencil '
                                                                                                                                'のレイヤーとマテリアルの同期を作業中も自動更新します。',
 'Enable at least one root-motion axis.': '少なくとも 1 つのルートモーション軸を有効にしてください。',
 'Enable the Storytools camera-change watcher so object and collection exclusion visibility updates automatically when the active camera changes.': 'Storytools '
                                                                                                                                                    'のカメラ変更監視を有効化し、アクティブカメラ切替時にオブジェクト '
                                                                                                                                                    '/ '
                                                                                                                                                    'コレクション除外表示を自動更新します。',
 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting is saved immediately and remains after Blender restarts and scene changes.': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は即時保存され、Blender '
                                                                                                                                                                                                                                                                            '再起動後やシーン切り替え後も維持されます。',
 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The setting is saved immediately and remains after Blender restarts and scene changes.': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo '
                                                                                                                                                                                                                                                                                                                      '/ '
                                                                                                                                                                                                                                                                                                                      'Redo、レンダー関連イベントなどで '
                                                                                                                                                                                                                                                                                                                      'Blender '
                                                                                                                                                                                                                                                                                                                      'が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。設定は即時保存され、Blender '
                                                                                                                                                                                                                                                                                                                      '再起動後やシーン切り替え後も維持されます。',
 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. The setting is saved immediately and remains after Blender restarts and scene changes.': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。設定は即時保存され、Blender '
                                                                                                                                                                                                                              '再起動後やシーン切り替え後も維持されます。',
 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The setting is saved immediately and remains after Blender restarts and scene changes.': 'Blender '
                                                                                                                                                                                                                                                                                        'データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する '
                                                                                                                                                                                                                                                                                        'msgbus '
                                                                                                                                                                                                                                                                                        '購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。設定は即時保存され、Blender '
                                                                                                                                                                                                                                                                                        '再起動後やシーン切り替え後も維持されます。',
 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting is saved immediately and remains after Blender restarts and scene changes.': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は即時保存され、Blender '
                                                                                                                                                                                                                                                                      '再起動後やシーン切り替え後も維持されます。',
 'End': '終了',
 'Enter the supported edit mode, enable the element channels you want, edit the data, then insert or delete keys from the migrated AnimAll panel or operators.': '対応する編集モードに入り、記録したい要素チャンネルを有効にしてデータを編集し、移植済み '
                                                                                                                                                                 'AnimAll '
                                                                                                                                                                 'パネルまたはオペレーターからキーの挿入・削除を行ってください。',
 'Error': 'エラー',
 'Evenly redistribute selected keyframes between the outermost keys. If no keys are selected, use the current Timing range. This is useful for blocking passes, stepped timing cleanup, and restoring consistent spacing after rough edits.': '外側のキーを固定したまま、選択キーフレームを等間隔に再配置します。キー選択がない場合は現在のタイミング範囲を使います。ブロッキング、段階補間の整理、荒い編集後の均一な間隔の復元に便利です。',
 'Excluded Collections:': '除外コレクション:',
 'Export JSON': 'JSON 書き出し',
 'Export the current motion library list as JSON into Blender text data and copy it to the clipboard.': '現在のモーションライブラリ一覧を '
                                                                                                        'JSON として '
                                                                                                        'Blender '
                                                                                                        'テキストデータへ出力し、クリップボードにもコピーします。',
 'Faces': '面',
 'Factor': '係数',
 'Feature setting saved.': '機能設定を保存しました。',
 'Figure': '図形',
 'Filepath': 'ファイルパス',
 'Fill': '塗りつぶし',
 'Film Transparent': 'フィルムを透明化',
 'Filtered': 'フィルター済み',
 'Filters': 'フィルター',
 'Flatten selected or targeted curves to the current-frame value across a frame range. This is useful for planted feet, hand contacts, held props, and fulcrum-style cleanup.': '選択または対象カーブを、指定範囲で現在フレームの値へ平坦化します。接地した足、手の接触、保持中の小物、Fulcrum '
                                                                                                                                                                                '風の整理に便利です。',
 'Focal': '焦点',
 'Focal Length': '焦点距離',
 'Footer Locations:': 'フッター位置:',
 'For internal use only': '内部使用専用',
 'Front (X-Z)': '正面 (X-Z)',
 'Future': '未来',
 'GP control bar behavior:': 'GP制御バーの動作:',
 'Gap': '間隔',
 'Generate editable delta-transform keys from a compact procedural signal. This acts like a Blender-friendly superset of Signal-style loop, noise, pulse, and stop-motion helpers while safely skipping objects that already use non-SAS animation on the chosen delta channel.': 'コンパクトなプロシージャル信号から、編集可能な '
                                                                                                                                                                                                                                                                                  'delta '
                                                                                                                                                                                                                                                                                  '変換キーを生成します。Signal '
                                                                                                                                                                                                                                                                                  '系のループ、ノイズ、パルス、ストップモーション補助を '
                                                                                                                                                                                                                                                                                  'Blender '
                                                                                                                                                                                                                                                                                  '向けにまとめた実務寄り上位機能で、選択した '
                                                                                                                                                                                                                                                                                  'delta '
                                                                                                                                                                                                                                                                                  'チャンネルに非 '
                                                                                                                                                                                                                                                                                  'SAS '
                                                                                                                                                                                                                                                                                  'アニメーションがあるオブジェクトは安全のため自動的にスキップします。',
 'Generate editable loop, noise, pulse, or stop-motion style delta-transform keys from a compact procedural signal. This is the practical Blender answer to Signal-style motion rules, delay chains, and quick non-destructive iteration.': 'コンパクトなプロシージャル信号から、ループ、ノイズ、パルス、ストップモーション風の '
                                                                                                                                                                                                                                            'delta '
                                                                                                                                                                                                                                            '変換キーを生成します。Signal '
                                                                                                                                                                                                                                            '系のモーションルール、ディレイ連鎖、高速な非破壊イテレーションへの '
                                                                                                                                                                                                                                            'Blender '
                                                                                                                                                                                                                                            '実務解です。',
 'Generated': '生成済み',
 'Generic controls for custom properties registered by this tool.': 'このツールが登録したカスタムプロパティの汎用操作 UI です。',
 'Ghost preview has no past or future frames configured.': 'ゴーストプレビューの過去・未来フレーム数が 0 に設定されています。',
 'H1 X': 'H1 X',
 'H1 Y': 'H1 Y',
 'H2 X': 'H2 X',
 'H2 Y': 'H2 Y',
 'Hold pose for N frames': 'Nフレーム分ポーズを保持',
 'Hotkeys': 'ホットキー',
 'How to use': '使い方',
 'Human Female': '女性人体',
 'Human Male': '男性人体',
 'Icon': 'アイコン',
 'Icon to display in interface': '画面に表示するアイコン',
 'Imperfection:': '不完全さ:',
 'In Front': '前面表示',
 'In Front State': '前面表示状態',
 'Include Notes Space': 'メモ欄を含める',
 'Include Page Footer': 'ページフッターを含める',
 'Info Note': '情報メモ',
 'Inline Help': 'インラインヘルプ',
 'Insert': '挿入',
 'Insert location keys on selected bones in Pose Mode or selected objects in Object Mode.': 'ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトに位置キーを打ちます。',
 'Insert location, rotation, and scale keys on the current frame for the current selection.': '現在の選択に対して、現在フレームへ位置・回転・スケールのキーを打ちます。',
 'Insert new panel': '新しいパネルを挿入します',
 'Insert rotation keys on selected bones in Pose Mode or selected objects in Object Mode.': 'ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトに回転キーを打ちます。',
 'Insert scale keys on selected bones in Pose Mode or selected objects in Object Mode.': 'ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトにスケールキーを打ちます。',
 'Insert visual keys so constrained motion is baked as the current visible transform on the current frame.': 'コンストレイント結果を含む見た目どおりの変形を、現在フレームへビジュアルキーとして記録します。',
 'Inspect the active scene for common animation workflow issues and write the findings into the activity log.': 'アクティブシーンにある一般的なアニメーション作業上の問題を点検し、結果をアクティビティログへ記録します。',
 'Inspect the current context and switch the Task to the most relevant one without changing your animation data.': '現在の状況を確認し、アニメーションデータを変更せずに最も関連性の高いタスクへ切り替えます。',
 'Integrated tools are always active while this toolset add-on is active.': 'このツールセットアドオンが有効な間、統合ツールは常に有効です。',
 'Integrated tools are loaded automatically while this toolset add-on is active. Runtime switching controls have been removed.': 'このツールセットアドオンが有効な間、統合ツールは自動で読み込まれます。ツール単位の切替操作はありません。',
 'Invalid Collection': '無効なコレクション',
 'Invalid image path': '無効な画像パス',
 'Invalid pose index': 'ポーズの番号が正しくありません',
 'Jump to the next camera-bound marker and activate its camera.': '次のカメラ付きマーカーへ移動し、そのカメラを有効化します。',
 'Jump to the previous camera-bound marker and activate its camera.': '前のカメラ付きマーカーへ移動し、そのカメラを有効化します。',
 'Keep Previous': '以前を保持',
 'Keep Z Up': 'Z上方向を維持',
 'Keep short splines': '短いスプラインを保持',
 'Keymap item not found': 'キーマップの項目が見つかりません',
 'Lay out every stored motion-library action as sequential NLA clips on the active object. This is a compact Story / Motion Mixer style assembler for quickly blocking a longer shot from reusable motion clips.': '保存済みモーションライブラリアクションを、アクティブオブジェクト上で順番に '
                                                                                                                                                                                                                   'NLA '
                                                                                                                                                                                                                   'クリップ化します。再利用モーションから長めのショットを素早く組み立てるための、コンパクトな '
                                                                                                                                                                                                                   'Story '
                                                                                                                                                                                                                   '/ '
                                                                                                                                                                                                                   'Motion '
                                                                                                                                                                                                                   'Mixer '
                                                                                                                                                                                                                   '風アセンブラです。',
 'Layer / Material Auto Sync Callbacks': 'レイヤー / マテリアル自動同期コールバック',
 'Left': '左',
 'Left Text': '左テキスト',
 'Left To Right': '左から右',
 'Left footer text': '左のフッター文字',
 'Left header text': '左のヘッダー文字',
 'Library Sequence': 'ライブラリシーケンス',
 'Library manifest JSON could not be parsed.': 'ライブラリ一覧 JSON を解析できませんでした。',
 'Library manifest text was not found.': 'ライブラリ一覧用テキストが見つかりません。',
 'Limit to Keying Set': 'キーイングセットに限定',
 'Line Thickness': '線の太さ',
 'Linked': 'リンク',
 'Live retarget preview did not complete.': 'ライブリターゲットプレビューは完了しませんでした。',
 'Live retarget refresh did not complete.': 'ライブリターゲット更新は完了しませんでした。',
 'Load failed': '読み込み失敗',
 'Loaded': '読み込み済み',
 'Loaded base Palette': '基本のパレットを読み込みました',
 'Lock Camera': 'カメラ固定',
 'Locked Pan': 'パンをロック',
 'Make the new camera active': '新しいカメラをアクティブにします',
 'Manage reusable armature pose books, pose sliders, conversion utilities, and pose maintenance helpers for character animation workflows.': 'アーマチュア用の再利用ポーズ集、スライダー制御、変換補助、保守機能をまとめたキャラクター向けポーズライブラリツールです。',
 'Manual Radius': '手動半径',
 'Mapping Preview': '対応プレビュー',
 'Maximum allowed distance error': '許容最大距離誤差',
 'Menus': 'メニュー',
 'Migrated Panels': '移植済みパネル',
 'Min': '最小',
 'Min Hold': '最小保持',
 "Mirror the selected pose using Blender's flipped pose copy/paste. Best results use standard side names like .L and .R.": 'Blender '
                                                                                                                           'の反転コピーペーストを使って選択ポーズをミラーします。.L '
                                                                                                                           '/ '
                                                                                                                           '.R '
                                                                                                                           'などの標準的な左右命名で最もよく機能します。',
 'Mirrored pose.': 'ポーズをミラーしました。',
 'Missing exclusion properties': '除外プロパティが見つかりません',
 'Motion Library': 'モーションライブラリ',
 'Motion library manifest exported to Blender text data and clipboard.': 'モーションライブラリ一覧を Blender '
                                                                         'テキストデータとクリップボードへ書き出しました。',
 'Motion paths calculated.': 'モーションパスを計算しました。',
 'Motion paths cleared.': 'モーションパスをクリアしました。',
 'Move, rotate, or scale animated objects while applying the same transform offset to their existing location, rotation, or scale keyframes.': 'アニメーション済みオブジェクトを移動・回転・拡縮しつつ、その差分を既存の位置・回転・スケールキーへまとめて反映するツールです。',
 'Moving Hold': 'ムービングホールド',
 'Multiple Data Users:': '複数データユーザー:',
 'Multiple Users State': '複数ユーザー状態',
 'Need to enter draw mode once': '一度ドローモードに入る必要があります',
 'New Name': '新規名',
 'No Euler rotation curves were found.': 'オイラー回転カーブが見つかりません。',
 'No F-Curves are available for push / pull.': 'プッシュ / プルに使える F カーブがありません。',
 'No F-Curves are available for scale-to-neighbors.': '隣のキーへのスケールに使える F カーブがありません。',
 'No F-Curves are available for tweening.': 'トゥイーンに使える F カーブがありません。',
 'No F-Curves are available.': '対象の F カーブがありません。',
 'No F-Curves to inspect.': '確認する F カーブがありません。',
 'No F-Curves to retime.': 'タイミング変更する F カーブがありません。',
 'No F-Curves to simplify.': '簡略化する F カーブがありません。',
 'No NLA clips could be created from the motion library.': 'モーションライブラリから NLA クリップを作成できませんでした。',
 'No RNA properties available.': 'RNA プロパティを取得できません。',
 'No Sync': '同期なし',
 'No actions found': 'Action が見つかりません',
 'No active action is available to turn into a layer.': 'レイヤー化するアクティブアクションがありません。',
 'No active action to clean.': '整理するアクティブアクションがありません。',
 'No active action to convert.': '変換するアクティブアクションがありません。',
 'No active action to duplicate.': '複製するアクティブアクションがありません。',
 'No active action to process.': '処理するアクティブアクションがありません。',
 'No active action to push.': 'プッシュするアクティブアクションがありません。',
 'No active action to store.': '保存するアクティブアクションがありません。',
 'No active action.': 'アクティブなアクションがありません。',
 'No active camera': 'アクティブカメラなし',
 'No active camera in scene': 'シーンにアクティブカメラがありません',
 'No active material': 'アクティブマテリアルなし',
 'No active object': 'アクティブオブジェクトがありません',
 'No active object or pose bone to copy.': 'コピー対象のアクティブオブジェクトまたはポーズボーンがありません。',
 'No active object or pose bone to paste onto.': '貼り付け先のアクティブオブジェクトまたはポーズボーンがありません。',
 'No active object.': 'アクティブオブジェクトがありません。',
 'No active pose bone.': 'アクティブなポーズボーンがありません。',
 'No active pose to duplicate': '複製するアクティブなポーズがありません',
 'No N-panel runtime property item was available.': '利用可能なNパネル実行時プロパティ項目がありません。',
 'No animated Shape Key curves were found.': 'アニメーション済みのシェイプキーカーブが見つかりません。',
 'No animated camera was found.': 'アニメーション付きカメラが見つかりません。',
 'No animation data found': 'アニメーションデータが見つかりません',
 'No area found': 'エリアが見つかりません',
 'No asset hub matched the current search.': '現在の検索に一致するアセットハブはありません。',
 'No ballistic keys were baked. Check the source and range.': '弾道キーはベイクされませんでした。ソースと範囲を確認してください。',
 'No bone map to export.': '書き出すボーン対応表がありません。',
 'No camera is available. Select a camera or set the scene camera first.': '利用できるカメラがありません。カメラを選択するか、シーンカメラを設定してください。',
 'No camera markers were found.': 'カメラマーカーが見つかりません。',
 'No camera object is available.': '利用できるカメラオブジェクトがありません。',
 'No camera was found. Select one or more cameras, or assign a scene camera first.': 'カメラが見つかりません。1 '
                                                                                     'つ以上のカメラを選択するか、先にシーンカメラを設定してください。',
 'No camera-bound markers were found.': 'カメラ付きマーカーが見つかりません。',
 'No change': '変更なし',
 'No compact animation hub matched the current search.': '現在の検索に一致するアニメーションハブはありません。',
 'No constrained bones were found on the target rig.': 'ターゲットリグに制約付きボーンが見つかりませんでした。',
 'No direct operator or menu entry was found.': '直接呼び出せるオペレーターやメニューが見つかりませんでした。',
 'No editable F-Curves were found.': '編集可能な F カーブが見つかりません。',
 'No editable properties detected.': '編集可能なプロパティが見つかりません。',
 'No eligible curves were found. Try selecting location curves or disable Location Only.': '対象カーブが見つかりません。位置カーブを選択するか、Location '
                                                                                           'Only を無効にしてください。',
 'No filepath set for rendering': 'レンダリングの出力先が設定されていません',
 'No library action selected.': 'ライブラリアクションが選択されていません。',
 'No live retarget constraints are active on the target rig.': 'ターゲットリグに有効なライブリターゲット拘束がありません。',
 'No low-motion spans matched the current fulcrum settings.': '現在のフルクラム設定に一致する低移動スパンは見つかりませんでした。',
 'No mapped bones are available for live retargeting.': 'ライブリターゲットに使える対応ボーンがありません。',
 'No markers found.': 'マーカーが見つかりません。',
 'No matching root-motion location curves were found.': '一致するルートモーション位置カーブが見つかりません。',
 'No more markers in that direction.': 'その方向にはこれ以上マーカーがありません。',
 'No object selected': 'オブジェクトが選択されていません',
 'No objects were selected for Motion Signal.': 'Motion Signal の対象オブジェクトが選択されていません。',
 'No objects were selected for motion stretch.': 'モーションストレッチ対象のオブジェクトが選択されていません。',
 'No objects were updated. Check the selection and replace settings.': '更新されたオブジェクトはありませんでした。選択状態と置換設定を確認してください。',
 'No objects were updated. Check the selection and safety filters.': '更新されたオブジェクトはありませんでした。選択状態と安全フィルターを確認してください。',
 'No panel strokes found': 'パネルのストロークが見つかりません',
 'No panels found to offset': 'オフセットするパネルが見つかりません',
 'No pose bones available.': '利用可能なポーズボーンがありません。',
 'No pose snapshots to export.': '書き出すポーズスナップショットがありません。',
 'No pose snapshots were imported.': '読み込めるポーズスナップショットがありませんでした。',
 'No registered runtime properties were detected.': '登録された実行時プロパティは見つかりません。',
 'No selected keyframes were found.': '選択中のキーフレームが見つかりません。',
 'No selected keys were found.': '選択されているキーが見つかりません。',
 'No selected targets or curves are available.': '選択ターゲットまたは対象カーブがありません。',
 'No selection sets are stored yet.': 'まだ選択セットが保存されていません。',
 'No selection sets to export.': '書き出す選択セットがありません。',
 'No selection sets were imported.': '読み込める選択セットがありませんでした。',
 'No shape keys matched the requested mode.': '指定モードに一致するシェイプキーがありません。',
 'No shot markers could be created.': 'ショットマーカーを作成できませんでした。',
 'No snapshot selected.': 'スナップショットが選択されていません。',
 'No sound strips were found in the sequence editor.': 'シーケンスエディターにサウンドストリップが見つかりません。',
 'No suitable objects were found for ghost preview.': 'ゴーストプレビューに使えるオブジェクトが見つかりません。',
 'No target curves are available for contact hold.': 'コンタクト保持に使える対象カーブがありません。',
 'No target curves are available.': '対象カーブがありません。',
 'No title in text area': 'テキストエリアにタイトルなし',
 'No track constraints to remove on camera': 'カメラに外す Track コンストレイントがありません',
 'No transfer hub matched the current search.': '現在の検索に一致する転送ハブはありません。',
 'No valid actions were found in the motion library.': 'モーションライブラリ内に有効なアクションが見つかりません。',
 'No valid ballistic owner was found.': '有効な弾道ベイク対象が見つかりません。',
 'No valid library entries were found.': '有効なライブラリエントリが見つかりませんでした。',
 'No wheel objects were updated. Check the selection and safety filters.': '更新された車輪オブジェクトはありませんでした。選択状態と安全フィルターを確認してください。',
 'Noise Seed': 'ノイズシード',
 'Not enough sampled points were collected for a trail.': 'トレイル生成に必要なサンプル点が足りません。',
 'Not in camera': 'カメラ内ではありません',
 'Notes': 'メモ',
 'Nothing': 'なし',
 'Nothing selected to bake.': 'ベイク対象が選択されていません。',
 'Nothing selected.': '何も選択されていません。',
 'Number of Pages': 'ページ数',
 'Number of columns in the grid': 'グリッドの列数',
 'Number of pages to add': '追加するページ数',
 'Number of rows in the grid': 'グリッドの行数',
 'Object Mode': 'オブジェクトモード',
 'On visible and unlocked layers': '表示中でロックされていないレイヤー',
 'Only Location': '位置のみ',
 'Only on all visible layers': 'すべての表示レイヤーのみ',
 'Open a 3D View area first.': '先に 3D ビュー領域を開いてください。',
 'Open the migrated Bezier Curve Editor panel in the relevant animation editor, select keyframes, then use the overlay controls to reshape easing and handle behavior.': '対応するアニメーションエディターで移植済み '
                                                                                                                                                                         'Bezier '
                                                                                                                                                                         'Curve '
                                                                                                                                                                         'Editor '
                                                                                                                                                                         'パネルを開き、キーフレームを選択してオーバーレイ操作でイージングやハンドル挙動を調整してください。',
 'Open the migrated Storytools panels or menus inside the Overview Task N-panel section and use the sub-tools that match your storyboard task, such as camera setup, layer sync, map placement, or shot organization.': 'Smart '
                                                                                                                                                                                                  'Tools '
                                                                                                                                                                                                  '内の移植済み '
                                                                                                                                                                                                  'Storytools '
                                                                                                                                                                                                  'パネルやメニューを開き、カメラ設定、レイヤー同期、マップ配置、ショット整理など、目的に合うサブツールを使用してください。',
 'Operation': '操作',
 'Operation log cleared.': '操作ログをクリアしました。',
 'Operation mode': '操作モード',
 'Operators': 'オペレーター',
 'Optimize animated Shape Key curves on the active object by removing duplicates, deleting static channels, and simplifying dense in-betweens.': 'アクティブオブジェクトのアニメーション済みシェイプキーカーブを最適化します。重複キー削除、静的チャンネル削除、密な中間キーの簡略化をまとめて行います。',
 'Order': '順序',
 'Original panel has no draw function.': '元パネルに draw 関数がありません。',
 'Others': 'その他',
 'Output': '出力',
 'Output splines': '出力スプライン',
 'Page Spacing': 'ページの間隔',
 'Page: XX (Pagination)': 'ページ：XX（ページ番号）',
 'Pages': 'ページ',
 'Palette': 'パレット',
 'Past': '過去',
 'Paste the stored world-space transform onto the active object or active pose bone. When Blender Auto Key is enabled, the snapped result is keyed on the current frame.': '保存したワールド変形を、アクティブオブジェクトまたはアクティブポーズボーンへ貼り付けます。Blender '
                                                                                                                                                                           'の自動キーが有効なら、スナップ結果を現在フレームにキー化します。',
 'Per Object': '個別位相',
 'Phase': '位相',
 'Pick a hub inside each tab, choose a task, then run it. The original toolset is restored, but grouped into fewer hubs.': '各タブ内のハブを選び、タスクを決めて実行します。元の機能は戻しつつ、ハブ単位で整理しています。',
 'Playback preset could not change any settings in this context.': 'この環境では再生プリセットが変更できる設定を見つけられませんでした。',
 'Pointer target is not available.': 'ポインター先がありません。',
 'Points': '点',
 'Portrait 9:16 (0.563)': '縦長 9:16 (0.563)',
 'Pose Library Background Maintenance': 'ポーズライブラリのバックグラウンド保守',
 'Pose Quick Palette': 'ポーズクイックパレット',
 'Pose snapshot JSON could not be parsed.': 'ポーズスナップショット JSON を解析できませんでした。',
 'Pose snapshot text was not found.': 'ポーズスナップショット用テキストが見つかりません。',
 'Pose snapshots exported to Blender text data and clipboard.': 'ポーズスナップショットを Blender テキストデータとクリップボードへ書き出しました。',
 'PoseBook not found': 'ポーズブックが見つかりません',
 'Position:': '位置:',
 'Predefined canvas sizes': '定義済みキャンバスサイズ',
 'Preset': 'プリセット',
 'Preview range disabled.': 'プレビュー範囲を無効化しました。',
 'Profile JSON could not be parsed.': 'プロファイル JSON を解析できませんでした。',
 'Profile JSON does not contain an items list.': 'プロファイル JSON に items リストがありません。',
 'Profile text was not found.': 'プロファイル用テキストが見つかりません。',
 'Progressively offset selected targets in time. This is useful for overlap, follow-through, chain motion, and staggered mechanical timing.': '選択ターゲットを段階的に時間オフセットします。オーバーラップ、フォロースルー、チェーンモーション、機械系の段差タイミングに便利です。',
 'Provide storyboard-oriented Grease Pencil, camera, object, map, and setup tools for rapid shot planning and previs workflows.': 'Grease '
                                                                                                                                  'Pencil、カメラ、オブジェクト、マップ、初期設定をまとめ、ショット設計やプリビズを素早く進めるためのストーリーボード支援ツール群です。',
 'Prune': '整理',
 'Prune removes missing entries from the current motion library.': '現在のモーションライブラリから欠損項目を整理します。',
 'Push / Pull needs a keyed frame with keys on both sides.': 'プッシュ / プルには、現在フレームのキーと前後両側のキーが必要です。',
 'Push Action': 'アクションをプッシュ',
 'Push NLA': 'NLA追加',
 'Push markers to the left': 'マーカーを左へ押し出します',
 'Push markers to the right': 'マーカーを右へ押し出します',
 'Push or pull the current-frame key away from, or back toward, the straight interpolation between its neighbors. This is a compact animBot-style spacing control for polish work.': '現在フレームのキーを、前後キーの直線補間から遠ざけたり近づけたりします。詰め作業に使える、コンパクトな '
                                                                                                                                                                                     'animBot '
                                                                                                                                                                                     '風スペーシング調整です。',
 'Push the current action into NLA as a protected base layer and create a fresh editable action on top. This is a Blender-native approximation of animation-layer workflows from Maya and MotionBuilder.': '現在のアクションを保護用のベースレイヤーとして '
                                                                                                                                                                                                           'NLA '
                                                                                                                                                                                                           'へ退避し、その上に新しい編集用アクションを作成します。Maya '
                                                                                                                                                                                                           'や '
                                                                                                                                                                                                           'MotionBuilder '
                                                                                                                                                                                                           'のアニメーションレイヤー作業を '
                                                                                                                                                                                                           'Blender '
                                                                                                                                                                                                           'ネイティブで近似します。',
 'Push the current editable action into NLA using the chosen blend mode, then create a new empty action above it. Use this to keep stacking offset or additive passes without destroying lower motion.': '現在の編集用アクションを選択中のブレンド方式で '
                                                                                                                                                                                                         'NLA '
                                                                                                                                                                                                         'へ送った後、その上に新しい空アクションを作成します。下層モーションを壊さず、オフセットや加算のパスを重ねていく用途に使います。',
 'Quick Access': 'クイックアクセス',
 'Quick Library': 'クイックライブラリ',
 'Quick Picker': 'クイックピッカー',
 'RNA Message Bus Watchers': 'RNAメッセージバス監視',
 'Randomly offset each selected or active F-Curve within the configured frame limits. This is useful for crowds, props, and mechanical systems that should not move in perfect sync.': '選択または対象の各 '
                                                                                                                                                                                       'F '
                                                                                                                                                                                       'カーブを、設定範囲内でランダムに時間オフセットします。群衆、小物、機械系が完全同期しすぎないようにしたい場合に便利です。',
 'Range': '範囲',
 'Range from Keys': 'キーから範囲',
 'Ratio': '比率',
 'Read Direction': '読み方向',
 'Ready (Not Loaded)': '使用時に読み込み',
 'Rebuild the live retarget preview using the current bone map, influence, and space settings. This is useful after changing mappings without having to clear and reapply manually.': '現在のボーン対応、影響度、空間設定でライブリターゲットプレビューを再構築します。マップ変更後に、手動で解除して再適用し直す手間を減らせます。',
 'Rebuild the name-based bone map from the current source and target rigs, then apply a live Copy Transforms preview. Use this when rigs changed and you want a fresh preview in one click.': '現在のソースリグとターゲットリグから名前ベースのボーン対応を再作成し、その後でライブ '
                                                                                                                                                                                              'Copy '
                                                                                                                                                                                              'Transforms '
                                                                                                                                                                                              'プレビューを適用します。リグが変わった後に、1クリックで新しいプレビューを作りたい時に使います。',
 'Recent Operation Log': '最近の操作ログ',
 'Recommended Next Step': 'おすすめの次操作',
 'Reduce point counts in curve objects and selected animation F-Curves with distance-based or curvature-based simplification.': '距離基準または曲率基準の簡略化で、カーブオブジェクトや選択 '
                                                                                                                                'F-Curve '
                                                                                                                                'の点数を削減する軽量化ツールです。',
 'Register the current active action in the internal motion library list so it can be reassigned or pushed to NLA later.': '現在のアクティブアクションを内部モーションライブラリ一覧へ登録し、後で再割り当てや '
                                                                                                                           'NLA '
                                                                                                                           '追加に使えるようにします。',
 'Remove 360-degree Euler flips by re-wrapping rotation-euler key values to the nearest continuous angle. This is useful after mocap import, retargeting, or aggressive pose edits.': '360 '
                                                                                                                                                                                      '度回転の飛びを抑えるため、rotation_euler '
                                                                                                                                                                                      'のキー値を最も連続的になる角度へ再ラップします。モーキャプ読み込み後、リターゲット後、大きなポーズ編集後に便利です。',
 'Remove Smart Animation Motion Signal curves from the selected objects and restore the stored delta-transform base value. Only SAS-generated delta animation is removed, so unrelated animation stays untouched.': '選択オブジェクトから '
                                                                                                                                                                                                                          'Smart '
                                                                                                                                                                                                                          'Animation '
                                                                                                                                                                                                                          'Toolset '
                                                                                                                                                                                                                          'の '
                                                                                                                                                                                                                          'Motion '
                                                                                                                                                                                                                          'Signal '
                                                                                                                                                                                                                          'カーブを削除し、保存していた '
                                                                                                                                                                                                                          'delta '
                                                                                                                                                                                                                          '変換の基準値を復元します。削除するのは '
                                                                                                                                                                                                                          'SAS '
                                                                                                                                                                                                                          'が生成した '
                                                                                                                                                                                                                          'delta '
                                                                                                                                                                                                                          'アニメーションだけなので、無関係なアニメーションはそのまま残ります。',
 'Remove Smart Animation dynamic-parent constraints from the active object or active pose bone.': 'アクティブオブジェクトまたはアクティブポーズボーンから '
                                                                                                        'Smart '
                                                                                                        'Animation '
                                                                                                        'Toolset '
                                                                                                        'の動的親制約を削除します。',
 'Remove Smart Animation live retarget constraints from the target rig without touching other user constraints.': 'Smart '
                                                                                                                        'Animation '
                                                                                                                        'Toolset '
                                                                                                                        'のライブリターゲット拘束だけをターゲットリグから削除し、他のユーザー拘束には触れません。',
 'Remove Smart Animation loop modifiers from the selected or active curves.': '選択または対象 F カーブから Smart Animation '
                                                                                    'Toolset のループモディファイアを削除します。',
 'Remove Smart Animation modifier-based reveal helpers from the selected mesh objects, including SAS Build or Roll modifiers and their helper empties.': '選択メッシュオブジェクトから '
                                                                                                                                                               'Smart '
                                                                                                                                                               'Animation '
                                                                                                                                                               'Toolset '
                                                                                                                                                               'のモディファイアベース・リビール補助を削除します。SAS '
                                                                                                                                                               'Build '
                                                                                                                                                               '/ '
                                                                                                                                                               'Roll '
                                                                                                                                                               'モディファイアと補助 '
                                                                                                                                                               'Empty '
                                                                                                                                                               'をまとめて除去します。',
 'Remove Smart Animation motion-stretch curves from the selected objects and restore each stored delta-scale base value. Only SAS-generated delta-scale keys are cleared, so unrelated animation stays untouched.': '選択オブジェクトから '
                                                                                                                                                                                                                          'Smart '
                                                                                                                                                                                                                          'Animation '
                                                                                                                                                                                                                          'Toolset '
                                                                                                                                                                                                                          'のモーションストレッチカーブを削除し、保存していた '
                                                                                                                                                                                                                          'delta '
                                                                                                                                                                                                                          'scale '
                                                                                                                                                                                                                          'の基準値を復元します。削除するのは '
                                                                                                                                                                                                                          'SAS '
                                                                                                                                                                                                                          'が生成した '
                                                                                                                                                                                                                          'delta '
                                                                                                                                                                                                                          'scale '
                                                                                                                                                                                                                          'キーだけなので、無関係なアニメーションはそのまま残ります。',
 'Remove Smart Animation noise modifiers from the active camera or scene camera.': 'アクティブカメラまたはシーンカメラから Smart '
                                                                                         'Animation Toolset '
                                                                                         'のノイズモディファイアを削除します。',
 'Remove Smart Animation noise modifiers from the selected or active curves.': '選択または対象カーブから Smart Animation '
                                                                                     'Toolset のノイズモディファイアを削除します。',
 'Remove Smart Animation stepped-preview modifiers from the selected or active curves.': '選択または対象カーブから Smart '
                                                                                               'Animation Toolset '
                                                                                               'の段階プレビュー用モディファイアを削除します。',
 'Remove Smart Animation wheel-drive curves from the selected objects and restore each stored delta-rotation base value. Only SAS-generated wheel-drive keys are cleared, so unrelated rotation animation stays untouched.': '選択オブジェクトから '
                                                                                                                                                                                                                                   'Smart '
                                                                                                                                                                                                                                   'Animation '
                                                                                                                                                                                                                                   'Toolset '
                                                                                                                                                                                                                                   'の車輪駆動カーブを削除し、保存していた '
                                                                                                                                                                                                                                   'delta '
                                                                                                                                                                                                                                   'rotation '
                                                                                                                                                                                                                                   'の基準値を復元します。削除するのは '
                                                                                                                                                                                                                                   'SAS '
                                                                                                                                                                                                                                   'が生成した車輪駆動キーだけなので、無関係な回転アニメーションはそのまま残ります。',
 'Remove exact same-frame duplicates and flat middle keys using the threshold. This helps reduce clutter after imports or aggressive baking.': '同一フレームの重複キーと、しきい値内で平坦な中間キーを削除します。読み込み後や強いベイク後の整理に役立ちます。',
 'Remove in-between keys whose values stay within the simplify factor from a straight-line interpolation. Use Preview Cleanup first if you want to see the impact before editing.': '直線補間との差が簡略化係数以内の中間キーを削除します。編集前に影響を見たい場合は先に整理プレビューを使ってください。',
 'Remove the highlighted entry from the internal motion library list. The original Blender action data-block is not deleted.': 'ハイライト中のエントリを内部モーションライブラリ一覧から外します。元の '
                                                                                                                               'Blender '
                                                                                                                               'アクションデータブロック自体は削除されません。',
 'Remove the highlighted reusable selection set from the current scene. This only deletes the stored shortcut, not the objects, bones, or actions themselves.': '現在のシーンから選択中の再利用用選択セットを削除します。削除されるのは保存済みショートカットだけで、オブジェクト、ボーン、アクション本体は消えません。',
 'Replicate': '複製',
 'Report exported to Blender text data.': 'レポートを Blender のテキストデータへ出力しました。',
 'Reset location, rotation, and scale on selected pose bones to their neutral values.': '選択したポーズボーンの位置・回転・スケールを中立値へ戻します。',
 'Resolution': '解像度',
 'Restore keymap item': 'キーマップ項目を復元',
 'Restore the highlighted selection set. Object sets reselect saved objects, and pose sets reactivate the saved armature and reselect its stored bones.': '選択中の選択セットを復元します。オブジェクトセットは保存済みオブジェクトを再選択し、ポーズセットは保存されたアーマチュアを再アクティブ化して保存ボーンを再選択します。',
 'Retarget Preview': 'リターゲットプレビュー',
 'Right': '右',
 'Right Text': '右テキスト',
 'Right header text': '右のヘッダー文字',
 'Rows': '行',
 'Run': '実行',
 'Run Cleanup Task': '整理実行',
 'Run Data Task': 'データ実行',
 'Run Timeline Task': 'タイムライン実行',
 'Run Timing Task': 'タイミング実行',
 'Run Transfer Task': '転送実行',
 'Run the currently selected asset or retarget import/export task from the compact data hub.': 'コンパクトデータハブで選択中のアセット / '
                                                                                               'リターゲット入出力作業を実行します。',
 'Run the currently selected bake / procedural / helper motion task from the compact FX hub.': 'コンパクト FX ハブで選択中のベイク / '
                                                                                               'プロシージャル / '
                                                                                               '補助モーション作業を実行します。',
 'Run the currently selected cleanup or curve-fix task from the compact hub.': 'コンパクトハブで選択中の整理 / カーブ修正作業を実行します。',
 'Run the currently selected retarget or root-motion task from the compact transfer hub.': 'コンパクト転送ハブで選択中のリターゲット / '
                                                                                           'ルートモーション作業を実行します。',
 'Run the currently selected timeline task from the compact hub.': 'コンパクトハブで選択中のタイムライン作業を実行します。',
 'Run the currently selected timing or spacing task from the compact hub.': 'コンパクトハブで選択中のタイミング / スペーシング作業を実行します。',
 'Runtime': '実行状態',
 'Runtime Properties': '実行時プロパティ',
 'Sakura Poselib': 'Sakura Poselib',
 'Sample': 'サンプル',
 'Sample selected rigid-body motion and write it back as editable transform keys. This is useful for ragdoll handoff, object impacts, collapses, and any baked-dynamics pass you want to keep inside the animation file.': '選択したリジッドボディの動きをサンプリングし、編集可能な変形キーとして書き戻します。ラグドール受け渡し、オブジェクト衝突、崩壊演出、その他の '
                                                                                                                                                                                                                           'Baked '
                                                                                                                                                                                                                           'Dynamics '
                                                                                                                                                                                                                           'をアニメーションファイル内へ保持したい場合に便利です。',
 'Sample selected rigid-body objects over the chosen bake range and write the result as editable transform keys. This gives Blender a practical baked-dynamics / ragdoll handoff step without leaving the Smart Animation workspace.': '選択したリジッドボディオブジェクトを指定ベイク範囲でサンプリングし、編集可能な変形キーとして書き出します。Smart '
                                                                                                                                                                                                                                       'Animation '
                                                                                                                                                                                                                                       'ワークスペースから離れず、実用的な '
                                                                                                                                                                                                                                       'Baked '
                                                                                                                                                                                                                                       'Dynamics '
                                                                                                                                                                                                                                       '/ '
                                                                                                                                                                                                                                       'ラグドール受け渡し工程を作れます。',
 'Sample the active object or active pose bone over time and generate a real 3D trail curve. In Speed mode the trail can thicken automatically on faster motion, making arcs and impact accents easier to read.': 'アクティブオブジェクトまたはアクティブポーズボーンを時間方向にサンプリングし、実体のある '
                                                                                                                                                                                                                  '3D '
                                                                                                                                                                                                                  'トレイルカーブを生成します。速度モードでは速い動きほど太くできるため、アークやインパクトの読み取りがしやすくなります。',
 'Sample the selected objects through the bake range and generate editable motion-stretch keys on delta scale. This gives you a Blender-friendly superset of smear and motion-stretch helpers while safely skipping objects that already use non-SAS delta-scale animation.': '選択オブジェクトをベイク範囲でサンプリングし、delta '
                                                                                                                                                                                                                                                                              'scale '
                                                                                                                                                                                                                                                                              'に編集可能なモーションストレッチキーを生成します。スミアや '
                                                                                                                                                                                                                                                                              'Motion '
                                                                                                                                                                                                                                                                              'Stretch '
                                                                                                                                                                                                                                                                              '系の実用的な '
                                                                                                                                                                                                                                                                              'Blender '
                                                                                                                                                                                                                                                                              '向け上位補助で、既に非 '
                                                                                                                                                                                                                                                                              'SAS '
                                                                                                                                                                                                                                                                              'の '
                                                                                                                                                                                                                                                                              'delta '
                                                                                                                                                                                                                                                                              'scale '
                                                                                                                                                                                                                                                                              'アニメーションを使っているオブジェクトは安全のため自動的にスキップします。',
 'Scale To Neighbors needs keys with anchor keys on both sides of the edited block.': '隣のキーへのスケールには、編集する範囲の両側に基準のキーが必要です。',
 'Scale factor must be greater than zero.': 'スケール係数は 0 より大きい必要があります。',
 'Scale selected keys, or the active timing range when no keys are selected, around the straight line between the surrounding anchor keys. This is a compact animBot-style polish tool for preserving or exaggerating a block of spacing.': '選択キー、またはキー未選択時はアクティブなタイミング範囲を、外側アンカーキー間の直線基準で拡縮します。スペーシングの塊を保ったまま強弱を付けられる、コンパクトな '
                                                                                                                                                                                                                                            'animBot '
                                                                                                                                                                                                                                            '風の詰め作業ツールです。',
 'Scene Audit': 'シーン監査',
 'Scene Snapshot': 'シーン要約',
 'Scene audit found no obvious issues.': 'シーン監査で明確な問題は見つかりませんでした。',
 'Scope': '範囲',
 'Sculpt': 'スカルプト',
 'Search': '検索',
 'Seed': 'シード',
 'Select a camera, open the migrated Camera Shakify controls, choose a shake preset or generated action, then adjust amplitude, timing, and blend settings as needed.': 'カメラを選択して移植済み '
                                                                                                                                                                        'Camera '
                                                                                                                                                                        'Shakify '
                                                                                                                                                                        '設定を開き、プリセットまたは生成アクションを選んでから、強さ・タイミング・ブレンドを調整してください。',
 'Select a valid source armature.': '有効なソースアーマチュアを選択してください。',
 'Select a valid target armature.': '有効なターゲットアーマチュアを選択してください。',
 'Select an active child bone and one parent target bone.': '子にするアクティブボーンと、親ターゲットとなる別のボーンを選択してください。',
 'Select an active child object and one parent target object.': '子にするアクティブオブジェクトと、親ターゲットとなる別のオブジェクトを選択してください。',
 'Select an active vehicle or root object first.': '先に車体またはルートになるアクティブオブジェクトを選択してください。',
 'Select an animated object or active pose bone first.': '先にアニメーション対象オブジェクトまたはアクティブポーズボーンを選択してください。',
 'Select an animated object with an active action first.': '先にアクションを持つアニメーション対象オブジェクトを選択してください。',
 'Select an animated object, set the frame step, offset, and jitter strength, then run Apply Stop Motion. Use Reset / Clean to remove the generated jitter.': 'アニメーション済みオブジェクトを選択し、フレーム間隔・オフセット・ジッター強度を設定して '
                                                                                                                                                              'Apply '
                                                                                                                                                              'Stop '
                                                                                                                                                              'Motion '
                                                                                                                                                              'を実行してください。生成したジッターは '
                                                                                                                                                              'Reset '
                                                                                                                                                              '/ '
                                                                                                                                                              'Clean '
                                                                                                                                                              'で除去できます。',
 'Select an armature in Pose Mode, choose the target Action and slot, set the frame range, capture the reference pose, move the bones, then run Propagate Offset once.': 'Pose '
                                                                                                                                                                         'モードのアーマチュアを選択し、対象 '
                                                                                                                                                                         'Action '
                                                                                                                                                                         'とスロット、反映範囲を指定して基準ポーズを記録し、ボーンを動かしたあとで '
                                                                                                                                                                         'Propagate '
                                                                                                                                                                         'Offset '
                                                                                                                                                                         'を '
                                                                                                                                                                         '1 '
                                                                                                                                                                         '回実行してください。',
 'Select an armature, open the migrated Sakura PoseLib panels, create or update a pose book, then store, organize, apply, mix, or convert poses as needed.': 'アーマチュアを選択して移植済み '
                                                                                                                                                             'Sakura '
                                                                                                                                                             'PoseLib '
                                                                                                                                                             'パネルを開き、ポーズブックを作成・更新したうえで、ポーズの保存・整理・適用・ミックス・変換を行ってください。',
 'Select an object first.': 'まずオブジェクトを選択してください。',
 'Select an object to manage actions.': 'アクション管理にはオブジェクトを選択してください。',
 'Select animated objects, run Grab / Rotate / Scale Offset or use the bundled Shift+G / Shift+R / Shift+S shortcuts, then confirm the transform to bake the delta into the action.': 'アニメーション済みオブジェクトを選択し、Grab '
                                                                                                                                                                                      '/ '
                                                                                                                                                                                      'Rotate '
                                                                                                                                                                                      '/ '
                                                                                                                                                                                      'Scale '
                                                                                                                                                                                      'Offset '
                                                                                                                                                                                      'か '
                                                                                                                                                                                      'Shift+G '
                                                                                                                                                                                      '/ '
                                                                                                                                                                                      'Shift+R '
                                                                                                                                                                                      '/ '
                                                                                                                                                                                      'Shift+S '
                                                                                                                                                                                      'を実行して変形を確定すると、その差分がアクションへ焼き込まれます。',
 'Select at least 3 keys, or define a Timing range that contains at least 3 keyframes.': '少なくとも 3 個のキーを選択するか、3 '
                                                                                         '個以上のキーフレームを含むタイミング範囲を指定してください。',
 'Select editable keyframes in the Graph Editor, open the migrated EaseIt panel, then click a preset icon to update the selected keyframe easing.': 'グラフエディターで編集可能なキーフレームを選択し、移植済み '
                                                                                                                                                    'EaseIt '
                                                                                                                                                    'パネルからプリセットアイコンを押してイージングを適用してください。',
 'Select keys first, or enable Use Range in Timing Tools so Scale To Neighbors knows which section to reshape.': '先にキーを選ぶか、タイミングツールの「範囲を使う」を有効にして、整える範囲を指定してください。',
 'Select object chains or pose-bone chains first.': '先にオブジェクトチェーンまたはポーズボーンチェーンを選択してください。',
 'Select one active source object and at least one wheel object.': 'アクティブなソース 1 つと、少なくとも 1 つの車輪オブジェクトを選択してください。',
 'Select one or more mesh objects first.': '先に 1 つ以上のメッシュオブジェクトを選択してください。',
 'Select one or more objects first.': '先に 1 つ以上のオブジェクトを選択してください。',
 'Select one or more rigid-body objects first.': '先に 1 つ以上のリジッドボディオブジェクトを選択してください。',
 'Select only the steering wheels or steering controls if you do not want every chosen wheel to steer.': 'すべての選択ホイールを曲げたくない場合は、ステアリング対象の前輪または操舵コントロールだけを選択してください。',
 'Select pose bones on an active armature first.': '先にアクティブなアーマチュア上でポーズボーンを選択してください。',
 'Select the child as the active item, then also select the parent target.': '子をアクティブにし、そのうえで親ターゲットも選択してください。',
 'Select the target curve object or animation F-Curves, choose the simplification mode and tolerance, then execute the migrated Simplify operator.': '対象のカーブオブジェクトまたはアニメーション '
                                                                                                                                                     'F-Curve '
                                                                                                                                                     'を選択し、簡略化モードと許容値を決めてから移植済み '
                                                                                                                                                     'Simplify '
                                                                                                                                                     'オペレーターを実行してください。',
 'Selected Curves': '選択カーブのみ',
 'Selection sets exported to Blender text data and clipboard.': '選択セットを Blender テキストデータとクリップボードへ書き出しました。',
 'Selection-set JSON could not be parsed.': '選択セット JSON を解析できませんでした。',
 'Selection-set text was not found.': '選択セット用テキストが見つかりません。',
 'Set Preview': 'プレビュー設定',
 'Set the scene preview range from selected keyframes. If no keys are selected, use the current action range instead.': '選択キーフレームからシーンのプレビュー範囲を設定します。キー選択が無い場合は現在のアクション範囲を使います。',
 'Set the scene preview range from selected sound strips. If no sound strips are selected, use all sound strips in the sequence editor instead. This is helpful for lip-sync and dialogue review.': '選択中のサウンドストリップからシーンのプレビュー範囲を設定します。選択が無い場合はシーケンスエディター内の全サウンドストリップを使います。リップシンクや台詞確認に便利です。',
 'Set the scene preview range to the current camera shot, using the active cut marker and the next camera marker.': '現在のカメラショット、つまり現在のカットマーカーから次のカメラマーカーまでにプレビュー範囲を設定します。',
 'Set the scene preview range to the full span covered by camera markers.': 'カメラマーカー全体がカバーする範囲にシーンのプレビュー範囲を設定します。',
 'Setup Drawing': '描画設定',
 'Shape Key smoothing found nothing to change.': '変更対象のシェイプキー値が見つかりませんでした。',
 'Shift': '移動',
 'Shot': 'ショット長',
 'Side (Y-Z)': '側面 (Y-Z)',
 'Side Aliases': '左右エイリアス',
 'Simplify': '簡略化係数',
 'Simplify F-Curves': 'Fカーブを簡略化',
 'Smooth Out': 'スムーズアウト',
 'Smooth animated Shape Key value curves on the active object. This is useful for facial animation, viseme transitions, and corrective blendshape polish.': 'アクティブオブジェクトのシェイプキー値カーブをスムージングします。フェイシャル、口形素のつなぎ、補正ブレンドシェイプの仕上げに便利です。',
 'Smooth selected or active F-Curve values with a gentle averaging pass. This is useful for facial curves, mocap cleanup, and noisy secondary motion.': '選択または対象 '
                                                                                                                                                        'F '
                                                                                                                                                        'カーブの値を、穏やかな平均化でスムージングします。フェイシャル、モーキャプ整理、ノイジーな二次モーションの整形に便利です。',
 'Snapshot data could not be parsed.': 'スナップショットデータを解析できませんでした。',
 'Sort By': '並び替え基準',
 'Sort poses by name or category': 'ポーズを名前またはカテゴリで並び替えます',
 'Source and target must be different armatures.': 'ソースとターゲットは別のアーマチュアである必要があります。',
 'Space': '空間',
 'Splines': 'スプライン',
 'Split Editor': 'エディター分割',
 'Split the current 3D View into a free review view and a locked camera view so you can pose from one side while judging the shot from the other. This is a compact Blender answer to Tear Off Viewport style shot review.': '現在の '
                                                                                                                                                                                                                             '3D '
                                                                                                                                                                                                                             'ビューを自由レビュー用と固定カメラ用に分割し、片側でポーズを触りながら、もう片側でショットの見え方を判断できるようにします。Tear '
                                                                                                                                                                                                                             'Off '
                                                                                                                                                                                                                             'Viewport '
                                                                                                                                                                                                                             '風ショット確認へのコンパクトな '
                                                                                                                                                                                                                             'Blender '
                                                                                                                                                                                                                             '解です。',
 'Square': '正方形',
 'Square aspect ratio (1.000)': '正方形のアスペクト比 (1.000)',
 'Stagger': '段差',
 'Start': '開始',
 'Start Angle': '開始角度',
 'Steering': 'ステアリング',
 'Step Keys': 'ステップキー',
 'Stick stroke to other strokes': 'ストロークを他のストロークに吸着',
 'Stick stroke to surfaces': 'ストロークをサーフェスに吸着',
 'Store': '保存',
 'Store the current object selection or the current pose-bone selection as a reusable set. This acts as a lightweight picker-style shortcut for repeated animation work.': '現在のオブジェクト選択、または現在のポーズボーン選択を再利用できるセットとして保存します。繰り返し作業用の軽量なピッカー風ショートカットとして使えます。',
 'Store the current selected pose bones, or all pose bones if nothing is selected, as a reusable snapshot.': '現在の選択ポーズボーンを、未選択なら全ポーズボーンを、再利用できるスナップショットとして保存します。',
 'Storytools': 'Storytools',
 'Stroke': 'ストローク',
 'Subdivision': '細分化',
 'Surface': 'サーフェス',
 'Swap': '入れ替え',
 'Swap two panels': '2つのパネルを入れ替えます',
 'Switch Blender to a blocking-friendly setup: Auto Key on, preview-range off, audio scrub off, and a lightweight realtime sync mode when available.': 'Blender '
                                                                                                                                                       'をブロッキング向け設定へ切り替えます。オートキーを有効、プレビュー範囲を無効、音声スクラブを無効、可能なら軽量なリアルタイム同期へ設定します。',
 'Switch Blender to a lip-sync review setup: preview-range on, Auto Key off, audio scrub on, and audio sync when Blender supports it.': 'Blender '
                                                                                                                                        'を口パク確認向け設定へ切り替えます。プレビュー範囲を有効、オートキーを無効、音声スクラブを有効、可能なら音声同期へ設定します。',
 'Switch Blender to a review-friendly setup: preview-range on, Auto Key off, audio scrub off, and a stable playback sync mode when available.': 'Blender '
                                                                                                                                                'をレビュー向け設定へ切り替えます。プレビュー範囲を有効、オートキーを無効、音声スクラブを無効、可能なら安定した再生同期へ設定します。',
 'Sync Mode': '再生同期',
 'Task': 'タスク',
 'Template Page': 'ひな形のページ',
 'Text': 'テキスト',
 'Text Name': 'テキスト名',
 'That action is already in the library.': 'そのアクションはすでにライブラリに登録されています。',
 'The active object has no Shape Keys.': 'アクティブオブジェクトにシェイプキーがありません。',
 'The active object has no usable shape keys.': 'アクティブオブジェクトに使用可能なシェイプキーがありません。',
 'The armature saved in this selection set is missing.': 'この選択セットに保存されたアーマチュアが見つかりません。',
 'The bake range is too short for Motion Signal.': 'Motion Signal にはベイク範囲が短すぎます。',
 'The bake range is too short for Spring Magic.': 'Spring Magic にはベイク範囲が短すぎます。',
 'The bake range is too short for motion stretch.': 'モーションストレッチにはベイク範囲が短すぎます。',
 'The bake range is too short for vehicle wheel rotation.': '車輪回転ベイクにはベイク範囲が短すぎます。',
 'The ballistic range is too short.': '弾道ガイド範囲が短すぎます。',
 'The camera action could not be prepared.': 'カメラ用アクションを準備できませんでした。',
 'The duplicated action could not expose matching curves.': '複製アクション上で一致するカーブを取得できませんでした。',
 'The global-transform clipboard is empty.': 'ワールド変形クリップボードが空です。',
 'The motion library is empty.': 'モーションライブラリが空です。',
 'The outer keyframes sit on the same frame, so spacing cannot be redistributed.': '外側キーが同じフレームにあるため、間隔を再配置できません。',
 'The selected feature could not be changed.': '選択した機能を変更できませんでした。',
 'The selected library action no longer exists.': '選択中のライブラリアクションはすでに存在しません。',
 'The stored selection set is empty.': '保存された選択セットが空です。',
 'The targeted keys are already evenly distributed.': '対象キーはすでに等間隔です。',
 'The timing range is too short for automatic fulcrum cleanup.': '自動フルクラム整理にはタイミング範囲が短すぎます。',
 'The timing range is too short for spring baking.': 'スプリングベイクにはタイミング範囲が短すぎます。',
 'The tool could not be loaded yet. Try running the task again after Blender finishes registering add-ons.': 'まだツールを読み込めません。Blender '
                                                                                                             'のアドオン登録完了後にもう一度実行してください。',
 'The view was split, but the new camera side could not be configured cleanly.': 'ビューは分割されましたが、新しいカメラ側を正常に設定できませんでした。',
 'These are the original tool panels, rendered inside the Overview Task N-panel section. Some panels require the matching editor, object selection, or mode before their controls become usable.': '元ツールのパネルを概要タスクのNパネル表示内に表示しています。一部のパネルは、対応エディター、選択状態、モードがそろった場合のみ操作できます。',
 'Thickness of the lines': '線の太さ',
 'This FX mode has no dedicated clear action.': 'この FX モードには専用の解除処理がありません。',
 'This bundled tool is disabled on the current OS or CPU.': 'この同梱ツールは現在の OS または CPU では無効です。',
 'This bundled tool is not available because a duplicate or superseded version was skipped.': 'この同梱ツールは重複または上位互換により無効化されています。',
 'This is the only viewport!': 'これが唯一のビューポートです！',
 'This package is bundled, but it is disabled on the current platform.': '同梱済みですが現在の環境では無効です。',
 'This package is intentionally disabled because a duplicate or superseded version was skipped.': '重複または上位互換により無効化されています。',
 'This package is not available.': 'このパッケージは利用できません。',
 'This package is unavailable on the current platform.': '現在の環境では利用できません。',
 'This panel is not active in the current context. Change selection, mode, or editor as required by the original tool, then run this overview task again.': '現在のコンテキストではこのパネルは有効になっていません。元ツールが必要とする選択、モード、エディターへ切り替えてから、この概要タスクを選び直すかNパネルを更新してください。',
 'Time Compression': '時間の圧縮',
 'Timeline Hub': 'タイムラインハブ',
 'Timing Hub': 'タイミングハブ',
 'Timing:': 'タイミング:',
 'Toggle an always-on Smart Animation feature. The setting is saved immediately.': 'Smart Animation '
                                                                               'の常時起動機能を切り替えます。設定は即時保存されます。',
 'Tolerance': '許容値',
 'Tool Settings': 'ツール設定',
 'Top': '上',
 'Top (X-Y)': '上面 (X-Y)',
 'Top To Bottom': '上から下',
 'Track To Constraint:': 'Track To コンストレイント：',
 'Transfer Hub': '転送ハブ',
 'Tweak': '微調整',
 'Tweening needs keys on both sides of the current frame.': 'トゥイーン作成には現在フレームの前後両側にキーが必要です。',
 'Twist': 'ツイスト',
 'Type': '種類',
 'Type of splines to output': '出力するスプラインの種類',
 'Unavailable by package definition': 'パッケージ定義により利用不可',
 'Unique Data User': '単一データユーザー',
 'Unknown': '不明',
 'Unsupported on this platform': 'この環境では非対応',
 'Unsupported platform': '現在の OS・CPU では無効',
 'Up': '上へ',
 'Use Preview Range': 'プレビュー範囲を使用',
 'Use the active object as the moving vehicle source and bake wheel spin on the other selected objects. Optional steering can also be derived from the travel path, giving you a more complete compact Drive-style helper without requiring a heavy vehicle rig.': 'アクティブオブジェクトを移動する車体ソースとして使い、他の選択オブジェクトへ車輪回転をベイクします。必要なら移動経路からステアリングも追加でき、重い専用車両リグなしでより完成度の高い '
                                                                                                                                                                                                                                                                   'Drive '
                                                                                                                                                                                                                                                                   '系補助になります。',
 'Use the active object as the vehicle motion source and bake wheel spin onto the other selected objects. Optional steering can also be baked from the travel path, giving you a safer Blender-friendly superset of compact Drive-style wheel helpers while skipping objects that already use non-SAS delta-rotation curves.': 'アクティブオブジェクトを車体の移動ソースとして使い、他の選択オブジェクトへ車輪回転をベイクします。必要なら移動経路からステアリングも追加でき、Drive '
                                                                                                                                                                                                                                                                                                                               '系の車輪補助を '
                                                                                                                                                                                                                                                                                                                               'Blender '
                                                                                                                                                                                                                                                                                                                               'で安全寄りに再構成した上位補助になります。非 '
                                                                                                                                                                                                                                                                                                                               'SAS '
                                                                                                                                                                                                                                                                                                                               'の '
                                                                                                                                                                                                                                                                                                                               'delta '
                                                                                                                                                                                                                                                                                                                               'rotation '
                                                                                                                                                                                                                                                                                                                               'カーブを持つオブジェクトは安全のため自動的にスキップします。',
 'User Interface': 'ユーザーインターフェース',
 'Value': '値',
 'Velocity': '速度',
 'Vertical spacing between pages': 'ページ間の垂直間隔',
 'Viewport / Editor Draw': 'ビューポート / エディター描画',
 'Visibility State': '表示状態',
 'Visible': '表示',
 'Visible and unlocked layers': '表示中でロックされていないレイヤー',
 'Visibles layers': '表示レイヤー',
 'Visual bake completed.': 'ビジュアルベイクが完了しました。',
 'Workspace:': 'ワークスペース:',
 'World background already set': 'ワールドの背景は設定済みです',
 'World:': 'ワールド:',
 "Write a scene, cleanup, and retarget summary into Blender's internal text editor as 'Smart Animation Report'.": 'シーン、整理、リターゲットの要約を、Blender '
                                                                                                                        '内部テキストエディタの「Smart '
                                                                                                                        'Animation '
                                                                                                                        'Toolset '
                                                                                                                        'Report」へ書き出します。',
 'button.apply_curve': 'button.apply_curve',
 'button.auto_off': 'button.auto_off',
 'button.auto_on': 'button.auto_on',
 'button.center': 'button.center',
 'button.constant': 'button.constant',
 'button.copy_selected': 'button.copy_selected',
 'button.linear': 'button.linear',
 'button.mirror': 'button.mirror',
 'button.reset': 'button.reset',
 'button.save': 'button.save',
 'button.save_preset': 'button.save_preset',
 'button.zoom_in': 'button.zoom_in',
 'button.zoom_out': 'button.zoom_out',
 'en': 'en',
 'info.curves': 'info.curves',
 'info.extrap': 'info.extrap',
 'info.frame_span': 'info.frame_span',
 'info.group': 'info.group',
 'info.keys': 'info.keys',
 'info.mods': 'info.mods',
 'info.no_selected_keys': 'info.no_selected_keys',
 'info.selected': 'info.selected',
 'info.selected_short': 'info.selected_short',
 'info.total': 'info.total',
 'info.value_now': 'info.value_now',
 'info.value_span': 'info.value_span',
 'opacity': '不透明度',
 'panel.auto_apply': 'panel.auto_apply',
 'panel.curve_samples': 'panel.curve_samples',
 'panel.display': 'panel.display',
 'panel.display_size': 'panel.display_size',
 'panel.editor': 'panel.editor',
 'panel.grid_subdivisions': 'panel.grid_subdivisions',
 'panel.open_preset_file': 'panel.open_preset_file',
 'panel.outer_padding': 'panel.outer_padding',
 'panel.read_curve': 'panel.read_curve',
 'panel.show_info': 'panel.show_info',
 'panel.sidebar_width': 'panel.sidebar_width',
 'prefs.redraw_threshold': 'prefs.redraw_threshold',
 'prefs.show_info_button': 'prefs.show_info_button',
 'prefs.show_timeline_button': 'prefs.show_timeline_button',
 'prefs.title': 'prefs.title',
 'report.applied_curve': 'report.applied_curve',
 'report.baked_elastic': 'report.baked_elastic',
 'report.bezier_loaded': 'report.bezier_loaded',
 'report.elastic_loaded': 'report.elastic_loaded',
 'report.enable_overlay_first': 'report.enable_overlay_first',
 'report.need_selected_key_with_next': 'report.need_selected_key_with_next',
 'report.no_selected_keyframes': 'report.no_selected_keyframes',
 'report.no_selected_pairs': 'report.no_selected_pairs',
 'report.preset_opened': 'report.preset_opened',
 'report.preset_path': 'report.preset_path',
 'report.preset_save_failed': 'report.preset_save_failed',
 'report.preset_saved': 'report.preset_saved',
 'report.set_interpolation': 'report.set_interpolation',
 'square format (15 x 15)': '正方形形式 (15 x 15)',
 'vertex_color': '頂点カラー',
 'will be used as track target': 'がトラックの対象になります'}

# Additional runtime-template translations added for Smart Animation 22.
# These entries cover UI labels and reports that are built with f-strings or
# str.format() after registration, so exact Blender msgid lookup alone cannot
# catch them.
SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    '{} details': '{} 詳細',
    'Expand to view the overview and usage guide for {}.': '{} の概要と使い方を表示します。',
    '{}.{}: {}': 'プロパティ {}.{}: {}',
    'Panels: {}': 'パネル: {}',
    'Commands: {}': 'コマンド: {}',
    'Operators: {}': 'オペレーター: {}',
    'Menus: {}': 'メニュー: {}',
    'Prefs: {}': '設定: {}',
    'Props: {}': 'プロパティ: {}',
    '{}: {}': '{}: {}',
    '{} - {}': '{} - {}',
    'Operator invoke failed: {} ({})': 'オペレーターの呼び出しに失敗しました: {} ({})',
    'Menu invoke failed: {} ({})': 'メニューの呼び出しに失敗しました: {} ({})',
    'Operator not found: {}': 'オペレーターが見つかりません: {}',
    'Captured pose for {} bone(s) at frame {}': 'ポーズを記録しました: {} 本のボーン、フレーム {}',
    'Anim Offset: {} keyframes offset.': 'Anim Offset: {} 個のキーフレームをオフセットしました。',
    'Applied {} easing to {} curve(s), {} keyframes processed': '{} イージングを {} 本のカーブに適用し、{} 個のキーフレームを処理しました',
    'Applied {} easing to {} curve(s), {} keyframes created': '{} イージングを {} 本のカーブに適用し、{} 個のキーフレームを作成しました',
    'Duplicated pose: {}': 'ポーズを複製しました: {}',
    'Pose "{}" loaded successfully.': 'ポーズ「{}」を読み込みました。',
    'Invalid regular expression: {}': '無効な正規表現です: {}',
    "Pose '{}' renamed to '{}', by naming conflict": '名前の競合によりポーズ「{}」を「{}」に変更しました',
    "Bone '{}' renamed to '{}', by naming conflict": '名前の競合によりボーン「{}」を「{}」に変更しました',
    'Alt Names: {}': '別名: {}',
    'Apply Buttons: {}': '適用ボタン: {}',
    'Select Bones Buttons: {}': 'ボーン選択ボタン: {}',
    'Replace Buttons: {}': '置換ボタン: {}',
    'Transforms: {}': '変形：{}',
    'k': 'k',
    'n': 'n',
    'Applied: Step {}, Offset {}, Jitter {}': '適用しました: ステップ {}、オフセット {}、ジッター {}',
    'Cannot set tool {}, need identifier (ex: "builtin.brush")': 'ツール {} を設定できません。識別子が必要です（例: "builtin.brush"）',
    'Cannot load {}, need to be an asset path, ex: "Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill"': '{} を読み込めません。アセットのパスが必要です（例："Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill"）',
    'Could not find brush named {}': 'ブラシ {} が見つかりません',
    'No keymap {} found': 'キーマップ {} が見つかりません',
    '{} (located in "Settings" Tab)': '{}（「設定」タブ内）',
    'Only on active layer': 'アクティブレイヤーのみ',
    'Sync material and layer globally': 'マテリアルとレイヤーを全体同期',
    '{} mm': '{} mm',
    'Selected empty "{}"': '選択中のエンプティ「{}」',
    '{} Created': '{} を作成しました',
    'Camera Removed: "{}"': 'カメラを削除しました: 「{}」',
    'Could not found object named "{}"': '「{}」という名前のオブジェクトが見つかりません',
    'No "{}" object to select': '選択する「{}」オブジェクトがありません',
    'removed {} track constraints on camera': 'カメラ上のトラック制約を {} 個削除しました',
    'Jump in keyframes of active and other selected layers': 'アクティブレイヤーと他の選択レイヤーのキーフレーム間を移動',
    'No {} keyframe on {} layer{}{}': '{} キーフレームが {} レイヤー{}{}にありません',
    'Create frame(s), jumping {} forward': 'フレームを作成し、{} フレーム先へ移動します',
    'Error, a frame is already at {}': 'エラー: {} に既にフレームがあります',
    'Select Map Object': 'マップオブジェクトを選択',
    '{} materials added': '{} 個のマテリアルを追加しました',
    'Added material "{}"': 'マテリアル「{}」を追加しました',
    '{} materials on object': 'オブジェクト上のマテリアル: {}',
    'Created material {}': 'マテリアル {} を作成しました',
    '"{}" not found': '「{}」が見つかりません',
    '"{}" is already in stack': '「{}」は既にスタック内にあります',
    'Delete object "{}" ?': 'オブジェクト「{}」を削除しますか？',
    "Deleted Grease Pencil object '{}'": 'Grease Pencil オブジェクト「{}」を削除しました',
    'Object Parented to "{}"': 'オブジェクトを「{}」へ親子付けしました',
    'Total Frames: {} ({}x{} x {} pages)': '総フレーム数: {}（{}x{} x {} ページ）',
    'Ratio: {}': '比率: {}',
    'Failed to import logo: {}': 'ロゴの読み込みに失敗しました: {}',
    'Frames': 'フレーム',
    'Time Per Panel: {} seconds': '1パネルあたりの時間: {} 秒',
    'x {}': 'x {}',
    'Number of panel frames: {}': 'パネルフレーム数: {}',
    'Current shot: {} frames. Time: {}s': '現在のショット: {} フレーム。時間: {} 秒',
    'Average time between frames: {} frames ({} seconds)': 'フレーム間の平均時間: {} フレーム（{} 秒）',
    'Marker range: {} - {}': 'マーカー範囲: {} - {}',
    'Current pages count: {}': '現在のページ数: {}',
    'Added {} new pages': '{} ページを追加しました',
    "Warning: Source page {} doesn't exist": '警告: ソースページ {} が存在しません',
    'Maximum page number is {}': '最大ページ番号は {} です',
    "Source page {} doesn't exist": 'ソースページ {} が存在しません',
    'Swapped panels {} and {}': 'パネル {} と {} を入れ替えました',
    'Inserted panel at position {}': '位置 {} にパネルを挿入しました',
    'Removed panel at position {}': '位置 {} のパネルを削除しました',
    'Smart Animation N-panel Controls': 'Smart Animation Nパネルコントロール',
    'Smart Animation centralizes Storytools controls in the N-panel.': 'Storytools の操作項目は Smart Animation のNパネルに集約されています。',
    'Storytools controls are available from the Smart Animation N-panel.': 'Storytools の操作項目は Smart Animation のNパネルから使用できます。',
    'Customize or disable this keymap from the Smart Animation N-panel controls.': 'このキーマップは Smart Animation のNパネル操作項目から調整または無効化してください。',
})


SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Toggle Always-on Feature': '常時起動機能を切り替え',
    'Enable or disable one centralized always-on feature.': '集約された常時起動機能を1つ有効または無効にします。',
    'Enable or disable one always-on Smart Animation feature. The setting is saved immediately.': 'Smart Animation の常時起動項目を有効 / 無効にします。設定はすぐに保存されます。',
    'Always-on Toggles': '常時起動切り替え',
    'Click to enable or disable this always-on item. The setting is saved immediately and the N-panel is redrawn.': 'クリックすると、この常時起動項目の有効 / 無効を切り替えます。設定はすぐに保存され、Nパネルを再描画します。',
    'The selected always-on item is invalid.': '選択された常時起動項目が無効です。',
    'Failed to change the always-on item: {}': '常時起動項目の変更に失敗しました: {}',
    'Always-on setting changed.': '常時起動設定を変更しました。',
    'Always-on setting saved. It will be applied when the tool is loaded.': '常時起動設定を保存しました。対象ツールの読み込み時に適用されます。',
    'The selected always-on item could not be changed.': '選択された常時起動項目を変更できませんでした。',
    'Smart Animation N-panel Controls': 'Smart Animation Nパネルコントロール',
    'Smart Animation centralizes Storytools controls in the N-panel.': 'Storytools の操作項目は Smart Animation のNパネルに集約されています。',
    'Storytools controls are available from the Smart Animation N-panel.': 'Storytools の操作項目は Smart Animation のNパネルから使用できます。',
    'Customize or disable this keymap from the Smart Animation N-panel controls.': 'このキーマップは Smart Animation のNパネル操作項目から調整または無効化してください。',
})

SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Show Always-on Toggle Group': '常時起動切り替えグループを表示',
    'Open the centralized always-on toggle group at the top of the Sidebar N-panel. This is disabled by default when the add-on is installed so the group starts closed.': 'サイドバーNパネル最上部の常時起動切り替えグループを開きます。アドオンのインストール時は無効で、グループは閉じた状態から始まります。',
    'Toggle Always-on Toggle Group': '常時起動切り替えグループを開閉',
    'Open or close the centralized always-on toggle group at the top of the N-panel.': 'Nパネル最上部に集約された常時起動切り替えグループを開閉します。',
    'Open the always-on toggle group and show all centralized enable/disable switches.': '常時起動切り替えグループを開き、集約された有効 / 無効スイッチをすべて表示します。',
    'Close the always-on toggle group. The switch states are kept unchanged.': '常時起動切り替えグループを閉じます。各スイッチの状態は変更されません。',
    'Smart Animation N-panel Controls': 'Smart Animation Nパネルコントロール',
    'Smart Animation centralizes Storytools controls in the N-panel.': 'Storytools の操作項目は Smart Animation のNパネルに集約されています。',
    'Storytools controls are available from the Smart Animation N-panel.': 'Storytools の操作項目は Smart Animation のNパネルから使用できます。',
    'Customize or disable this keymap from the Smart Animation N-panel controls.': 'このキーマップは Smart Animation のNパネル操作項目から調整または無効化してください。',
})


SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Always-on Toggles': '常時起動切り替え',
    'No always-on item is currently registered.': '現在登録されている常時起動項目はありません。',
    'Load Tool': 'ツールを読み込む',
    'Load Integrated Tool': '統合ツールを読み込む',
    'This bundled tool is not loaded yet. The N-panel is showing only lightweight metadata. Press Load Tool only when you want to activate this tool and display its commands.': 'この同梱ツールはまだ読み込まれていません。Nパネルには軽量な概要情報だけを表示しています。このツールを有効化してコマンドを表示したい場合だけ「ツールを読み込む」を押してください。',
    'The target tool is unknown.': '対象ツールが不明です。',
    'Tool load failed.': 'ツールの読み込みに失敗しました。',
    'Loaded: {}': '読み込みました: {}',
    'Smart Animation N-panel Controls': 'Smart Animation Nパネルコントロール',
    'Smart Animation centralizes Storytools controls in the N-panel.': 'Storytools の操作項目は Smart Animation のNパネルに集約されています。',
    'Storytools controls are available from the Smart Animation N-panel.': 'Storytools の操作項目は Smart Animation のNパネルから使用できます。',
    'Customize or disable this keymap from the Smart Animation N-panel controls.': 'このキーマップは Smart Animation のNパネル操作項目から調整または無効化してください。',
})

SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Help': 'ヘルプ',
    'Show detailed help for this Smart Animation tool group.': 'この Smart Animation ツールグループの詳細ヘルプを表示します。',
    'Show detailed help for this tool group, including function overview, usage, and settings.': 'このツールグループの機能概要、使用方法、設定項目を詳しく表示します。',
    'Help could not be opened: {}': 'ヘルプを開けませんでした: {}',
    'Help draw failed: {}': 'ヘルプ描画に失敗しました: {}',
    'Function Overview': '機能概要',
    'How to Use': '使用方法',
    'Settings': '設定項目',
    'No editable setting is required for this item.': 'この項目で必須の編集設定はありません。',
    'Overview Task Dropdown': '概要タスクドロップダウン',
    'Migrated Bundled Tools': '移植済み同梱ツール',
    'Included Tools': '含まれるツール',
    'Tool-specific Runtime Settings': 'ツール固有の実行時設定',
    'Editable runtime setting registered by this bundled tool.': 'この同梱ツールが登録する編集可能な実行時設定です。',
    'No statically declared editable runtime setting was found before loading this tool. Any properties registered after loading are shown in the migrated tool section when available.': 'このツールの読み込み前に静的宣言された編集可能な実行時設定は見つかりませんでした。読み込み後に登録されるプロパティは、利用可能な場合に移植済みツール欄へ表示されます。',
    'Loads the bundled tool from the N-panel only when you request it.': '必要な時だけ、Nパネルから同梱ツールを読み込みます。',
    'Displays high-priority commands in the N-panel after the tool is loaded.': 'ツール読込後、使用頻度の高いコマンドをNパネルに表示します。',
    'Displays migrated operators and menus that belong to the loaded tool.': '読み込み済みツールに属する移植済みオペレーターとメニューを表示します。',
    'Displays editable runtime properties exposed by the loaded tool when available.': '読み込み済みツールが公開する編集可能な実行時プロパティを、利用可能な場合に表示します。',
    'Displays editable runtime properties exposed by the loaded tool when available. Add-on Preferences properties are not used.': '読み込んだツールが公開する実行時プロパティがある場合、Nパネル内に表示します。アドオンプリファレンスのプロパティは使用しません。',
    'Smart Animation N-panel Controls': 'Smart Animation Nパネルコントロール',
    'Smart Animation centralizes Storytools controls in the N-panel.': 'Storytools の操作項目は Smart Animation のNパネルに集約されています。',
    'Storytools controls are available from the Smart Animation N-panel.': 'Storytools の操作項目は Smart Animation のNパネルから使用できます。',
    'Customize or disable this keymap from the Smart Animation N-panel controls.': 'このキーマップは Smart Animation のNパネル操作項目から調整または無効化してください。',
})


# Localization pass 2026-08-19: catalog entries for user-visible suite literals
# that were confirmed to display raw English under the ja_JP interface language.
SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Open Help': 'ヘルプを開く',
    'Open the detailed help popup for this tool group.': 'このツールグループの詳細ヘルプポップアップを開きます。',
    'Always-on Toggle': '常時起動切り替え',
    'Set an always-on feature to enabled or disabled. When N-panel State Save is enabled the change is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed.': '常時起動機能の有効 / 無効を設定します。Nパネル状態保存が有効な場合は変更を即時書き込みし、無効な場合はシーンを閉じたときか「設定を保存」を押したときに保存します。',
    'Save Preferences': '設定を保存',
    "Save current N-panel settings to Blender's config/Smart_Animation_Suite/Smart_Animation_Suite.json and request Blender to save user preferences.": '現在のNパネル設定を Blender の config/Smart_Animation_Suite/Smart_Animation_Suite.json に保存し、Blender にユーザー設定の保存を要求します。',
    'Always-on': '常時起動',
    'Saved always-on switch for this tool. Enable it only when persistent helper behavior is required; disable it for ordinary manual use.': 'このツールの保存対象となる常時起動スイッチです。常駐の補助動作が必要な場合のみ有効にし、通常の手動利用では無効にしてください。',
    'Smart Animation Help': 'Smart Animation ヘルプ',
    'Display detailed Smart Animation help.': 'Smart Animation の詳細ヘルプを表示します。',
    'Smart Animation UI is hidden while the current View3D mode is changing or unsupported.': '現在の3Dビューのモードが切り替え中または未対応のため、Smart Animation の UI を非表示にしています。',
    'Panel draw skipped to prevent Blender UI crash.': 'Blender UI のクラッシュを防ぐため、パネル描画をスキップしました。',
    'Operator draw skipped to prevent UI error.': 'UI エラーを防ぐため、オペレーター描画をスキップしました。',
    'Menu draw skipped.': 'メニュー描画をスキップしました。',
    'Toggle UI Section': 'UIセクションの開閉',
    'Expand or collapse this Smart Animation UI section.': 'この Smart Animation UI セクションを展開または折りたたみます。',
    'N-panel State Save': 'Nパネル状態保存',
    'Function: controls when Smart Animation writes all N-panel state and always-on switch values to config/Smart_Animation_Suite/Smart_Animation_Suite.json. How to use: enable this to save every setting change immediately; disable it to save when the current scene is closed or switched, when the file is saved, when Save Preferences is pressed, or when the add-on is unloaded.': '機能: Smart Animation が全てのNパネル状態と常時起動スイッチ値を config/Smart_Animation_Suite/Smart_Animation_Suite.json に書き込むタイミングを制御します。 使い方: 有効にすると設定変更を毎回即時保存します。無効にすると、現在のシーンを閉じるか切り替えたとき、ファイル保存時、「設定を保存」を押したとき、またはアドオン停止時に保存します。',
    'UI Section State': 'UIセクション状態',
    'Stores whether this Smart Animation UI section is open in the Sidebar N-panel.': 'この Smart Animation UI セクションがサイドバーNパネルで開いているかを保存します。',
    'Function: stores whether this Smart Animation N-panel section is open. How to use: click the section header to expand or collapse it; the value is persisted according to N-panel State Save.': '機能: この Smart Animation Nパネルセクションが開いているかを保存します。 使い方: セクションヘッダーをクリックして開閉します。値はNパネル状態保存の設定に従って保持されます。',
    'Smart': 'スマート',
    'upgraded Animation Recipe hub for advanced animation-assistance workflows.': '高度なアニメーション補助ワークフロー向けの アニメーション レシピ 上位互換レシピハブです。',
    'Create / Refresh': '作成 / 更新',
    'Create or refresh custom-property drivers for shape keys.': 'シェイプキー用のカスタムプロパティドライバーを作成または更新します。',
    'Remove Smart Shape Control drivers from shape keys.': 'シェイプキーから Smart Shape Control のドライバーを削除します。',
})

# camera_shakify vendored panel: collapsible section header missing from the catalog.
SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Misc Utilities': 'その他のユーティリティ',
})

# Vendored confirmation dialogs: title and confirm-button labels missing from the catalog.
SUPPLEMENTAL_UI_JA_TRANSLATIONS.update({
    'Similar Materials Detected': '類似マテリアルを検出',
    'Create New Material': '新規マテリアルを作成',
    'Set Origin Anyway': 'そのまま原点を設定',
})
