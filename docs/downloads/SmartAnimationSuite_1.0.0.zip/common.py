# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

import json
import os
import re
import sys
from collections import OrderedDict
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

try:
    from .undo_support import ensure_operator_undo
except Exception:  # pragma: no cover
    def ensure_operator_undo(cls):
        return cls

try:
    from .panel_header_guard import disable_panel_header_callbacks, disable_many_panel_header_callbacks, harden_class_callbacks
except Exception:  # pragma: no cover - fallback only outside normal package import
    def disable_panel_header_callbacks(cls):
        return cls
    def disable_many_panel_header_callbacks(classes):
        return None
    def harden_class_callbacks(cls):
        return cls

try:
    from .storage import user_data_dir, user_data_file
except Exception:  # pragma: no cover - fallback only outside normal package import
    user_data_dir = None
    user_data_file = None

PACKAGE_ID = 'smart_animation_suite'
ADDON_NAME = 'Smart_Animation_Suite'
TOOL_LABEL_EN = 'Smart Animation'
TOOL_LABEL_JA = 'スマートアニメーション'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_HELP_GROUP_CACHE_MAX = 64
_HELP_GROUP_CACHE: OrderedDict[str, dict] = OrderedDict()
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_TRANSLATION_OWNER = None

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時起動切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    if callable(user_data_dir):
        try:
            return user_data_dir(create=bool(create))
        except Exception:
            pass
    # Last-resort fallback; generated files always stay below Blender CONFIG.
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        version_text = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
    except Exception:
        version_text = '5.1'
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        root = Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'config' / ADDON_NAME
    else:
        root = Path.home() / '.config' / 'blender' / version_text / 'config' / ADDON_NAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    if callable(user_data_file) and clean_parts:
        try:
            return user_data_file(*clean_parts, create_parent=bool(create_parent))
        except Exception:
            pass
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        from . import config_store
        return config_store.config_path(create=True)
    except Exception:
        return storage_path('Smart_Animation_Suite.json')


def _load_previews():
    # Custom help/header/clock PNGs were removed in favor of Blender standard icons.
    return None


def icon_value(name, fallback=0):
    try:
        from . import icons as sas_icons
        return int(sas_icons.icon_value(str(name)) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


def _load_help_group_for_event(topic: str) -> dict:
    """Load help metadata only at an explicit operator event, never from draw."""
    key = str(topic or 'overview').strip() or 'overview'
    cached = _HELP_GROUP_CACHE.get(key)
    if isinstance(cached, dict):
        try:
            _HELP_GROUP_CACHE.move_to_end(key)
        except Exception:
            pass
        return cached
    try:
        from . import guide
        group = guide.get_group(key)
        if not isinstance(group, dict):
            group = {}
    except Exception as exc:
        group = {
            'title_en': TOOL_LABEL_EN + ' Help',
            'title_ja': TOOL_LABEL_JA + ' ヘルプ',
            'overview_en': ['The help catalog could not be loaded: ' + str(exc)],
            'overview_ja': ['ヘルプカタログを読み込めませんでした。'],
            'usage_en': [], 'usage_ja': [], 'settings': [], 'operators': [],
        }
    _HELP_GROUP_CACHE[key] = group
    try:
        _HELP_GROUP_CACHE.move_to_end(key)
    except Exception:
        pass
    while len(_HELP_GROUP_CACHE) > _HELP_GROUP_CACHE_MAX:
        try:
            _HELP_GROUP_CACHE.popitem(last=False)
        except Exception:
            break
    return group


def _cached_help_group(topic: str) -> dict:
    key = str(topic or 'overview').strip() or 'overview'
    group = _HELP_GROUP_CACHE.get(key)
    if isinstance(group, dict):
        return group
    return {
        'title_en': TOOL_LABEL_EN + ' Help',
        'title_ja': TOOL_LABEL_JA + ' ヘルプ',
        'overview_en': ['Open this help item again to refresh its catalog.'],
        'overview_ja': ['ヘルプカタログを更新するには、この項目を開き直してください。'],
        'usage_en': [], 'usage_ja': [], 'settings': [], 'operators': [],
    }


class SMART_ANIMATION_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'
    bl_options = set()

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        _load_help_group_for_event(str(getattr(self, 'topic', '') or 'overview'))
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        group = _cached_help_group(topic)
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        iv = icon_value('help')
        if iv:
            row.template_icon(icon_value=iv, scale=1.0)
        else:
            row.label(text='', icon='QUESTION')
        row.label(text=str(title))
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='QUESTION')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_ANIMATION_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled. When N-panel State Save is enabled the change is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed.'
    bl_options = set()
    _sms_no_undo = True

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, text('The setting could not be changed.', '設定を変更できませんでした。', context))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, text('The setting could not be changed.', '設定を変更できませんでした。', context))
        try:
            save_persistent_settings(context, force=False)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_ANIMATION_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = "Save current N-panel settings to Blender's config/Smart_Animation_Suite/Smart_Animation_Suite.json and request Blender to save user preferences."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        try:
            from . import core
            flush = getattr(core, 'save_all_external_settings', None)
            if callable(flush):
                flush(context=context, force=True)
            else:
                save_persistent_settings(context, force=True)
        except Exception:
            save_persistent_settings(context, force=True)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


# The standalone Always-on panel was removed intentionally.
# The only user-facing Always-on UI is the group drawn inside the main Smart Animation panel.


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper or
        'SMART_ANIMATION_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False


def _purge_standalone_always_on_panel():
    # Exact generation teardown owns only this generation's class objects.
    return None

def _flatten_npanel_parent_before_register(cls):
    """Preserve the panel hierarchy declared by each integrated tool.

    Earlier builds cleared ``bl_parent_id`` for Sidebar panels during class
    registration. That removed child and grandchild bodies from Blender's
    native hierarchy and made lazily loaded panels appear as unrelated roots.
    Registration now leaves the class metadata unchanged.
    """
    return cls


def _register_class_wrapper(cls):
    # Compatibility helper only; never installed process-globally.
    _flatten_npanel_parent_before_register(cls)
    _materialize_annotations(cls)
    ensure_operator_undo(cls)
    disable_panel_header_callbacks(cls)
    harden_class_callbacks(cls)
    return bpy.utils.register_class(cls)


def begin_register():
    return None


def end_register():
    return None

def _iter_relevant_panels():
    # Registered-type discovery is intentionally disabled.
    return iter(())

def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    # Do not mutate registered Panel classes. Header callbacks are removed only
    # before registration by panel_header_guard; changing draw_header/poll after
    # registration can hard-crash Blender 5.1 during panel redraw.
    return None


def _unpatch_panel_headers():
    # No registered Panel callbacks are modified by _patch_panel_headers. Clear
    # any stale bookkeeping from older sessions without touching classes.
    _PATCHED_PANELS.clear()
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    # AddonPreferences are not exposed by Smart Animation.
    return iter(())

def _patch_addon_preferences():
    return None

def _unpatch_addon_preferences():
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                if hasattr(cls, 'draw'):
                    delattr(cls, 'draw')
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


_SAFE_SCALAR_PROP_TYPES = {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}
_PROTECTED_PERSISTENT_SETTING_NAMES = {
    'location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle',
    'scale', 'matrix_world', 'matrix_local', 'matrix_basis', 'matrix_parent_inverse',
}


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _rna_properties(obj):
    for attr in ('bl_rna', 'rna_type'):
        try:
            props = getattr(getattr(obj, attr, None), 'properties', None)
            if props is not None:
                return props
        except Exception:
            pass
    return ()


def _prop_type(prop) -> str:
    try:
        return str(getattr(prop, 'type', '') or '').upper()
    except Exception:
        return ''


def _prop_skip(prop) -> bool:
    try:
        if bool(getattr(prop, 'is_readonly', False)):
            return True
    except Exception:
        pass
    try:
        if bool(getattr(prop, 'is_skip_save', False)):
            return True
    except Exception:
        pass
    return False


def _is_sas_settings_instance(obj) -> bool:
    try:
        ident = str(getattr(getattr(obj, 'bl_rna', None), 'identifier', '') or getattr(getattr(obj, 'rna_type', None), 'identifier', '') or '')
        if ident == 'SAS_Settings':
            return True
    except Exception:
        pass
    try:
        return type(obj).__name__ == 'SAS_Settings'
    except Exception:
        return False


def _safe_scalar_setting_property(prop, identifier: str) -> bool:
    name = str(identifier or '').strip()
    if not name or name == 'rna_type' or name.startswith('_'):
        return False
    if name.lower() in _PROTECTED_PERSISTENT_SETTING_NAMES:
        return False
    if _prop_skip(prop):
        return False
    return _prop_type(prop) in _SAFE_SCALAR_PROP_TYPES


def _serialize_sas_settings(settings):
    if settings is None:
        return {}
    data = {}
    for prop in _rna_properties(settings):
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not _safe_scalar_setting_property(prop, identifier):
                continue
            value = getattr(settings, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                data[identifier] = simple
        except Exception:
            continue
    try:
        for key, value in settings.items():
            identifier = str(key or '').strip()
            if not identifier.startswith('ui_section_'):
                continue
            if isinstance(value, bool):
                data[identifier] = bool(value)
            elif isinstance(value, (int, float)):
                data[identifier] = bool(value)
    except Exception:
        pass
    return data


def collect_persistent_settings(context=None):
    """Persist global N-panel settings in Blender's config/Smart_Animation_Suite/Smart_Animation_Suite.json.

    Only Smart Animation scalar UI settings are saved. File/datablock-specific
    pointer and collection data remain excluded so opening another .blend cannot
    restore object, pose, action, or transform data from a global config file.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return {'version': 3, 'settings': {}}
    payload = {'version': 3}
    try:
        wm = getattr(ctx, 'window_manager', None)
        if wm is not None and hasattr(wm, _ALWAYS_ON_PROP):
            payload['window_manager'] = {_ALWAYS_ON_PROP: bool(getattr(wm, _ALWAYS_ON_PROP))}
    except Exception:
        pass
    try:
        settings = getattr(getattr(ctx, 'scene', None), 'sas_settings', None)
        data = _serialize_sas_settings(settings)
        if data:
            payload['settings'] = data
    except Exception:
        pass
    return payload


def _sanitize_loaded_settings(raw):
    if not isinstance(raw, dict):
        return {'version': 3, 'settings': {}}
    clean = {'version': 3}
    try:
        wm_data = raw.get('window_manager') if isinstance(raw.get('window_manager'), dict) else {}
        if _ALWAYS_ON_PROP in wm_data:
            clean['window_manager'] = {_ALWAYS_ON_PROP: bool(wm_data.get(_ALWAYS_ON_PROP))}
    except Exception:
        pass

    # Current format: {'settings': {SAS_Settings scalar values...}}
    try:
        settings_data = raw.get('settings') if isinstance(raw.get('settings'), dict) else {}
        if settings_data:
            clean['settings'] = dict(settings_data)
    except Exception:
        pass

    # Legacy format: {'scene': {'sas_settings': {...}}}
    try:
        scene_data = raw.get('scene') if isinstance(raw.get('scene'), dict) else {}
        sas_data = scene_data.get('sas_settings') if isinstance(scene_data.get('sas_settings'), dict) else {}
        if sas_data and not clean.get('settings'):
            clean['settings'] = dict(sas_data)
    except Exception:
        pass
    clean.setdefault('settings', {})
    return clean


def _common_values_equal(current, stored, prop_type: str = '') -> bool:
    prop_type = str(prop_type or '').upper()
    try:
        if prop_type == 'BOOLEAN':
            return bool(current) is bool(stored)
        if prop_type == 'INT':
            return int(current) == int(stored)
        if prop_type == 'FLOAT':
            return abs(float(current) - float(stored)) <= max(
                1.0e-8, 1.0e-7 * max(abs(float(current)), abs(float(stored))),
            )
        if prop_type == 'ENUM' and isinstance(current, (set, frozenset)):
            return set(current) == set(stored or ())
        return current == stored
    except Exception:
        return False


def _apply_sas_settings(settings, data):
    """Legacy scalar restorer with comparison-before-assignment semantics.

    The canonical Scene restore is owned by :mod:`core`.  This helper remains
    for compatibility with older direct callers, but it is not used by the
    normal register/load_post transaction and therefore cannot reapply the
    current Scene after core has restored all Scenes.
    """
    if settings is None or not isinstance(data, dict):
        return 0
    prop_map = {}
    try:
        prop_map = {str(getattr(prop, 'identifier', '') or ''): prop for prop in _rna_properties(settings)}
    except Exception:
        prop_map = {}
    assignments = 0
    for key, value in data.items():
        try:
            identifier = str(key or '').strip()
            prop = prop_map.get(identifier)
            if prop is None or not _safe_scalar_setting_property(prop, identifier):
                continue
            if not hasattr(settings, identifier):
                continue
            current = getattr(settings, identifier)
            assigned = value
            if _prop_type(prop) == 'ENUM' and isinstance(current, (set, frozenset)):
                assigned = set(value or ())
            if _common_values_equal(current, assigned, _prop_type(prop)):
                continue
            setattr(settings, identifier, assigned)
            assignments += 1
        except Exception:
            pass
    return assignments


def apply_persistent_settings(context=None, *, payload=None):
    """Apply only common process-global settings from the shared snapshot.

    ``core.apply_saved_settings_to_all_scenes`` is the sole authority for
    ``Scene.sas_settings``.  Keeping this function WindowManager-only removes
    the former all-Scene -> current-Scene duplicate 283-key setter loop.
    """
    global _LOADED_SETTINGS
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return False
    if isinstance(payload, dict):
        data = payload if payload is _LOADED_SETTINGS else _sanitize_loaded_settings(payload)
        _LOADED_SETTINGS = data
    elif isinstance(_LOADED_SETTINGS, dict) and _LOADED_SETTINGS:
        data = _LOADED_SETTINGS
    else:
        data = load_settings_file()
    try:
        wm_data = data.get('window_manager') if isinstance(data.get('window_manager'), dict) else {}
        wm = getattr(ctx, 'window_manager', None)
        if wm is None or _ALWAYS_ON_PROP not in wm_data or not hasattr(wm, _ALWAYS_ON_PROP):
            return False
        desired = bool(wm_data.get(_ALWAYS_ON_PROP))
        if bool(getattr(wm, _ALWAYS_ON_PROP)) == desired:
            return False
        setattr(wm, _ALWAYS_ON_PROP, desired)
        return True
    except Exception:
        return False



def _legacy_settings_candidates():
    candidates = []
    try:
        candidates.append(storage_path('settings', 'n_panel_settings.json'))
    except Exception:
        pass
    return candidates


def load_settings_file(*, payload=None):
    """Sanitize one shared payload snapshot without redundant config writes."""
    global _LOADED_SETTINGS
    payload_supplied = isinstance(payload, dict)
    raw = payload if payload_supplied else {}
    if not payload_supplied:
        try:
            from . import config_store
            section = config_store.get_section('npanel_settings', {})
            if isinstance(section, dict) and (section.get('settings') or section.get('window_manager') or section.get('scene')):
                raw = section
        except Exception:
            raw = {}

    if not raw and not payload_supplied:
        for path in _legacy_settings_candidates():
            try:
                if path.exists():
                    legacy = json.loads(path.read_text(encoding='utf-8'))
                    if isinstance(legacy, dict):
                        raw = legacy
                        break
            except Exception:
                continue

    clean = _sanitize_loaded_settings(raw)
    _LOADED_SETTINGS = clean
    # Migration writes are finite and occur only when the sanitized schema is
    # actually different.  The previous unconditional rewrite of every valid
    # settings payload added synchronous fsync/replace work to every file load.
    if raw and clean != raw and not payload_supplied:
        try:
            from . import config_store
            config_store.set_section('npanel_settings', clean)
        except Exception:
            pass
    return clean



def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    if not force:
        try:
            from . import core
            if not core.npanel_auto_save_enabled(context=context):
                return
        except Exception:
            pass
    data = _sanitize_loaded_settings(collect_persistent_settings(context))
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        from . import config_store
        existing = config_store.get_section('npanel_settings', {})
        if isinstance(existing, dict):
            existing_settings = existing.get('settings') if isinstance(existing.get('settings'), dict) else {}
            data_settings = data.setdefault('settings', {})
            if isinstance(data_settings, dict):
                for key, value in existing_settings.items():
                    ident = str(key or '').strip()
                    if ident.startswith('ui_section_') and ident not in data_settings:
                        data_settings[ident] = bool(value)
        config_store.set_section('npanel_settings', data)
    except Exception:
        pass


def _autosave_timer():
    """Compatibility callback for old generations; never reschedules."""
    return None


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register(ledger=None):
    """Register shared UI without leaking a hard failure to the Suite boundary."""
    global _TRANSLATION_OWNER
    _REGISTERED_CLASSES.clear()
    healthy = True
    generation = int(getattr(ledger, 'generation', 0) or 0)
    token = getattr(ledger, 'token', None)
    owner = f'{PACKAGE_ID}.common.g{generation}.{id(token if token is not None else object()):x}'
    translation_owned = False
    try:
        result = bpy.app.translations.register(owner, _translation_payload())
        if result is False:
            if ledger is not None:
                ledger.note_failure('common translation registration returned False')
            healthy = False
        else:
            translation_owned = True
            _TRANSLATION_OWNER = owner
        if result is not False and ledger is not None:
            try:
                ledger.record_callback(
                    kind='translation', label='common translations', identity=owner,
                    remover=lambda _owner=owner: bpy.app.translations.unregister(_owner),
                )
                translation_owned = False  # exact ledger now owns removal
            except Exception as exc:
                try:
                    bpy.app.translations.unregister(owner)
                except Exception:
                    pass
                _TRANSLATION_OWNER = None
                if ledger is not None:
                    ledger.note_failure(f'common translation ledger failed: {type(exc).__name__}: {exc}')
                healthy = False
    except Exception as exc:
        if translation_owned:
            try:
                bpy.app.translations.unregister(owner)
            except Exception:
                pass
        _TRANSLATION_OWNER = None
        if ledger is not None:
            ledger.note_failure(f'common translation registration failed: {type(exc).__name__}: {exc}')
        healthy = False

    prop_def = BoolProperty(
        name='Always-on',
        description='Saved always-on switch for this tool. Enable it only when persistent helper behavior is required; disable it for ordinary manual use.',
        default=False,
    )
    try:
        if ledger is not None:
            if ledger.set_rna_property(bpy.types.WindowManager, _ALWAYS_ON_PROP, prop_def, required=False) is None:
                healthy = False
        elif not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, prop_def)
        else:
            healthy = False
    except Exception as exc:
        if ledger is not None:
            ledger.note_failure(f'common WindowManager property failed: {type(exc).__name__}: {exc}')
        healthy = False

    for cls in (SMART_ANIMATION_OT_open_help, SMART_ANIMATION_OT_set_always_on, SMART_ANIMATION_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            harden_class_callbacks(cls)
            identity = ledger.register_class(cls, required=False) if ledger is not None else bpy.utils.register_class(cls)
            if ledger is not None and identity is None:
                healthy = False
                continue
            _REGISTERED_CLASSES.append(cls)
        except Exception as exc:
            if ledger is not None:
                ledger.note_failure(f'common class registration failed {getattr(cls, "__name__", cls)}: {type(exc).__name__}: {exc}')
            healthy = False
    return healthy


def unregister(*, ledger_owned: bool = False):
    global _TRANSLATION_OWNER
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    if not ledger_owned:
        for cls in reversed(_REGISTERED_CLASSES):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        try:
            if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
                delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
        except Exception:
            pass
        owner = _TRANSLATION_OWNER
        if owner:
            try:
                bpy.app.translations.unregister(owner)
            except Exception:
                pass
    _TRANSLATION_OWNER = None
    _REGISTERED_CLASSES.clear()
    _HELP_GROUP_CACHE.clear()
    _remove_previews()
