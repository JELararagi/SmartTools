# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Bezier Curve Editor Overlay",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Dope Sheet > Sidebar",
    "description": "Bezier curve overlay editor for Timeline keyframe easing",
    "category": "Animation",
}

from .main import register, unregister

__all__ = ("register", "unregister")
