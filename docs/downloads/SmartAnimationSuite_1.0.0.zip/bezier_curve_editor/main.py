import bpy
import gpu
import blf
import math
import time
import os
import json
from gpu_extras.batch import batch_for_shader
from .translation import translations_dict
from ..global_preferences import get_preferences as _get_integrated_preferences, root_addon_id as _root_addon_id
from ..storage import addon_data_path
from .. import lifecycle
from .. import smart_tools_manager_compat as manager_compat

from .config import (
    ADDON_KEY,
    INFO_ADDON_KEY,
    EDITOR_UI_KEY,
    ENABLED_AREAS_KEY,
    PRESET_FILE,
    HANDLE_HIT_RADIUS_PX,
    SIDEBAR_EDGE_HIT_PX,
    REDRAW_LOAD_EWMA_KEY,
    REDRAW_LAST_TICK_KEY,
    REDRAW_LAST_INTERVAL_KEY,
    MODAL_SESSION_KEY,
    SWITCH_BLOCK_UNTIL_KEY,
    TLFC_PROPERTY_DEFAULTS,
    TLFC_PROPERTY_RANGES,
    TLFC_UI_NUMBERS,
    TLFC_COLORS,
)

def _operator_id_available(op_id):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return False
    group_name, op_name = op_id.split('.', 1)
    group = getattr(bpy.ops, group_name, None)
    if group is None:
        return False
    try:
        op = getattr(group, op_name)
    except Exception:
        return False
    try:
        op.get_rna_type()
        return True
    except AttributeError:
        return callable(op)
    except Exception:
        return False


def _safe_popover(layout, panel_id, **kwargs):
    panel_id = str(panel_id or '').strip()
    if not panel_id or not hasattr(bpy.types, panel_id):
        return False
    try:
        layout.popover(panel=panel_id, **kwargs)
        return True
    except Exception:
        return False

_MAX_PRESET_FILE_BYTES = 4 * 1024 * 1024
_MAX_PRESET_COUNT = 512
_MAX_PRESET_NAME_CHARS = 256
_PRESET_CACHE = []
_PRESET_MTIME = -1.0
ADDON_MODULE_KEY = __package__ or __name__.split(".")[0]
ROOT_EXTENSION_KEY = _root_addon_id(ADDON_MODULE_KEY) or ADDON_MODULE_KEY
_TRANSLATION_OWNER = None
_OWNED_RNA_IDENTITIES = {}


def _preset_file_path() -> str:
    try:
        return str(addon_data_path('bezier_curve_editor', PRESET_FILE, create=True))
    except Exception:
        roaming = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
        fallback = os.path.join(
            roaming, 'Blender Foundation', 'Blender', '5.1',
            'config', 'Smart_Animation_Suite', 'data', 'bezier_curve_editor',
        )
        try:
            os.makedirs(fallback, exist_ok=True)
        except Exception:
            pass
        return os.path.join(fallback, PRESET_FILE)


def _prop_default(name):
    return TLFC_PROPERTY_DEFAULTS[name]


def _prop_range(name):
    return TLFC_PROPERTY_RANGES[name]


def _clamp_prop(name, value):
    min_v, max_v = _prop_range(name)
    out = value
    if min_v is not None:
        out = max(min_v, out)
    if max_v is not None:
        out = min(max_v, out)
    return out


def _prop_to_unit(name, value):
    """Map a property value to normalized 0..1 space based on configured range."""
    min_v, max_v = _prop_range(name)
    if min_v is None or max_v is None:
        return _clamp01(float(value))
    span = max(1e-8, float(max_v) - float(min_v))
    return _clamp01((float(value) - float(min_v)) / span)


def _unit_to_prop(name, unit_value):
    """Map normalized 0..1 value back to configured property range."""
    min_v, max_v = _prop_range(name)
    u = _clamp01(float(unit_value))
    if min_v is None or max_v is None:
        return _clamp_prop(name, u)
    return _clamp_prop(name, float(min_v) + u * (float(max_v) - float(min_v)))


def _reset_ui_state(wm, *, clear_drag=True, clear_hover=True, clear_buttons=True, clear_handle=True):
    if clear_hover:
        wm.tlfc_hover_sidebar = False
        wm.tlfc_hover_sidebar_edge = False
    if clear_drag:
        wm.tlfc_dragging_sidebar = False
    if clear_buttons:
        wm.tlfc_hover_button = ""
        wm.tlfc_pressed_button = ""
    if clear_handle:
        wm.tlfc_hover_handle = ""


def _addon_prefs():
    prefs_cls = globals().get("TLFC_AP_preferences")
    return _get_integrated_preferences(__package__, prefs_cls, ADDON_MODULE_KEY, ROOT_EXTENSION_KEY)


def _pref_bool(name, default=False):
    prefs = _addon_prefs()
    if prefs is None:
        return bool(default)
    return bool(getattr(prefs, name, default))


def _pref_float(name, default=0.0):
    prefs = _addon_prefs()
    if prefs is None:
        return float(default)
    return float(getattr(prefs, name, default))


def _set_editor_enabled_exclusive(area):
    key = _area_key(area)
    if key == 0:
        return
    data = _enabled_areas_map(create=True)
    # Keep only the requested area enabled to avoid conflicting modal/UI state.
    for k in list(data.keys()):
        if k != key:
            data.pop(k, None)
    data[key] = True

def _tag_redraw_dopesheet():
    try:
        for w in bpy.data.window_managers:
            for win in w.windows:
                scr = win.screen
                if not scr:
                    continue
                for area in scr.areas:
                    if area.type in {'DOPESHEET_EDITOR', 'INFO'}:
                        area.tag_redraw()
    except Exception:
        pass


def _supports_editor_space(space):
    if not space:
        return False
    if space.type == 'DOPESHEET_EDITOR':
        return getattr(space, "mode", None) == 'TIMELINE'
    return space.type == 'INFO'


def _enabled_areas_map(*, create=False):
    """Return the Suite-owned editor-state map without mutating from draw/poll."""
    ns = bpy.app.driver_namespace
    data = ns.get(ENABLED_AREAS_KEY)
    if isinstance(data, dict):
        return data
    if not create:
        return {}
    data = {}
    ns[ENABLED_AREAS_KEY] = data
    return data


def _area_key(area):
    return int(area.as_pointer()) if area else 0


def _is_editor_enabled(area):
    key = _area_key(area)
    if key == 0:
        return False
    return bool(_enabled_areas_map().get(key, False))


def _set_editor_enabled(area, enabled):
    key = _area_key(area)
    if key == 0:
        return
    data = _enabled_areas_map(create=True)
    if enabled:
        data[key] = True
    else:
        data.pop(key, None)


def _any_timeline_editor_enabled():
    try:
        for w in bpy.data.window_managers:
            for win in w.windows:
                scr = win.screen
                if not scr:
                    continue
                for area in scr.areas:
                    if area.type not in {'DOPESHEET_EDITOR', 'INFO'}:
                        continue
                    sp = area.spaces.active
                    if not _supports_editor_space(sp):
                        continue
                    if _is_editor_enabled(area):
                        return True
    except Exception:
        pass
    return False


def _truncate_text_to_width(text, max_width, size=10):
    if max_width <= 1.0:
        return ""
    font_id = 0
    blf.size(font_id, size)
    if blf.dimensions(font_id, text)[0] <= max_width:
        return text

    ellipsis = "..."
    ell_w = blf.dimensions(font_id, ellipsis)[0]
    if ell_w >= max_width:
        return ""

    lo = 0
    hi = len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate = text[:mid] + ellipsis
        if blf.dimensions(font_id, candidate)[0] <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo] + ellipsis


def _draw_text_centered(x0, y0, x1, y1, text, size=10, color=TLFC_COLORS["white"], truncate=False, pad=4):
    font_id = 0
    if truncate:
        text = _truncate_text_to_width(str(text), max(1.0, (x1 - x0) - (pad * 2.0)), size=size)
        if not text:
            return
    blf.size(font_id, size)
    tw, th = blf.dimensions(font_id, text)
    tx = x0 + ((x1 - x0) - tw) * 0.5
    ty = y0 + ((y1 - y0) - th) * 0.5 + 1.0
    _draw_text(tx, ty, text, size=size, color=color)


def _t(wm, key, default=None):
    del wm
    msgid = str(default if default is not None else key)
    return bpy.app.translations.pgettext(msgid)




def _load_presets(force=False):
    global _PRESET_CACHE, _PRESET_MTIME
    path = _preset_file_path()
    try:
        mtime = os.path.getmtime(path)
    except Exception:
        _PRESET_CACHE = []
        _PRESET_MTIME = -1.0
        return []

    if not force and mtime == _PRESET_MTIME:
        return _PRESET_CACHE

    try:
        if os.path.getsize(path) > _MAX_PRESET_FILE_BYTES:
            raise ValueError("Preset file exceeds the bounded cache limit")
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        presets = []
        source_presets = data[:_MAX_PRESET_COUNT] if isinstance(data, list) else []
        for p in source_presets:
            if not isinstance(p, dict):
                continue
            preset = {
                "name": str(p.get("name", "Preset"))[:_MAX_PRESET_NAME_CHARS],
                "type": str(p.get("type", "BEZIER")),  # Default to BEZIER for backwards compatibility
            }
            # Load type-specific parameters
            if preset["type"] == "ELASTIC":
                preset["amplitude"] = float(p.get("amplitude", _prop_default("tlfc_elastic_amplitude")))
                preset["period"] = float(p.get("period", _prop_default("tlfc_elastic_period")))
            else:
                # BEZIER or fallback
                preset["h1x"] = float(p.get("h1x", _prop_default("tlfc_h1x")))
                preset["h1y"] = float(p.get("h1y", _prop_default("tlfc_h1y")))
                preset["h2x"] = float(p.get("h2x", _prop_default("tlfc_h2x")))
                preset["h2y"] = float(p.get("h2y", _prop_default("tlfc_h2y")))
            presets.append(preset)
        _PRESET_CACHE = presets
        _PRESET_MTIME = mtime
        return presets
    except Exception:
        _PRESET_CACHE = []
        _PRESET_MTIME = mtime
        return []


def _save_presets(presets):
    path = _preset_file_path()
    bounded = list(presets or ())[:_MAX_PRESET_COUNT]
    tmp_path = path + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
            json.dump(bounded, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        return False
    _load_presets(force=True)
    return True


def _add_current_preset(wm):
    presets = list(_load_presets())
    _mode_val = getattr(wm, 'tlfc_sidebar_mode', _prop_default("tlfc_sidebar_mode"))
    preset = {
        "name": "Curve",
        "type": _mode_val,  # 'BEZIER' or 'ELASTIC'
    }
    if _mode_val == 'ELASTIC':
        preset["amplitude"] = float(getattr(wm, 'tlfc_elastic_amplitude', _prop_default("tlfc_elastic_amplitude")))
        preset["period"] = float(getattr(wm, 'tlfc_elastic_period', _prop_default("tlfc_elastic_period")))
    else:
        preset["h1x"] = float(wm.tlfc_h1x)
        preset["h1y"] = float(wm.tlfc_h1y)
        preset["h2x"] = float(wm.tlfc_h2x)
        preset["h2y"] = float(wm.tlfc_h2y)
    presets.append(preset)
    return _save_presets(presets)


def _apply_preset_index(wm, idx):
    presets = _load_presets()
    if idx < 0 or idx >= len(presets):
        return False
    p = presets[idx]

    # Switch to appropriate mode
    preset_type = p.get("type", _prop_default("tlfc_sidebar_mode"))
    wm.tlfc_sidebar_mode = preset_type

    if preset_type == "ELASTIC":
        wm.tlfc_elastic_amplitude = p.get("amplitude", _prop_default("tlfc_elastic_amplitude"))
        wm.tlfc_elastic_period = p.get("period", _prop_default("tlfc_elastic_period"))
    else:
        wm.tlfc_h1x = p.get("h1x", _prop_default("tlfc_h1x"))
        wm.tlfc_h1y = p.get("h1y", _prop_default("tlfc_h1y"))
        wm.tlfc_h2x = p.get("h2x", _prop_default("tlfc_h2x"))
        wm.tlfc_h2y = p.get("h2y", _prop_default("tlfc_h2y"))
    return True


def _delete_preset_index(idx):
    presets = list(_load_presets())
    if idx < 0 or idx >= len(presets):
        return False
    presets.pop(idx)
    return _save_presets(presets)


def _draw_preset_tile(x0, y0, x1, y1, preset, size_scale):
    _draw_rect(x0, y0, x1, y1, TLFC_COLORS["preset_tile_bg"])
    _draw_aa_line_strip([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)], TLFC_COLORS["preset_tile_border"], width=2.0)
    pad = max(4, int(5 * size_scale))
    ix0 = x0 + pad
    iy0 = y0 + pad + 10
    ix1 = x1 - pad
    iy1 = y1 - pad
    _draw_rect(ix0, iy0, ix1, iy1, TLFC_COLORS["preset_preview_bg"])
    _draw_aa_line_strip([(ix0, iy0), (ix1, iy0), (ix1, iy1), (ix0, iy1), (ix0, iy0)], TLFC_COLORS["preset_preview_border"], width=2.0)

    preset_type = preset.get("type", "BEZIER")
    pts = []
    preview_steps = 32

    if preset_type == "ELASTIC":
        # Draw elastic curve preview
        amplitude = preset.get("amplitude", _prop_default("tlfc_elastic_amplitude"))
        period = preset.get("period", _prop_default("tlfc_elastic_period"))
        for i in range(preview_steps):
            t = i / (preview_steps - 1.0)
            bx = t
            by = _elastic_ease_out_normalized(t, amplitude, period)
            # Clamp to preview box so overshoot doesn't bleed outside the tile
            by_clamped = max(0.0, min(1.0, by / 2.0))
            pts.append((ix0 + bx * (ix1 - ix0), iy0 + by_clamped * (iy1 - iy0)))
    else:
        # Draw bezier curve preview
        h1x = max(0.0, float(preset.get("h1x", _prop_default("tlfc_h1x"))))
        h1y = float(preset.get("h1y", _prop_default("tlfc_h1y")))
        h2x = min(1.0, float(preset.get("h2x", _prop_default("tlfc_h2x"))))
        h2y = float(preset.get("h2y", _prop_default("tlfc_h2y")))
        p0 = (0.0, 0.0)
        p1 = (h1x, h1y)
        p2 = (h2x, h2y)
        p3 = (1.0, 1.0)
        for i in range(preview_steps):
            t = i / (preview_steps - 1.0)
            bx, by = _bezier_point(t, p0, p1, p2, p3)
            pts.append((ix0 + bx * (ix1 - ix0), iy0 + by * (iy1 - iy0)))

    _draw_aa_line_strip(pts, TLFC_COLORS["curve_orange"], width=2.0)
    _draw_text_centered(x0, y0, x1, y0 + 12, preset.get("name", "P"), size=max(8, int(9 * size_scale)), color=TLFC_COLORS["preset_title_text"], truncate=True, pad=4)

# ---------- Drawing helpers ----------
def _draw_rect(x0, y0, x1, y1, color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    verts = [(x0, y0), (x1, y0), (x0, y1), (x1, y1)]
    batch = batch_for_shader(shader, 'TRI_STRIP', {"pos": verts})
    shader.bind()
    shader.uniform_float("color", color)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def _draw_aa_line_strip(points, color, width=1.0):
    if len(points) < 2:
        return
    try:
        vp = gpu.state.viewport_get()
        if len(vp) >= 4:
            viewport_size = (float(vp[2]), float(vp[3]))
        else:
            viewport_size = (1920.0, 1080.0)
    except Exception:
        viewport_size = (1920.0, 1080.0)

    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": points})
    shader.bind()
    shader.uniform_float("viewportSize", viewport_size)
    shader.uniform_float("lineWidth", max(1.0, float(width)))
    shader.uniform_float("color", color)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def _draw_filled_circle(x, y, r, color, steps=24):
    ns = bpy.app.driver_namespace
    cos_fn = ns.get('_tlfc_cos', math.cos)
    sin_fn = ns.get('_tlfc_sin', math.sin)
    verts = [(x, y)]
    for i in range(steps + 1):
        t = (i / steps) * 6.28318530718
        verts.append((
            x + r * cos_fn(t),
            y + r * sin_fn(t),
        ))
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": verts})
    shader.bind()
    shader.uniform_float("color", color)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def _draw_circle(x, y, r, color, steps=24, width=1.0):
    ns = bpy.app.driver_namespace
    cos_fn = ns.get('_tlfc_cos', math.cos)
    sin_fn = ns.get('_tlfc_sin', math.sin)
    pts = []
    for i in range(steps + 1):
        t = (i / steps) * 6.28318530718
        pts.append((
            x + r * cos_fn(t),
            y + r * sin_fn(t),
        ))
    _draw_aa_line_strip(pts, color, width=width)


def _draw_aa_circle(x, y, r, fill_color, outline_color, steps=28):
    # Keep original perceived thickness while improving edge quality.
    step_count = max(24, int(steps))
    _draw_filled_circle(x, y, max(1.0, r - 0.8), fill_color, steps=step_count)
    _draw_circle(x, y, r, outline_color, steps=step_count, width=2.0)


def _adjust_rgba(color, delta):
    return (
        _clamp01(color[0] + delta),
        _clamp01(color[1] + delta),
        _clamp01(color[2] + delta),
        color[3],
    )


def _button_state_colors(kind, state):
    if kind == "apply":
        base = TLFC_COLORS["button_apply_base"]
        border = TLFC_COLORS["button_apply_border"]
    elif kind == "auto_on":
        base = TLFC_COLORS["button_auto_on_base"]
        border = TLFC_COLORS["button_auto_on_border"]
    elif kind == "auto_off":
        base = TLFC_COLORS["button_auto_off_base"]
        border = TLFC_COLORS["button_auto_off_border"]
    elif kind == "preset":
        base = TLFC_COLORS["button_preset_base"]
        border = TLFC_COLORS["button_preset_border"]
    else:
        base = TLFC_COLORS["button_default_base"]
        border = TLFC_COLORS["button_default_border"]

    if state == "hover":
        return _adjust_rgba(base, 0.08), _adjust_rgba(border, 0.07), TLFC_COLORS["white"]
    if state == "pressed":
        return _adjust_rgba(base, -0.08), _adjust_rgba(border, -0.05), TLFC_COLORS["text_pressed"]
    return base, border, TLFC_COLORS["text_default"]


def _draw_text_clipped_left(x, y, max_width, text, size=10, color=TLFC_COLORS["white"], pad=0):
    clipped = _truncate_text_to_width(str(text), max(1.0, max_width - pad), size=size)
    if not clipped:
        return
    _draw_text(x, y, clipped, size=size, color=color)


def _button_token(op, kwargs):
    if op == "zoom":
        return f"zoom:{kwargs.get('mode', 'CENTER')}"
    if op == "interp":
        return f"interp:{kwargs.get('mode', 'LINEAR')}"
    if op == "preset_apply":
        return f"preset:{int(kwargs.get('idx', -1))}"
    if op == "set_mode":
        return f"set_mode:{kwargs.get('mode', 'BEZIER')}"
    return op

def _elastic_ease_out_normalized(t, amplitude=1.0, period=0.3):
    if t <= 0.0:
        return 0.0
    if t >= 1.0:
        return 1.0
    per = max(0.001, float(period))
    amp_in = max(0.0, float(amplitude))

    time = -float(t)
    f = 1.0

    if amp_in < 1.0:
        s = per / 4.0
        blend_t = abs(s)
        if amp_in > 0.0:
            f *= amp_in
        else:
            f = 0.0
        if blend_t > 1e-8 and abs(time) < blend_t:
            l = abs(time) / blend_t
            f = (f * l) + (1.0 - l)
        amp = 1.0
    else:
        amp = amp_in
        asin_arg = max(-1.0, min(1.0, 1.0 / amp))
        s = per / (2.0 * math.pi) * math.asin(asin_arg)

    return (f * (amp * math.pow(2.0, 10.0 * time) * math.sin((time - s) * (2.0 * math.pi) / per))) + 1.0


def _apply_elastic_to_segment(fc, k0, k1, amplitude, period):
    """Apply elastic ease out to keyframe segment using ELASTIC interpolation."""
    f0, v0 = k0.co[0], k0.co[1]
    f1, v1 = k1.co[0], k1.co[1]
    df = f1 - f0
    dv = v1 - v0
    if abs(df) < 1e-8:
        return False

    # Scale amplitude by value delta so large value changes can overshoot more.
    value_scale = max(1.0, abs(dv))
    amp_scaled = max(1.0, float(amplitude) * value_scale)

    # Remove existing keys strictly between k0 and k1
    existing = [kp for kp in fc.keyframe_points if f0 < kp.co[0] < f1]
    for kp in reversed(existing):
        try:
            fc.keyframe_points.remove(kp)
        except Exception:
            pass

    # Set keyframe interpolation to ELASTIC and apply parameters
    try:
        k0.interpolation = 'ELASTIC'
        k0.easing = 'EASE_OUT'
        k0.amplitude = amp_scaled
        k0.period = period * df
        k1.interpolation = 'ELASTIC'
    except Exception:
        # Fallback if ELASTIC is not supported
        return False

    return True


def _draw_text(x, y, text, size=12, color=TLFC_COLORS["white"]):
    font_id = 0
    blf.size(font_id, size)
    blf.color(font_id, *color)
    blf.position(font_id, x, y, 0)
    blf.draw(font_id, text)


def _clip_line_to_rect(p1, p2, x0, y0, x1, y1):
    """Cohen-Sutherland line clipping. Returns clipped [(x,y),(x,y)] or None."""
    lx1, ly1 = p1
    lx2, ly2 = p2
    # Trivial reject
    if lx1 < x0 and lx2 < x0:
        return None
    if lx1 > x1 and lx2 > x1:
        return None
    if ly1 < y0 and ly2 < y0:
        return None
    if ly1 > y1 and ly2 > y1:
        return None
    # Clip each endpoint
    dx = lx2 - lx1
    dy = ly2 - ly1
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, lx1 - x0), (dx, x1 - lx1), (-dy, ly1 - y0), (dy, y1 - ly1)):
        if p == 0:
            if q < 0:
                return None
        elif p < 0:
            r = q / p
            if r > t1:
                return None
            if r > t0:
                t0 = r
        else:
            r = q / p
            if r < t0:
                return None
            if r < t1:
                t1 = r
    return [(lx1 + t0 * dx, ly1 + t0 * dy), (lx1 + t1 * dx, ly1 + t1 * dy)]


# ---------- Data gathering ----------
def _collect_action_fcurves(anim_data):
    action = getattr(anim_data, "action", None) if anim_data else None
    if action is None:
        return []

    # Blender versions with classic Action API expose action.fcurves directly.
    direct = getattr(action, "fcurves", None)
    if direct is not None:
        try:
            return list(direct)
        except Exception:
            return []

    # Layered action fallback (newer APIs): try channel bags per strip/slot.
    out = []
    seen = set()
    layers = getattr(action, "layers", None)
    if not layers:
        return out

    slot_candidates = []
    active_slot = getattr(anim_data, "action_slot", None)
    if active_slot is not None:
        slot_candidates.append(active_slot)
    slots = getattr(action, "slots", None)
    if slots:
        try:
            slot_candidates.extend(list(slots))
        except Exception:
            pass

    for layer in layers:
        strips = getattr(layer, "strips", None)
        if not strips:
            continue
        for strip in strips:
            channelbag_fn = getattr(strip, "channelbag", None)
            if not callable(channelbag_fn):
                continue
            for slot in slot_candidates:
                try:
                    bag = channelbag_fn(slot)
                except Exception:
                    continue
                if not bag:
                    continue
                bag_fcurves = getattr(bag, "fcurves", None)
                if not bag_fcurves:
                    continue
                try:
                    for fc in bag_fcurves:
                        fc_id = fc.as_pointer()
                        if fc_id in seen:
                            continue
                        seen.add(fc_id)
                        out.append(fc)
                except Exception:
                    continue
    return out


def _selected_fcurves_with_selected_keys(context):
    candidates = []
    for attr in ("selected_editable_fcurves", "selected_visible_fcurves", "visible_fcurves"):
        fcurves = getattr(context, attr, None)
        if fcurves:
            candidates = list(fcurves)
            break
    if not candidates:
        obj = context.active_object
        if obj and obj.animation_data:
            candidates = _collect_action_fcurves(obj.animation_data)

    out = []
    seen = set()
    for fc in candidates:
        fc_id = id(fc)
        if fc_id in seen:
            continue
        seen.add(fc_id)

        all_keys = list(fc.keyframe_points)
        sel_keys = []
        for kp in all_keys:
            if kp.select_control_point or kp.select_left_handle or kp.select_right_handle:
                sel_keys.append(kp)

        # In Timeline/Dopesheet it is common to select channels without key points.
        if sel_keys or getattr(fc, "select", False):
            out.append((fc, sel_keys, all_keys))
    return out

def _clamp01(x):
    return max(0.0, min(1.0, x))

def _focused_curve_item(context, selected_items):
    if not selected_items:
        return None
    active_fc = getattr(context, "active_editable_fcurve", None)
    if active_fc is not None:
        for item in selected_items:
            if item[0] == active_fc:
                return item
    return selected_items[0]


def _focused_segment(context, selected_items):
    item = _focused_curve_item(context, selected_items)
    if item is None:
        return None

    fc, sel_keys, all_keys = item
    key_source = list(sel_keys) if len(sel_keys) >= 2 else list(all_keys)
    if len(key_source) < 2:
        return None

    key_source.sort(key=lambda kp: kp.co[0])
    frame_now = context.scene.frame_current
    pair = None
    for i in range(len(key_source) - 1):
        a = key_source[i]
        b = key_source[i + 1]
        if a.co[0] <= frame_now <= b.co[0]:
            pair = (a, b)
            break
    if pair is None:
        pair = (key_source[0], key_source[1])

    k0, k1 = pair
    f0, v0 = k0.co[0], k0.co[1]
    f1, v1 = k1.co[0], k1.co[1]
    df = f1 - f0
    dv = v1 - v0
    if abs(df) < 1e-8:
        return None
    if abs(dv) < 1e-8:
        dv = 1.0

    def to_norm(pt):
        return ((pt[0] - f0) / df, (pt[1] - v0) / dv)

    c1 = to_norm(k0.handle_right)
    c2 = to_norm(k1.handle_left)
    return {
        "fc": fc,
        "k0": k0,
        "k1": k1,
        "f0": f0,
        "v0": v0,
        "df": df,
        "dv": dv,
        "c1": c1,
        "c2": c2,
    }


def _segment_from_selected_key(context, selected_items):
    item = _focused_curve_item(context, selected_items)
    if item is None:
        return None

    fc, sel_keys, all_keys = item
    if not sel_keys:
        return None

    key_sorted = sorted(all_keys, key=lambda kp: kp.co[0])
    key_pos = {id(kp): i for i, kp in enumerate(key_sorted)}
    frame_now = context.scene.frame_current

    # Prefer the selected key closest to current frame.
    cur = min(sel_keys, key=lambda kp: abs(kp.co[0] - frame_now))
    idx = key_pos.get(id(cur), -1)
    if idx < 0 or idx >= len(key_sorted) - 1:
        return None

    nxt = key_sorted[idx + 1]
    if nxt.co[0] <= cur.co[0]:
        return None

    f0, v0 = cur.co[0], cur.co[1]
    f1, v1 = nxt.co[0], nxt.co[1]
    df = f1 - f0
    dv = v1 - v0
    if abs(df) < 1e-8:
        return None
    if abs(dv) < 1e-8:
        dv = 1.0

    def to_norm(pt):
        return ((pt[0] - f0) / df, (pt[1] - v0) / dv)

    return {
        "fc": fc,
        "k0": cur,
        "k1": nxt,
        "f0": f0,
        "v0": v0,
        "df": df,
        "dv": dv,
        "c1": to_norm(cur.handle_right),
        "c2": to_norm(nxt.handle_left),
    }

def _bezier_point(t, p0, p1, p2, p3):
    u = 1.0 - t
    b0 = u * u * u
    b1 = 3.0 * u * u * t
    b2 = 3.0 * u * t * t
    b3 = t * t * t
    return (
        b0 * p0[0] + b1 * p1[0] + b2 * p2[0] + b3 * p3[0],
        b0 * p0[1] + b1 * p1[1] + b2 * p2[1] + b3 * p3[1],
    )

def _editor_to_screen(nx, ny, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y):
    vx = (nx - 0.5) * zoom + 0.5 + pan_x
    vy = (ny - 0.5) * zoom + 0.5 + pan_y
    return (
        sx0 + vx * (sx1 - sx0),
        sy0 + vy * (sy1 - sy0),
    )


def _screen_to_editor(px, py, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y):
    vx = (px - sx0) / max(1e-8, (sx1 - sx0))
    vy = (py - sy0) / max(1e-8, (sy1 - sy0))
    nx = ((vx - 0.5 - pan_x) / max(1e-8, zoom)) + 0.5
    ny = ((vy - 0.5 - pan_y) / max(1e-8, zoom)) + 0.5
    return nx, ny


def _constrain_handle(which, x, y):
    # Asymmetric x limits per request; y is intentionally unbounded.
    # if which == "h1":
    #     return max(0.0, x), y
    # return min(1.0, x), y
    return _clamp01(x), y


def _snap_edge(x, y, threshold):
    sx, sy = x, y
    for edge in (0.0, 1.0):
        if abs(sx - edge) <= threshold:
            sx = edge
        if abs(sy - edge) <= threshold:
            sy = edge
    return sx, sy


def _snap_grid(x, y, subdiv):
    if subdiv <= 0:
        return x, y
    step = 1.0 / float(subdiv)
    return round(x / step) * step, round(y / step) * step


def _point_in_rect(px, py, rect):
    x0, y0, x1, y1 = rect
    return x0 <= px <= x1 and y0 <= py <= y1


def _overlay_buttons(_wm):
    auto_label = _t(_wm, "button.auto_on", "Auto: ON") if getattr(_wm, "tlfc_auto_apply", False) else _t(_wm, "button.auto_off", "Auto: OFF")
    return [
        [
            # {"label": _t(_wm, "button.zoom_in", "Zoom +"), "op": "zoom", "kwargs": {"mode": "IN"}},
            # {"label": _t(_wm, "button.zoom_out", "Zoom -"), "op": "zoom", "kwargs": {"mode": "OUT"}},
            {"label": _t(_wm, "button.center", "Center"), "op": "zoom", "kwargs": {"mode": "CENTER"}},
        ],
        [
            {"label": _t(_wm, "button.mirror", "Mirror"), "op": "mirror", "kwargs": {}},
            {"label": _t(_wm, "button.copy_selected", "Copy Sel."), "op": "read", "kwargs": {}},
            {"label": _t(_wm, "button.reset", "Reset"), "op": "reset", "kwargs": {}},
        ],
        [
            {"label": _t(_wm, "button.linear", "Linear"), "op": "interp", "kwargs": {"mode": "LINEAR"}},
            {"label": _t(_wm, "button.constant", "Constant"), "op": "interp", "kwargs": {"mode": "CONSTANT"}},
            {"label": auto_label, "op": "toggle_auto", "kwargs": {}},
            {"label": _t(_wm, "button.save", "Save"), "op": "preset_save", "kwargs": {}},
        ],
    ]


def _invoke_overlay_button(context, op, kwargs, shift=False):
    try:
        if op == "zoom":
            bpy.ops.tlfc.editor_zoom(mode=kwargs.get("mode", "CENTER"))
        elif op == "preset_save":
            bpy.ops.tlfc.save_preset()
        elif op == "preset_apply":
            idx = int(kwargs.get("idx", -1))
            if shift:
                _delete_preset_index(idx)
            elif _apply_preset_index(context.window_manager, idx):
                if context.window_manager.tlfc_auto_apply:
                    bpy.ops.tlfc.apply_curve()
        elif op == "toggle_auto":
            context.window_manager.tlfc_auto_apply = not context.window_manager.tlfc_auto_apply
        elif op == "apply":
            bpy.ops.tlfc.apply_curve()
        elif op == "interp":
            bpy.ops.tlfc.set_interpolation(mode=kwargs.get("mode", "LINEAR"))
        elif op == "mirror":
            bpy.ops.tlfc.mirror_curve()
        elif op == "reset":
            bpy.ops.tlfc.reset_curve()
        elif op == "read":
            bpy.ops.tlfc.read_curve()
        elif op == "set_mode":
            context.window_manager.tlfc_sidebar_mode = kwargs.get("mode", "BEZIER")
    except Exception:
        pass


def _iter_selected_segments(context):
    selected_items = _selected_fcurves_with_selected_keys(context)
    for fc, sel_keys, all_keys in selected_items:
        if not sel_keys:
            continue
        key_sorted = sorted(all_keys, key=lambda kp: kp.co[0])
        selected_ids = {id(kp) for kp in sel_keys}
        for i, kp in enumerate(key_sorted[:-1]):
            if id(kp) in selected_ids:
                nxt = key_sorted[i + 1]
                if nxt.co[0] > kp.co[0]:
                    yield fc, kp, nxt


def _apply_editor_curve_to_segment(k0, k1, h1x, h1y, h2x, h2y):
    f0, v0 = k0.co[0], k0.co[1]
    f1, v1 = k1.co[0], k1.co[1]
    df = f1 - f0
    dv = v1 - v0
    if abs(df) < 1e-8:
        return False

    k0.interpolation = 'BEZIER'
    k1.interpolation = 'BEZIER'
    k0.handle_right_type = 'FREE'
    k1.handle_left_type = 'FREE'
    h1x, h1y = _constrain_handle("h1", h1x, h1y)
    h2x, h2y = _constrain_handle("h2", h2x, h2y)
    k0.handle_right = (f0 + h1x * df, v0 + h1y * dv)
    k1.handle_left = (f0 + h2x * df, v0 + h2y * dv)
    return True


def _focused_curve_info(context, selected_items):
    item = _focused_curve_item(context, selected_items)
    if item is None:
        return None

    fc, sel_keys, all_keys = item
    key_source = sel_keys if sel_keys else all_keys
    frames = [kp.co[0] for kp in key_source]
    values = [kp.co[1] for kp in key_source]
    frame_now = context.scene.frame_current
    try:
        eval_now = fc.evaluate(frame_now)
    except Exception:
        eval_now = None

    return {
        "name": f"{fc.data_path}[{fc.array_index}]",
        "group": fc.group.name if fc.group else "None",
        "keys_total": len(all_keys),
        "keys_selected": len(sel_keys),
        "frame_span": (min(frames), max(frames)) if frames else None,
        "value_span": (min(values), max(values)) if values else None,
        "eval_now": eval_now,
        "modifiers": len(fc.modifiers),
        "extrapolation": fc.extrapolation,
    }
# ---------- Draw callback ----------
def draw_editor_sidebar():
    ctx = bpy.context
    if not manager_compat.workspace_runtime_allows_context(ctx):
        return
    # A retained draw callback can be dispatched while registration is still
    # incomplete or during unload.  Treat the RNA owner ledger as the single
    # readiness boundary; never synthesize or partially default owned state.
    if not _runtime_rna_ready():
        return
    region = ctx.region
    wm = ctx.window_manager
    space = ctx.space_data
    if not _supports_editor_space(space):
        return
    if region is None or region.type != 'WINDOW':
        return
    if not _is_editor_enabled(ctx.area):
        return
    is_info_space = (space.type == 'INFO')
    size_scale = wm.tlfc_display_size
    if is_info_space:
        # Info editor variant: keep sidebar full-width whenever active.
        x0 = 0
        x1 = region.width
        pad_outer = 0
    else:
        sidebar_w = int(region.width * (wm.tlfc_sidebar_width / 100.0))
        sidebar_w = min(region.width, max(int(TLFC_UI_NUMBERS["sidebar_min_px"]), sidebar_w))
        pad_outer = min(wm.tlfc_outer_pad, region.width * 0.25, region.height * 0.25)
        x1 = region.width - pad_outer
        x0 = max(0, x1 - sidebar_w)
    y0 = pad_outer
    y1 = region.height - pad_outer
    # Panel background and border
    bg = (TLFC_COLORS["panel_bg"][0], TLFC_COLORS["panel_bg"][1], TLFC_COLORS["panel_bg"][2], 1.0)
    border = (TLFC_COLORS["panel_border"][0], TLFC_COLORS["panel_border"][1], TLFC_COLORS["panel_border"][2], 1.0)
    if getattr(wm, "tlfc_hover_sidebar_edge", False) or getattr(wm, "tlfc_dragging_sidebar", False):
        border = (TLFC_COLORS["panel_border_hover"][0], TLFC_COLORS["panel_border_hover"][1], TLFC_COLORS["panel_border_hover"][2], 1.0)
    _draw_rect(x0, y0, x1, y1, bg)
    full_width_panel = (x0 <= 0 and x1 >= region.width)
    if pad_outer == 0:
        # Keep left edge invisible when panel spans entire editor width.
        if not full_width_panel:
            _draw_aa_line_strip([(x0, y0), (x0, y1)], border, width=2.0)
        _draw_aa_line_strip([(x1, y0), (x1, y1)], border, width=2.0)
    else:
        if full_width_panel:
            _draw_aa_line_strip([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], border, width=2.0)
        else:
            _draw_aa_line_strip([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)], border, width=2.0)
    title_top_pad = max(6, int(8 * size_scale))
    selected_items = _selected_fcurves_with_selected_keys(ctx)
    ns = bpy.app.driver_namespace

    sidebar_mode = getattr(wm, 'tlfc_sidebar_mode', _prop_default("tlfc_sidebar_mode"))
    hover_token = getattr(wm, "tlfc_hover_button", "")
    pressed_token = getattr(wm, "tlfc_pressed_button", "")
    _tab_btn_font = max(9, int(10 * size_scale))

    # Tab bar layout (sits below top padding)
    tab_h_val = max(14, int(16 * size_scale))
    tab_gap_below = max(3, int(4 * size_scale))
    tab_y1 = y1 - title_top_pad
    tab_y0 = tab_y1 - tab_h_val

    # Square easing editor (0..1 mapped space)
    # Preserve a usable graph when the native editor is narrower than the
    # normal margins; a reversed rectangle also reverses pointer mapping.
    pad = min(12, (x1 - x0) * 0.25)
    sx0 = x0 + pad
    sx1_limit = x1 - pad
    sy1 = tab_y0 - tab_gap_below
    extra_tab_space = tab_h_val + tab_gap_below
    max_h = max(80, (y1 - y0) - 190 - extra_tab_space)
    sq = min(max_h, sx1_limit - sx0)
    sx1 = sx0 + sq
    sy0 = sy1 - sq

    _draw_rect(sx0, sy0, sx1, sy1, TLFC_COLORS["graph_bg"])
    _draw_aa_line_strip([(sx0, sy0), (sx1, sy0), (sx1, sy1), (sx0, sy1), (sx0, sy0)], TLFC_COLORS["preset_preview_border"], width=1.0)

    # Draw tab buttons (Bezier | Elastic) and collect rects for hit-testing
    _pending_tab_buttons = []
    _tab_defs = [
        ("tab.bezier", "Bezier", "BEZIER"),
        ("tab.elastic", "Elastic", "ELASTIC"),
    ]
    _tab_total_w = sx1 - sx0
    _tab_gap = min(1, _tab_total_w * 0.25)
    _tab_w = (_tab_total_w - _tab_gap) / 2.0
    for _ti, (_tkey, _tdefault, _tmode) in enumerate(_tab_defs):
        _tx0 = sx0 + _ti * (_tab_w + _tab_gap)
        _tx1 = _tx0 + _tab_w
        _is_active = (sidebar_mode == _tmode)
        _token = _button_token("set_mode", {"mode": _tmode})
        _tstate = "pressed" if pressed_token == _token else ("hover" if hover_token == _token else "normal")
        if _is_active:
            _tab_bg = TLFC_COLORS["tab_active_bg"]
            _tab_tc = TLFC_COLORS["tab_active_text"]
        else:
            _tab_bg = TLFC_COLORS["tab_inactive_bg"]
            _tab_tc = TLFC_COLORS["tab_inactive_text"]
        if _tstate == "hover":
            _tab_bg = _adjust_rgba(_tab_bg, 0.08)
            if not _is_active:
                _tab_tc = TLFC_COLORS["tab_inactive_hover_text"]
        elif _tstate == "pressed":
            _tab_bg = _adjust_rgba(_tab_bg, -0.06)
        _draw_rect(_tx0, tab_y0, _tx1, tab_y1, _tab_bg)
        if _is_active:
            _draw_aa_line_strip([(_tx0, tab_y0), (_tx1, tab_y0), (_tx1, tab_y1), (_tx0, tab_y1), (_tx0, tab_y0)], TLFC_COLORS["tab_active_outline"], width=1.0)
        _draw_text_centered(_tx0, tab_y0, _tx1, tab_y1, _t(wm, _tkey, _tdefault), size=_tab_btn_font, color=_tab_tc, truncate=True, pad=4)
        _pending_tab_buttons.append({
            "rect_local": (_tx0, tab_y0, _tx1, tab_y1),
            "op": "set_mode",
            "kwargs": {"mode": _tmode},
            "id": _token,
        })

    zoom = wm.tlfc_view_zoom
    pan_x = wm.tlfc_view_pan_x
    pan_y = wm.tlfc_view_pan_y

    # Grid for readability in normalized space with pan/zoom.
    # Extended grid range to show lines outside (0,0)-(1,1) area
    subdiv = max(1, wm.tlfc_grid_subdiv)

    # Calculate extended grid range based on zoom and pan
    # We want to draw grid lines that are visible in the viewport
    grid_extend = 2.0  # Draw grid lines from -2 to 3 in normalized space
    grid_min = -grid_extend
    grid_max = 1.0 + grid_extend
    grid_total_divs = int((grid_max - grid_min) * subdiv)

    # Determine line width based on zoom level
    base_width = 2.0
    grid_line_width = base_width * (0.8 + 0.2 * min(zoom, 3.0))
    axis_line_width = grid_line_width * 1.8

    for i in range(grid_total_divs + 1):
        g = grid_min + i / float(subdiv)
        va = _editor_to_screen(g, grid_min, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        vb = _editor_to_screen(g, grid_max, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        ha = _editor_to_screen(grid_min, g, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        hb = _editor_to_screen(grid_max, g, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)

        # Highlight x=0 and y=0 axes
        is_x_axis = abs(g) < 1e-6  # g ≈ 0
        is_boundary = (abs(g) < 1e-6 or abs(g - 1.0) < 1e-6)  # g = 0 or g = 1

        if is_x_axis:
            # X=0 and Y=0 axes - bright highlight
            col = TLFC_COLORS["grid_axis"]
            width = axis_line_width
        elif is_boundary:
            # Boundary lines at 0 and 1
            col = TLFC_COLORS["grid_boundary"]
            width = grid_line_width
        else:
            # Regular grid lines
            col = TLFC_COLORS["grid_regular"]
            width = grid_line_width * 0.8

        # Draw vertical line (clipped)
        v_clipped = _clip_line_to_rect(va, vb, sx0, sy0, sx1, sy1)
        if v_clipped:
            _draw_aa_line_strip(v_clipped, col, width=width)

        # Draw horizontal line (clipped)
        h_clipped = _clip_line_to_rect(ha, hb, sx0, sy0, sx1, sy1)
        if h_clipped:
            _draw_aa_line_strip(h_clipped, col, width=width)

    # Helper: clamp a screen-space point to inside the graph view rect.
    def _clamp_to_view(px, py):
        return (max(sx0, min(sx1, px)), max(sy0, min(sy1, py)))

    # Helper: compute smart text offset so a label near handle (hx,hy) stays inside view.
    def _label_pos(hx, hy, lbl_w, lbl_h, off_x, off_y):
        tx = hx + off_x
        ty = hy + off_y
        tx = max(sx0 + 2, min(sx1 - lbl_w - 2, tx))
        ty = max(sy0 + 2, min(sy1 - lbl_h - 2, ty))
        return tx, ty

    if sidebar_mode == 'ELASTIC':
        # --- Elastic mode ---
        # Editor ranges: amplitude 0.0–1.0, period 0.05–1.0
        _el_amp = _clamp_prop("tlfc_elastic_amplitude", getattr(wm, 'tlfc_elastic_amplitude', _prop_default("tlfc_elastic_amplitude")))
        _el_per = _clamp_prop("tlfc_elastic_period", getattr(wm, 'tlfc_elastic_period', _prop_default("tlfc_elastic_period")))

        # --- Draw elastic curve, clipped to the graph box via scissor ---
        _el_n = max(96, wm.tlfc_samples * 3)
        _el_pts = []
        for _si in range(_el_n):
            _st = _si / (_el_n - 1.0)
            _sv = _elastic_ease_out_normalized(_st, _el_amp, _el_per) * 0.5
            _el_pts.append(_editor_to_screen(_st, _sv, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y))

        # Proper segment-level clip using Cohen-Sutherland (matches grid behavior).
        for _i in range(len(_el_pts) - 1):
            _seg = _clip_line_to_rect(_el_pts[_i], _el_pts[_i + 1], sx0, sy0, sx1, sy1)
            if _seg:
                _draw_aa_line_strip(_seg, TLFC_COLORS["elastic_curve"], width=4.0)

        # Handle positions in normalized editor space mapped from configured ranges.
        _amp_norm = _prop_to_unit("tlfc_elastic_amplitude", _el_amp)
        _per_norm = _prop_to_unit("tlfc_elastic_period", _el_per)
        p1s_raw = _editor_to_screen(TLFC_UI_NUMBERS["elastic_handle_x"], _amp_norm, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        p2s_raw = _editor_to_screen(_per_norm, TLFC_UI_NUMBERS["elastic_handle_y"], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        # Clamp handle positions to view rect for drawing and hit-testing.
        p1s = _clamp_to_view(*p1s_raw)
        p2s = _clamp_to_view(*p2s_raw)

        # --- Start / end point markers (only when inside view) ---
        _p_start = _editor_to_screen(0.0, 0.0, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _p_end   = _editor_to_screen(1.0, 0.5, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _ep_r = 4.0 * size_scale
        if sx0 <= _p_start[0] <= sx1 and sy0 <= _p_start[1] <= sy1:
            _draw_aa_circle(_p_start[0], _p_start[1], _ep_r, TLFC_COLORS["endpoint_fill"], TLFC_COLORS["endpoint_outline"])
        if sx0 <= _p_end[0] <= sx1 and sy0 <= _p_end[1] <= sy1:
            _draw_aa_circle(_p_end[0], _p_end[1], _ep_r, TLFC_COLORS["endpoint_fill"], TLFC_COLORS["endpoint_outline"])

        # --- Axis guide lines (clipped to view) ---
        _g_amp_bot = _editor_to_screen(TLFC_UI_NUMBERS["elastic_handle_x"], 0.0, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _g_amp_top = _editor_to_screen(TLFC_UI_NUMBERS["elastic_handle_x"], 1.0, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _gc = _clip_line_to_rect(_g_amp_bot, _g_amp_top, sx0, sy0, sx1, sy1)
        if _gc:
            _draw_aa_line_strip(_gc, TLFC_COLORS["elastic_amp_guide"], width=4.0)
        _g_per_l = _editor_to_screen(0.0, TLFC_UI_NUMBERS["elastic_handle_y"], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _g_per_r = _editor_to_screen(1.0, TLFC_UI_NUMBERS["elastic_handle_y"], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        _gp = _clip_line_to_rect(_g_per_l, _g_per_r, sx0, sy0, sx1, sy1)
        if _gp:
            _draw_aa_line_strip(_gp, TLFC_COLORS["elastic_per_guide"], width=4.0)

        # --- Handle circles (drawn at clamped positions, always inside view) ---
        hover_handle = getattr(wm, 'tlfc_hover_handle', '')
        h1_radius = 7.0 * size_scale if hover_handle == 'h1' else 5.4 * size_scale
        h2_radius = 7.0 * size_scale if hover_handle == 'h2' else 5.4 * size_scale
        h1_alpha  = 1.0 if hover_handle == 'h1' else 0.92
        h2_alpha  = 1.0 if hover_handle == 'h2' else 0.92
        _draw_aa_circle(p1s[0], p1s[1], h1_radius, TLFC_COLORS["handle_amp_fill"], (TLFC_COLORS["handle_outline"][0], TLFC_COLORS["handle_outline"][1], TLFC_COLORS["handle_outline"][2], h1_alpha))
        _draw_aa_circle(p2s[0], p2s[1], h2_radius, TLFC_COLORS["handle_per_fill"], (TLFC_COLORS["handle_outline"][0], TLFC_COLORS["handle_outline"][1], TLFC_COLORS["handle_outline"][2], h2_alpha))

        # --- Labels next to handles, kept inside view ---
        _lbl_sz = max(8, int(9 * size_scale))
        _lbl_off = int(7 * size_scale)
        _lbl_h   = _lbl_sz + 2
        _a_text = "Amp: {:.2f}".format(_el_amp)
        _p_text = "Per: {:.3f}".format(_el_per)
        blf.size(0, _lbl_sz)
        _a_w = blf.dimensions(0, _a_text)[0]
        _p_w = blf.dimensions(0, _p_text)[0]
        _ax, _ay = _label_pos(p1s[0], p1s[1], _a_w, _lbl_h, _lbl_off, -4)
        _px, _py = _label_pos(p2s[0], p2s[1], _p_w, _lbl_h, -4, _lbl_off)
        _draw_text(_ax, _ay, _a_text, size=_lbl_sz, color=TLFC_COLORS["elastic_amp_label"])
        _draw_text(_px, _py, _p_text, size=_lbl_sz, color=TLFC_COLORS["elastic_per_label"])

    else:
        # --- Bezier mode ---
        p0 = (0.0, 0.0)
        p1 = (wm.tlfc_h1x, wm.tlfc_h1y)
        p2 = (wm.tlfc_h2x, wm.tlfc_h2y)
        p3 = (1.0, 1.0)
        p0s = _editor_to_screen(p0[0], p0[1], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        p3s = _editor_to_screen(p3[0], p3[1], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        p1s_raw = _editor_to_screen(p1[0], p1[1], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        p2s_raw = _editor_to_screen(p2[0], p2[1], sx0, sy0, sx1, sy1, zoom, pan_x, pan_y)
        # Clamp handle screen positions so they and their UI stay inside the view box.
        p1s = _clamp_to_view(*p1s_raw)
        p2s = _clamp_to_view(*p2s_raw)

        # Handle lines: clip from anchor circle to (clamped) handle – always stays inside.
        _p0_in = sx0 <= p0s[0] <= sx1 and sy0 <= p0s[1] <= sy1
        _p3_in = sx0 <= p3s[0] <= sx1 and sy0 <= p3s[1] <= sy1
        _hl1 = _clip_line_to_rect(p0s, p1s, sx0, sy0, sx1, sy1)
        if _hl1:
            _draw_aa_line_strip(_hl1, TLFC_COLORS["handle_line"], width=2.0)
        _hl2 = _clip_line_to_rect(p3s, p2s, sx0, sy0, sx1, sy1)
        if _hl2:
            _draw_aa_line_strip(_hl2, TLFC_COLORS["handle_line"], width=2.0)

        # Bezier curve – scissor-clip to view rect so it never bleeds outside.
        curve_pts = []
        samples = wm.tlfc_samples
        n = max(48, samples * 2)
        for i in range(n):
            t = i / (n - 1)
            bx, by = _bezier_point(t, p0, p1, p2, p3)
            curve_pts.append(_editor_to_screen(bx, by, sx0, sy0, sx1, sy1, zoom, pan_x, pan_y))
        # Segment-level clip using Cohen-Sutherland (matches grid behavior).
        for _i in range(len(curve_pts) - 1):
            _cs = _clip_line_to_rect(curve_pts[_i], curve_pts[_i + 1], sx0, sy0, sx1, sy1)
            if _cs:
                _draw_aa_line_strip(_cs, TLFC_COLORS["curve_orange"], width=4.0)

        # --- Start / end point markers (only when anchor is inside view) ---
        _ep_r = 4.0 * size_scale
        if sx0 <= p0s[0] <= sx1 and sy0 <= p0s[1] <= sy1:
            _draw_aa_circle(p0s[0], p0s[1], _ep_r, TLFC_COLORS["endpoint_fill"], TLFC_COLORS["endpoint_outline"])
        if sx0 <= p3s[0] <= sx1 and sy0 <= p3s[1] <= sy1:
            _draw_aa_circle(p3s[0], p3s[1], _ep_r, TLFC_COLORS["endpoint_fill"], TLFC_COLORS["endpoint_outline"])

        # --- Handle circles (always drawn at clamped positions, always inside view) ---
        hover_handle = getattr(wm, 'tlfc_hover_handle', '')
        h1_radius = 7.0 * size_scale if hover_handle == 'h1' else 5.4 * size_scale
        h2_radius = 7.0 * size_scale if hover_handle == 'h2' else 5.4 * size_scale
        h1_alpha  = 1.0 if hover_handle == 'h1' else 0.92
        h2_alpha  = 1.0 if hover_handle == 'h2' else 0.92
        _draw_aa_circle(p1s[0], p1s[1], h1_radius, TLFC_COLORS["handle_amp_fill"], (TLFC_COLORS["handle_outline"][0], TLFC_COLORS["handle_outline"][1], TLFC_COLORS["handle_outline"][2], h1_alpha))
        _draw_aa_circle(p2s[0], p2s[1], h2_radius, TLFC_COLORS["handle_per_fill"], (TLFC_COLORS["handle_outline"][0], TLFC_COLORS["handle_outline"][1], TLFC_COLORS["handle_outline"][2], h2_alpha))

        # --- Labels for handle values, kept inside view ---
        _lbl_sz  = max(8, int(9 * size_scale))
        _lbl_off = int(7 * size_scale)
        _lbl_h   = _lbl_sz + 2
        _h1_text = f"({wm.tlfc_h1x:.2f}, {wm.tlfc_h1y:.2f})"
        _h2_text = f"({wm.tlfc_h2x:.2f}, {wm.tlfc_h2y:.2f})"
        blf.size(0, _lbl_sz)
        _h1_w = blf.dimensions(0, _h1_text)[0]
        _h2_w = blf.dimensions(0, _h2_text)[0]
        _h1x, _h1y = _label_pos(p1s[0], p1s[1], _h1_w, _lbl_h, _lbl_off, -4)
        _h2x, _h2y = _label_pos(p2s[0], p2s[1], _h2_w, _lbl_h, -_h2_w - _lbl_off, _lbl_off)
        _draw_text(_h1x, _h1y, _h1_text, size=_lbl_sz, color=TLFC_COLORS["bezier_h1_label"])
        _draw_text(_h2x, _h2y, _h2_text, size=_lbl_sz, color=TLFC_COLORS["bezier_h2_label"])

    area_ptr = ctx.area.as_pointer() if ctx.area else 0
    ui_map = ns.get(EDITOR_UI_KEY)
    if not isinstance(ui_map, dict):
        ui_map = {}
        ns[EDITOR_UI_KEY] = ui_map

    ui_map[area_ptr] = {
        "area": ctx.area.as_pointer() if ctx.area else 0,
        "space_type": space.type,
        "region": region.as_pointer(),
        "region_w": region.width,
        "panel_rect_abs": (region.x + x0, region.y + y0, region.x + x1, region.y + y1),
        "panel_x1_abs": (region.x + x1),
        "sidebar_edge_abs": (region.x + x0),
        "sidebar_edge_hit_px": SIDEBAR_EDGE_HIT_PX,
        "rect": (sx0, sy0, sx1, sy1),
        "rect_abs": (region.x + sx0, region.y + sy0, region.x + sx1, region.y + sy1),
        "h1": p1s,
        "h2": p2s,
        "h1_abs": (region.x + p1s[0], region.y + p1s[1]),
        "h2_abs": (region.x + p2s[0], region.y + p2s[1]),
        "buttons_abs": [],
    }
    # Register tab buttons for click hit-testing (must happen after ui_map is initialised)
    for _tb in _pending_tab_buttons:
        _rx0, _ry0, _rx1, _ry1 = _tb["rect_local"]
        ui_map[area_ptr]["buttons_abs"].append({
            "rect": (region.x + _rx0, region.y + _ry0, region.x + _rx1, region.y + _ry1),
            "op": _tb["op"],
            "kwargs": _tb["kwargs"],
            "id": _tb["id"],
        })

    # Draw interactive overlay buttons with responsive placement.
    bx0 = sx1 + 12
    bx1 = x1 - 10
    gap = max(4, int(6 * size_scale))
    row_h = max(18, int(22 * size_scale))
    btn_font = max(9, int(10 * size_scale))
    apply_h = max(24, int(30 * size_scale))
    tile = max(38, int(46 * size_scale))
    presets = _load_presets()
    side_has_space = (bx1 - bx0) > 80
    if side_has_space:
        # If side buttons would truncate text, switch to a single-column layout for more width.
        force_column = False
        blf.size(0, btn_font)
        for row in _overlay_buttons(wm):
            cols = len(row)
            cell_w = (bx1 - bx0 - gap * (cols - 1)) / max(1, cols)
            for b in row:
                if blf.dimensions(0, str(b.get("label", "")))[0] > (cell_w - 12):
                    force_column = True
                    break
            if force_column:
                break

        # Apply button pinned to panel bottom at all times.
        ay0 = y0 + 10
        ay1 = ay0 + apply_h
        apply_token = _button_token("apply", {})
        apply_state = "pressed" if pressed_token == apply_token else ("hover" if hover_token == apply_token else "normal")
        apply_fill, apply_border, apply_text = _button_state_colors("apply", apply_state)
        _draw_rect(bx0, ay0, bx1, ay1, apply_fill)
        # _draw_aa_line_strip([(bx0, ay0), (bx1, ay0), (bx1, ay1), (bx0, ay1), (bx0, ay0)], apply_border, width=1.0)
        _draw_text_centered(bx0, ay0, bx1, ay1, _t(wm, "button.apply_curve", "APPLY CURVE"), size=btn_font, color=apply_text, truncate=True, pad=8)
        ui_map[area_ptr]["buttons_abs"].append({
            "rect": (region.x + bx0, region.y + ay0, region.x + bx1, region.y + ay1),
            "op": "apply",
            "kwargs": {},
            "id": apply_token,
        })

        by = y1 - 42
        if force_column:
            for b in [btn for row in _overlay_buttons(wm) for btn in row]:
                rx0 = bx0
                rx1 = bx1
                ry1 = by
                ry0 = ry1 - row_h
                token = _button_token(b["op"], b["kwargs"])
                state = "pressed" if pressed_token == token else ("hover" if hover_token == token else "normal")
                kind = "auto_on" if (b["op"] == "toggle_auto" and wm.tlfc_auto_apply) else ("auto_off" if b["op"] == "toggle_auto" else "default")
                fill, border_col, text_col = _button_state_colors(kind, state)
                _draw_rect(rx0, ry0, rx1, ry1, fill)
                # _draw_aa_line_strip([(rx0, ry0), (rx1, ry0), (rx1, ry1), (rx0, ry1), (rx0, ry0)], border_col, width=1.0)
                _draw_text_centered(rx0, ry0, rx1, ry1, b["label"], size=btn_font, color=text_col, truncate=True, pad=6)
                ui_map[area_ptr]["buttons_abs"].append({
                    "rect": (region.x + rx0, region.y + ry0, region.x + rx1, region.y + ry1),
                    "op": b["op"],
                    "kwargs": b["kwargs"],
                    "id": token,
                })
                by -= (row_h + gap)
        else:
            for row in _overlay_buttons(wm):
                cols = len(row)
                cell_w = (bx1 - bx0 - gap * (cols - 1)) / max(1, cols)
                for i, b in enumerate(row):
                    rx0 = bx0 + i * (cell_w + gap)
                    rx1 = rx0 + cell_w
                    ry1 = by
                    ry0 = ry1 - row_h
                    token = _button_token(b["op"], b["kwargs"])
                    state = "pressed" if pressed_token == token else ("hover" if hover_token == token else "normal")
                    kind = "auto_on" if (b["op"] == "toggle_auto" and wm.tlfc_auto_apply) else ("auto_off" if b["op"] == "toggle_auto" else "default")
                    fill, border_col, text_col = _button_state_colors(kind, state)
                    _draw_rect(rx0, ry0, rx1, ry1, fill)
                    # _draw_aa_line_strip([(rx0, ry0), (rx1, ry0), (rx1, ry1), (rx0, ry1), (rx0, ry0)], border_col, width=1.0)
                    _draw_text_centered(rx0, ry0, rx1, ry1, b["label"], size=btn_font, color=text_col, truncate=True, pad=6)
                    ui_map[area_ptr]["buttons_abs"].append({
                        "rect": (region.x + rx0, region.y + ry0, region.x + rx1, region.y + ry1),
                        "op": b["op"],
                        "kwargs": b["kwargs"],
                        "id": token,
                    })
                by -= (row_h + gap)

        # Preset square buttons under existing buttons.
        if presets:
            cols = max(1, int((bx1 - bx0 + gap) // (tile + gap)))
            for idx, p in enumerate(presets):
                c = idx % cols
                r = idx // cols
                tx0 = bx0 + c * (tile + gap)
                tx1 = min(tx0 + tile, bx1)
                ty1 = by - r * (tile + gap)
                ty0 = ty1 - tile
                if ty0 < y0 + apply_h + 20:
                    break
                _draw_preset_tile(tx0, ty0, tx1, ty1, p, size_scale)
                token = _button_token("preset_apply", {"idx": idx})
                if pressed_token == token:
                    outline = _button_state_colors("preset", "pressed")[1]
                    _draw_aa_line_strip([(tx0, ty0), (tx1, ty0), (tx1, ty1), (tx0, ty1), (tx0, ty0)], outline, width=4.0)
                elif hover_token == token:
                    outline = _button_state_colors("preset", "hover")[1]
                    _draw_aa_line_strip([(tx0, ty0), (tx1, ty0), (tx1, ty1), (tx0, ty1), (tx0, ty0)], outline, width=3.2)
                ui_map[area_ptr]["buttons_abs"].append({
                    "rect": (region.x + tx0, region.y + ty0, region.x + tx1, region.y + ty1),
                    "op": "preset_apply",
                    "kwargs": {"idx": idx},
                    "id": token,
                })
    else:
        # Not enough side space: move buttons under the grid and hide info text.
        ux0 = x0 + 10
        ux1 = x1 - 10
        by = sy0 - 10
        for row in _overlay_buttons(wm):
            cols = len(row)
            cell_w = (ux1 - ux0 - gap * (cols - 1)) / max(1, cols)
            ry1 = by
            ry0 = ry1 - row_h
            if ry0 < y0 + 50:
                break
            for i, b in enumerate(row):
                rx0 = ux0 + i * (cell_w + gap)
                rx1 = rx0 + cell_w
                token = _button_token(b["op"], b["kwargs"])
                state = "pressed" if pressed_token == token else ("hover" if hover_token == token else "normal")
                kind = "auto_on" if (b["op"] == "toggle_auto" and wm.tlfc_auto_apply) else ("auto_off" if b["op"] == "toggle_auto" else "default")
                fill, border_col, text_col = _button_state_colors(kind, state)
                _draw_rect(rx0, ry0, rx1, ry1, fill)
                # _draw_aa_line_strip([(rx0, ry0), (rx1, ry0), (rx1, ry1), (rx0, ry1), (rx0, ry0)], border_col, width=1.0)
                _draw_text_centered(rx0, ry0, rx1, ry1, b["label"], size=btn_font, color=text_col, truncate=True, pad=6)
                ui_map[area_ptr]["buttons_abs"].append({
                    "rect": (region.x + rx0, region.y + ry0, region.x + rx1, region.y + ry1),
                    "op": b["op"],
                    "kwargs": b["kwargs"],
                    "id": token,
                })
            by -= (row_h + gap)

        # Presets under existing buttons in compact layout.
        if presets:
            cols = max(2, int((ux1 - ux0 + gap) // (tile + gap)))
            for idx, p in enumerate(presets):
                c = idx % cols
                r = idx // cols
                tx0 = ux0 + c * (tile + gap)
                tx1 = min(tx0 + tile, ux1)
                ty1 = by - r * (tile + gap)
                ty0 = ty1 - tile
                if ty0 < y0 + apply_h + 20:
                    break
                _draw_preset_tile(tx0, ty0, tx1, ty1, p, size_scale)
                token = _button_token("preset_apply", {"idx": idx})
                if pressed_token == token:
                    outline = _button_state_colors("preset", "pressed")[1]
                    _draw_aa_line_strip([(tx0, ty0), (tx1, ty0), (tx1, ty1), (tx0, ty1), (tx0, ty0)], outline, width=2.0)
                elif hover_token == token:
                    outline = _button_state_colors("preset", "hover")[1]
                    _draw_aa_line_strip([(tx0, ty0), (tx1, ty0), (tx1, ty1), (tx0, ty1), (tx0, ty0)], outline, width=1.6)
                ui_map[area_ptr]["buttons_abs"].append({
                    "rect": (region.x + tx0, region.y + ty0, region.x + tx1, region.y + ty1),
                    "op": "preset_apply",
                    "kwargs": {"idx": idx},
                    "id": token,
                })

        ay1 = y0 + 10 + apply_h
        ay0 = y0 + 10
        apply_token = _button_token("apply", {})
        apply_state = "pressed" if pressed_token == apply_token else ("hover" if hover_token == apply_token else "normal")
        apply_fill, apply_border, apply_text = _button_state_colors("apply", apply_state)
        _draw_rect(ux0, ay0, ux1, ay1, apply_fill)
        # _draw_aa_line_strip([(ux0, ay0), (ux1, ay0), (ux1, ay1), (ux0, ay1), (ux0, ay0)], apply_border, width=1.0)
        _draw_text_centered(ux0, ay0, ux1, ay1, _t(wm, "button.apply_curve", "APPLY CURVE"), size=btn_font, color=apply_text, truncate=True, pad=8)
        ui_map[area_ptr]["buttons_abs"].append({
            "rect": (region.x + ux0, region.y + ay0, region.x + ux1, region.y + ay1),
            "op": "apply",
            "kwargs": {},
            "id": apply_token,
        })

    # Focused curve details (active selected curve if available).
    info = _focused_curve_info(ctx, selected_items)
    if wm.tlfc_show_info and side_has_space and info:
        info_size = 10
        info_step = 14
        info_lines = [
            "{}: {}".format(_t(wm, 'info.selected', 'Selected'), info['name']),
            "{}: {} | {}: {} | {}: {}".format(
                _t(wm, 'info.group', 'Group'),
                info['group'],
                _t(wm, 'info.mods', 'Mods'),
                info['modifiers'],
                _t(wm, 'info.extrap', 'Extrap'),
                info['extrapolation'],
            ),
            "{}: {} {} / {} {}".format(
                _t(wm, 'info.keys', 'Keys'),
                info['keys_selected'],
                _t(wm, 'info.selected_short', 'selected'),
                info['keys_total'],
                _t(wm, 'info.total', 'total'),
            ),
        ]
        if info["frame_span"]:
            fs0, fs1 = info["frame_span"]
            info_lines.append("{}: {:.2f} -> {:.2f}".format(_t(wm, 'info.frame_span', 'Frame span'), fs0, fs1))
        if info["value_span"]:
            vs0, vs1 = info["value_span"]
            info_lines.append("{}: {:.4f} -> {:.4f}".format(_t(wm, 'info.value_span', 'Value span'), vs0, vs1))
        if info["eval_now"] is not None:
            info_lines.append("{}: {:.4f}".format(_t(wm, 'info.value_now', 'Value @ current frame'), info['eval_now']))

        y = sy0 - 16
        info_x = x0 + 10
        info_w = max(60.0, sx1 - info_x - 8)
        for line in info_lines:
            _draw_text_clipped_left(info_x, y, info_w, line, size=info_size, color=TLFC_COLORS["info_text"], pad=2)
            y -= info_step
        _draw_text_clipped_left(info_x, y0 + 4, info_w, "{}: {}".format(_t(wm, 'info.curves', 'Curves'), len(selected_items)), size=info_size, color=TLFC_COLORS["info_footer_text"], pad=2)
    elif wm.tlfc_show_info and side_has_space:
        info_x = x0 + 10
        info_w = max(60.0, sx1 - info_x - 8)
        info_size = 14
        _draw_text_clipped_left(info_x, sy0 - 16, info_w, _t(wm, "info.no_selected_keys", "No selected keys."), size=info_size, color=TLFC_COLORS["info_empty_text"], pad=2)

    gpu.state.blend_set('NONE')
# ---------- Redraw timer ----------
def redraw_timer():
    """Compatibility callback for old generations; never reschedules itself."""
    return None


class TLFC_PT_editor_header_dropdown(bpy.types.Panel):
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'HEADER'
    bl_label = 'Bezier Editor Settings'

    @classmethod
    def poll(cls, context):
        sp = context.space_data
        return _supports_editor_space(sp)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        sp = context.space_data
        is_info_space = bool(sp and sp.type == 'INFO')

        col = layout.column(align=True)
        col.label(text=_t(wm, "panel.display", "Display"))
        if not is_info_space:
            col.prop(wm, "tlfc_sidebar_width", text=_t(wm, "panel.sidebar_width", "Sidebar Width"))
            col.prop(wm, "tlfc_outer_pad", text=_t(wm, "panel.outer_padding", "Outer Padding"))
        col.prop(wm, "tlfc_samples", text=_t(wm, "panel.curve_samples", "Curve Samples"))
        col.prop(wm, "tlfc_display_size", text=_t(wm, "panel.display_size", "Display Size"))
        tog = col.row(align=True)
        tog.prop(wm, "tlfc_show_info", text=_t(wm, "panel.show_info", "Show Info"))
        tog.prop(wm, "tlfc_auto_apply", text=_t(wm, "panel.auto_apply", "Auto Apply"))
        col.prop(wm, "tlfc_grid_subdiv", text=_t(wm, "panel.grid_subdivisions", "Grid Subdivisions"))

        col.separator()
        col.label(text=_t(wm, "panel.editor", "Editor"))
        h1 = col.row(align=True)
        h1.prop(wm, "tlfc_h1x")
        h1.prop(wm, "tlfc_h1y")
        h2 = col.row(align=True)
        h2.prop(wm, "tlfc_h2x")
        h2.prop(wm, "tlfc_h2y")

        col.separator()
        nav = col.row(align=True)
        nav.operator("tlfc.editor_zoom", text=_t(wm, "button.zoom_in", "Zoom +")).mode = 'IN'
        nav.operator("tlfc.editor_zoom", text=_t(wm, "button.zoom_out", "Zoom -")).mode = 'OUT'
        nav.operator("tlfc.editor_zoom", text=_t(wm, "button.center", "Center")).mode = 'CENTER'

        ease = col.row(align=True)
        ease.operator("tlfc.set_interpolation", text=_t(wm, "button.linear", "Linear")).mode = 'LINEAR'
        ease.operator("tlfc.set_interpolation", text=_t(wm, "button.constant", "Constant")).mode = 'CONSTANT'
        ease.operator("tlfc.mirror_curve", text=_t(wm, "button.mirror", "Mirror"))
        ease.operator("tlfc.reset_curve", text=_t(wm, "button.reset", "Reset"))

        col.operator("tlfc.read_curve", text=_t(wm, "panel.read_curve", "Read curve from Keyframe"))
        col.operator("tlfc.save_preset", text=_t(wm, "button.save_preset", "Save Preset"))
        col.operator("tlfc.open_preset_file", text=_t(wm, "panel.open_preset_file", "Open Preset File"))

        col.separator()
        apply_row = col.row()
        apply_row.scale_y = 1.5
        apply_row.operator("tlfc.apply_curve", text=_t(wm, "button.apply_curve", "APPLY CURVE"))


def draw_tlfc_timeline_header(self, context):
    sp = context.space_data
    if not sp or sp.type != 'DOPESHEET_EDITOR' or sp.mode != 'TIMELINE':
        return
    if not _pref_bool("tlfc_show_timeline_header_button", _prop_default("tlfc_show_timeline_header_button")):
        return
    wm = context.window_manager
    row = self.layout.row(align=True)
    is_on = _is_editor_enabled(context.area) and wm.tlfc_mouse_editing
    icon = 'IPO_BEZIER'
    if not _operator_id_available("tlfc.toggle_editor_mode"):
        return
    row.operator("tlfc.toggle_editor_mode", text="", icon=icon, depress=is_on)
    _safe_popover(row, "TLFC_PT_editor_header_dropdown", text="")


def draw_tlfc_info_header(self, context):
    sp = context.space_data
    if not sp or sp.type != 'INFO':
        return
    if not _pref_bool("tlfc_show_info_header_button", _prop_default("tlfc_show_info_header_button")):
        return
    wm = context.window_manager
    self.layout.separator_spacer()
    row = self.layout.row(align=True)
    row.alignment = 'RIGHT'
    is_on = _is_editor_enabled(context.area) and wm.tlfc_mouse_editing
    icon = 'IPO_BEZIER'
    if not _operator_id_available("tlfc.toggle_editor_mode"):
        return
    row.operator("tlfc.toggle_editor_mode", text="", icon=icon, depress=is_on)
    _safe_popover(row, "TLFC_PT_editor_header_dropdown", text="")


class TLFC_OT_toggle_editor_mode(bpy.types.Operator):
    bl_idname = "tlfc.toggle_editor_mode"
    bl_label = "Toggle Editor Mode"
    bl_description = "Enable or disable the curve editor overlay in this area"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        sp = context.space_data
        area = context.area
        if not area or not _supports_editor_space(sp):
            return {'CANCELLED'}

        if _is_editor_enabled(area):
            _set_editor_enabled(area, False)
            if not _any_timeline_editor_enabled():
                wm.tlfc_mouse_editing = False
                _reset_ui_state(wm)
                _disable_runtime_handlers(clear_ui=True)
        else:
            _set_editor_enabled_exclusive(area)
            _reset_ui_state(wm)
            _ensure_runtime_handlers()

            ns = bpy.app.driver_namespace
            ns[SWITCH_BLOCK_UNTIL_KEY] = time.perf_counter() + (1.0 / 30.0)

            ui_map = ns.get(EDITOR_UI_KEY)
            area_key = _area_key(area)
            if isinstance(ui_map, dict):
                for k in list(ui_map.keys()):
                    if k != area_key:
                        ui_map.pop(k, None)

            # Restart modal so stale handlers from another area are invalidated.
            if wm.tlfc_mouse_editing:
                wm.tlfc_mouse_editing = False
            try:
                bpy.ops.tlfc.mouse_edit_curve('INVOKE_DEFAULT')
            except Exception:
                wm.tlfc_mouse_editing = True

        if not _any_timeline_editor_enabled():
            _reset_ui_state(wm)
            _disable_runtime_handlers(clear_ui=True)
        _tag_redraw_dopesheet()
        return {'FINISHED'}


class TLFC_OT_mouse_edit_curve(bpy.types.Operator):
    bl_idname = "tlfc.mouse_edit_curve"
    bl_label = "Toggle Mouse Edit"
    bl_description = "Left drag handles, middle drag to pan the editor"
    bl_options = set()
    _sms_no_undo = True

    _drag = None
    _cursor = None
    _session_id = 0

    def _set_modal_cursor(self, context, cursor):
        if self._cursor == cursor:
            return
        try:
            if cursor:
                context.window.cursor_modal_set(cursor)
            else:
                context.window.cursor_modal_restore()
            self._cursor = cursor
        except Exception:
            self._cursor = None

    def _clear_modal_cursor(self, context):
        if self._cursor is None:
            return
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        self._cursor = None

    def invoke(self, context, event):
        wm = context.window_manager
        if wm.tlfc_mouse_editing:
            wm.tlfc_mouse_editing = False
            _reset_ui_state(wm)
            self._clear_modal_cursor(context)
            return {'FINISHED'}
        sp = context.space_data
        if not _supports_editor_space(sp) or not _is_editor_enabled(context.area):
            self.report({'WARNING'}, _t(wm, "report.enable_overlay_first", "Enable Overlay first"))
            return {'CANCELLED'}
        _ensure_runtime_handlers()
        wm.tlfc_mouse_editing = True
        _reset_ui_state(wm)
        self._drag = None
        self._cursor = None
        ns = bpy.app.driver_namespace
        self._session_id = int(ns.get(MODAL_SESSION_KEY, 0)) + 1
        ns[MODAL_SESSION_KEY] = self._session_id
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        wm = context.window_manager
        ns = bpy.app.driver_namespace
        if self._session_id != int(ns.get(MODAL_SESSION_KEY, self._session_id)):
            self._drag = None
            self._clear_modal_cursor(context)
            return {'CANCELLED'}

        if not wm.tlfc_mouse_editing:
            _reset_ui_state(wm, clear_buttons=False, clear_handle=False)
            self._clear_modal_cursor(context)
            return {'CANCELLED'}

        if event.type == 'ESC' and event.value == 'PRESS':
            wm.tlfc_mouse_editing = False
            self._drag = None
            _reset_ui_state(wm)
            self._clear_modal_cursor(context)
            return {'CANCELLED'}

        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            return {'PASS_THROUGH'}

        ui_map = bpy.app.driver_namespace.get(EDITOR_UI_KEY)
        area_ptr = context.area.as_pointer() if context.area else 0
        ui = ui_map.get(area_ptr) if isinstance(ui_map, dict) else None
        if not ui:
            _reset_ui_state(wm)
            self._clear_modal_cursor(context)
            return {'PASS_THROUGH'}

        block_until = float(ns.get(SWITCH_BLOCK_UNTIL_KEY, 0.0))
        if time.perf_counter() < block_until:
            self._drag = None
            _reset_ui_state(wm)
            self._set_modal_cursor(context, None)
            return {'RUNNING_MODAL'}

        mx_abs = event.mouse_x
        my_abs = event.mouse_y
        is_info_ui = (ui.get("space_type") == 'INFO')
        panel_rect = ui.get("panel_rect_abs")
        wm.tlfc_hover_sidebar = _point_in_rect(mx_abs, my_abs, panel_rect) if panel_rect else False
        edge_hit = float(ui.get("sidebar_edge_hit_px", SIDEBAR_EDGE_HIT_PX))
        edge_x = float(ui.get("sidebar_edge_abs", panel_rect[0] if panel_rect else 0.0))
        if panel_rect:
            _, py0, _, py1 = panel_rect
            wm.tlfc_hover_sidebar_edge = (not is_info_ui) and (py0 <= my_abs <= py1) and (abs(mx_abs - edge_x) <= edge_hit)
        else:
            wm.tlfc_hover_sidebar_edge = False
        rx0, ry0, rx1, ry1 = ui["rect_abs"]
        inside = (rx0 <= mx_abs <= rx1 and ry0 <= my_abs <= ry1)
        sx0, sy0, sx1, sy1 = ui["rect"]
        # Convert absolute window coords to WINDOW-region local editor coords.
        mx = mx_abs - rx0 + sx0
        my = my_abs - ry0 + sy0

        # Check handle hover state
        h1 = ui["h1_abs"]
        h2 = ui["h2_abs"]
        d1 = (mx_abs - h1[0]) * (mx_abs - h1[0]) + (my_abs - h1[1]) * (my_abs - h1[1])
        d2 = (mx_abs - h2[0]) * (mx_abs - h2[0]) + (my_abs - h2[1]) * (my_abs - h2[1])
        handle_hit_sq = float(HANDLE_HIT_RADIUS_PX * HANDLE_HIT_RADIUS_PX)

        # Store which handle is being hovered (if any)
        if d1 <= handle_hit_sq and not self._drag:
            wm.tlfc_hover_handle = "h1"
        elif d2 <= handle_hit_sq and not self._drag:
            wm.tlfc_hover_handle = "h2"
        else:
            wm.tlfc_hover_handle = ""

        hovered_token = ""
        for btn in ui.get("buttons_abs", []):
            if _point_in_rect(mx_abs, my_abs, btn["rect"]):
                hovered_token = btn.get("id", "")
                break
        wm.tlfc_hover_button = hovered_token

        if self._drag == "sidebar" or getattr(wm, "tlfc_dragging_sidebar", False):
            self._set_modal_cursor(context, 'MOVE_X')
        elif hovered_token:
            self._set_modal_cursor(context, 'HAND_POINT')
        elif wm.tlfc_hover_sidebar_edge:
            self._set_modal_cursor(context, 'MOVE_X')
        else:
            self._set_modal_cursor(context, None)

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if wm.tlfc_hover_sidebar_edge:
                self._drag = "sidebar"
                wm.tlfc_dragging_sidebar = True
                wm.tlfc_pressed_button = ""
                return {'RUNNING_MODAL'}

            h1 = ui["h1_abs"]
            h2 = ui["h2_abs"]
            d1 = (mx_abs - h1[0]) * (mx_abs - h1[0]) + (my_abs - h1[1]) * (my_abs - h1[1])
            d2 = (mx_abs - h2[0]) * (mx_abs - h2[0]) + (my_abs - h2[1]) * (my_abs - h2[1])
            if d1 <= handle_hit_sq:
                self._drag = "h1"
                wm.tlfc_pressed_button = ""
                return {'RUNNING_MODAL'}
            if d2 <= handle_hit_sq:
                self._drag = "h2"
                wm.tlfc_pressed_button = ""
                return {'RUNNING_MODAL'}

            for btn in ui.get("buttons_abs", []):
                if _point_in_rect(mx_abs, my_abs, btn["rect"]):
                    wm.tlfc_pressed_button = btn.get("id", "")
                    _invoke_overlay_button(context, btn["op"], btn.get("kwargs", {}), shift=event.shift)
                    if context.area:
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
            wm.tlfc_pressed_button = ""
            return {'PASS_THROUGH'}

        if event.type == 'MIDDLEMOUSE' and event.value == 'PRESS':
            if not inside:
                return {'PASS_THROUGH'}
            self._drag = "pan"
            wm.tlfc_pan_start_x = mx_abs
            wm.tlfc_pan_start_y = my_abs
            wm.tlfc_pan_origin_x = wm.tlfc_view_pan_x
            wm.tlfc_pan_origin_y = wm.tlfc_view_pan_y
            return {'RUNNING_MODAL'}

        # Mouse wheel zoom when hovering over the editor
        if event.type == 'WHEELUPMOUSE' and inside:
            # Zoom in
            old_zoom = wm.tlfc_view_zoom
            new_zoom = min(_prop_range("tlfc_view_zoom")[1], old_zoom * TLFC_UI_NUMBERS["zoom_wheel_factor"])

            # Zoom towards mouse cursor position
            if old_zoom > 0:
                # Get mouse position in editor space
                sx0, sy0, sx1, sy1 = ui["rect"]
                mx_editor, my_editor = _screen_to_editor(mx, my, sx0, sy0, sx1, sy1, old_zoom, wm.tlfc_view_pan_x, wm.tlfc_view_pan_y)

                # Adjust pan to keep the mouse point fixed
                zoom_factor = new_zoom / old_zoom
                wm.tlfc_view_pan_x = wm.tlfc_view_pan_x * zoom_factor + (mx_editor - 0.5) * (new_zoom - old_zoom)
                wm.tlfc_view_pan_y = wm.tlfc_view_pan_y * zoom_factor + (my_editor - 0.5) * (new_zoom - old_zoom)

                # Apply pan limits
                max_pan = TLFC_UI_NUMBERS["pan_limit_base"] / max(TLFC_UI_NUMBERS["pan_zoom_floor"], new_zoom)
                wm.tlfc_view_pan_x = max(-max_pan, min(max_pan, wm.tlfc_view_pan_x))
                wm.tlfc_view_pan_y = max(-max_pan, min(max_pan, wm.tlfc_view_pan_y))

            wm.tlfc_view_zoom = new_zoom
            if context.area:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'WHEELDOWNMOUSE' and inside:
            # Zoom out
            old_zoom = wm.tlfc_view_zoom
            new_zoom = max(_prop_range("tlfc_view_zoom")[0], old_zoom / TLFC_UI_NUMBERS["zoom_wheel_factor"])

            # Zoom towards mouse cursor position
            if old_zoom > 0:
                # Get mouse position in editor space
                sx0, sy0, sx1, sy1 = ui["rect"]
                mx_editor, my_editor = _screen_to_editor(mx, my, sx0, sy0, sx1, sy1, old_zoom, wm.tlfc_view_pan_x, wm.tlfc_view_pan_y)

                # Adjust pan to keep the mouse point fixed
                zoom_factor = new_zoom / old_zoom
                wm.tlfc_view_pan_x = wm.tlfc_view_pan_x * zoom_factor + (mx_editor - 0.5) * (new_zoom - old_zoom)
                wm.tlfc_view_pan_y = wm.tlfc_view_pan_y * zoom_factor + (my_editor - 0.5) * (new_zoom - old_zoom)

                # Apply pan limits
                max_pan = TLFC_UI_NUMBERS["pan_limit_base"] / max(TLFC_UI_NUMBERS["pan_zoom_floor"], new_zoom)
                wm.tlfc_view_pan_x = max(-max_pan, min(max_pan, wm.tlfc_view_pan_x))
                wm.tlfc_view_pan_y = max(-max_pan, min(max_pan, wm.tlfc_view_pan_y))

            wm.tlfc_view_zoom = new_zoom
            if context.area:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'MIDDLEMOUSE'} and event.value == 'RELEASE':
            had_drag = self._drag is not None
            had_pressed = bool(wm.tlfc_pressed_button)
            was_sidebar_drag = self._drag == "sidebar"

            if event.type == 'LEFTMOUSE':
                wm.tlfc_pressed_button = ""
            if was_sidebar_drag:
                wm.tlfc_dragging_sidebar = False

            # Only capture release if this modal was actively handling interaction.
            if had_drag or had_pressed:
                self._drag = None
                return {'RUNNING_MODAL'}

            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE' and self._drag == "sidebar":
            if is_info_ui:
                self._drag = None
                wm.tlfc_dragging_sidebar = False
                return {'PASS_THROUGH'}
            panel_x1_abs = float(ui.get("panel_x1_abs", panel_rect[2] if panel_rect else mx_abs))
            region_w = max(1.0, float(ui.get("region_w", context.region.width if context.region else 1.0)))
            sidebar_w_px = max(TLFC_UI_NUMBERS["sidebar_min_px"], min(region_w, panel_x1_abs - mx_abs))
            new_pct = (sidebar_w_px / region_w) * 100.0
            wm.tlfc_sidebar_width = _clamp_prop("tlfc_sidebar_width", new_pct)
            if context.area:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE' and self._drag in {"h1", "h2"}:
            nx, ny = _screen_to_editor(mx, my, sx0, sy0, sx1, sy1, wm.tlfc_view_zoom, wm.tlfc_view_pan_x, wm.tlfc_view_pan_y)
            _mode_val = getattr(wm, 'tlfc_sidebar_mode', _prop_default("tlfc_sidebar_mode"))
            if _mode_val == 'ELASTIC':
                nx = _clamp01(nx)
                ny = _clamp01(ny)
                if event.ctrl:
                    nx, ny = _snap_grid(nx, ny, wm.tlfc_grid_subdiv)
                    nx = _clamp01(nx)
                    ny = _clamp01(ny)
                if self._drag == "h1":
                    wm.tlfc_elastic_amplitude = _unit_to_prop("tlfc_elastic_amplitude", ny)
                else:
                    wm.tlfc_elastic_period = _unit_to_prop("tlfc_elastic_period", nx)
            else:
                nx, ny = _constrain_handle(self._drag, nx, ny)
                if event.ctrl:
                    nx, ny = _snap_grid(nx, ny, wm.tlfc_grid_subdiv)
                    nx, ny = _constrain_handle(self._drag, nx, ny)
                if event.shift:
                    nx, ny = _snap_edge(nx, ny, wm.tlfc_snap_threshold)
                    nx, ny = _constrain_handle(self._drag, nx, ny)
                if self._drag == "h1":
                    wm.tlfc_h1x = nx
                    wm.tlfc_h1y = ny
                else:
                    wm.tlfc_h2x = nx
                    wm.tlfc_h2y = ny

            if wm.tlfc_auto_apply:
                bpy.ops.tlfc.apply_curve()

            # Redraw all dopesheet areas for lower perceived drag latency.
            try:
                for w in bpy.data.window_managers:
                    for win in w.windows:
                        scr = win.screen
                        if not scr:
                            continue
                        for area in scr.areas:
                            if area.type in {'DOPESHEET_EDITOR', 'INFO'}:
                                area.tag_redraw()
            except Exception:
                if context.area:
                    context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE' and self._drag == "pan":
            dx = mx_abs - wm.tlfc_pan_start_x
            dy = my_abs - wm.tlfc_pan_start_y
            rw = max(1.0, sx1 - sx0)
            rh = max(1.0, sy1 - sy0)
            new_pan_x = wm.tlfc_pan_origin_x + (dx / rw)
            new_pan_y = wm.tlfc_pan_origin_y + (dy / rh)

            # Clamp pan to reasonable limits based on zoom
            # Allow panning to show content within (-1, -1) to (2, 2) in normalized space
            zoom = wm.tlfc_view_zoom
            max_pan = TLFC_UI_NUMBERS["pan_limit_base"] / max(TLFC_UI_NUMBERS["pan_zoom_floor"], zoom)  # More pan allowed when zoomed in
            new_pan_x = max(-max_pan, min(max_pan, new_pan_x))
            new_pan_y = max(-max_pan, min(max_pan, new_pan_y))

            wm.tlfc_view_pan_x = new_pan_x
            wm.tlfc_view_pan_y = new_pan_y
            if context.area:
                context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}


class TLFC_OT_editor_zoom(bpy.types.Operator):
    bl_idname = "tlfc.editor_zoom"
    bl_label = "Bezier Editor Zoom"
    bl_description = "Zoom the editor view in, out, or reset to center"
    bl_options = {'UNDO'}
    _sms_no_undo = True
    mode: bpy.props.EnumProperty(
        items=[
            ('IN', 'In', ''),
            ('OUT', 'Out', ''),
            ('CENTER', 'Center', ''),
        ]
    )

    def execute(self, context):
        wm = context.window_manager
        if self.mode == 'IN':
            wm.tlfc_view_zoom = min(_prop_range("tlfc_view_zoom")[1], wm.tlfc_view_zoom * TLFC_UI_NUMBERS["zoom_button_factor"])
        elif self.mode == 'OUT':
            wm.tlfc_view_zoom = max(_prop_range("tlfc_view_zoom")[0], wm.tlfc_view_zoom / TLFC_UI_NUMBERS["zoom_button_factor"])
        else:
            wm.tlfc_view_zoom = _prop_default("tlfc_view_zoom")
            wm.tlfc_view_pan_x = _prop_default("tlfc_view_pan_x")
            wm.tlfc_view_pan_y = _prop_default("tlfc_view_pan_y")
        return {'FINISHED'}


class TLFC_OT_apply_curve(bpy.types.Operator):
    bl_idname = "tlfc.apply_curve"
    bl_label = "Apply Curve"
    bl_description = "Apply the current editor curve to selected keyframe segments"
    bl_options = {'UNDO'}

    def execute(self, context):
        wm = context.window_manager
        _mode_val = getattr(wm, 'tlfc_sidebar_mode', _prop_default("tlfc_sidebar_mode"))
        if _mode_val == 'ELASTIC':
            amplitude = _clamp_prop("tlfc_elastic_amplitude", getattr(wm, 'tlfc_elastic_amplitude', _prop_default("tlfc_elastic_amplitude")))
            period = _clamp_prop("tlfc_elastic_period", getattr(wm, 'tlfc_elastic_period', _prop_default("tlfc_elastic_period")))
            pairs = 0
            curves = set()
            # FCurve.update() can reallocate the key array, so update only after every
            # segment of the selection has been written.
            touched = {}
            for fc, k0, k1 in list(_iter_selected_segments(context)):
                if _apply_elastic_to_segment(fc, k0, k1, amplitude, period):
                    pairs += 1
                    touched[fc.as_pointer()] = fc
            for fc in touched.values():
                fc.update()
            curves = touched
            if pairs == 0:
                self.report({'WARNING'}, _t(wm, "report.no_selected_pairs", "No selected keyframe pairs found to apply"))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(wm, "Baked elastic curve to {pairs} segment(s) on {curves} F-curve(s)").format(pairs=pairs, curves=len(curves)))
            return {'FINISHED'}
        h1x, h1y = wm.tlfc_h1x, wm.tlfc_h1y
        h2x, h2y = wm.tlfc_h2x, wm.tlfc_h2y
        pairs = 0
        curves = set()
        # FCurve.update() can reallocate the key array, so update only after every
        # segment of the selection has been written.
        touched = {}
        for fc, k0, k1 in list(_iter_selected_segments(context)):
            if _apply_editor_curve_to_segment(k0, k1, h1x, h1y, h2x, h2y):
                pairs += 1
                touched[fc.as_pointer()] = fc
        for fc in touched.values():
            fc.update()
        curves = touched
        if pairs == 0:
            self.report({'WARNING'}, _t(wm, "report.no_selected_pairs", "No selected keyframe pairs found to apply"))
            return {'CANCELLED'}
        self.report({'INFO'}, _t(wm, "Applied curve to {pairs} segment(s) on {curves} F-curve(s)").format(pairs=pairs, curves=len(curves)))
        return {'FINISHED'}


class TLFC_OT_set_interpolation(bpy.types.Operator):
    bl_idname = "tlfc.set_interpolation"
    bl_label = "Set Interpolation"
    bl_description = "Set interpolation mode for selected keyframes"
    bl_options = {'UNDO'}
    mode: bpy.props.EnumProperty(
        items=[
            ('LINEAR', 'Linear', ''),
            ('CONSTANT', 'Constant', ''),
        ]
    ) # type: ignore

    def execute(self, context):
        changed = 0
        for _fc, sel_keys, _all_keys in _selected_fcurves_with_selected_keys(context):
            for kp in sel_keys:
                kp.interpolation = self.mode
                changed += 1
        if changed == 0:
            self.report({'WARNING'}, _t(context.window_manager, "report.no_selected_keyframes", "No selected keyframes"))
            return {'CANCELLED'}
        self.report({'INFO'}, _t(context.window_manager, "Set {count} keyframe(s) to {mode}").format(count=changed, mode=bpy.app.translations.pgettext(self.mode.title())))
        return {'FINISHED'}


class TLFC_OT_mirror_curve(bpy.types.Operator):
    bl_idname = "tlfc.mirror_curve"
    bl_label = "Mirror Handle"
    bl_description = "Mirror Bezier handles across the center"
    bl_options = {'UNDO'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        h1x, h1y = wm.tlfc_h1x, wm.tlfc_h1y
        h2x, h2y = wm.tlfc_h2x, wm.tlfc_h2y
        nh1x, nh1y = 1.0 - h2x, 1.0 - h2y
        nh2x, nh2y = 1.0 - h1x, 1.0 - h1y
        wm.tlfc_h1x, wm.tlfc_h1y = _constrain_handle("h1", nh1x, nh1y)
        wm.tlfc_h2x, wm.tlfc_h2y = _constrain_handle("h2", nh2x, nh2y)
        return {'FINISHED'}

class TLFC_OT_reset_curve(bpy.types.Operator):
    bl_idname = "tlfc.reset_curve"
    bl_label = "Reset Curve"
    bl_description = "Reset Bezier handles to default values"
    bl_options = {'UNDO'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        wm.tlfc_h1x, wm.tlfc_h1y = _prop_default("tlfc_h1x"), _prop_default("tlfc_h1y")
        wm.tlfc_h2x, wm.tlfc_h2y = _prop_default("tlfc_h2x"), _prop_default("tlfc_h2y")
        return {'FINISHED'}


class TLFC_OT_read_curve(bpy.types.Operator):
    bl_idname = "tlfc.read_curve"
    bl_label = "Read Curve from Keyframe"
    bl_description = "Read curve settings from the selected keyframe segment"
    bl_options = {'UNDO'}
    _sms_no_undo = True

    def execute(self, context):
        seg = _segment_from_selected_key(context, _selected_fcurves_with_selected_keys(context))
        if seg is None:
            self.report({'WARNING'}, _t(context.window_manager, "report.need_selected_key_with_next", "Need a selected key with a next keyframe"))
            return {'CANCELLED'}
        wm = context.window_manager
        k0 = seg.get("k0")
        k1 = seg.get("k1")
        is_elastic = False
        try:
            if k0 and getattr(k0, "interpolation", "") == 'ELASTIC':
                is_elastic = True
            elif k1 and getattr(k1, "interpolation", "") == 'ELASTIC':
                is_elastic = True
        except Exception:
            is_elastic = False

        if is_elastic and k0 is not None:
            wm.tlfc_sidebar_mode = 'ELASTIC'
            amp = float(getattr(k0, "amplitude", _prop_default("tlfc_elastic_amplitude")))
            per = float(getattr(k0, "period", _prop_default("tlfc_elastic_period")))
            df = float(seg.get("df", 1.0))
            if abs(df) > 1e-8:
                per = per / df
            wm.tlfc_elastic_amplitude = _clamp_prop("tlfc_elastic_amplitude", amp)
            wm.tlfc_elastic_period = _clamp_prop("tlfc_elastic_period", per)
            self.report({'INFO'}, _t(wm, "report.elastic_loaded", "Elastic curve loaded from selected key segment"))
        else:
            wm.tlfc_sidebar_mode = 'BEZIER'
            wm.tlfc_h1x, wm.tlfc_h1y = seg["c1"]
            wm.tlfc_h2x, wm.tlfc_h2y = seg["c2"]
            self.report({'INFO'}, _t(wm, "report.bezier_loaded", "Bezier curve loaded from selected key segment"))
        return {'FINISHED'}


class TLFC_OT_save_preset(bpy.types.Operator):
    bl_idname = "tlfc.save_preset"
    bl_label = "Save Preset"
    bl_description = "Save the current curve (Bezier or Elastic) as a preset"
    bl_options = {'UNDO'}
    _sms_no_undo = True

    def execute(self, context):
        ok = _add_current_preset(context.window_manager)
        if not ok:
            self.report({'WARNING'}, _t(context.window_manager, "report.preset_save_failed", "Failed to save preset file"))
            return {'CANCELLED'}
        self.report({'INFO'}, _t(context.window_manager, "report.preset_saved", "Preset saved"))
        return {'FINISHED'}


class TLFC_OT_open_preset_file(bpy.types.Operator):
    bl_idname = "tlfc.open_preset_file"
    bl_label = "Open Preset File"
    bl_description = "Open the preset file location on disk"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        path = _preset_file_path()
        # Ensure file exists so opening does not fail on first use.
        if not os.path.exists(path):
            _save_presets(list(_load_presets()))

        try:
            bpy.ops.wm.path_open(filepath=path)
            self.report({'INFO'}, _t(context.window_manager, "report.preset_opened", "Opened preset file"))
            return {'FINISHED'}
        except Exception:
            self.report({'WARNING'}, _t(context.window_manager, "Preset file: {path}").format(path=path))
            return {'CANCELLED'}


class TLFC_AP_preferences:
    bl_idname = ADDON_MODULE_KEY
    tlfc_redraw_load_threshold: bpy.props.FloatProperty(
        name="Redraw Load Threshold",
        description="Increase redraw interval when measured redraw load exceeds this threshold",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_redraw_load_threshold"],
        min=TLFC_PROPERTY_RANGES["tlfc_redraw_load_threshold"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_redraw_load_threshold"][1],
    )
    tlfc_show_timeline_header_button: bpy.props.BoolProperty(
        name="Show Timeline Header Button",
        description="Show Bezier editor toggle and dropdown in Timeline header",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_show_timeline_header_button"],
    )
    tlfc_show_info_header_button: bpy.props.BoolProperty(
        name="Show Info Header Button",
        description="Show Bezier editor toggle and dropdown in Info header",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_show_info_header_button"],
    )

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager if context and context.window_manager else bpy.context.window_manager
        col = layout.column(align=True)
        col.label(text=_t(wm, "prefs.title", "Bezier Curve Editor Overlay"))
        col.prop(self, "tlfc_redraw_load_threshold", text=_t(wm, "prefs.redraw_threshold", "Redraw Load Threshold"))
        rowB = col.row(align=True)
        rowB.prop(self, "tlfc_show_timeline_header_button", text=_t(wm, "prefs.show_timeline_button", "Show Timeline Header Button"))
        rowB.prop(self, "tlfc_show_info_header_button", text=_t(wm, "prefs.show_info_button", "Show Info Header Button"))


classes = (
    TLFC_OT_toggle_editor_mode,
    TLFC_OT_mouse_edit_curve,
    TLFC_OT_editor_zoom,
    TLFC_OT_apply_curve,
    TLFC_OT_set_interpolation,
    TLFC_OT_mirror_curve,
    TLFC_OT_reset_curve,
    TLFC_OT_read_curve,
    TLFC_OT_save_preset,
    TLFC_OT_open_preset_file,
    TLFC_PT_editor_header_dropdown,
)

_TLFC_RNA_PROPS = (
    "tlfc_show_display_settings", "tlfc_sidebar_width", "tlfc_outer_pad",
    "tlfc_samples", "tlfc_show_info", "tlfc_display_size", "tlfc_h1x",
    "tlfc_h1y", "tlfc_h2x", "tlfc_h2y", "tlfc_grid_subdiv",
    "tlfc_auto_apply", "tlfc_snap_threshold", "tlfc_view_zoom",
    "tlfc_view_pan_x", "tlfc_view_pan_y", "tlfc_pan_start_x",
    "tlfc_pan_start_y", "tlfc_pan_origin_x", "tlfc_pan_origin_y",
    "tlfc_mouse_editing", "tlfc_hover_sidebar", "tlfc_hover_sidebar_edge",
    "tlfc_dragging_sidebar", "tlfc_hover_button", "tlfc_pressed_button",
    "tlfc_hover_handle", "tlfc_sidebar_mode", "tlfc_elastic_amplitude",
    "tlfc_elastic_period",
)


def _runtime_rna_ready(*, verify_identity: bool = False) -> bool:
    """Return true only after the complete owned WindowManager RNA transaction."""
    # The ledger is populated only after every property identity was verified,
    # and is cleared on rollback/unregister.  Keep the per-draw readiness check
    # constant-time; lifecycle entry/exit owns the full identity scan.
    if len(_OWNED_RNA_IDENTITIES) != len(_TLFC_RNA_PROPS):
        return False
    if not verify_identity:
        return True
    return all(
        expected is not None
        and lifecycle.rna_property_identity(bpy.types.WindowManager, prop) == expected
        for prop in _TLFC_RNA_PROPS
        for expected in (_OWNED_RNA_IDENTITIES.get(prop),)
    )


def _cleanup_previous():
    ns = bpy.app.driver_namespace
    old_handle = ns.get(ADDON_KEY)
    if old_handle is not None:
        try:
            bpy.types.SpaceDopeSheetEditor.draw_handler_remove(old_handle, 'WINDOW')
        except Exception:
            pass
        ns.pop(ADDON_KEY, None)
    old_info_handle = ns.get(INFO_ADDON_KEY)
    if old_info_handle is not None:
        try:
            bpy.types.SpaceInfo.draw_handler_remove(old_info_handle, 'WINDOW')
        except Exception:
            pass
        ns.pop(INFO_ADDON_KEY, None)
    if bpy.app.timers.is_registered(redraw_timer):
        try:
            bpy.app.timers.unregister(redraw_timer)
        except Exception:
            pass
    ns.pop(ENABLED_AREAS_KEY, None)


def _disable_runtime_handlers(clear_ui=True):
    ns = bpy.app.driver_namespace
    old_handle = ns.get(ADDON_KEY)
    if old_handle is not None:
        try:
            bpy.types.SpaceDopeSheetEditor.draw_handler_remove(old_handle, 'WINDOW')
        except Exception:
            pass
        ns.pop(ADDON_KEY, None)

    old_info_handle = ns.get(INFO_ADDON_KEY)
    if old_info_handle is not None:
        try:
            bpy.types.SpaceInfo.draw_handler_remove(old_info_handle, 'WINDOW')
        except Exception:
            pass
        ns.pop(INFO_ADDON_KEY, None)

    if bpy.app.timers.is_registered(redraw_timer):
        try:
            bpy.app.timers.unregister(redraw_timer)
        except Exception:
            pass

    if clear_ui:
        ns.pop(EDITOR_UI_KEY, None)


def _ensure_runtime_handlers():
    # Event-driven: overlay draw handlers exist only while at least one supported
    # editor is explicitly enabled. Native editor/modal redraw events drive the
    # overlay; no polling or status timer is registered.
    if not _runtime_rna_ready(verify_identity=True):
        _disable_runtime_handlers(clear_ui=True)
        return False
    if not _any_timeline_editor_enabled():
        _disable_runtime_handlers(clear_ui=True)
        return False
    ns = bpy.app.driver_namespace
    if ns.get(ADDON_KEY) is None:
        handle = bpy.types.SpaceDopeSheetEditor.draw_handler_add(
            draw_editor_sidebar, (), 'WINDOW', 'POST_PIXEL'
        )
        ns[ADDON_KEY] = handle

    if ns.get(INFO_ADDON_KEY) is None:
        info_handle = bpy.types.SpaceInfo.draw_handler_add(
            draw_editor_sidebar, (), 'WINDOW', 'POST_PIXEL'
        )
        ns[INFO_ADDON_KEY] = info_handle
    _tag_redraw_dopesheet()
    return True


_HEADER_CALLBACKS_ENABLED = False


def _append_header_once(header_type, callback):
    try:
        header_type.remove(callback)
    except Exception:
        pass
    try:
        header_type.append(callback)
    except Exception:
        pass


def _remove_header_callback(header_type, callback):
    try:
        header_type.remove(callback)
    except Exception:
        pass


def enable_header_callbacks():
    """Enable optional Bezier Curve Editor header buttons from the central always-on switch."""
    global _HEADER_CALLBACKS_ENABLED
    _HEADER_CALLBACKS_ENABLED = True
    _append_header_once(bpy.types.DOPESHEET_HT_header, draw_tlfc_timeline_header)
    _append_header_once(bpy.types.INFO_HT_header, draw_tlfc_info_header)


def disable_header_callbacks():
    """Disable optional Bezier Curve Editor header buttons from the central always-on switch."""
    global _HEADER_CALLBACKS_ENABLED
    _HEADER_CALLBACKS_ENABLED = False
    _remove_header_callback(bpy.types.DOPESHEET_HT_header, draw_tlfc_timeline_header)
    _remove_header_callback(bpy.types.INFO_HT_header, draw_tlfc_info_header)


def _persist_tlfc_setting(self=None, context=None):
    """Persist portable Bezier editor controls in the assigning RNA event."""
    try:
        from .. import runtime_persistence
        runtime_persistence.save_runtime_properties_if_changed(
            context=context or getattr(bpy, 'context', None), force=False
        )
    except Exception:
        pass


def _register_impl():
    global _TRANSLATION_OWNER
    owner = f'{ADDON_MODULE_KEY}.translations.{id(register):x}'
    result = bpy.app.translations.register(owner, translations_dict)
    if result is False:
        raise RuntimeError('Bezier translation registration returned False')
    _TRANSLATION_OWNER = owner
    # Preserve any unknown legacy RNA/property.  This generation defines only
    # the explicit tlfc_* properties below and never deletes foreign state.
    for c in classes:
        result = bpy.utils.register_class(c)
        if result is False:
            raise RuntimeError(f'Bezier class registration returned False: {c.__name__}')
    bpy.types.WindowManager.tlfc_show_display_settings = bpy.props.BoolProperty(
        name="Show Display Settings",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_show_display_settings"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_sidebar_width = bpy.props.FloatProperty(
        name="Sidebar Width",
        description="Sidebar width as percentage of timeline panel width",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_sidebar_width"],
        min=TLFC_PROPERTY_RANGES["tlfc_sidebar_width"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_sidebar_width"][1],
        subtype='PERCENTAGE',
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_outer_pad = bpy.props.IntProperty(
        name="Outer Padding",
        description="Padding in pixels between the timeline region edges and the overlay panel",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_outer_pad"],
        min=TLFC_PROPERTY_RANGES["tlfc_outer_pad"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_outer_pad"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_samples = bpy.props.IntProperty(
        name="Curve Samples",
        description="Number of curve samples used for drawing the Bezier preview",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_samples"],
        min=TLFC_PROPERTY_RANGES["tlfc_samples"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_samples"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_show_info = bpy.props.BoolProperty(
        name="Toggle Info",
        description="Show selected curve diagnostics under the graph area",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_show_info"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_display_size = bpy.props.FloatProperty(
        name="Display Size",
        description="Global size multiplier for overlay UI elements",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_display_size"],
        min=TLFC_PROPERTY_RANGES["tlfc_display_size"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_display_size"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_h1x = bpy.props.FloatProperty(
        name="H1 X",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_h1x"],
        min=TLFC_PROPERTY_RANGES["tlfc_h1x"][0],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_h1y = bpy.props.FloatProperty(
        name="H1 Y",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_h1y"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_h2x = bpy.props.FloatProperty(
        name="H2 X",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_h2x"],
        max=TLFC_PROPERTY_RANGES["tlfc_h2x"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_h2y = bpy.props.FloatProperty(
        name="H2 Y",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_h2y"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_sidebar_mode = bpy.props.EnumProperty(
        name="Sidebar Mode",
        description="Active easing editor mode",
        items=[
            ('BEZIER',  'Bezier',  'Bezier curve editor'),
            ('ELASTIC', 'Elastic', 'Elastic ease-out editor'),
        ],
        default=TLFC_PROPERTY_DEFAULTS["tlfc_sidebar_mode"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_elastic_amplitude = bpy.props.FloatProperty(
        name="Elastic Amplitude",
        description="Overshoot factor",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_elastic_amplitude"],
        min=TLFC_PROPERTY_RANGES["tlfc_elastic_amplitude"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_elastic_amplitude"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_elastic_period = bpy.props.FloatProperty(
        name="Elastic Period",
        description="Oscillation period",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_elastic_period"],
        min=TLFC_PROPERTY_RANGES["tlfc_elastic_period"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_elastic_period"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_grid_subdiv = bpy.props.IntProperty(
        name="Grid Subdivisions",
        description="Grid density for the normalized editor view",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_grid_subdiv"],
        min=TLFC_PROPERTY_RANGES["tlfc_grid_subdiv"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_grid_subdiv"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_auto_apply = bpy.props.BoolProperty(
        name="Auto Apply",
        description="Automatically apply handle edits to selected keyframe segments while dragging",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_auto_apply"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_snap_threshold = bpy.props.FloatProperty(
        name="Edge Snap Threshold",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_snap_threshold"],
        min=TLFC_PROPERTY_RANGES["tlfc_snap_threshold"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_snap_threshold"][1],
        options={'HIDDEN'},
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_view_zoom = bpy.props.FloatProperty(
        name="View Zoom",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_view_zoom"],
        min=TLFC_PROPERTY_RANGES["tlfc_view_zoom"][0],
        max=TLFC_PROPERTY_RANGES["tlfc_view_zoom"][1],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_view_pan_x = bpy.props.FloatProperty(
        name="View Pan X",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_view_pan_x"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_view_pan_y = bpy.props.FloatProperty(
        name="View Pan Y",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_view_pan_y"],
        update=_persist_tlfc_setting,
    )
    bpy.types.WindowManager.tlfc_pan_start_x = bpy.props.FloatProperty(
        name="Pan Start X",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_pan_start_x"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_pan_start_y = bpy.props.FloatProperty(
        name="Pan Start Y",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_pan_start_y"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_pan_origin_x = bpy.props.FloatProperty(
        name="Pan Origin X",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_pan_origin_x"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_pan_origin_y = bpy.props.FloatProperty(
        name="Pan Origin Y",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_pan_origin_y"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_mouse_editing = bpy.props.BoolProperty(
        name="Mouse Edit",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_mouse_editing"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_hover_sidebar = bpy.props.BoolProperty(
        name="Hover Sidebar",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_hover_sidebar"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_hover_sidebar_edge = bpy.props.BoolProperty(
        name="Hover Sidebar Edge",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_hover_sidebar_edge"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_dragging_sidebar = bpy.props.BoolProperty(
        name="Dragging Sidebar",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_dragging_sidebar"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_hover_button = bpy.props.StringProperty(
        name="Hover Button",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_hover_button"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_pressed_button = bpy.props.StringProperty(
        name="Pressed Button",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_pressed_button"],
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.tlfc_hover_handle = bpy.props.StringProperty(
        name="Hover Handle",
        default=TLFC_PROPERTY_DEFAULTS["tlfc_hover_handle"],
        options={'HIDDEN'},
    )
    disable_header_callbacks()
    _OWNED_RNA_IDENTITIES.clear()
    for prop in _TLFC_RNA_PROPS:
        identity = lifecycle.rna_property_identity(bpy.types.WindowManager, prop)
        if identity is None:
            raise RuntimeError(f'Bezier RNA property missing after registration: WindowManager.{prop}')
        _OWNED_RNA_IDENTITIES[prop] = identity
    return True


def register():
    """No-raise lazy-tool registration boundary with exact partial rollback."""
    global _TRANSLATION_OWNER
    before_classes = {cls: lifecycle.class_registration_identity(cls) for cls in classes}
    before_rna = {name: lifecycle.rna_property_identity(bpy.types.WindowManager, name) for name in _TLFC_RNA_PROPS}
    owner_before = _TRANSLATION_OWNER
    try:
        result = _register_impl()
        if result is False:
            return False
        return True
    except Exception:
        disable_header_callbacks()
        _disable_runtime_handlers(clear_ui=True)
        owner = _TRANSLATION_OWNER
        if owner and owner != owner_before:
            try:
                bpy.app.translations.unregister(owner)
            except Exception:
                pass
        _TRANSLATION_OWNER = owner_before
        for name, previous in before_rna.items():
            current = lifecycle.rna_property_identity(bpy.types.WindowManager, name)
            if previous is None and current is not None:
                try:
                    delattr(bpy.types.WindowManager, name)
                except Exception:
                    pass
        _OWNED_RNA_IDENTITIES.clear()
        for cls in reversed(classes):
            if before_classes.get(cls) is None and lifecycle.class_registration_identity(cls) is not None:
                try:
                    bpy.utils.unregister_class(cls)
                except Exception:
                    pass
        return False


def unregister():
    global _TRANSLATION_OWNER
    owner = _TRANSLATION_OWNER
    if owner:
        try:
            bpy.app.translations.unregister(owner)
        except Exception:
            pass
    _TRANSLATION_OWNER = None
    _cleanup_previous()
    disable_header_callbacks()
    try:
        bpy.types.WindowManager.tlfc_mouse_editing = False
    except Exception:
        pass
    for prop in _TLFC_RNA_PROPS:
        expected = _OWNED_RNA_IDENTITIES.get(prop)
        if expected is not None and lifecycle.rna_property_identity(bpy.types.WindowManager, prop) == expected:
            try:
                delattr(bpy.types.WindowManager, prop)
            except Exception:
                pass
    _OWNED_RNA_IDENTITIES.clear()
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    return True
