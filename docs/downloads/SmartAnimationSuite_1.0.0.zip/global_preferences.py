# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import copy
from collections import OrderedDict
from types import SimpleNamespace
from typing import Any

from . import registry

_MAX_PROXY_CACHE = 64
_PROXY_CACHE: OrderedDict[str, Any] = OrderedDict()


class _PropertyNamesProxy:
    def __init__(self, names):
        self._names = tuple(names)

    def keys(self):
        return tuple(self._names)


class _BlRNAProxy:
    def __init__(self, names):
        self.properties = _PropertyNamesProxy(names)


def root_addon_id(module_name: str) -> str:
    text = str(module_name or '').strip()
    if not text:
        return text

    if text.startswith('bl_ext.'):
        parts = text.split('.')
        if len(parts) >= 4:
            return '.'.join(parts[:4])

    for alias in registry.TOOL_ALIASES:
        marker = f'.{alias}'
        if marker in text:
            head = text.split(marker, 1)[0].strip()
            if head:
                return head

    if '.' in text:
        return text.split('.', 1)[0]
    return text


def _copy_default(value: Any) -> Any:
    try:
        return copy.deepcopy(value)
    except Exception:
        pass
    try:
        return value.copy()
    except Exception:
        return value


def _property_keywords(prop_def: Any) -> dict[str, Any]:
    keywords = getattr(prop_def, 'keywords', None)
    if isinstance(keywords, dict):
        return dict(keywords)
    if isinstance(prop_def, tuple) and len(prop_def) >= 2 and isinstance(prop_def[1], dict):
        return dict(prop_def[1])
    return {}


def _property_function_name(prop_def: Any) -> str:
    fn = getattr(prop_def, 'function', None)
    if callable(fn):
        return str(getattr(fn, '__name__', '') or '')
    if isinstance(prop_def, tuple) and prop_def and callable(prop_def[0]):
        return str(getattr(prop_def[0], '__name__', '') or '')
    return ''


def _enum_default_from_keywords(keywords: dict[str, Any]) -> Any:
    if 'default' in keywords:
        return _copy_default(keywords.get('default'))
    items = keywords.get('items')
    if callable(items):
        return ''
    if isinstance(items, (list, tuple)) and items:
        first = items[0]
        if isinstance(first, (list, tuple)) and first:
            return _copy_default(first[0])
    return ''


def _proxy_from_class(rna_cls: type | None):
    if rna_cls is None or not isinstance(rna_cls, type):
        return SimpleNamespace()

    cache_key = f"{getattr(rna_cls, '__module__', '')}.{getattr(rna_cls, '__name__', '')}"
    cached = _PROXY_CACHE.get(cache_key)
    if cached is not None:
        try:
            _PROXY_CACHE.move_to_end(cache_key)
        except Exception:
            pass
        return cached

    proxy = SimpleNamespace()
    _PROXY_CACHE[cache_key] = proxy
    try:
        _PROXY_CACHE.move_to_end(cache_key)
    except Exception:
        pass
    while len(_PROXY_CACHE) > _MAX_PROXY_CACHE:
        try:
            _PROXY_CACHE.popitem(last=False)
        except Exception:
            break

    annotations = dict(getattr(rna_cls, '__annotations__', {}) or {})
    values: dict[str, Any] = {}
    for name, prop_def in annotations.items():
        try:
            values[name] = _default_from_property_definition(prop_def)
        except Exception:
            values[name] = None

    for name, value in values.items():
        setattr(proxy, name, value)

    try:
        setattr(proxy, 'bl_rna', _BlRNAProxy(values.keys()))
    except Exception:
        pass
    try:
        setattr(proxy, '_smart_animation_suite_proxy_preferences', True)
    except Exception:
        pass
    return proxy


def _default_from_property_definition(prop_def: Any) -> Any:
    keywords = _property_keywords(prop_def)
    function_name = _property_function_name(prop_def)

    if 'default' in keywords:
        return _copy_default(keywords.get('default'))

    pointer_type = keywords.get('type')
    if isinstance(pointer_type, type):
        if 'PointerProperty' in function_name:
            return _proxy_from_class(pointer_type)
        if 'CollectionProperty' in function_name:
            return []

    if 'EnumProperty' in function_name:
        return _enum_default_from_keywords(keywords)
    if 'StringProperty' in function_name:
        return ''
    if 'BoolProperty' in function_name:
        return False
    if 'FloatVectorProperty' in function_name:
        size = max(0, int(keywords.get('size') or 3))
        return tuple(0.0 for _ in range(size))
    if 'IntVectorProperty' in function_name:
        size = max(0, int(keywords.get('size') or 3))
        return tuple(0 for _ in range(size))
    if 'FloatProperty' in function_name:
        return 0.0
    if 'IntProperty' in function_name:
        return 0
    if 'CollectionProperty' in function_name:
        return []
    if 'PointerProperty' in function_name:
        return _proxy_from_class(pointer_type)

    enum_default = _enum_default_from_keywords(keywords)
    if enum_default != '':
        return enum_default
    return None


def is_suite_proxy_preferences(prefs: Any) -> bool:
    return bool(getattr(prefs, '_smart_animation_suite_proxy_preferences', False))


def get_preferences(module_name: str, preferences_cls: type | None = None, *extra_module_keys: str):
    del module_name, extra_module_keys
    if preferences_cls is not None:
        return _proxy_from_class(preferences_cls)
    return SimpleNamespace()


def open_root_preferences(module_name: str):
    del module_name
    return {'CANCELLED'}
