# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import re

import bpy
from bpy.types import Panel
from bpy.props import StringProperty, BoolProperty

from .translation import sas_error_reason, sas_text, sas_info, sas_localize_text
from . import registry, loader, ui_runtime
from . import icons as sas_icons
from . import smart_tools_manager_compat as manager_compat
from .core import *
from .ui_helpers import (
    draw_action_library_quick_picker,
    draw_pose_snapshot_quick_picker,
    draw_selection_set_quick_picker,
)


_PANEL_CLASSES = []


def _custom_icon_value(key: str) -> int:
    try:
        return int(sas_icons.icon_value(key) or 0)
    except Exception:
        return 0


def _draw_custom_label(layout, *, text: str, icon_key: str = '', fallback_icon: str = 'NONE'):
    value = _custom_icon_value(icon_key)
    resolved_icon = sas_icons.builtin_icon_name(icon_key, fallback_icon)
    if value:
        layout.label(text=text, icon='NONE', icon_value=value)
    else:
        layout.label(text=text, icon=resolved_icon)


def _draw_custom_operator(layout, operator_id: str, *, text: str, icon_key: str = '', fallback_icon: str = 'NONE', **kwargs):
    if not str(text or ''):
        kwargs.pop('emboss', None)
    value = _custom_icon_value(icon_key)
    resolved_icon = sas_icons.builtin_icon_name(icon_key, fallback_icon)
    if value:
        return layout.operator(operator_id, text=text, icon='NONE', icon_value=value, **kwargs)
    return layout.operator(operator_id, text=text, icon=resolved_icon, **kwargs)


_SMART_TOPIC_ICON_KEYS = {
    'smart_studio_dashboard': 'stage',
    'section_animation_recipes': 'super',
    'smart_motion_director': 'motion',
    'smart_graph_optimizer': 'graph',
    'smart_visualizer': 'visual',
    'smart_physics_director': 'physics',
    'smart_locomotion': 'locomotion',
    'smart_shape_control': 'shape',
    'smart_ifl': 'ifl',
    'smart_retarget': 'retarget',
    'smart_quality': 'quality',
    'smart_contact_timing': 'contact',
}


def _draw_help_button(layout, context, topic_key: str, *, text: bool = False):
    # Compact icon-only help button for N-panel groups.
    # The localized text stays in the operator tooltip and help popup.
    del text
    help_row = layout.row(align=True)
    help_row.scale_x = 0.82
    help_row.scale_y = 1.0
    op = help_row.operator('sas.show_help', text='', icon=sas_icons.builtin_icon_name('help', 'QUESTION'))
    op.topic_key = str(topic_key or '')
    return op


class _SASNullLayout:
    """No-op layout used to keep collapsed section bodies from drawing."""
    __slots__ = ()

    def __getattr__(self, _name):
        return self

    def __setattr__(self, _name, _value):
        return None

    def __call__(self, *args, **kwargs):
        return self

    def __bool__(self):
        return False


_NULL_LAYOUT = _SASNullLayout()

_OVERVIEW_ANALYSIS_CACHE = {'key': None, 'value': None, 'meta': None}
_OVERVIEW_ANALYSIS_REVISION = 0


def _schedule_all_integrated_tools_for_audit(_settings=None) -> None:
    """Compatibility no-op kept for callers outside Panel.draw.

    Integrated modules are loaded only by explicit operators.  The audit collector
    must not schedule imports, timers, registration, or persistence from UI draw.
    """
    return None


def invalidate_performance_cache(*_args, **kwargs) -> None:
    """Invalidate scalar diagnostics from explicit events, never from draw.

    Successful Suite operators and modal completion may refresh immediately when
    the Overview section is actually open. Load/unregister callers pass
    ``clear=True`` and only clear state. No timer, handler or redraw loop is used.
    """
    global _OVERVIEW_ANALYSIS_REVISION
    _OVERVIEW_ANALYSIS_REVISION = int(_OVERVIEW_ANALYSIS_REVISION or 0) + 1
    _OVERVIEW_ANALYSIS_CACHE['key'] = None
    _OVERVIEW_ANALYSIS_CACHE['meta'] = None
    if bool(kwargs.get('clear', False)):
        _OVERVIEW_ANALYSIS_CACHE['value'] = None
        return None
    context = kwargs.get('context')
    if context is not None and _overview_refresh_is_visible(context):
        refresh_performance_cache(context=context)
    return None



def _overview_analysis_revision_bump(_scene=None, _depsgraph=None):
    # Compatibility callback retained only so unregister can remove callbacks left
    # by older versions. Smart Animation 1.5.33 never registers it.
    invalidate_performance_cache()


def register_performance_cache() -> None:
    # Event-driven only. Remove obsolete continuously invoked handlers and keep no
    # timer/handler/msgbus resource while the Suite is idle.
    unregister_performance_cache()


def unregister_performance_cache() -> None:
    try:
        from bpy.app.handlers import depsgraph_update_post, frame_change_post, load_post
        for collection in (depsgraph_update_post, frame_change_post, load_post):
            while _overview_analysis_revision_bump in collection:
                collection.remove(_overview_analysis_revision_bump)
    except Exception:
        pass
    invalidate_performance_cache(clear=True)



def _ptr_key(value):
    if value is None:
        return 0
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _depsgraph_dirty_signature(context, action) -> tuple[int, ...]:
    """Read only the finite dirty-ID queue; never scan all objects/F-Curves."""
    result: list[int] = []
    try:
        depsgraph = context.evaluated_depsgraph_get()
        for update in tuple(getattr(depsgraph, 'updates', ()) or ())[:64]:
            original = getattr(getattr(update, 'id', None), 'original', None) or getattr(update, 'id', None)
            if original is action or str(getattr(getattr(original, 'bl_rna', None), 'identifier', '') or '') in {'Action', 'Object', 'Scene'}:
                result.append(_ptr_key(original))
    except Exception:
        pass
    return tuple(result)


def _is_animation_playing(context) -> bool:
    try:
        screen = getattr(context, 'screen', None)
        return bool(screen and getattr(screen, 'is_animation_playing', False))
    except Exception:
        return False


def _action_content_signature(action) -> tuple:
    """Scalar change fingerprint, evaluated only while visible and not playing.

    Mute flags are included for every F-Curve. Key values are sampled with a hard
    global cap, keeping the draw cost finite for pathological actions while still
    invalidating ordinary edited actions exactly. No RNA object is retained.
    """
    if action is None:
        return ()
    try:
        fcurves = tuple(getattr(action, 'fcurves', ()) or ())
    except Exception:
        return ()
    curve_meta: list[tuple] = []
    key_meta: list[tuple] = []
    remaining = 4096
    for index, fcurve in enumerate(fcurves):
        try:
            points = getattr(fcurve, 'keyframe_points', ()) or ()
            point_count = len(points)
            curve_meta.append((
                index, str(getattr(fcurve, 'data_path', '') or ''),
                int(getattr(fcurve, 'array_index', 0) or 0),
                bool(getattr(fcurve, 'mute', False)),
                bool(getattr(fcurve, 'lock', False)),
                point_count,
            ))
            if remaining <= 0 or point_count <= 0:
                continue
            take = min(point_count, remaining)
            if take == point_count:
                indices = range(point_count)
            elif take == 1:
                indices = (0,)
            else:
                indices = tuple(round(i * (point_count - 1) / (take - 1)) for i in range(take))
            for point_index in indices:
                point = points[point_index]
                co = getattr(point, 'co', (0.0, 0.0))
                key_meta.append((
                    index, int(point_index), round(float(co[0]), 7), round(float(co[1]), 7),
                    str(getattr(point, 'interpolation', '') or ''),
                    str(getattr(point, 'handle_left_type', '') or ''),
                    str(getattr(point, 'handle_right_type', '') or ''),
                ))
            remaining -= take
        except Exception:
            curve_meta.append((index, '', 0, False, False, 0))
    return (tuple(curve_meta), tuple(key_meta))


def _overview_analysis_key(context, settings, obj, action, *, dirty_signature=(), content_signature=()):
    """Build a scalar-only cache key from visible state and finite dirty input."""
    scene = getattr(context, 'scene', None)
    # Draw-time validation uses scalar identity/update flags only. F-Curve and
    # frame-range traversal is confined to explicit cache-refresh events.
    try:
        action_shape = (
            bool(getattr(action, 'is_updated', False)),
            bool(getattr(action, 'is_updated_data', False)),
        )
    except Exception:
        action_shape = (False, False)
    return (
        int(_OVERVIEW_ANALYSIS_REVISION or 0),
        _ptr_key(scene),
        _ptr_key(obj),
        _ptr_key(action),
        action_shape,
        tuple(content_signature or ()),
        tuple(dirty_signature or ()),
        bool(getattr(scene, 'use_preview_range', False)) if scene is not None else False,
        int(getattr(scene, 'frame_preview_start', 0) or 0) if scene is not None else 0,
        int(getattr(scene, 'frame_preview_end', 0) or 0) if scene is not None else 0,
        bool(getattr(settings, 'retime_use_range', False)),
        int(getattr(settings, 'retime_range_start', 0) or 0),
        int(getattr(settings, 'retime_range_end', 0) or 0),
        _ptr_key(getattr(settings, 'retarget_source', None)),
        _ptr_key(getattr(settings, 'retarget_target', None)),
        len(getattr(settings, 'bone_map', ()) or ()),
        len(getattr(settings, 'action_library', ()) or ()),
        len(getattr(settings, 'selection_sets', ()) or ()),
        bool(getattr(settings, 'auto_backup_action', False)),
        bool(getattr(settings, 'preview_only', False)),
    )

def _scalarize(value):
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, tuple):
        return tuple(_scalarize(item) for item in value)
    if isinstance(value, list):
        return [_scalarize(item) for item in value[:256]]
    if isinstance(value, dict):
        return {str(key): _scalarize(item) for key, item in list(value.items())[:256]}
    return str(value)


def _playback_overview_without_scan(context, settings):
    """Return a finite scalar placeholder without object/F-Curve traversal."""
    obj = active_object(context)
    action = active_action(context)
    scene = getattr(context, 'scene', None)
    try:
        total_mapping = int(len(getattr(settings, 'bone_map', ()) or ()))
    except Exception:
        total_mapping = 0
    return {
        'object_name': str(getattr(obj, 'name', '') or ''),
        'action_name': str(getattr(action, 'name', '') or ''),
        'nla_tracks': 0,
        'markers': int(len(getattr(scene, 'timeline_markers', ()) or ())) if scene is not None else 0,
        'stats': {'keys': 0, 'fcurves': 0},
        'issues': [],
        'readiness': 0,
        'density': (0, '-'),
        'mapping': {'matched': 0, 'unmatched': total_mapping, 'total': total_mapping},
        'live_constraints': 0,
    }




def _overview_context_marker(context, settings) -> tuple:
    """Cheap scalar marker used by Panel.draw; no depsgraph/F-Curve traversal."""
    scene = getattr(context, 'scene', None)
    obj = active_object(context)
    action = active_action(context)
    # Draw-time validation uses scalar identity/update flags only. F-Curve and
    # frame-range traversal is confined to explicit cache-refresh events.
    try:
        action_shape = (
            bool(getattr(action, 'is_updated', False)),
            bool(getattr(action, 'is_updated_data', False)),
        )
    except Exception:
        action_shape = (False, False)
    return (
        _ptr_key(scene), _ptr_key(obj), _ptr_key(action), action_shape,
        bool(getattr(scene, 'use_preview_range', False)) if scene is not None else False,
        int(getattr(scene, 'frame_preview_start', 0) or 0) if scene is not None else 0,
        int(getattr(scene, 'frame_preview_end', 0) or 0) if scene is not None else 0,
        str(getattr(settings, 'compact_timing_mode', '') or ''),
        str(getattr(settings, 'compact_timeline_mode', '') or ''),
        bool(getattr(settings, 'retime_use_range', False)),
        int(getattr(settings, 'retime_range_start', 0) or 0),
        int(getattr(settings, 'retime_range_end', 0) or 0),
        float(getattr(settings, 'remove_threshold', 0.0) or 0.0),
        float(getattr(settings, 'simplify_factor', 0.0) or 0.0),
        str(getattr(settings, 'compact_cleanup_mode', '') or ''),
        str(getattr(settings, 'compact_transfer_mode', '') or ''),
        str(getattr(settings, 'root_motion_bone', '') or ''),
        _ptr_key(getattr(settings, 'retarget_source', None)),
        _ptr_key(getattr(settings, 'retarget_target', None)),
        len(getattr(settings, 'bone_map', ()) or ()),
        bool(getattr(settings, 'auto_backup_action', False)),
        bool(getattr(settings, 'preview_only', False)),
    )



def _overview_refresh_is_visible(context) -> bool:
    try:
        scene = getattr(context, 'scene', None)
        settings = getattr(scene, 'sas_settings', None)
        if settings is None:
            return False
        return any(bool(getattr(settings, name, False)) for name in (
            'ui_section_overview',
            'ui_section_scene_snapshot',
            'ui_section_recommended_next_step',
            'ui_section_current_findings',
            'ui_section_timing_hub',
            'ui_section_cleanup_preview',
            'ui_section_transfer_hub',
            'ui_section_mapping_preview',
            'ui_section_animation',
        ))
    except Exception:
        return False



def refresh_performance_cache(context=None, settings=None) -> dict:
    """Build bounded scalar snapshots only from an explicit event boundary."""
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return {}
    settings = settings or _context_sas_settings(context)
    if settings is None or _is_animation_playing(context):
        cached = _OVERVIEW_ANALYSIS_CACHE.get('value')
        return cached if isinstance(cached, dict) else _playback_overview_without_scan(context, settings)

    marker_value = _overview_context_marker(context, settings)
    obj = active_object(context)
    action = active_action(context)
    overview_visible = any(bool(getattr(settings, name, False)) for name in (
        'ui_section_overview', 'ui_section_scene_snapshot',
        'ui_section_recommended_next_step', 'ui_section_current_findings',
    ))
    if overview_visible:
        issues = collect_scene_issues(context)
        mapping = count_mapped_bones(settings)
        data = {
            'object_name': str(getattr(obj, 'name', '') or ''),
            'action_name': str(getattr(action, 'name', '') or ''),
            'nla_tracks': int(nla_track_count(obj) or 0),
            'markers': int(len(getattr(getattr(context, 'scene', None), 'timeline_markers', ()) or ())),
            'stats': _scalarize(action_stats(action, obj=obj)),
            'issues': _scalarize(issues),
            'readiness': int(scene_readiness(context, issues) or 0),
            'density': _scalarize(get_action_density(action, obj=obj)),
            'mapping': _scalarize(mapping),
            'live_constraints': int(count_sas_retarget_constraints(getattr(settings, 'retarget_target', None)) or 0),
        }
    else:
        current = _OVERVIEW_ANALYSIS_CACHE.get('value')
        data = current if isinstance(current, dict) else _playback_overview_without_scan(context, settings)

    metrics: dict[str, object] = {}
    if (
        bool(getattr(settings, 'ui_section_animation', False))
        and str(getattr(settings, 'compact_timeline_mode', '') or '') in {'SHAPE_KEYS_ALL', 'SHAPE_KEYS_ACTIVE'}
    ):
        try:
            metrics['shape_key_count'] = int(shape_key_count(obj) or 0)
        except Exception:
            metrics['shape_key_count'] = 0
        try:
            metrics['shape_key_curve_count'] = int(len(iter_shape_key_fcurves(obj, create=False)) or 0)
        except Exception:
            metrics['shape_key_curve_count'] = 0

    if bool(getattr(settings, 'ui_section_timing_hub', False)) and action is not None:
        try:
            start_frame, end_frame = get_timing_range(context, action, settings)
            affected_curves = selected_fcurves(context, action) or iter_action_fcurves(action, datablock=obj)
            metrics['timing_frame_range'] = (float(start_frame), float(end_frame))
            metrics['timing_key_count'] = int(count_keys_in_frame_range(affected_curves, start_frame, end_frame) or 0)
        except Exception:
            metrics['timing_key_count'] = 0

    if bool(getattr(settings, 'ui_section_cleanup_preview', False)) and action is not None:
        try:
            metrics['cleanup_summary'] = _scalarize(summarize_cleanup(
                action, selected_fcurves(context, action),
                settings.remove_threshold, settings.simplify_factor,
            ))
        except Exception:
            metrics['cleanup_summary'] = {
                'simplify_keys': 0, 'duplicate_keys': 0, 'static_channels': 0,
            }

    if any(bool(getattr(settings, name, False)) for name in (
        'ui_section_transfer_hub', 'ui_section_mapping_preview',
    )):
        try:
            metrics['root_curve_count'] = int(count_matching_root_curves(action, obj, settings) or 0)
        except Exception:
            metrics['root_curve_count'] = 0
        try:
            metrics['mapping'] = _scalarize(count_mapped_bones(settings))
        except Exception:
            metrics['mapping'] = {'matched': 0, 'total': 0, 'high_conf': 0}
        try:
            metrics['live_constraints'] = int(count_sas_retarget_constraints(settings.retarget_target) or 0)
        except Exception:
            metrics['live_constraints'] = 0

    _OVERVIEW_ANALYSIS_CACHE['key'] = marker_value
    _OVERVIEW_ANALYSIS_CACHE['value'] = data
    _OVERVIEW_ANALYSIS_CACHE['meta'] = {
        'revision': int(_OVERVIEW_ANALYSIS_REVISION or 0),
        'context_marker': marker_value,
        'draw_metrics': metrics,
    }
    return data




def _draw_metric(context, settings, name: str, default=None):
    meta = _OVERVIEW_ANALYSIS_CACHE.get('meta')
    if not isinstance(meta, dict):
        return default
    if tuple(meta.get('context_marker') or ()) != _overview_context_marker(context, settings):
        return default
    metrics = meta.get('draw_metrics')
    if not isinstance(metrics, dict):
        return default
    return metrics.get(str(name or ''), default)


def _overview_analysis(context, settings):
    """Pure read-only draw lookup of an event-built scalar snapshot."""
    cached = _OVERVIEW_ANALYSIS_CACHE.get('value')
    meta = _OVERVIEW_ANALYSIS_CACHE.get('meta')
    marker_value = _overview_context_marker(context, settings)
    if (
        isinstance(cached, dict)
        and isinstance(meta, dict)
        and tuple(meta.get('context_marker') or ()) == marker_value
    ):
        return cached
    return _playback_overview_without_scan(context, settings)


def _section_storage_key(section_key: str) -> str:
    value = str(section_key or '').strip()
    value = re.sub(r'[^0-9A-Za-z_]+', '_', value).strip('_').lower()
    if not value:
        value = 'section'
    if value == 'show_always_on_toggle_group':
        return value
    if value.startswith('ui_section_'):
        return value
    if value.startswith('section_'):
        return 'ui_' + value
    return 'ui_section_' + value


def _section_state(settings, section_key: str, default: bool = False) -> bool:
    """Read one statically registered RNA flag without creating ID properties."""
    key = _section_storage_key(section_key)
    if settings is None or not key:
        return bool(default)
    try:
        return bool(getattr(settings, key)) if hasattr(settings, key) else bool(default)
    except Exception:
        return bool(default)


def _section_state_set(settings, section_key: str, value: bool, *, context=None) -> None:
    """Update only a register-time BoolProperty; unknown keys remain untouched."""
    key = _section_storage_key(section_key)
    if settings is None or not key:
        return
    try:
        if not hasattr(settings, key):
            return
        setattr(settings, key, bool(value))
    except Exception:
        return
    try:
        save_settings_if_changed(settings, context=context)
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in list(getattr(wm, 'windows', ()) or ()):  # type: ignore[attr-defined]
            screen = getattr(window, 'screen', None)
            for area in list(getattr(screen, 'areas', ()) or ()):  # type: ignore[attr-defined]
                if getattr(area, 'type', None) in _SAS_NPANEL_SPACE_TYPES:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _section_icon_key(topic_key: str) -> str:
    return _SMART_TOPIC_ICON_KEYS.get(str(topic_key or '').strip(), '')


def _draw_section_toggle_operator(row, context, *, section_key: str, label: str, default_state: bool, text: str = '', icon: str = 'NONE', icon_key: str = '', emboss: bool = True, depress: bool = False):
    value = _custom_icon_value(icon_key) if icon_key else 0
    resolved_icon = sas_icons.builtin_icon_name(icon_key, icon) if icon_key else icon
    try:
        if value:
            op = row.operator('sas.toggle_ui_section', text=text, icon='NONE', icon_value=value, emboss=emboss, depress=depress)
        else:
            op = row.operator('sas.toggle_ui_section', text=text, icon=resolved_icon, emboss=emboss, depress=depress)
    except TypeError:
        if value:
            op = row.operator('sas.toggle_ui_section', text=text, icon='NONE', icon_value=value, emboss=emboss)
        else:
            op = row.operator('sas.toggle_ui_section', text=text, icon=resolved_icon, emboss=emboss)
    op.section_key = str(section_key or '')
    op.label = str(label or '')
    op.default_state = bool(default_state)
    return op


def _draw_collapsible_section_header(box, context, settings, section_key: str, en_label: str, ja_label: str, icon: str = 'NONE', topic_key: str = '', *, default: bool = False) -> bool:
    topic_key = str(topic_key or section_key or '').strip()
    label = sas_text(en_label, ja_label, context)
    key = section_key or topic_key or en_label
    expanded = _section_state(settings, key, default)
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    _draw_section_toggle_operator(
        row,
        context,
        section_key=key,
        label=label,
        default_state=default,
        text='',
        icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
        emboss=True,
        depress=bool(expanded),
    )
    # Match Smart Transform's stable Blender 5.1 header layout: use one
    # borderless operator for the section icon + title. Avoid separator_spacer()
    # and nested right-aligned rows because they can leave stair-step indentation
    # in the N-panel after redraws.
    _draw_section_toggle_operator(
        row,
        context,
        section_key=key,
        label=label,
        default_state=default,
        text=label,
        icon=icon,
        icon_key=_section_icon_key(topic_key),
        emboss=False,
        depress=bool(expanded),
    )
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(row, context, topic_key, text=False)
    return bool(expanded)


def _panel_id_from_key(prefix: str, section_key: str) -> str:
    value = re.sub(r'[^0-9A-Za-z_]+', '_', str(section_key or '').strip()).strip('_').lower()
    if not value:
        value = 'section'
    return f'{prefix}_{value}'


def _setup_section_body(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _ensure_section_bool_idprop(settings, storage_key: str, default: bool) -> str:
    """Return an already-registered RNA property without mutating during draw."""
    storage_key = str(storage_key or '').strip()
    if not storage_key or settings is None:
        return ''
    try:
        if hasattr(settings, storage_key):
            return storage_key
    except Exception:
        pass
    # Dynamic child-section keys are created only by the explicit toggle
    # operator. Panel drawing must remain a read-only operation.
    return ''


def _draw_standard_child_header(header, context, label: str, icon: str, topic_key: str):
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    try:
        header.label(text=label, icon=icon)
    except Exception:
        try:
            header.label(text=label)
        except Exception:
            pass
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(header, context, topic_key, text=False)


def _begin_standard_child_section(layout, context, settings, section_key: str, en_label: str, ja_label: str, icon: str = 'NONE', topic_key: str = '', *, default: bool = False):
    if not layout:
        return _NULL_LAYOUT
    topic_key = str(topic_key or section_key or '').strip()
    label = sas_text(en_label, ja_label, context)
    key = section_key or topic_key or en_label
    storage_key = _section_storage_key(key)
    prop_name = _ensure_section_bool_idprop(settings, storage_key, default)

    # Child sections use Blender's native collapsible sub-panel control when
    # available. This gives the standard disclosure ">" behavior instead of the
    # Smart Modeling-style custom header used only by top-level sections.
    if settings is not None and prop_name:
        try:
            header, panel = layout.panel_prop(settings, prop_name)
            if header is not None:
                _draw_standard_child_header(header, context, label, icon, topic_key)
            expanded = panel is not None
            if not expanded:
                return _NULL_LAYOUT
            return _setup_section_body(panel)
        except Exception:
            pass

    header, panel = layout.panel(
        idname=f'sas_native_child_{storage_key}',
        default_closed=not _section_state(settings, key, default),
    )
    _draw_standard_child_header(header, context, label, icon, topic_key)
    if panel is None:
        return _NULL_LAYOUT
    return _setup_section_body(panel)


def _begin_top_level_section(layout, context, settings, section_key: str, en_label: str, ja_label: str, icon: str = 'NONE', topic_key: str = '', *, default: bool = False):
    box = layout.box()
    expanded = _draw_collapsible_section_header(box, context, settings, section_key, en_label, ja_label, icon, topic_key or section_key, default=default)
    if not expanded:
        return _NULL_LAYOUT
    # Return the parent layout rather than a nested box/column. This lets child
    # sections use full-width Blender-style BoolProperty disclosure rows.
    return _setup_section_body(layout)


def _begin_collapsible_section(layout, context, settings, section_key: str, en_label: str, ja_label: str, icon: str = 'NONE', topic_key: str = '', *, default: bool = False):
    return _begin_standard_child_section(layout, context, settings, section_key, en_label, ja_label, icon, topic_key, default=default)


def _draw_header_with_help(box, context, en_label: str, ja_label: str, icon: str, topic_key: str):
    # Legacy non-collapsible header renderer kept for compatibility with any
    # unconverted call sites. Use the same no-spacer, no-nested-row layout as
    # collapsible section headers to avoid Blender 5.1 N-panel stair-step redraws.
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    row.label(text='', icon='BLANK1')
    icon_key = _section_icon_key(topic_key)
    value = _custom_icon_value(icon_key) if icon_key else 0
    if value:
        row.label(text=sas_text(en_label, ja_label, context), icon='NONE', icon_value=value)
    else:
        row.label(text=sas_text(en_label, ja_label, context), icon=icon)
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(row, context, topic_key, text=False)
    return row


_SAS_NPANEL_SPACE_TYPES = {
    'VIEW_3D',          # 3D Viewport.
    'IMAGE_EDITOR',     # Image Editor / UV Editor.
    'NODE_EDITOR',      # Shader / Compositor / Geometry Nodes / Texture Nodes.
    'SEQUENCE_EDITOR',  # Video Sequencer.
    'CLIP_EDITOR',      # Movie Clip Editor.
    'DOPESHEET_EDITOR', # Dope Sheet.
    'GRAPH_EDITOR',     # Graph Editor / Drivers.
    'NLA_EDITOR',       # Nonlinear Animation.
    'TEXT_EDITOR',      # Text Editor.
    'FILE_BROWSER',     # File Browser / Asset Browser.
    'SPREADSHEET',      # Spreadsheet.
}


def _is_sas_npanel_context(context) -> bool:
    try:
        area = getattr(context, "area", None)
        area_type = getattr(area, "type", None) if area is not None else None
        if area_type not in _SAS_NPANEL_SPACE_TYPES:
            return False
        if getattr(context, 'scene', None) is None:
            return False
        # Do not hide the panel during mode transitions. The draw path is guarded,
        # and Smart Tools Manager may proxy this panel across editor contexts.
        return True
    except Exception:
        return False


def _is_view3d_sidebar_context(context) -> bool:
    # Backward-compatible helper name used by older internal code. The Smart
    # Animation N-panel now supports the animation editors listed above.
    return _is_sas_npanel_context(context)



COMPACT_TABS = (
    ('OVERVIEW', "Overview", 'HOME'),
    ('ANIMATE', "Animate", 'KEY_HLT'),
    ('ASSETS', "Assets", 'ASSET_MANAGER'),
    ('TRANSFER', "Transfer", 'ARROW_LEFTRIGHT'),
)


FX_CLEARABLE_MODES = {
    'SIGNAL',
    'STRETCH',
    'VEHICLE',
    'REVEAL',
    'TRAIL',
    'GHOST',
    'BALLISTIC_GUIDE',
    'BALLISTIC_BAKE',
    'CAMERA_SHAKE',
    'LOOP',
    'NOISE',
    'PATHS',
    'DYNAMIC_PARENT',
}

PLAYBACK_MODES = {
    'PREVIEW_FROM_KEYS',
    'PREVIEW_FROM_SOUND',
    'PREVIEW_FROM_CURRENT_SHOT',
    'PREVIEW_FROM_ALL_SHOTS',
    'CLEAR_PREVIEW',
    'PLAYBACK_BLOCKING',
    'PLAYBACK_REVIEW',
    'PLAYBACK_LIPSYNC',
}


def _search_ok(settings, tokens):
    # The top search field was removed. Keep legacy saved search text from
    # filtering hidden sections after upgrading older files.
    del settings, tokens
    return True


def _compact_header(layout, context, settings):
    box = _begin_top_level_section(
        layout,
        context,
        settings,
        'overview_task_dropdown',
        'Overview Task',
        '概要タスク',
        'ACTION',
        'overview_task_dropdown',
        default=False,
    )
    if getattr(getattr(context, "area", None), "type", "") != 'VIEW_3D':
        header = box.row(align=True)
        header.label(text=sas_text("Smart Animation", "Smart Animation", context), icon='ACTION')
    row = box.row(align=True)
    row.prop(settings, "compact_diag_mode", text=sas_text("Task", "タスク", context))
    return box



def _stats_box(layout, context, settings, analysis=None):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('scene_snapshot'), "Scene Snapshot", "シーン要約", 'SCENE_DATA', str('scene_snapshot'))
    if not box:
        return None
    analysis = analysis or _overview_analysis(context, settings)
    object_name = str(analysis.get('object_name') or '')
    action_name = str(analysis.get('action_name') or '')
    stats = analysis.get('stats') or {'keys': 0, 'fcurves': 0}
    issues = analysis.get('issues') or []
    readiness = int(analysis.get('readiness') or 0)
    _density_value, density_label = analysis.get('density') or (0, '-')
    mapping = analysis.get('mapping') or {'matched': 0, 'total': 0}
    live_constraints = int(analysis.get('live_constraints') or 0)

    box.label(text=sas_text(f"Object: {object_name or '-'}", f"オブジェクト: {object_name or '-'}", context), translate=False, icon='OBJECT_DATA')
    box.label(text=sas_text(f"Action: {action_name or '-'}", f"アクション: {action_name or '-'}", context), translate=False, icon='ACTION')
    box.label(text=sas_text(f"Mode: {_mode_display_name(context.mode, context)}", f"モード: {_mode_display_name(context.mode, context)}", context), translate=False, icon='VIEW3D')
    grid = box.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
    grid.label(text=sas_text(f"Keys: {stats['keys']}", f"キー数: {stats['keys']}", context), icon='KEY_HLT')
    grid.label(text=sas_text(f"F-Curves: {stats['fcurves']}", f"F カーブ: {stats['fcurves']}", context), icon='IPO_BEZIER')
    grid.label(text=sas_text(f"Markers: {int(analysis.get('markers') or 0)}", f"マーカー: {int(analysis.get('markers') or 0)}", context), icon='MARKER')
    grid.label(text=sas_text(f"NLA Tracks: {int(analysis.get('nla_tracks') or 0)}", f"NLA トラック: {int(analysis.get('nla_tracks') or 0)}", context), icon='NLA')
    grid.label(text=sas_text(f"Ready: {readiness}%", f"準備度: {readiness}%", context), icon='CHECKMARK' if readiness >= 80 else 'ERROR')
    grid.label(text=sas_text(f"Density: {density_label}", f"密度: {_DENSITY_NAMES_JA.get(str(density_label), str(density_label))}", context), icon='SEQ_LUMA_WAVEFORM')
    grid.label(text=sas_text(f"Issues: {len(issues)}", f"問題数: {len(issues)}", context), icon='ERROR' if issues else 'CHECKMARK')
    grid.label(text=sas_text(f"Mapped: {mapping['matched']}/{mapping['total']}", f"一致ボーン: {mapping['matched']}/{mapping['total']}", context), icon='BONE_DATA')
    grid.label(text=sas_text(f"Live: {live_constraints}", f"ライブ: {live_constraints}", context), icon='CONSTRAINT')
    return issues


def _cached_recommendations(context, issues, settings, analysis):
    """Build recommendation labels from the bounded scalar event snapshot only."""
    analysis = analysis if isinstance(analysis, dict) else {}
    settings = settings or _context_sas_settings(context)
    object_name = str(analysis.get('object_name') or '')
    action_name = str(analysis.get('action_name') or '')
    stats = analysis.get('stats') if isinstance(analysis.get('stats'), dict) else {}
    mapping = analysis.get('mapping') if isinstance(analysis.get('mapping'), dict) else {}
    live_constraints = int(analysis.get('live_constraints') or 0)
    recs = []

    if not object_name:
        return [("OBJECT_DATA", "Select an object to begin.", "開始するにはオブジェクトを選択してください。")]

    if not action_name:
        recs.append(("ADD", "Create or assign an action, then start keying with Timeline Hub in the Animation Tools task.", "アクションを作成または割り当ててから、タスク「アニメーションツール」のタイムラインハブでキー作業を始めてください。"))
    elif int(stats.get('keys') or 0) <= 0:
        recs.append(("KEY_HLT", "Insert your first keys with Timeline Hub in the Animation Tools task.", "タスク「アニメーションツール」のタイムラインハブで最初のキーを挿入してください。"))
    else:
        recs.append(("VIEWZOOM", "Use Cleanup Preview before destructive cleanup on dense animation.", "密なアニメーションを整理する前に、整理プレビューで影響を確認してください。"))

    error_count = sum(1 for item in list(issues or ())[:256] if isinstance(item, (tuple, list)) and item and item[0] == 'ERROR')
    if error_count:
        recs.append(("CANCEL", f"Resolve {error_count} blocking issue(s) shown in Current Findings.", f"現在の検出結果に表示された{error_count}件の停止要因を先に解消してください。"))

    source_present = bool(getattr(settings, 'retarget_source', None)) if settings is not None else False
    target_present = bool(getattr(settings, 'retarget_target', None)) if settings is not None else False
    total = int(mapping.get('total') or 0)
    matched = int(mapping.get('matched') or 0)
    unmatched = int(mapping.get('unmatched') or max(0, total - matched))
    if source_present and target_present and total <= 0:
        recs.append(("ARROW_LEFTRIGHT", "Build a bone map before creating a live retarget preview.", "ライブリターゲットの前にボーン対応表を作成してください。"))
    elif total and matched < total:
        recs.append(("BONE_DATA", f"Review unmatched retarget pairs ({unmatched} bones) before baking anything.", f"未一致の対応 ({unmatched} 本) を確認してからベイクしてください。"))
    elif matched and live_constraints <= 0:
        recs.append(("CONSTRAINT", "Build a live retarget preview to test the mapping non-destructively.", "非破壊で対応確認するため、ライブリターゲットプレビューを作成してください。"))

    if not recs:
        recs.append(("CHECKMARK", "The scene looks ready. Continue animating or export a report for review.", "シーンの準備状態は良好です。作業を続けるか、確認用レポートを出力してください。"))
    return recs[:5]


def _recommended_box(layout, context, issues, settings=None, analysis=None):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('recommended_next_step'), "Recommended Next Step", "おすすめの次操作", 'FORWARD', str('recommended_next_step'))
    if not box:
        return issues
    if issues is None:
        settings = settings or _context_sas_settings(context)
        analysis = analysis or _overview_analysis(context, settings)
        issues = analysis.get('issues') or []
    settings = settings or _context_sas_settings(context)
    analysis = analysis or _overview_analysis(context, settings)
    from . import help as sas_help
    region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    ui_scale = float(context.preferences.system.ui_scale)
    max_pixels = max(int(120 * ui_scale), int(region_width - 90 * ui_scale))
    for icon_name, en_message, ja_message in _cached_recommendations(context, issues, settings, analysis):
        message_col = box.column(align=True)
        for index, line in enumerate(sas_help._wrap_line_to_pixels(context, sas_text(en_message, ja_message, context), max_pixels)):
            message_col.label(text=line, icon=icon_name if index == 0 else 'BLANK1')
    return issues


def _action_slot_box(layout, context):
    obj = active_object(context)
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('action_slot'), "Current Action Slot", "現在のアクションスロット", 'ACTION', str('action_slot'))
    if not box:
        return box
    if obj:
        anim_data = obj.animation_data
        if anim_data:
            box.template_ID(anim_data, "action", new="sas.new_action")
        else:
            box.operator("sas.new_action", text=sas_text("Create Action", "アクション作成", context), icon='ADD')
    else:
        box.label(text=sas_text("Select an object first.", "まずオブジェクトを選択してください。", context), icon='OBJECT_DATA')
    return box


def _scene_findings_box(layout, context, issues, settings):
    if not issues:
        return
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('current_findings'), "Current Findings", "現在の検出結果", 'ERROR', str('current_findings'))
    if not box:
        return
    for level, en_message, ja_message in issues[:6]:
        column = box.column(align=True)
        column.alert = level == "ERROR"
        icon_name = 'CANCEL' if level == "ERROR" else ('ERROR' if level == "WARN" else 'DOT')
        from . import help as sas_help
        region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
        ui_scale = float(context.preferences.system.ui_scale)
        max_pixels = max(int(120 * ui_scale), int(region_width - 100 * ui_scale))
        for index, line in enumerate(sas_help._wrap_line_to_pixels(context, sas_text(en_message, ja_message, context), max_pixels)):
            column.label(text=line, icon=icon_name if index == 0 else 'BLANK1', translate=False)


def _operation_log_box(layout, context, settings):
    log_box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('operation_log'), "Operation Log", "操作ログ", 'TEXT', str('operation_log'))
    if not log_box:
        return
    row = log_box.row(align=True)
    row.prop(settings, "log_limit", text=sas_text("Log Limit", "ログ保持数", context))
    row.operator("sas.clear_operation_log", text=sas_text("Clear", "クリア", context), icon='TRASH')
    count_row = log_box.row(align=True)
    count_row.label(text=sas_text(f"Info: {operation_log_count(context, 'INFO')}", f"情報: {operation_log_count(context, 'INFO')}", context))
    count_row.label(text=sas_text(f"Warn: {operation_log_count(context, 'WARN')}", f"警告: {operation_log_count(context, 'WARN')}", context), icon='ERROR')
    count_row.label(text=sas_text(f"Error: {operation_log_count(context, 'ERROR')}", f"エラー: {operation_log_count(context, 'ERROR')}", context), icon='CANCEL')
    if settings.operation_log:
        log_box.template_list("SAS_UL_operation_log", "", settings, "operation_log", settings, "operation_log_index", rows=4)


_DENSITY_NAMES_JA = {'None': 'なし', 'Sparse': '少ない', 'Balanced': '標準', 'Dense': '多い', 'Very Dense': '非常に多い'}
_MODE_NAMES = {
    'OBJECT': ('Object', 'オブジェクト'),
    'POSE': ('Pose', 'ポーズ'),
    'SCULPT': ('Sculpt', 'スカルプト'),
    'PAINT_WEIGHT': ('Weight Paint', 'ウェイトペイント'),
    'PAINT_VERTEX': ('Vertex Paint', '頂点ペイント'),
    'PAINT_TEXTURE': ('Texture Paint', 'テクスチャペイント'),
    'PARTICLE': ('Particle Edit', 'パーティクル編集'),
    'EDIT_MESH': ('Edit Mesh', 'メッシュ編集'),
    'EDIT_CURVE': ('Edit Curve', 'カーブ編集'),
    'EDIT_CURVES': ('Edit Hair Curves', 'ヘアカーブ編集'),
    'EDIT_SURFACE': ('Edit Surface', 'サーフェス編集'),
    'EDIT_TEXT': ('Edit Text', 'テキスト編集'),
    'EDIT_ARMATURE': ('Edit Armature', 'アーマチュア編集'),
    'EDIT_METABALL': ('Edit Metaball', 'メタボール編集'),
    'EDIT_LATTICE': ('Edit Lattice', 'ラティス編集'),
    'EDIT_POINTCLOUD': ('Edit Point Cloud', 'ポイントクラウド編集'),
    'SCULPT_CURVES': ('Sculpt Curves', 'カーブスカルプト'),
    'EDIT_GREASE_PENCIL': ('Grease Pencil Edit', 'グリースペンシル編集'),
    'PAINT_GREASE_PENCIL': ('Grease Pencil Draw', 'グリースペンシル描画'),
    'SCULPT_GREASE_PENCIL': ('Grease Pencil Sculpt', 'グリースペンシルスカルプト'),
    'WEIGHT_GREASE_PENCIL': ('Grease Pencil Weight', 'グリースペンシルウェイト'),
    'VERTEX_GREASE_PENCIL': ('Grease Pencil Vertex', 'グリースペンシル頂点ペイント'),
}


def _mode_display_name(mode, context) -> str:
    key = str(mode or '')
    names = _MODE_NAMES.get(key)
    if names is None:
        fallback = key.replace('_', ' ').title()
        return sas_text(fallback, 'その他', context)
    return sas_text(names[0], names[1], context)


_OVERVIEW_ACTION_BUTTONS = (
    ('sas.smart_assist', 'Smart Assist', 'スマートアシスト', 'Check the current scene and switch the Task to the most relevant one.', '現在のシーンを確認し、作業に合うタスクへ切り替えます。', 'LIGHT'),
    ('sas.auto_fix_scene_basics', 'Auto Fix', '自動修復', 'Repair common setup problems such as missing actions or invalid preview ranges.', 'アクション欠落や不正なプレビュー範囲など、よくある設定問題を修復します。', 'TOOL_SETTINGS'),
    ('sas.run_scene_audit', 'Audit', '監査', 'Scan the scene for animation issues that should be checked before editing or export.', '編集や書き出し前に確認すべきアニメーション上の問題を検査します。', 'VIEWZOOM'),
    ('sas.export_report', 'Export Report', 'レポート書き出し', 'Write the current scene summary and diagnostic result to a Blender text datablock.', '現在のシーン要約と診断結果を Blender テキストデータへ書き出します。', 'TEXT'),
    ('sas.clear_operation_log', 'Clear Log', 'ログをクリア', 'Remove old messages from the in-panel operation log.', 'Nパネル内の操作ログから古いメッセージを消去します。', 'TRASH'),
)


def _operator_id_available(op_id: str) -> bool:
    if '.' not in str(op_id or ''):
        return False
    group_name, op_name = str(op_id).split('.', 1)
    group = getattr(bpy.ops, group_name, None)
    return group is not None and hasattr(group, op_name)


def _draw_overview_action_buttons(layout, context):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), 'overview_actions', 'Overview Actions', '概要アクション', 'TOOL_SETTINGS', 'overview_actions')
    if not box:
        return
    col = box.column(align=True)
    for op_id, en_label, ja_label, en_desc, ja_desc, icon in _OVERVIEW_ACTION_BUTTONS:
        row = col.row(align=True)
        if _operator_id_available(op_id):
            row.operator(op_id, text=sas_text(en_label, ja_label, context), icon=icon)
        else:
            row.label(text=sas_text(en_label, ja_label, context), icon='ERROR')


def _section_help_key(en_label: str) -> str:
    mapping = {
        'Overview / Diagnostics': 'section_overview',
        'Animation Recipes': 'section_animation_recipes',
        'Animation Tools': 'section_animation',
        'Asset Tools': 'section_assets',
        'Transfer Tools': 'section_transfer',
        'Migrated Bundled Tools': 'section_migrated',
    }
    return mapping.get(str(en_label or ''), 'overview_task_dropdown')


def _draw_section_header(layout, context, en_label: str, ja_label: str, icon: str = 'NONE'):
    return _begin_top_level_section(layout, context, _context_sas_settings(context), _section_help_key(en_label), en_label, ja_label, icon, _section_help_key(en_label), default=False)


def _tool_display_name(alias: str) -> str:
    alias = str(alias or '').strip()
    meta = registry.TOOL_META.get(alias) or {}
    return str(meta.get('display_name') or alias.replace('_', ' ').title() or alias)


def _always_on_manual_entries():
    entries = []
    for alias in registry.TOOL_ALIASES:
        try:
            tool_entries = loader.tool_background_entries(alias)
        except Exception:
            tool_entries = []
        for item in tool_entries:
            key = str(item.get('key') or '').strip()
            if not key:
                continue
            entries.append({
                'source': 'MANUAL',
                'alias': alias,
                'feature_key': key,
                'tool_label': _tool_display_name(alias),
                'label_en': str(item.get('label_en') or key),
                'label_ja': str(item.get('label_ja') or key),
                'description_en': str(item.get('description_en') or ''),
                'description_ja': str(item.get('description_ja') or ''),
                'enabled': bool(item.get('enabled')),
                'property_name': str(item.get('property_name') or ''),
                'sort_key': (_tool_display_name(alias).lower(), str(item.get('label_en') or key).lower()),
            })
    return entries




def _draw_small_wrapped(layout, text: str, *, icon: str = 'NONE', width: int = 90):
    text = str(text or '').strip()
    if not text:
        return
    words = text.replace('\n', ' ').split()
    line = ''
    for word in words:
        candidate = f'{line} {word}'.strip()
        if len(candidate) > width and line:
            layout.label(text=line, icon=icon)
            icon = 'NONE'
            line = word
        else:
            line = candidate
    if line:
        layout.label(text=line, icon=icon)


def _collect_always_on_entries(*, schedule_audit: bool = False, settings=None) -> list[dict]:
    if schedule_audit:
        _schedule_all_integrated_tools_for_audit(settings)
    # Startup-safe source of truth: only declared optional always-on items are
    # shown here.  Captured third-party callbacks are intentionally not drawn as
    # ad-hoc operator buttons because the centralized UI must use real saved
    # BoolProperty toggles so Blender keeps the active blue overlay stable.
    entries = _always_on_manual_entries()
    seen = set()
    unique_entries = []
    for item in entries:
        marker = (str(item.get('source') or ''), str(item.get('alias') or ''), str(item.get('feature_key') or ''))
        if marker in seen:
            continue
        seen.add(marker)
        unique_entries.append(item)
    unique_entries.sort(key=lambda item: item.get('sort_key') or ('', ''))
    return unique_entries



def _draw_always_on_toggle_row(layout, context, settings, *, label: str, prop_name: str = '', enabled: bool = False, disabled_label: bool = False) -> None:
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.column(align=True)
    tool_name, separator, feature_name = str(label or '').partition(': ')
    if separator:
        left.label(text=tool_name, icon='NONE')
        left.label(text=feature_name, icon='NONE')
    else:
        left.label(text=str(label or ''), icon='NONE')
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if prop_name and settings is not None and hasattr(settings, prop_name):
        try:
            enabled = bool(getattr(settings, prop_name))
        except Exception:
            enabled = bool(enabled)
        right.prop(
            settings,
            prop_name,
            text=sas_text('On', '有効', context) if enabled else sas_text('Off', '無効', context),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
    else:
        holder = right.row(align=True)
        holder.enabled = not bool(disabled_label)
        holder.label(
            text=sas_text('On', '有効', context) if enabled else sas_text('Off', '無効', context),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
        )


def _draw_npanel_state_save_toggle(layout, context, settings) -> None:
    _draw_always_on_toggle_row(
        layout,
        context,
        settings,
        label=sas_text('N-panel State Save', 'Nパネル状態保存', context),
        prop_name='npanel_state_auto_save',
        enabled=True,
    )


def _draw_always_on_toggles(layout, context, settings) -> None:
    box = _begin_top_level_section(
        layout,
        context,
        settings,
        'show_always_on_toggle_group',
        'Resident Feature Toggles',
        '常時機能切り替え',
        'TIME',
        'always_on',
        default=False,
    )
    if not box:
        return

    unique_entries = _collect_always_on_entries(schedule_audit=False, settings=settings)

    col = box.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    _draw_npanel_state_save_toggle(col, context, settings)
    try:
        col.separator(factor=0.5)
    except Exception:
        col.separator()

    if not unique_entries:
        col.label(text=sas_text('No always-on item is currently registered.', '現在登録されている常時起動項目はありません。', context))
        return

    for item in unique_entries:
        prop_name = str(item.get('property_name') or '').strip()
        if prop_name == 'npanel_state_auto_save':
            continue
        if prop_name and hasattr(settings, prop_name):
            try:
                enabled = bool(getattr(settings, prop_name))
            except Exception:
                enabled = bool(item.get('enabled'))
        else:
            enabled = bool(item.get('enabled'))
        tool_label = sas_localize_text(str(item.get('tool_label') or _tool_display_name(str(item.get('alias') or ''))), context)
        feature_label = sas_text(str(item.get('label_en') or ''), str(item.get('label_ja') or ''), context)
        label = f'{tool_label}: {feature_label}' if feature_label else tool_label
        _draw_always_on_toggle_row(
            col,
            context,
            settings,
            label=label,
            prop_name=prop_name,
            enabled=enabled,
            disabled_label=not bool(prop_name and hasattr(settings, prop_name)),
        )


def _integrated_group_label(group: str, context) -> str:
    ja_map = {
        'Pose': 'ポーズ',
        'Key Data': 'キーデータ',
        'Transform': '変形',
        'Timing': 'タイミング',
        'Curve': 'カーブ',
        'Camera': 'カメラ',
        'Storyboard': 'ストーリーボード',
    }
    group = str(group or '').strip()
    return sas_text(f'{group} Tools', f'{ja_map.get(group, group)}ツール', context)


def _integrated_group_icon(group: str) -> str:
    return {
        'Pose': 'POSE_HLT',
        'Key Data': 'KEY_HLT',
        'Transform': 'ORIENTATION_GLOBAL',
        'Timing': 'TIME',
        'Curve': 'IPO_BEZIER',
        'Camera': 'CAMERA_DATA',
        'Storyboard': 'SEQ_STRIP_DUPLICATE',
    }.get(str(group or '').strip(), 'TOOL_SETTINGS')


def _draw_integrated_tool_alias(layout, context, alias: str) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    try:
        draw_fn = getattr(ui_runtime, 'draw_integrated_overview_task', None)
        if callable(draw_fn):
            draw_fn(layout, context, alias)
            return
        fallback = getattr(ui_runtime, '_draw_integrated_overview_task', None)
        if callable(fallback):
            fallback(layout, context, alias)
            return
    except Exception as exc:
        layout.label(text=sas_text(f'Integrated tool draw failed: {exc}', f'統合ツール描画に失敗しました: {sas_error_reason(exc)}', context), icon='ERROR')
        return
    layout.label(text=sas_text('Integrated tool UI renderer is not available.', '統合ツールUI描画機能が見つかりません。', context), icon='ERROR')


def _draw_integrated_tool_group(layout, context, group: str, *, show_header: bool = True) -> None:
    group = str(group or '').strip()
    aliases = registry.overview_group_aliases(group)
    target = layout
    if show_header:
        target = _begin_collapsible_section(
            layout,
            context,
            _context_sas_settings(context),
            f'group_{group}',
            f'{group} Tools',
            _integrated_group_label(group, context),
            _integrated_group_icon(group),
            f'group:{group}',
            default=False,
        )
    if not aliases:
        target.label(text=sas_text('No migrated tool is assigned to this overview task.', 'この概要タスクに割り当てられた移植済みツールはありません。', context))
        return
    for alias in aliases:
        _draw_integrated_tool_alias(target, context, alias)


def _draw_all_integrated_tool_groups(layout, context) -> None:
    if not layout:
        return
    for group in registry.TOOL_OVERVIEW_GROUP_ORDER:
        if registry.overview_group_aliases(group):
            _draw_integrated_tool_group(layout, context, group, show_header=True)


def _smart_details_visible(settings) -> bool:
    density = str(getattr(settings, 'smart_ui_density', 'BALANCED') or 'BALANCED').upper()
    return density != 'COMPACT' or bool(getattr(settings, 'smart_show_advanced_controls', False))



def _draw_smart_icon_command(container, context, op_id: str, icon_key: str, en_label: str, ja_label: str, *, fallback_icon: str = 'PLAY'):
    settings = getattr(getattr(context, 'scene', None), 'sas_settings', None)
    try:
        scale = float(getattr(settings, 'smart_icon_button_scale', 4.0))
    except Exception:
        scale = 4.0
    scale = max(1.0, min(8.0, scale))
    show_label = bool(getattr(settings, 'smart_show_icon_labels', True)) if settings is not None else True

    col = container.column(align=True)
    icon_row = col.row(align=True)
    icon_row.alignment = 'CENTER'
    icon_row.scale_y = scale
    icon_row.scale_x = max(1.55, min(4.4, scale * 0.82))
    op = _draw_custom_operator(
        icon_row,
        op_id,
        text='',
        icon_key=icon_key,
        fallback_icon=fallback_icon,
    )
    if show_label:
        label_row = col.row(align=True)
        label_row.alignment = 'CENTER'
        label_row.label(text=sas_text(en_label, ja_label, context))
    return op


def _draw_smart_icon_command_grid(box, context, settings):
    del settings
    grid = box.grid_flow(columns=4, even_columns=True, even_rows=True, align=True)
    _draw_smart_icon_command(grid, context, 'sas.smart_superior_director', 'super', 'Superior', '最強統合', fallback_icon='SOLO_ON')
    _draw_smart_icon_command(grid, context, 'sas.smart_stage_director', 'stage', 'Stage', '段階', fallback_icon='LIGHT')
    _draw_smart_icon_command(grid, context, 'sas.smart_precision_polish', 'precision', 'Precision', '精密', fallback_icon='MODIFIER')
    _draw_smart_icon_command(grid, context, 'sas.smart_quality_report', 'quality', 'Quality', '品質', fallback_icon='CHECKMARK')
    _draw_smart_icon_command(grid, context, 'sas.smart_motion_director', 'motion', 'Motion', '動き', fallback_icon='IPO_BEZIER')
    _draw_smart_icon_command(grid, context, 'sas.smart_graph_optimizer', 'graph', 'Graph', 'カーブ', fallback_icon='IPO_BEZIER')
    _draw_smart_icon_command(grid, context, 'sas.smart_contact_stabilizer', 'contact', 'Contact', '接地', fallback_icon='SNAP_FACE')
    _draw_smart_icon_command(grid, context, 'sas.smart_visualize_motion', 'visual', 'Visual', '可視化', fallback_icon='CURVE_DATA')

def _smart_stage_dashboard(layout, context, settings):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_studio_dashboard'), "Animation Recipes Studio", "スタジオ", 'ARMATURE_DATA', str('smart_studio_dashboard'))
    _draw_smart_icon_command_grid(box, context, settings)
    row = box.row(align=True)
    row.prop(settings, "smart_workflow_stage", text=sas_text("Stage", "段階", context))
    row.prop(settings, "smart_ui_density", text=sas_text("UI Density", "UI密度", context))
    row = box.column(align=True)
    row.prop(settings, "smart_recipe", text=sas_text("Recipe", "レシピ", context))
    _draw_custom_operator(row, "sas.animation_recipe", text=sas_text("Run Recipe", "レシピ実行", context), icon_key='recipe', fallback_icon='PLAY')
    row = box.row(align=True)
    _draw_custom_operator(row, "sas.smart_stage_director", text=sas_text("Stage Director", "段階ディレクター", context), icon_key='stage', fallback_icon='LIGHT')
    _draw_custom_operator(row, "sas.smart_precision_polish", text=sas_text("Precision Polish", "精密ポリッシュ", context), icon_key='precision', fallback_icon='MODIFIER')
    row = box.column(align=True)
    _draw_custom_operator(row, "sas.smart_superior_director", text=sas_text("Superior Director", "最強統合ディレクター", context), icon_key='super', fallback_icon='SOLO_ON')
    _draw_custom_operator(row, "sas.smart_quality_report", text=sas_text("Quality Gate", "品質ゲート", context), icon_key='quality', fallback_icon='CHECKMARK')
    row = box.row(align=True)
    _draw_custom_operator(row, "sas.smart_visualize_motion", text=sas_text("Visual Review", "可視レビュー", context), icon_key='visual', fallback_icon='CURVE_DATA')
    row = box.column(align=True)
    row.prop(settings, "smart_precision_profile", text=sas_text("Precision", "精度", context))
    row.prop(settings, "smart_quality_gate_min_score", text=sas_text("Gate", "ゲート", context))
    row = box.row(align=True)
    row.prop(settings, "smart_enable_adaptive_precision", text=sas_text("Adaptive", "適応", context), toggle=True)
    row.prop(settings, "smart_precision_curvature_guard", text=sas_text("Curvature Guard", "曲率保護", context), toggle=True)
    row = box.column(align=True)
    row.prop(settings, "smart_timing_intent", text=sas_text("Timing Intent", "意図", context))
    row.prop(settings, "smart_contact_floor_epsilon", text=sas_text("Contact ε", "接地ε", context))
    row = box.row(align=True)
    row.prop(settings, "smart_preflight_before_run", text=sas_text("Preflight", "事前診断", context), toggle=True)
    row.prop(settings, "smart_super_visual_review", text=sas_text("Visual Review", "可視レビュー", context), toggle=True)
    row = box.row(align=True)
    row.prop(settings, "smart_show_advanced_controls", text=sas_text("Advanced Controls", "詳細操作", context), toggle=True)
    row = box.column(align=True)
    row.prop(settings, "smart_icon_button_scale", text=sas_text("Icon Size", "アイコンサイズ", context))
    row.prop(settings, "smart_show_icon_labels", text=sas_text("Icon Labels", "アイコンラベル", context), toggle=True)
    return box


def _animation_recipes_body(layout, context, settings):
    if not layout:
        return
    matched_any = False
    if _search_ok(settings, "animation recipe animbot cascadeur motionbuilder houdini signal physics graph retarget locomotion shape IFL"):
        matched_any = True
        _smart_stage_dashboard(layout, context, settings)
        if not _smart_details_visible(settings):
            return

    if _search_ok(settings, "motion director tween push pull animbot animaide inbetween"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_motion_director'), "Motion Director", "モーションディレクター", 'IPO_BEZIER', str('smart_motion_director'))
        box.prop(settings, "smart_motion_director_mode", text=sas_text("Mode", "モード", context))
        row = box.column(align=True)
        row.prop(settings, "tween_factor", text=sas_text("Tween", "トゥイーン", context))
        row.prop(settings, "tween_mode", text=sas_text("Tween Mode", "方式", context))
        row = box.column(align=True)
        row.prop(settings, "push_pull_factor", text=sas_text("Push/Pull", "プッシュ/プル", context))
        row.prop(settings, "neighbor_scale_factor", text=sas_text("Neighbor Scale", "近隣スケール", context))
        box.prop(settings, "smart_motion_preserve_flow", text=sas_text("Preserve Flow Handles", "流れ保持ハンドル", context), toggle=True)
        _draw_custom_operator(box, "sas.smart_motion_director", text=sas_text("Run Motion Director", "モーション調整実行", context), icon_key='motion', fallback_icon='PLAY')

    if _search_ok(settings, "graph optimizer graphkit key manager euler unbake cleanup"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_graph_optimizer'), "Graph Optimizer", "グラフ最適化", 'IPO_BEZIER', str('smart_graph_optimizer'))
        row = box.row(align=True)
        row.prop(settings, "smart_graph_include_unbake", text=sas_text("Include Unbake", "アンベイク含む", context), toggle=True)
        row.prop(settings, "smart_graph_auto_clamped", text=sas_text("Auto Clamped", "自動クランプ", context), toggle=True)
        row = box.column(align=True)
        row.prop(settings, "smart_precision_profile", text=sas_text("Precision", "精度", context))
        row.prop(settings, "smart_enable_adaptive_precision", text=sas_text("Adaptive", "適応", context), toggle=True)
        row = box.column(align=True)
        row.prop(settings, "remove_threshold", text=sas_text("Threshold", "しきい値", context))
        row.prop(settings, "curve_smooth_factor", text=sas_text("Smooth", "平滑", context))
        row = box.row(align=True)
        row.prop(settings, "smart_preserve_selected_keys", text=sas_text("Preserve Selected", "選択キー保護", context), toggle=True)
        row.prop(settings, "smart_preserve_extreme_keys", text=sas_text("Preserve Extremes", "極値保護", context), toggle=True)
        row = box.row(align=True)
        row.prop(settings, "smart_overshoot_tolerance", text=sas_text("Overshoot Tol.", "オーバーシュート許容", context))
        row = box.row(align=True)
        _draw_custom_operator(row, "sas.smart_graph_optimizer", text=sas_text("Run Graph Optimizer", "グラフ最適化実行", context), icon_key='graph', fallback_icon='PLAY')
        _draw_custom_operator(row, "sas.smart_quality_report", text=sas_text("Report", "レポート", context), icon_key='report', fallback_icon='TEXT')

    if _search_ok(settings, "visualizer ghost trail ballistic motion path spacing"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_visualizer'), "Motion Visualizer", "モーション可視化", 'CURVE_DATA', str('smart_visualizer'))
        box.prop(settings, "smart_visualizer_mode", text=sas_text("Mode", "モード", context))
        row = box.row(align=True)
        row.prop(settings, "ghost_past_frames", text=sas_text("Past", "過去", context))
        row.prop(settings, "ghost_future_frames", text=sas_text("Future", "未来", context))
        row.prop(settings, "ghost_step", text=sas_text("Step", "間隔", context))
        _draw_custom_operator(box, "sas.smart_visualize_motion", text=sas_text("Create Visual Helpers", "可視化ヘルパー作成", context), icon_key='visual', fallback_icon='PLAY')

    if _search_ok(settings, "physics brodynamics cascadeur autophysics fulcrum spring rigid body"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_physics_director'), "Physics Director", "物理ディレクター", 'PHYSICS', str('smart_physics_director'))
        box.prop(settings, "smart_physics_director_mode", text=sas_text("Mode", "モード", context))
        row = box.column(align=True)
        row.prop(settings, "ballistic_blend", text=sas_text("Ballistic", "弾道", context))
        row.prop(settings, "spring_blend", text=sas_text("Spring", "スプリング", context))
        row = box.row(align=True)
        row.prop(settings, "contact_hold_start", text=sas_text("Contact Start", "接地開始", context))
        row.prop(settings, "contact_hold_end", text=sas_text("Contact End", "接地終了", context))
        _draw_custom_operator(box, "sas.smart_physics_director", text=sas_text("Run Physics Director", "物理処理実行", context), icon_key='physics', fallback_icon='PLAY')

    if _search_ok(settings, "contact timing fulcrum foot sliding interpolation intent"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_contact_timing'), "Contact / Timing Stabilizer", "接地 / タイミング安定化", 'SNAP_FACE', str('smart_contact_timing'))
        row = box.column(align=True)
        row.prop(settings, "smart_timing_intent", text=sas_text("Timing Intent", "意図", context))
        row.prop(settings, "smart_contact_floor_epsilon", text=sas_text("Contact ε", "接地ε", context))
        row = box.column(align=True)
        row.prop(settings, "smart_contact_min_span", text=sas_text("Min Span", "最小連続", context))
        row.prop(settings, "smart_contact_flatten_handles", text=sas_text("Flatten Handles", "ハンドル平坦化", context), toggle=True)
        row = box.row(align=True)
        _draw_custom_operator(row, "sas.smart_contact_stabilizer", text=sas_text("Stabilize Contact", "接地安定化", context), icon_key='contact', fallback_icon='SNAP_FACE')
        _draw_custom_operator(row, "sas.smart_timing_intent_solver", text=sas_text("Solve Timing", "タイミング適用", context), icon_key='timing', fallback_icon='TIME')

    if _search_ok(settings, "locomotion motionmaker cmotion cycle walk run"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_locomotion'), "Locomotion Generator", "ロコモーション生成", 'ARMATURE_DATA', str('smart_locomotion'))
        row = box.row(align=True)
        row.prop(settings, "bake_range", text=sas_text("Range", "範囲", context))
        row.prop(settings, "smart_locomotion_axis", text=sas_text("Axis", "軸", context))
        if settings.bake_range == 'CUSTOM':
            row = box.row(align=True)
            row.prop(settings, "custom_frame_start", text=sas_text("Start", "開始", context))
            row.prop(settings, "custom_frame_end", text=sas_text("End", "終了", context))
        row = box.row(align=True)
        row.prop(settings, "smart_locomotion_distance", text=sas_text("Distance", "距離", context))
        row.prop(settings, "smart_locomotion_cycle_length", text=sas_text("Cycle", "周期", context))
        box.prop(settings, "smart_locomotion_style", text=sas_text("Style", "スタイル", context))
        row = box.row(align=True)
        row.prop(settings, "smart_locomotion_sample_density", text=sas_text("Samples", "サンプル", context))
        row.prop(settings, "smart_locomotion_contact_lock", text=sas_text("Contact Lock", "接地ロック", context), toggle=True)
        row = box.row(align=True)
        row.prop(settings, "smart_locomotion_bob", text=sas_text("Bob", "上下", context))
        row.prop(settings, "smart_locomotion_yaw_degrees", text=sas_text("Yaw", "ヨー", context))
        row = box.column(align=True)
        row.prop(settings, "smart_locomotion_stride_width", text=sas_text("Stride Width", "横揺れ", context))
        row.prop(settings, "smart_locomotion_add_cycles", text=sas_text("Add Cycle Modifier", "サイクル追加", context), toggle=True)
        _draw_custom_operator(box, "sas.smart_generate_locomotion_cycle", text=sas_text("Generate Locomotion", "ロコモーション生成", context), icon_key='locomotion', fallback_icon='PLAY')

    if _search_ok(settings, "shape key pose morph overmorpher dorito custom control"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_shape_control'), "Shape Control Mixer", "シェイプ制御ミキサー", 'SHAPEKEY_DATA', str('smart_shape_control'))
        box.prop(settings, "smart_shape_control_prefix", text=sas_text("Prefix", "接頭辞", context))
        box.prop(settings, "smart_shape_control_key_controls", text=sas_text("Key Controls", "制御にキー", context), toggle=True)
        row = box.row(align=True)
        _draw_custom_operator(row, "sas.smart_shape_control_mixer", text=sas_text("Create Controls", "制御作成", context), icon_key='shape', fallback_icon='IPO_BEZIER')
        clear = row.operator("sas.smart_shape_control_mixer", text=sas_text("Clear Controls", "制御解除", context), icon='X')
        clear.mode = 'CLEAR'

    if _search_ok(settings, "IFL image sequence texture playback manager"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_ifl'), "Image Sequence Manager", "画像シーケンス管理", 'IMAGE_DATA', str('smart_ifl'))
        row = box.row(align=True)
        row.prop(settings, "smart_ifl_frame_start", text=sas_text("Start", "開始", context))
        row.prop(settings, "smart_ifl_frame_duration", text=sas_text("Duration", "長さ", context))
        row.prop(settings, "smart_ifl_frame_offset", text=sas_text("Offset", "ずらし", context))
        row = box.row(align=True)
        row.prop(settings, "smart_ifl_use_cyclic", text=sas_text("Cyclic", "循環", context), toggle=True)
        row.prop(settings, "smart_ifl_key_offset", text=sas_text("Key Offset", "キー打ち", context), toggle=True)
        row.prop(settings, "smart_ifl_match_scene_range", text=sas_text("Match Scene", "シーン一致", context), toggle=True)
        _draw_custom_operator(box, "sas.smart_ifl_sequence_manager", text=sas_text("Apply Image Timing", "画像タイミング適用", context), icon_key='ifl', fallback_icon='PLAY')

    if _search_ok(settings, "retarget red9 kinefx motionbuilder"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('smart_retarget'), "Retarget Director", "リターゲットディレクター", 'ARROW_LEFTRIGHT', str('smart_retarget'))
        row = box.column(align=True)
        row.prop(settings, "retarget_source", text=sas_text("Source", "ソース", context))
        row.prop(settings, "retarget_target", text=sas_text("Target", "対象", context))
        row = box.column(align=True)
        row.prop(settings, "retarget_constraint_influence", text=sas_text("Influence", "影響度", context))
        row.prop(settings, "retarget_space", text=sas_text("Space", "空間", context))
        row = box.row(align=True)
        _draw_custom_operator(row, "sas.smart_retarget_director", text=sas_text("Build Preview", "プレビュー作成", context), icon_key='retarget', fallback_icon='CONSTRAINT')
        row.operator("sas.bake_live_retarget", text=sas_text("Bake Retarget", "リターゲットベイク", context), icon='KEY_HLT')

    if settings.ui_search and not matched_any:
        layout.label(text=sas_text("No Animation Recipes group matched the current search.", "現在の検索に一致する アニメーション レシピ グループはありません。", context))


def _draw_all_functions_body(layout, context, settings):
    section = _begin_top_level_section(layout, context, settings, 'section_overview', 'Overview / Diagnostics', '概要 / 診断', 'VIEWZOOM', 'section_overview', default=False)
    if section:
        _overview_body(section, context, settings)
    section = _begin_top_level_section(layout, context, settings, 'section_animation_recipes', 'Animation Recipes', 'Animation Recipes', 'ARMATURE_DATA', 'section_animation_recipes', default=False)
    if section:
        _animation_recipes_body(section, context, settings)
    section = _begin_top_level_section(layout, context, settings, 'section_animation', 'Animation Tools', 'アニメーションツール', 'KEY_HLT', 'section_animation', default=False)
    if section:
        _animate_body(section, context, settings)
    section = _begin_top_level_section(layout, context, settings, 'section_assets', 'Asset Tools', 'アセットツール', 'ASSET_MANAGER', 'section_assets', default=False)
    if section:
        _assets_body(section, context, settings)
    section = _begin_top_level_section(layout, context, settings, 'section_transfer', 'Transfer Tools', '転送ツール', 'ARROW_LEFTRIGHT', 'section_transfer', default=False)
    if section:
        _transfer_body(section, context, settings)
    section = _begin_top_level_section(layout, context, settings, 'section_migrated', 'Migrated Bundled Tools', '移植済み同梱ツール', 'TOOL_SETTINGS', 'section_migrated', default=False)
    if section:
        _draw_all_integrated_tool_groups(section, context)


def _draw_playback_controls(box, context):
    scene = context.scene
    tool_settings = getattr(scene, 'tool_settings', None)
    frame_start = getattr(scene, 'frame_preview_start', scene.frame_start) if getattr(scene, 'use_preview_range', False) else scene.frame_start
    frame_end = getattr(scene, 'frame_preview_end', scene.frame_end) if getattr(scene, 'use_preview_range', False) else scene.frame_end
    box.label(text=sas_text(f"Active Range: {int(frame_start)}-{int(frame_end)}", f"現在範囲: {int(frame_start)}-{int(frame_end)}", context), icon='PREVIEW_RANGE')
    box.label(text=sas_text(f"Current Frame: {int(scene.frame_current)}", f"現在フレーム: {int(scene.frame_current)}", context), icon='TIME')
    row = box.row(align=True)
    if tool_settings and hasattr(tool_settings, 'use_keyframe_insert_auto'):
        row.prop(tool_settings, 'use_keyframe_insert_auto', text=sas_text('Auto Key', 'オートキー', context), toggle=True)
    if hasattr(scene, 'use_preview_range'):
        row.prop(scene, 'use_preview_range', text=sas_text('Use Preview Range', 'プレビュー範囲を使用', context), toggle=True)
    row = box.row(align=True)
    if hasattr(scene, 'use_audio_scrub'):
        row.prop(scene, 'use_audio_scrub', text=sas_text('Audio Scrub', '音声スクラブ', context), toggle=True)
    if hasattr(scene, 'sync_mode'):
        row.prop(scene, 'sync_mode', text=sas_text('Sync Mode', '再生同期', context))
    if tool_settings and hasattr(tool_settings, 'use_keyframe_insert_keyingset'):
        row = box.row(align=True)
        row.prop(tool_settings, 'use_keyframe_insert_keyingset', text=sas_text('Limit to Keying Set', 'キーイングセットに限定', context), toggle=True)


def _draw_shape_key_info(box, context, settings):
    available_count = int(_draw_metric(context, settings, 'shape_key_count', 0) or 0)
    animated_count = int(_draw_metric(context, settings, 'shape_key_curve_count', 0) or 0)
    box.label(text=sas_text(f"Available Shape Keys: {available_count}", f"利用可能シェイプキー数: {available_count}", context), icon='SHAPEKEY_DATA')
    box.label(text=sas_text(f"Animated Shape Key Curves: {animated_count}", f"アニメーション済みシェイプキーカーブ数: {animated_count}", context), icon='IPO_BEZIER')


def _draw_timeline_settings(box, context, settings):
    mode = settings.compact_timeline_mode
    obj = active_object(context)

    if mode == 'ADD_MARKER':
        box.prop(settings, "marker_name", text=sas_text("Marker Name", "マーカー名", context))
    elif mode == 'BAKE_VISUAL':
        row = box.row(align=True)
        row.prop(settings, "bake_range", text=sas_text("Range", "範囲", context))
        row.prop(settings, "frame_step", text=sas_text("Step", "間隔", context))
        if settings.bake_range == 'CUSTOM':
            row = box.row(align=True)
            row.prop(settings, "custom_frame_start", text=sas_text("Start", "開始", context))
            row.prop(settings, "custom_frame_end", text=sas_text("End", "終了", context))
    elif mode in {'ADD_CAMERA_MARKER', 'PREV_CAMERA_MARKER', 'NEXT_CAMERA_MARKER', 'PREVIEW_FROM_CURRENT_SHOT', 'PREVIEW_FROM_ALL_SHOTS'}:
        camera_obj = obj if obj and obj.type == 'CAMERA' else context.scene.camera
        box.label(text=sas_text(f"Camera Source: {camera_obj.name if camera_obj else '-'}", f"カメラ元: {camera_obj.name if camera_obj else '-'}", context), icon='CAMERA_DATA')
        if mode in {'PREVIEW_FROM_CURRENT_SHOT', 'PREVIEW_FROM_ALL_SHOTS'}:
            _draw_playback_controls(box, context)
    elif mode == 'CAMERA_SEQUENCE':
        row = box.row(align=True)
        row.prop(settings, "camera_sequence_start", text=sas_text("Start", "開始", context))
        row.prop(settings, "camera_sequence_shot_length", text=sas_text("Shot", "ショット長", context))
        row.prop(settings, "camera_sequence_gap", text=sas_text("Spacing", "間隔", context))
        row = box.row(align=True)
        row.prop(settings, "camera_sequence_clear_existing", text=sas_text("Clear SAS", "旧SAS削除", context))
        row.prop(settings, "camera_sequence_set_preview", text=sas_text("Set Preview", "プレビュー設定", context))
    elif mode == 'CAMERA_REVIEW_SPLIT':
        row = box.row(align=True)
        row.prop(settings, "camera_review_split_direction", text=sas_text("Direction", "方向", context))
        row.prop(settings, "camera_review_split_factor", text=sas_text("Ratio", "比率", context))
        row.prop(settings, "camera_review_lock_camera", text=sas_text("Lock Camera", "カメラ固定", context))
    elif mode in PLAYBACK_MODES:
        _draw_playback_controls(box, context)
    elif mode in {'SHAPE_KEYS_ALL', 'SHAPE_KEYS_ACTIVE'}:
        _draw_shape_key_info(box, context, settings)


def _timing_range_without_scan(context, settings):
    """Return a scalar-only range for draw fallback; never inspect F-Curves."""
    if bool(getattr(settings, 'retime_use_range', False)):
        start = int(getattr(settings, 'retime_range_start', 0) or 0)
        end = int(getattr(settings, 'retime_range_end', 0) or 0)
        return (min(start, end), max(start, end))
    scene = getattr(context, 'scene', None)
    if scene is None:
        return (0, 0)
    if bool(getattr(scene, 'use_preview_range', False)):
        return (
            int(getattr(scene, 'frame_preview_start', 0) or 0),
            int(getattr(scene, 'frame_preview_end', 0) or 0),
        )
    return (
        int(getattr(scene, 'frame_start', 0) or 0),
        int(getattr(scene, 'frame_end', 0) or 0),
    )


def _draw_timing_settings(box, context, settings):
    if not box:
        return
    mode = settings.compact_timing_mode
    action = active_action(context)
    obj = active_object(context)

    if mode in {'SHIFT', 'SCALE', 'EVEN'}:
        row = box.row(align=True)
        row.prop(settings, "retime_use_range", text=sas_text("Use Range", "範囲使用", context))
        if mode == 'SHIFT':
            row.prop(settings, "retime_offset", text=sas_text("Shift", "移動", context))
        elif mode == 'SCALE':
            row.prop(settings, "retime_scale", text=sas_text("Scale", "倍率", context))
        if settings.retime_use_range:
            row = box.row(align=True)
            row.prop(settings, "retime_range_start", text=sas_text("Start", "開始", context))
            row.prop(settings, "retime_range_end", text=sas_text("End", "終了", context))
        if mode == 'SCALE':
            row = box.row(align=True)
            row.prop(settings, "retime_pivot_mode", text=sas_text("Pivot", "ピボット", context))
            if settings.retime_pivot_mode == 'CUSTOM':
                row.prop(settings, "retime_custom_pivot", text=sas_text("Custom", "カスタム", context))
        if action:
            frame_range = _draw_metric(context, settings, 'timing_frame_range', None)
            if isinstance(frame_range, (tuple, list)) and len(frame_range) >= 2:
                start_frame, end_frame = frame_range[:2]
            else:
                start_frame, end_frame = _timing_range_without_scan(context, settings)
            box.label(text=sas_text(f"Frame Range: {int(start_frame)}-{int(end_frame)}", f"フレーム範囲: {int(start_frame)}-{int(end_frame)}", context), icon='PREVIEW_RANGE')
            affected_keys = int(_draw_metric(context, settings, 'timing_key_count', 0) or 0)
            box.label(text=sas_text(f"Affected Keys: {affected_keys}", f"対象キー数: {affected_keys}", context), icon='KEY_HLT')
    elif mode == 'TWEEN':
        row = box.row(align=True)
        row.prop(settings, "tween_factor", text=sas_text("Factor", "係数", context))
        row.prop(settings, "tween_mode", text=sas_text("Mode", "モード", context))
    elif mode == 'PUSH_PULL':
        box.prop(settings, "push_pull_factor", text=sas_text("Factor", "係数", context))
    elif mode == 'SCALE_TO_NEIGHBORS':
        box.prop(settings, "neighbor_scale_factor", text=sas_text("Factor", "係数", context))
    elif mode == 'CONTACT_HOLD':
        row = box.row(align=True)
        row.prop(settings, "contact_hold_start", text=sas_text("Start", "開始", context))
        row.prop(settings, "contact_hold_end", text=sas_text("End", "終了", context))
        box.label(text=sas_text(f"Source Frame: {context.scene.frame_current}", f"基準フレーム: {context.scene.frame_current}", context), icon='TIME')
    elif mode == 'STEPPED_PREVIEW':
        row = box.row(align=True)
        row.prop(settings, "step_preview_frames", text=sas_text("Step", "間隔", context))
        row.prop(settings, "step_preview_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
    elif mode == 'OVERLAP':
        row = box.row(align=True)
        row.prop(settings, "overlap_pass_frames", text=sas_text("Delay", "遅延", context))
        row.prop(settings, "overlap_pass_blend", text=sas_text("Blend", "ブレンド", context))
        row.prop(settings, "overlap_pass_decay", text=sas_text("Decay", "減衰", context))
    elif mode == 'CASCADE':
        box.prop(settings, "cascade_delay_frames", text=sas_text("Delay", "遅延", context))
    elif mode == 'RANDOMIZE':
        row = box.row(align=True)
        row.prop(settings, "random_seed", text=sas_text("Seed", "シード", context))
        row.prop(settings, "random_timing_min", text=sas_text("Min", "最小", context))
        row.prop(settings, "random_timing_max", text=sas_text("Max", "最大", context))
    elif mode == 'AUTO_FULCRUM':
        row = box.row(align=True)
        row.prop(settings, "fulcrum_velocity_threshold", text=sas_text("Velocity", "速度", context))
        row.prop(settings, "fulcrum_min_hold", text=sas_text("Min Hold", "最小保持", context))
        row.prop(settings, "fulcrum_only_location", text=sas_text("Only Location", "位置のみ", context))


def _draw_fx_settings(box, context, settings):
    mode = settings.compact_fx_mode

    if mode == 'LIMITED':
        row = box.row(align=True)
        row.prop(settings, "limited_bake_step", text=sas_text("Step", "間隔", context))
        row.prop(settings, "limited_interpolation", text=sas_text("Interpolation", "補間", context))
    elif mode == 'SPRING':
        row = box.row(align=True)
        row.prop(settings, "spring_stiffness", text=sas_text("Stiffness", "剛性", context))
        row.prop(settings, "spring_damping", text=sas_text("Damping", "減衰", context))
        row.prop(settings, "spring_blend", text=sas_text("Blend", "ブレンド", context))
        row = box.row(align=True)
        row.prop(settings, "spring_sample_step", text=sas_text("Step", "サンプル間隔", context))
        row.prop(settings, "spring_auto_simplify", text=sas_text("Auto Simplify", "自動簡略化", context))
    elif mode == 'SPRING_MAGIC':
        row = box.row(align=True)
        row.prop(settings, "spring_magic_axis", text=sas_text("Axis", "軸", context))
        row.prop(settings, "spring_magic_mode", text=sas_text("Mode", "モード", context))
        row.prop(settings, "spring_magic_clear_range", text=sas_text("Clear", "クリア", context))
        row = box.row(align=True)
        row.prop(settings, "spring_stiffness", text=sas_text("Stiffness", "剛性", context))
        row.prop(settings, "spring_damping", text=sas_text("Damping", "減衰", context))
        row.prop(settings, "spring_blend", text=sas_text("Blend", "ブレンド", context))
        row = box.row(align=True)
        row.prop(settings, "spring_sample_step", text=sas_text("Sample", "サンプル", context))
        row.prop(settings, "spring_magic_substeps", text=sas_text("Substeps", "サブステップ", context))
        row.prop(settings, "spring_magic_collision_iterations", text=sas_text("Iterations", "反復", context))
        row = box.row(align=True)
        row.prop(settings, "spring_magic_twist_strength", text=sas_text("Twist", "ツイスト", context))
        row.prop(settings, "spring_magic_scale_strength", text=sas_text("Scale", "スケール", context))
        row.prop(settings, "spring_magic_scale_max", text=sas_text("Scale Max", "最大スケール", context))
        row = box.row(align=True)
        row.prop(settings, "spring_magic_collision_mode", text=sas_text("Collision", "衝突", context))
        row.prop(settings, "spring_magic_collision_radius", text=sas_text("Radius", "半径", context))
        row.prop(settings, "spring_magic_collision_margin", text=sas_text("Margin", "余白", context))
        if settings.spring_magic_collision_mode in {'FLOOR', 'BOTH'}:
            box.prop(settings, "spring_magic_floor_height", text=sas_text("Floor Height", "床高さ", context))
        if settings.spring_magic_collision_mode in {'COLLECTION', 'BOTH'}:
            box.prop(settings, "spring_magic_collision_collection", text=sas_text("Collection", "コレクション", context))
        row = box.row(align=True)
        row.prop(settings, "spring_magic_collision_object_enabled", text=sas_text("Use Object", "オブジェクト使用", context), toggle=True)
        if settings.spring_magic_collision_object_enabled:
            box.prop(settings, "spring_magic_collision_object", text=sas_text("Collider", "コライダー", context))
    elif mode == 'PHYSICS':
        row = box.row(align=True)
        row.prop(settings, "bake_range", text=sas_text("Range", "範囲", context))
        row.prop(settings, "frame_step", text=sas_text("Step", "間隔", context))
        row.prop(settings, "physics_bake_clear_range", text=sas_text("Clear Existing", "既存削除", context))
        if settings.bake_range == 'CUSTOM':
            row = box.row(align=True)
            row.prop(settings, "custom_frame_start", text=sas_text("Start", "開始", context))
            row.prop(settings, "custom_frame_end", text=sas_text("End", "終了", context))
    elif mode == 'SIGNAL':
        row = box.row(align=True)
        row.prop(settings, "signal_mode", text=sas_text("Mode", "モード", context))
        row.prop(settings, "signal_target", text=sas_text("Target", "対象", context))
        row.prop(settings, "signal_axes", text=sas_text("Axes", "軸", context))
        row = box.row(align=True)
        row.prop(settings, "signal_time_mode", text=sas_text("Time", "時間", context))
        if settings.signal_time_mode == 'BPM':
            row.prop(settings, "signal_bpm", text=sas_text("BPM", "BPM", context))
        else:
            row.prop(settings, "signal_frequency", text=sas_text("Frequency", "周波数", context))
        row.prop(settings, "signal_amplitude", text=sas_text("Amplitude", "振幅", context))
        row = box.row(align=True)
        row.prop(settings, "signal_phase", text=sas_text("Phase", "位相", context))
        row.prop(settings, "signal_object_phase_offset", text=sas_text("Per Object", "個別位相", context))
        row.prop(settings, "signal_order", text=sas_text("Order", "順序", context))
        if settings.signal_mode == 'STEP':
            box.prop(settings, "signal_step_frames", text=sas_text("Step Frames", "保持フレーム", context))
        if settings.signal_mode == 'NOISE':
            box.prop(settings, "signal_noise_seed", text=sas_text("Noise Seed", "ノイズシード", context))
        box.prop(settings, "signal_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
    elif mode == 'STRETCH':
        row = box.row(align=True)
        row.prop(settings, "motion_stretch_axis", text=sas_text("Axis", "軸", context))
        row.prop(settings, "motion_stretch_plane", text=sas_text("Plane", "平面", context))
        row.prop(settings, "motion_stretch_strength", text=sas_text("Strength", "強さ", context))
        row = box.row(align=True)
        row.prop(settings, "motion_stretch_squash", text=sas_text("Squash", "スクワッシュ", context))
        row.prop(settings, "motion_stretch_max", text=sas_text("Max", "最大", context))
        row.prop(settings, "motion_stretch_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
    elif mode == 'VEHICLE':
        row = box.row(align=True)
        row.prop(settings, "vehicle_wheel_axis", text=sas_text("Wheel Axis", "車輪軸", context))
        row.prop(settings, "vehicle_motion_plane", text=sas_text("Plane", "平面", context))
        row.prop(settings, "vehicle_radius_mode", text=sas_text("Radius", "半径", context))
        if settings.vehicle_radius_mode == 'MANUAL':
            box.prop(settings, "vehicle_wheel_radius", text=sas_text("Manual Radius", "手動半径", context))
        row = box.row(align=True)
        row.prop(settings, "vehicle_spin_direction", text=sas_text("Direction", "方向", context))
        row.prop(settings, "vehicle_auto_side_flip", text=sas_text("Auto Flip", "自動反転", context))
        row.prop(settings, "vehicle_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
        box.prop(settings, "vehicle_enable_steering", text=sas_text("Steering", "ステアリング", context))
        if settings.vehicle_enable_steering:
            row = box.row(align=True)
            row.prop(settings, "vehicle_steering_axis", text=sas_text("Axis", "軸", context))
            row.prop(settings, "vehicle_steering_max", text=sas_text("Max", "最大", context))
            row.prop(settings, "vehicle_steering_reverse", text=sas_text("Reverse", "反転", context))
    elif mode == 'TRANSFORM_REVEAL':
        row = box.row(align=True)
        row.prop(settings, "transform_reveal_distance", text=sas_text("Distance", "距離", context))
        row.prop(settings, "transform_reveal_axis", text=sas_text("Axis", "軸", context))
        row.prop(settings, "transform_reveal_order", text=sas_text("Order", "順序", context))
        row = box.row(align=True)
        row.prop(settings, "transform_reveal_stagger", text=sas_text("Stagger", "段差", context))
        row.prop(settings, "transform_reveal_duration", text=sas_text("Duration", "時間", context))
    elif mode == 'REVEAL':
        row = box.row(align=True)
        row.prop(settings, "deform_reveal_mode", text=sas_text("Mode", "モード", context))
        row.prop(settings, "deform_reveal_axis", text=sas_text("Axis", "軸", context))
        row.prop(settings, "deform_reveal_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
        if settings.deform_reveal_mode != 'BUILD':
            box.prop(settings, "deform_reveal_angle", text=sas_text("Angle", "角度", context))
        row = box.row(align=True)
        row.prop(settings, "transform_reveal_order", text=sas_text("Order", "順序", context))
        row.prop(settings, "transform_reveal_stagger", text=sas_text("Stagger", "段差", context))
        row.prop(settings, "transform_reveal_duration", text=sas_text("Duration", "時間", context))
    elif mode == 'TRAIL':
        row = box.row(align=True)
        row.prop(settings, "trail_step", text=sas_text("Step", "間隔", context))
        row.prop(settings, "trail_radius", text=sas_text("Radius", "太さ", context))
        row.prop(settings, "trail_radius_mode", text=sas_text("Mode", "モード", context))
        row = box.row(align=True)
        row.prop(settings, "trail_resolution", text=sas_text("Resolution", "解像度", context))
        row.prop(settings, "trail_speed_scale", text=sas_text("Speed Scale", "速度倍率", context))
        row.prop(settings, "trail_keep_previous", text=sas_text("Keep Previous", "以前を保持", context))
    elif mode == 'GHOST':
        row = box.row(align=True)
        row.prop(settings, "ghost_past_frames", text=sas_text("Past", "過去", context))
        row.prop(settings, "ghost_future_frames", text=sas_text("Future", "未来", context))
        row.prop(settings, "ghost_step", text=sas_text("Step", "間隔", context))
        box.prop(settings, "ghost_keep_previous", text=sas_text("Keep Previous", "以前を保持", context))
    elif mode in {'BALLISTIC_GUIDE', 'BALLISTIC_BAKE'}:
        row = box.row(align=True)
        row.prop(settings, "ballistic_step", text=sas_text("Step", "間隔", context))
        row.prop(settings, "ballistic_keep_previous", text=sas_text("Keep Previous", "以前を保持", context))
        row = box.row(align=True)
        row.prop(settings, "ballistic_blend", text=sas_text("Blend", "ブレンド", context))
        row.prop(settings, "ballistic_clear_range", text=sas_text("Clear Existing", "既存削除", context))
    elif mode == 'CAMERA_SHAKE':
        box.prop(settings, "camera_shake_preset", text=sas_text("Preset", "プリセット", context))
    elif mode == 'LOOP':
        row = box.row(align=True)
        row.prop(settings, "loop_modifier_mode", text=sas_text("Mode", "モード", context))
        row.prop(settings, "loop_modifier_scope", text=sas_text("Scope", "範囲", context))
        row = box.row(align=True)
        row.prop(settings, "loop_cycles_before", text=sas_text("Before", "前", context))
        row.prop(settings, "loop_cycles_after", text=sas_text("After", "後", context))
    elif mode == 'NOISE':
        row = box.row(align=True)
        row.prop(settings, "noise_strength", text=sas_text("Strength", "強さ", context))
        row.prop(settings, "noise_scale", text=sas_text("Scale", "スケール", context))
        row = box.row(align=True)
        row.prop(settings, "noise_phase", text=sas_text("Phase", "位相", context))
        row.prop(settings, "noise_depth", text=sas_text("Depth", "深さ", context))
    elif mode == 'PATHS':
        pass
    elif mode == 'DYNAMIC_PARENT':
        pass
    elif mode in {'COPY_GLOBAL', 'PASTE_GLOBAL'}:
        pass


def _draw_cleanup_settings(box, context, settings):
    mode = settings.compact_cleanup_mode
    row = box.grid_flow(columns=2, even_columns=True, align=True)
    row.prop(settings, "only_selected_curves", text=sas_text("Selected Curves", "選択のみ", context))
    row.prop(settings, "skip_locked_curves", text=sas_text("Skip Locked", "ロック除外", context))
    row.prop(settings, "skip_muted_curves", text=sas_text("Skip Muted", "ミュート除外", context))
    row.prop(settings, "skip_hidden_curves", text=sas_text("Skip Hidden", "非表示除外", context))
    if mode in {'PREVIEW', 'SIMPLIFY'}:
        box.prop(settings, "simplify_factor", text=sas_text("Simplify", "簡略化係数", context))
    elif mode in {'REMOVE_DUPLICATES', 'DELETE_STATIC'}:
        box.prop(settings, "remove_threshold", text=sas_text("Threshold", "しきい値", context))
    elif mode in {'SMOOTH', 'SHAPE_SMOOTH'}:
        row = box.row(align=True)
        row.prop(settings, "curve_smooth_factor", text=sas_text("Factor", "係数", context))
        row.prop(settings, "curve_smooth_iterations", text=sas_text("Iterations", "反復", context))
    elif mode == 'UNBAKE':
        row = box.column(align=True)
        row.prop(settings, "unbake_tolerance", text=sas_text("Tolerance", "許容値", context))
        row.prop(settings, "unbake_preserve_extrema", text=sas_text("Preserve Extremes", "極値保持", context))
    elif mode == 'TANGENT':
        box.prop(settings, "tangent_mode", text=sas_text("Preset", "プリセット", context))
    elif mode == 'SHAPE_OPTIMIZE':
        row = box.column(align=True)
        row.prop(settings, "simplify_factor", text=sas_text("Simplify", "簡略化係数", context))
        row.prop(settings, "remove_threshold", text=sas_text("Threshold", "しきい値", context))


def _cleanup_preview_box(layout, context, settings):
    action = active_action(context)
    if not action:
        return
    preview = _begin_collapsible_section(
        layout, context, _context_sas_settings(context), 'cleanup_preview',
        "Cleanup Preview", "整理プレビュー", 'VIEWZOOM', 'cleanup_hub',
    )
    if not preview:
        return
    summary_data = _draw_metric(context, settings, 'cleanup_summary', {
        'simplify_keys': 0, 'duplicate_keys': 0, 'static_channels': 0,
    })
    grid = preview.grid_flow(columns=3, even_columns=True, even_rows=True, align=True)
    grid.label(text=sas_text(f"Simplify: {summary_data['simplify_keys']}", f"簡略: {summary_data['simplify_keys']}", context), icon='MOD_SIMPLIFY')
    grid.label(text=sas_text(f"Duplicates: {summary_data['duplicate_keys']}", f"重複: {summary_data['duplicate_keys']}", context), icon='X')
    grid.label(text=sas_text(f"Static: {summary_data['static_channels']}", f"静的: {summary_data['static_channels']}", context), icon='TRASH')



def _overview_body(layout, context, settings):
    if not layout:
        return
    analysis = None
    issues = _stats_box(layout, context, settings)
    _action_slot_box(layout, context)
    row = layout.row(align=True)
    row.prop(settings, "auto_backup_action", text=sas_text("Auto Backup", "自動バックアップ", context))
    row.prop(settings, "preview_only", text=sas_text("Preview Only", "プレビューのみ", context))
    row = layout.row(align=True)
    row.prop(settings, "show_safety_hints", text=sas_text("Show Safety Hints", "安全ヒント", context))

    need_issues = False
    try:
        need_issues = _section_state(settings, 'recommended_next_step', False) or (bool(getattr(settings, 'show_safety_hints', False)) and _section_state(settings, 'current_findings', False))
    except Exception:
        need_issues = False
    if issues is None and need_issues:
        analysis = _overview_analysis(context, settings)
        issues = analysis.get('issues') or []
    elif issues is None:
        issues = []
    issues = _recommended_box(layout, context, issues, settings=settings, analysis=analysis) or []
    if issues and settings.show_safety_hints:
        _scene_findings_box(layout, context, issues, settings)
    _draw_overview_action_buttons(layout, context)
    _operation_log_box(layout, context, settings)


def _animate_body(layout, context, settings):
    if not layout:
        return
    matched_any = False

    if _search_ok(settings, "timeline action key marker preview playback camera bake shape timeline マーカー カメラ 再生 形状キー"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('timeline_hub'), "Timeline Hub", "タイムラインハブ", 'TIME', str('timeline_hub'))
        box.prop(settings, "compact_timeline_mode", text=sas_text("Task", "タスク", context))
        _draw_timeline_settings(box, context, settings)
        box.operator("sas.run_compact_timeline", text=sas_text("Run Timeline Task", "タイムライン実行", context), icon='PLAY')

    if _search_ok(settings, "timing retime tween hold overlap random step fulcrum stepped key コマ打ち ステップ コンタクト タイミング トゥイーン"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('timing_hub'), "Timing Hub", "タイミングハブ", 'IPO_BEZIER', str('timing_hub'))
        box.prop(settings, "compact_timing_mode", text=sas_text("Task", "タスク", context))
        _draw_timing_settings(box, context, settings)
        row = box.row(align=True)
        if settings.compact_timing_mode == 'CONTACT_HOLD':
            row.operator("sas.set_contact_hold_range_from_keys", text=sas_text("Range from Keys", "キーから範囲", context), icon='PREVIEW_RANGE')
            row.operator("sas.run_compact_timing", text=sas_text("Apply", "適用", context), icon='PLAY')
        elif settings.compact_timing_mode == 'STEPPED_PREVIEW':
            row.operator("sas.apply_stepped_preview", text=sas_text("Preview", "プレビュー", context), icon='IPO_CONSTANT')
            row.operator("sas.bake_step_keys", text=sas_text("Step Keys", "ステップキー", context), icon='KEY_HLT')
            row.operator("sas.clear_stepped_preview", text=sas_text("Clear", "クリア", context), icon='X')
        else:
            row.operator("sas.run_compact_timing", text=sas_text("Run Timing Task", "タイミング実行", context), icon='PLAY')

    if _search_ok(settings, "spring magic signal stretch vehicle reveal trail ghost ballistic shake loop noise path parent global physics limited fx deformer モーションFX"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('fx_hub'), "Bake / FX Hub", "ベイク / FX ハブ", 'MODIFIER', str('fx_hub'))
        box.prop(settings, "compact_fx_mode", text=sas_text("Task", "タスク", context))
        _draw_fx_settings(box, context, settings)
        row = box.row(align=True)
        row.operator("sas.run_compact_fx", text=sas_text("Apply", "適用", context), icon='PLAY')
        if settings.compact_fx_mode in FX_CLEARABLE_MODES:
            op = row.operator("sas.run_compact_fx", text=sas_text("Clear", "クリア", context), icon='X')
            op.clear_mode = True

    if _search_ok(settings, "cleanup clean simplify unbake duplicate static tangent euler shape step clear 整理 クリア"):
        matched_any = True
        if settings.compact_cleanup_mode in {'PREVIEW', 'SIMPLIFY', 'REMOVE_DUPLICATES', 'DELETE_STATIC'}:
            _cleanup_preview_box(layout, context, settings)
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('cleanup_hub'), "Cleanup Hub", "整理ハブ", 'BRUSH_DATA', str('cleanup_hub'))
        row = box.column(align=True)
        row.prop(settings, "compact_cleanup_mode", text=sas_text("Task", "タスク", context))
        row.prop(settings, "preview_only", text=sas_text("Preview Only", "プレビューのみ", context))
        _draw_cleanup_settings(box, context, settings)
        if settings.show_safety_hints and not settings.auto_backup_action and settings.compact_cleanup_mode in {'SIMPLIFY', 'REMOVE_DUPLICATES', 'DELETE_STATIC', 'UNBAKE'}:
            box.label(text=sas_text("Auto Backup is off. Consider enabling it before destructive cleanup.", "自動バックアップがオフです。破壊的整理の前に有効化を推奨します。", context), icon='ERROR')
        box.operator("sas.run_compact_cleanup", text=sas_text("Run Cleanup Task", "整理実行", context), icon='PLAY')

    if settings.ui_search and not matched_any:
        layout.label(text=sas_text("No compact animation hub matched the current search.", "現在の検索に一致するアニメーションハブはありません。", context))


def _selection_sets_box(layout, context, settings):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('selection_sets'), "Selection Sets", "選択セット", 'RESTRICT_SELECT_OFF', str('selection_sets'))
    box.prop(settings, "selection_set_name", text=sas_text("New Name", "新規名", context))
    box.template_list("SAS_UL_selection_sets", "", settings, "selection_sets", settings, "selection_set_index", rows=4)
    row = box.row(align=True)
    row.operator("sas.store_selection_set", text=sas_text("Store", "保存", context), icon='ADD')
    row.operator("sas.apply_selection_set", text=sas_text("Apply", "適用", context), icon='CHECKMARK')
    row.operator("sas.remove_selection_set", text=sas_text("Remove", "削除", context), icon='X')
    draw_selection_set_quick_picker(box, context, settings)


def _pose_snapshots_box(layout, context, settings):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('pose_snapshots'), "Pose Snapshots", "ポーズスナップショット", 'POSE_HLT', str('pose_snapshots'))
    box.prop(settings, "snapshot_name", text=sas_text("New Name", "新規名", context))
    box.template_list("SAS_UL_pose_snapshots", "", settings, "pose_snapshots", settings, "pose_snapshot_index", rows=4)
    row = box.row(align=True)
    row.operator("sas.store_pose_snapshot", text=sas_text("Store", "保存", context), icon='ADD')
    row.operator("sas.apply_pose_snapshot", text=sas_text("Apply", "適用", context), icon='CHECKMARK')
    row.operator("sas.remove_pose_snapshot", text=sas_text("Remove", "削除", context), icon='X')
    draw_pose_snapshot_quick_picker(box, context, settings)
    row = box.column(align=True)
    row.prop(settings, "snapshot_blend_factor", text=sas_text("Blend", "ブレンド", context))
    row.operator("sas.apply_snapshot_blend", text=sas_text("Blend Snapshot", "スナップショットブレンド", context), icon='IPO_BEZIER')
    row = box.row(align=True)
    row.operator("sas.pose_mirror", text=sas_text("Mirror", "反転", context), icon='MOD_MIRROR')
    row.operator("sas.pose_reset", text=sas_text("Reset", "リセット", context), icon='LOOP_BACK')


def _action_workflow_box(layout, context, settings):
    obj = active_object(context)
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('action_nla'), "Action / NLA Workflow", "アクション / NLA ワークフロー", 'ACTION', str('action_nla'))
    if obj:
        anim_data = obj.animation_data
        if anim_data:
            box.template_ID(anim_data, "action", new="sas.new_action")
        else:
            box.operator("sas.new_action", text=sas_text("Create Action", "アクション作成", context), icon='ADD')
    else:
        box.label(text=sas_text("Select an object to manage actions.", "アクション管理にはオブジェクトを選択してください。", context), icon='OBJECT_DATA')
    box.prop(settings, "nla_blend_mode", text=sas_text("NLA Blend", "NLA 合成", context))
    box.prop(settings, "layer_action_name", text=sas_text("Layer Action Name", "層の名前", context))
    row = box.column(align=True)
    row.operator("sas.push_action_to_nla", text=sas_text("Push Action", "アクションをプッシュ", context), icon='NLA')
    row.operator("sas.build_layer_stack", text=sas_text("Build Stack", "スタック作成", context), icon='SEQ_STRIP_DUPLICATE')
    row.operator("sas.add_animation_layer", text=sas_text("Add Layer", "レイヤー追加", context), icon='ADD')


def _library_box(layout, context, settings):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('motion_library'), "Motion Library", "モーションライブラリ", 'ASSET_MANAGER', str('motion_library'))
    box.prop(settings, "library_assign_mode", text=sas_text("Assign Mode", "割当方式", context))
    box.template_list("SAS_UL_action_library", "", settings, "action_library", settings, "action_library_index", rows=4)
    row = box.row(align=True)
    row.operator("sas.add_action_to_library", text=sas_text("Add Current", "現在を追加", context), icon='ADD')
    row.operator("sas.assign_library_action", text=sas_text("Assign", "割り当て", context), icon='ACTION')
    row = box.row(align=True)
    row.operator("sas.push_library_action_to_nla", text=sas_text("Push NLA", "NLA追加", context), icon='NLA')
    row.operator("sas.remove_action_from_library", text=sas_text("Remove", "削除", context), icon='X')
    row = box.row(align=True)
    row.operator("sas.prune_action_library", text=sas_text("Prune", "整理", context), icon='TRASH')
    draw_action_library_quick_picker(box, context, settings)

    seq_box = _begin_collapsible_section(box, context, _context_sas_settings(context), str('library_sequence'), "Library Sequence", "ライブラリシーケンス", 'SEQ_SEQUENCER', str('library_sequence'))
    row = seq_box.row(align=True)
    row.prop(settings, "library_sequence_start", text=sas_text("Start", "開始", context))
    row.prop(settings, "library_sequence_gap", text=sas_text("Spacing", "間隔", context))
    row.prop(settings, "library_sequence_clear_existing", text=sas_text("Clear Older SAS", "古いSAS整理", context), toggle=True)
    seq_box.operator("sas.sequence_library_actions", text=sas_text("Sequence Library to NLA", "ライブラリを NLA へ並べる", context), icon='PLAY')


def _data_io_box(layout, context, settings):
    box = _begin_collapsible_section(layout, context, _context_sas_settings(context), str('data_io'), "Data I/O Hub", "データ入出力ハブ", 'TEXT', str('data_io'))
    box.prop(settings, "compact_data_mode", text=sas_text("Task", "タスク", context))
    mode = settings.compact_data_mode
    if mode.startswith('POSE_'):
        box.prop_search(settings, "pose_snapshot_text_name", bpy.data, "texts", text=sas_text("Text Name", "テキスト", context), icon='TEXT')
    elif mode.startswith('SELECTION_'):
        box.prop_search(settings, "selection_set_text_name", bpy.data, "texts", text=sas_text("Text Name", "テキスト", context), icon='TEXT')
    elif mode.startswith('LIBRARY_'):
        if mode == 'LIBRARY_PRUNE':
            pass
        else:
            box.prop_search(settings, "library_manifest_text_name", bpy.data, "texts", text=sas_text("Text Name", "テキスト", context), icon='TEXT')
    else:
        box.prop_search(settings, "retarget_profile_name", bpy.data, "texts", text=sas_text("Text Name", "テキスト", context), icon='TEXT')
    box.operator("sas.run_compact_data", text=sas_text("Run Data Task", "データ実行", context), icon='PLAY')


def _assets_body(layout, context, settings):
    if not layout:
        return
    matched_any = False

    if _search_ok(settings, "selection set picker control 選択セット"):
        matched_any = True
        _selection_sets_box(layout, context, settings)

    if _search_ok(settings, "pose snapshot blend mirror reset ポーズ スナップショット"):
        matched_any = True
        _pose_snapshots_box(layout, context, settings)

    if _search_ok(settings, "action nla library motion story sequence clip アクション NLA ライブラリ"):
        matched_any = True
        _action_workflow_box(layout, context, settings)
        _library_box(layout, context, settings)

    if _search_ok(settings, "import export json text data profile manifest map 入出力 JSON テキスト"):
        matched_any = True
        _data_io_box(layout, context, settings)

    if settings.ui_search and not matched_any:
        layout.label(text=sas_text("No asset hub matched the current search.", "現在の検索に一致するアセットハブはありません。", context))


def _transfer_body(layout, context, settings):
    if not layout:
        return
    matched_any = False
    if _search_ok(settings, "retarget root motion map bake transfer リターゲット ルートモーション"):
        matched_any = True
        box = _begin_collapsible_section(layout, context, _context_sas_settings(context), 'transfer_hub', "Transfer Hub", "転送ハブ", 'ARROW_LEFTRIGHT', 'transfer_hub')
        if box:
            row = box.column(align=True)
            row.prop(settings, "retarget_source", text=sas_text("Source", "ソース", context))
            row.prop(settings, "retarget_target", text=sas_text("Target", "対象", context))
            row = box.row(align=True)
            row.prop(settings, "strip_namespaces", text=sas_text("Strip Namespaces", "名前空間除去", context))
            row.prop(settings, "use_side_aliases", text=sas_text("Side Aliases", "左右エイリアス", context))
            row = box.column(align=True)
            row.prop(settings, "retarget_constraint_influence", text=sas_text("Influence", "影響度", context))
            row.prop(settings, "retarget_space", text=sas_text("Space", "空間", context))
            row = box.row(align=True)
            row.prop(settings, "retarget_replace_existing", text=sas_text("Replace SAS", "SAS置換", context))
            row.prop(settings, "clear_constraints_after_bake", text=sas_text("Clear After Bake", "ベイク後解除", context))
            box.prop(settings, "compact_transfer_mode", text=sas_text("Task", "タスク", context))
            if settings.compact_transfer_mode in {'ROOT_MOTION', 'IN_PLACE'}:
                box.prop(settings, "root_motion_bone", text=sas_text("Root Bone", "ルートボーン", context))
                row = box.row(align=True)
                row.prop(settings, "root_motion_axis_x", text="X")
                row.prop(settings, "root_motion_axis_y", text="Y")
                row.prop(settings, "root_motion_axis_z", text="Z")
                root_count = int(_draw_metric(context, settings, 'root_curve_count', 0) or 0)
                box.label(text=sas_text(f"Matched Root Curves: {root_count}", f"一致ルートカーブ数: {root_count}", context), icon='IPO_BEZIER')
            if settings.show_safety_hints and settings.compact_transfer_mode in {'LIVE_PREVIEW', 'APPLY_CURRENT_MAP', 'BAKE_TO_KEYS'}:
                box.label(text=sas_text("Confirm source and target rigs before live retarget or bake.", "ライブリターゲットやベイクの前にソースとターゲットを確認してください。", context), icon='ERROR')
            box.operator("sas.run_compact_transfer", text=sas_text("Run Transfer Task", "転送実行", context), icon='PLAY')

        profile = _begin_collapsible_section(layout, context, _context_sas_settings(context), 'retarget_profile', "Retarget Profile", "リターゲットプロファイル", 'TEXT', 'retarget_profile')
        if profile:
            profile.prop_search(settings, "retarget_profile_name", bpy.data, "texts", text=sas_text("Profile Text", "テキスト", context), icon='TEXT')
            row = profile.row(align=True)
            row.operator("sas.export_bone_map", text=sas_text("Export JSON", "JSON 書き出し", context), icon='EXPORT')
            row.operator("sas.import_bone_map", text=sas_text("Import JSON", "JSON 読み込み", context), icon='IMPORT')

        preview = _begin_collapsible_section(layout, context, _context_sas_settings(context), 'mapping_preview', "Mapping Preview", "対応プレビュー", 'BONE_DATA', 'mapping_preview')
        if preview:
            mapping = _draw_metric(context, settings, 'mapping', {
                'matched': 0, 'total': int(len(getattr(settings, 'bone_map', ()) or ())), 'high_conf': 0,
            })
            row = preview.row(align=True)
            row.label(text=sas_text(f"Matched: {mapping['matched']}/{mapping['total']}", f"一致: {mapping['matched']}/{mapping['total']}", context), icon='CHECKMARK')
            row.label(text=sas_text(f"High Confidence: {mapping['high_conf']}", f"高信頼: {mapping['high_conf']}", context))
            live_count = int(_draw_metric(context, settings, 'live_constraints', 0) or 0)
            row.label(text=sas_text(f"Live: {live_count}", f"ライブ: {live_count}", context), icon='CONSTRAINT')
            if settings.bone_map:
                preview.template_list("SAS_UL_bone_map", "", settings, "bone_map", settings, "bone_map_index", rows=6)
    if settings.ui_search and not matched_any:
        layout.label(text=sas_text("No transfer hub matched the current search.", "現在の検索に一致する転送ハブはありません。", context))




def _context_sas_settings(context):
    try:
        scene = getattr(context, 'scene', None)
        if scene is None:
            return None
        return getattr(scene, 'sas_settings', None)
    except (ReferenceError, RuntimeError):
        return None



class SAS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'sas.toggle_ui_section'
    bl_label = 'Toggle UI Section'
    bl_description = 'Expand or collapse this Smart Animation UI section.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    section_key: StringProperty(options={'SKIP_SAVE'})
    label: StringProperty(options={'SKIP_SAVE'})
    default_state: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'section_key', '') or '').strip()
        return sas_text(
            f'Open or close the {label} section.',
            f'{label} セクションを開閉します。',
            context,
        )

    def execute(self, context):
        key = str(self.section_key or '').strip()
        if not key:
            return {'CANCELLED'}
        settings = _context_sas_settings(context)
        current = _section_state(settings, key, bool(self.default_state))
        new_state = not current
        _section_state_set(settings, key, new_state, context=context)
        if new_state and key in {
            'section_overview', 'scene_snapshot', 'recommended_next_step', 'current_findings',
            'timing_hub', 'cleanup_preview', 'transfer_hub', 'mapping_preview',
            'section_animation',
        }:
            refresh_performance_cache(context=context, settings=settings)
        return {'FINISHED'}


class SAS_OT_show_help(bpy.types.Operator):
    bl_idname = 'sas.show_help'
    bl_label = 'Help'
    bl_description = 'Show detailed help for this Smart Animation tool group.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    topic_key: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            'Open detailed help for this tool group, including feature overview, usage, and every exposed setting.',
            'このツールグループの機能概要、使用方法、表示される全設定項目を詳しく表示します。',
            context,
        )

    def invoke(self, context, _event):
        return self.execute(context)

    def execute(self, context):
        topic_key = str(self.topic_key or '').strip()
        try:
            from . import help
            if not help.show_help_popup(context, topic_key):
                self.report({'ERROR'}, sas_text('Help is not available for this item.', 'この項目のヘルプを利用できません。', context))
                return {'CANCELLED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f'Help could not be opened: {exc}', f'ヘルプを開けませんでした: {sas_error_reason(exc)}', context))
            return {'CANCELLED'}
        return {'FINISHED'}



_SAS_PRIMARY_PANEL_SPACE = 'VIEW_3D'
_SAS_NATIVE_ROOT_TOOL_KEY = 'SMART_ANIMATION'
_SAS_NATIVE_ROOT_CATEGORY = 'Smart Animation'
_SAS_NATIVE_ROOT_PHYSICAL_SPACES = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
)


def _sas_main_panel_poll(context, editor_key: str = '') -> bool:
    """Pure native-root placement gate.

    The Panel remains structurally present through selection and mode changes;
    only Smart Tools Manager's current workspace/logical-editor rule controls
    category visibility.  No RNA, class, configuration, timer, or cache state is
    changed from this callback.
    """
    try:
        if not _is_sas_npanel_context(context):
            return False
        return bool(manager_compat.panel_rule_allows_context(context, editor_key=editor_key))
    except Exception:
        return False


class _SASMainPanelMixin:
    def draw_header_preset(self, context):
        _draw_help_button(self.layout, context, 'section_overview')

    bl_label = _SAS_NATIVE_ROOT_CATEGORY
    bl_region_type = 'UI'
    bl_category = _SAS_NATIVE_ROOT_CATEGORY
    bl_description = "Compact Smart Animation workspace shown in the Sidebar N-panel."

    @classmethod
    def poll(cls, context):
        # Contract order is intentional: reject the wrong physical area first,
        # then classify its logical Manager cell and perform one read-only
        # placement_allowed() query. No import, registration, or cache mutation.
        if not _is_sas_npanel_context(context):
            return False
        physical = str(getattr(cls, 'bl_space_type', '') or '')
        area = getattr(context, 'area', None)
        if str(getattr(area, 'type', '') or '') != physical:
            return False
        logical = manager_compat.logical_editor_key(context, physical)
        if physical == 'FILE_BROWSER' and logical not in cls._smart_tools_manager_logical_editor_keys:
            return False
        return bool(manager_compat.panel_rule_allows_context(context, editor_key=logical))

    def draw(self, context):
        layout = getattr(self, 'layout', None)
        if layout is None:
            return None
        settings = _context_sas_settings(context)
        if settings is None:
            # Keep an enabled Manager root full-body even while Blender is
            # materialising Scene RNA during a file or workspace transition.
            # This path is read-only and intentionally performs no repair.
            box = layout.box()
            box.label(
                text=sas_text(
                    'Smart Animation settings are not ready in this context.',
                    'このコンテキストでは Smart Animation 設定の準備が完了していません。',
                    context,
                ),
            )
            return None

        try:
            # Registration, load_post, and the scene-change persistence guard
            # restore canonical state before drawing. A panel redraw must remain
            # a pure read: never read JSON, apply RNA, sync resident features,
            # register resources, or mark a Scene from this callback.
            _draw_always_on_toggles(layout, context, settings)
            _compact_header(layout, context, settings)

            mode = str(getattr(settings, 'compact_diag_mode', 'ALL') or 'ALL')
            if mode == 'ALL':
                _draw_all_functions_body(layout, context, settings)
            elif mode == 'OVERVIEW':
                section = _begin_top_level_section(layout, context, settings, 'section_overview', 'Overview / Diagnostics', '概要 / 診断', 'VIEWZOOM', 'section_overview', default=False)
                if section:
                    _overview_body(section, context, settings)
            elif mode == 'SMART':
                section = _begin_top_level_section(layout, context, settings, 'section_animation_recipes', 'Animation Recipes', 'Animation Recipes', 'ARMATURE_DATA', 'section_animation_recipes', default=False)
                if section:
                    _animation_recipes_body(section, context, settings)
            elif mode == 'ANIMATE':
                section = _begin_top_level_section(layout, context, settings, 'section_animation', 'Animation Tools', 'アニメーションツール', 'KEY_HLT', 'section_animation', default=False)
                if section:
                    _animate_body(section, context, settings)
            elif mode == 'ASSETS':
                section = _begin_top_level_section(layout, context, settings, 'section_assets', 'Asset Tools', 'アセットツール', 'ASSET_MANAGER', 'section_assets', default=False)
                if section:
                    _assets_body(section, context, settings)
            elif mode == 'TRANSFER':
                section = _begin_top_level_section(layout, context, settings, 'section_transfer', 'Transfer Tools', '転送ツール', 'ARROW_LEFTRIGHT', 'section_transfer', default=False)
                if section:
                    _transfer_body(section, context, settings)
            elif mode.startswith('INT_GROUP_'):
                group = registry.overview_group_name(mode)
                if group:
                    _draw_integrated_tool_group(layout, context, group, show_header=True)
                else:
                    layout.label(text=sas_text('Selected overview task group was not found.', '選択された概要タスクグループが見つかりません。', context), icon='ERROR')
            else:
                _draw_all_functions_body(layout, context, settings)
        except Exception as exc:
            error_box = layout.box()
            error_box.alert = True
            error_box.label(text=sas_text('Smart Animation UI draw failed.', 'Smart Animation UIの描画に失敗しました。', context), icon='ERROR')
            error_box.label(text=sas_text(str(exc)[:240], sas_error_reason(exc), context), translate=False)
        return None


class SAS_PT_main(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('VIEW_3D',)


class SAS_PT_main_image(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_image"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('IMAGE_EDITOR', 'UV_EDITOR')


class SAS_PT_main_node(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_node"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = (
        'SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR',
    )


class SAS_PT_main_sequence(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_sequence"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('VIDEO_SEQUENCER',)


class SAS_PT_main_clip(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_clip"
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('MOVIE_CLIP_EDITOR',)


class SAS_PT_main_dopesheet(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_dopesheet"
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('DOPE_SHEET',)


class SAS_PT_main_graph(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_graph"
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('GRAPH_EDITOR', 'DRIVERS')


class SAS_PT_main_nla(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_nla"
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('NLA_EDITOR',)


class SAS_PT_main_text(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_text"
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('TEXT_EDITOR',)


class SAS_PT_main_file_browser(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_file_browser"
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('FILE_BROWSER',)


class SAS_PT_main_asset_browser(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_asset_browser"
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_category = 'Smart Animation'
    bl_description = "Compact Smart Animation workspace in the Asset Browser tool properties."
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('ASSET_BROWSER',)


class SAS_PT_main_spreadsheet(_SASMainPanelMixin, Panel):
    bl_idname = "SAS_PT_main_spreadsheet"
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    _smart_tools_manager_tool_key = 'SMART_ANIMATION'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_logical_editor_keys = ('SPREADSHEET',)


_ROOT_PANEL_CLASSES = (
    SAS_PT_main,
    SAS_PT_main_image,
    SAS_PT_main_node,
    SAS_PT_main_sequence,
    SAS_PT_main_clip,
    SAS_PT_main_dopesheet,
    SAS_PT_main_graph,
    SAS_PT_main_nla,
    SAS_PT_main_text,
    SAS_PT_main_file_browser,
    SAS_PT_main_asset_browser,
    SAS_PT_main_spreadsheet,
)

_PANEL_CLASSES = [
    SAS_OT_toggle_ui_section,
    SAS_OT_show_help,
    *_ROOT_PANEL_CLASSES,
]

UI_CLASSES = (
    SAS_OT_toggle_ui_section,
    SAS_OT_show_help,
    *_ROOT_PANEL_CLASSES,
)
