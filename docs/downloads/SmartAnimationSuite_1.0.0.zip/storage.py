# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_animation_suite'
PACKAGE_ALIASES = {'smart_animation_suite', 'Smart_Animation_Suite'}
USER_DATA_DIRNAME = 'user_data'
CONFIG_DIRNAME = 'Smart_Animation_Suite'


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _config_root(*, create: bool = True) -> Path:
    """Return the only writable root owned by Smart Animation Suite."""
    if bpy is not None:
        try:
            user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
            value = user_resource('CONFIG', create=bool(create)) if callable(user_resource) else ''
        except Exception:
            value = ''
        if value:
            root = Path(value) / CONFIG_DIRNAME
            if create:
                root.mkdir(parents=True, exist_ok=True)
            return root
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / CONFIG_DIRNAME
    else:
        root = Path.home() / '.config' / 'blender' / version / 'config' / CONFIG_DIRNAME
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def _legacy_user_data_root() -> Path:
    """Read-only migration source used by releases that wrote beside code."""
    return _package_root() / USER_DATA_DIRNAME


def _is_below(path: Path, root: Path) -> bool:
    try:
        Path(path).resolve(strict=False).relative_to(Path(root).resolve(strict=False))
        return True
    except Exception:
        return False


def _require_mutable_target(path: Path) -> Path:
    target = Path(path)
    if not _is_below(target, _config_root(create=False)):
        raise ValueError(f'Smart Animation mutable path must stay below Blender CONFIG/{CONFIG_DIRNAME}: {target}')
    return target


def _migrate_legacy_relative(relative_parts: Iterable[object], target: Path) -> bool:
    """Copy one legacy package file into CONFIG without modifying the source."""
    clean = _clean_parts(relative_parts)
    if not clean:
        return False
    legacy = _legacy_user_data_root().joinpath(*clean)
    target = _require_mutable_target(target)
    try:
        if target.exists() or not legacy.is_file():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        return True
    except Exception:
        return False


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        parent = current.parent
        aliases = {str(alias).lower() for alias in PACKAGE_ALIASES}
        if parent.name == 'user_default' and parent.parent.name == 'extensions':
            if current.name.lower() in aliases or current.name.lower() == PACKAGE_ID.lower():
                return current
    except Exception:
        pass
    return None


def _package_candidates(package_id: str) -> tuple[str, ...]:
    values: list[str] = []
    for item in (package_id, PACKAGE_ID, *PACKAGE_ALIASES):
        text = str(item or '').strip()
        if text and text not in values:
            values.append(text)
    return tuple(values)


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    del create
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for candidate_id in _package_candidates(package_id):
        for args, kwargs in (
            ((candidate_id,), {'path': '', 'create': False}),
            ((candidate_id,), {'create': False}),
            ((candidate_id, ''), {'create': False}),
        ):
            try:
                value = fn(*args, **kwargs)
            except TypeError:
                continue
            except Exception:
                continue
            if value:
                path = Path(value)
                return path
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    del create
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for candidate_id in _package_candidates(package_id):
        try:
            value = user_resource('EXTENSIONS', path=f'user_default/{candidate_id}', create=False)
        except Exception:
            value = ''
        if value:
            return Path(value)
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / PACKAGE_ID
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    del create
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Return an extension package location for read-only discovery.

    ``create`` is retained for API compatibility but deliberately ignored. An
    installed Extension directory contains immutable code and bundled assets;
    runtime code must use the CONFIG-backed helpers below.
    """
    pkg = package_id(package)
    aliases = {value.lower() for value in _package_candidates(PACKAGE_ID)}
    installed = _installed_extension_root() if pkg.lower() in aliases else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(PACKAGE_ID if pkg.lower() in aliases else pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    # Historical name retained for callers, but mutable data is no longer
    # written into extensions/user_default/<id>.
    del package_id
    root = _config_root(create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=False)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = _config_root(create=create)
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_relative(clean, path)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    _migrate_legacy_relative(['data', *clean], path)
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_relative(['storage', *clean], path)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = _config_root(create=create) / 'runtime'
    if pkg.lower() not in {value.lower() for value in _package_candidates(PACKAGE_ID)}:
        root = root / _clean_part(pkg)
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    _migrate_legacy_relative(['settings', clean], path)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    legacy_clean = ['runtime', *_clean_parts([*subdirs, filename])]
    _migrate_legacy_relative(legacy_clean, path)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = _config_root(create=create) / 'storage'
    pkg = package_id and str(package_id or '').strip()
    if pkg and pkg.lower() not in {value.lower() for value in _package_candidates(PACKAGE_ID)}:
        root = root / _clean_part(pkg)
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    path = root / clean[-1]
    _migrate_legacy_relative(['storage', *clean], path)
    return path


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = _require_mutable_target(Path(path))
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(text, encoding=encoding)
    tmp.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = _require_mutable_target(Path(target_path))
    try:
        if not _is_below(legacy, _legacy_user_data_root()):
            return False
        if not legacy.is_file() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        # ``remove_legacy`` is intentionally ignored. The installed package is
        # a read-only migration source and is never edited or cleaned in place.
        del remove_legacy
        return True
    except Exception:
        return False
