# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Stop Motion Style Animator",
    "author": "JELararagi",
    "version": (0, 7),
    "blender": (5, 1, 0),
    "location": "Dope Sheet > StopMotion",
    "description": "Stop-motion tools: Step, Jitter, and Offset",
    "category": "Animation",
}

import bpy
import random

from ..action_compat import iter_action_fcurves


def get_action_fcurves(action, datablock=None):
    for fc in iter_action_fcurves(action, datablock=datablock):
        yield fc

class SM_OT_ConvertToStopMotion(bpy.types.Operator):
    bl_idname = "anim.stop_motion_convert"
    bl_label = "Apply Stop Motion"
    bl_description = "Applies stepped animation and optional noise"
    bl_options = {'UNDO'}

    def execute(self, context):
        step = context.scene.sm_step
        offset = context.scene.sm_offset
        jitter_strength = context.scene.sm_jitter

        obj = context.object
        if not obj or not obj.animation_data:
            self.report({"WARNING"}, bpy.app.translations.pgettext_tip("No animation data found"))
            return {"CANCELLED"}

        # Collect actions
        actions_to_process = set()
        if obj.animation_data.action:
            actions_to_process.add(obj.animation_data.action)
        for track in obj.animation_data.nla_tracks:
            for strip in track.strips:
                if strip.action:
                    actions_to_process.add(strip.action)

        if not actions_to_process:
            self.report({"WARNING"}, bpy.app.translations.pgettext_tip("No actions found"))
            return {"CANCELLED"}
            
        changed = False
        
        for action in actions_to_process:
            for fcurve in get_action_fcurves(action, datablock=obj):
                
                # --- 1. HANDLE KEYFRAMES (STEPPING) ---
                keys = fcurve.keyframe_points
                if keys:
                    # Iterate backwards to remove safely
                    for i in range(len(keys) - 1, -1, -1):
                        kp = keys[i]
                        frame = int(round(kp.co.x))

                        # Use offset in calculation: (frame - offset) % step
                        if step > 1 and (frame - offset) % step != 0:
                            # Don't remove the very first and very last key to keep range
                            if i != 0 and i != len(keys)-1: 
                                keys.remove(kp)
                                changed = True
                                continue
                        
                        if kp.interpolation != 'CONSTANT':
                            kp.interpolation = 'CONSTANT'
                            changed = True

                # --- 2. HANDLE NOISE (JITTER) ---
                # Remove existing stop-motion noise to avoid stacking
                for mod in fcurve.modifiers:
                    if mod.type == 'NOISE' and mod.name == "SM_Jitter":
                        fcurve.modifiers.remove(mod)
                
                # Add new noise if strength > 0
                if jitter_strength > 0:
                    mod = fcurve.modifiers.new('NOISE')
                    mod.name = "SM_Jitter"
                    mod.scale = step * 2.0 # Scale noise relative to step speed
                    mod.strength = jitter_strength
                    mod.phase = random.random() * 100
                    changed = True

        self.report({"INFO"}, bpy.app.translations.pgettext("Applied: Step {}, Offset {}, Jitter {:.2f}").format(step, offset, jitter_strength))
        return {"FINISHED"}

class SM_OT_ResetAnimation(bpy.types.Operator):
    bl_idname = "anim.stop_motion_reset"
    bl_label = "Reset / Clean"
    bl_description = "Removes Jitter and sets interpolation back to Bezier (Does not restore deleted keys!)"
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or not obj.animation_data:
            return {"CANCELLED"}

        actions_to_process = set()
        if obj.animation_data.action:
            actions_to_process.add(obj.animation_data.action)
        for track in obj.animation_data.nla_tracks:
            for strip in track.strips:
                if strip.action:
                    actions_to_process.add(strip.action)

        for action in actions_to_process:
            for fcurve in get_action_fcurves(action, datablock=obj):
                # Remove Noise
                for mod in fcurve.modifiers:
                    if mod.name == "SM_Jitter":
                        fcurve.modifiers.remove(mod)
                
                # Set Interpolation to Bezier
                for kp in fcurve.keyframe_points:
                    kp.interpolation = 'BEZIER'
                    kp.handle_left_type = 'AUTO_CLAMPED'
                    kp.handle_right_type = 'AUTO_CLAMPED'

        self.report({"INFO"}, "Animation cleaned (Interpolation: Bezier, Modifiers removed)")
        return {"FINISHED"}

class SM_PT_Panel(bpy.types.Panel):
    bl_label = "Stop Motion Style"
    bl_idname = "ANIM_PT_stop_motion"
    bl_space_type = "DOPESHEET_EDITOR"
    bl_region_type = "UI"
    bl_category = 'Smart Animation'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        col = layout.column(align=True)
        col.label(text="Timing:")
        col.prop(scene, "sm_step", text="Step Frames")
        col.prop(scene, "sm_offset", text="Phase Offset")
        
        col.separator()
        col.label(text="Imperfection:")
        col.prop(scene, "sm_jitter", text="Jitter Strength")
        
        col.separator()
        col.operator("anim.stop_motion_convert", icon="FRAME_NEXT", text="Apply Stop Motion")
        
        layout.separator()
        col.operator("anim.stop_motion_reset", icon="FILE_REFRESH", text="Reset to Smooth")


classes = (
    SM_OT_ConvertToStopMotion,
    SM_OT_ResetAnimation,
    SM_PT_Panel,
)

def register():
    bpy.types.Scene.sm_step = bpy.props.IntProperty(
        name="Step", default=3, min=1, description="Hold pose for N frames"
    )
    bpy.types.Scene.sm_offset = bpy.props.IntProperty(
        name="Offset", default=0, min=0, description="Shift the hold pattern by N frames"
    )
    bpy.types.Scene.sm_jitter = bpy.props.FloatProperty(
        name="Jitter", default=0.0, min=0.0, max=10.0, description="Add noise to simulate handmade imperfections"
    )

    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    del bpy.types.Scene.sm_step
    del bpy.types.Scene.sm_offset
    del bpy.types.Scene.sm_jitter

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()