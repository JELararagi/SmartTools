# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================


import math

import bpy
from bpy.types import Operator
from mathutils import Vector

from .translation import sas_text
from .core import (
    active_object,
    add_log,
    ensure_action_backup,
    get_bake_range,
    get_or_create_action_for_object,
)
from .action_compat import ensure_action_fcurve, iter_action_fcurves, remove_action_fcurve


MOTION_STRETCH_GROUP = "SAS_MotionStretch"
VEHICLE_DRIVE_GROUP = "SAS_VehicleDrive"
DEFORM_REVEAL_PREFIX = "SAS_DeformReveal"


def _unique_objects(objects):
    result = []
    seen = set()
    for obj in list(objects or []):
        if obj is None:
            continue
        key = getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj)
        if key in seen:
            continue
        seen.add(key)
        result.append(obj)
    return result


def _axis_index(axis_name):
    axis_name = str(axis_name or "X").upper()
    return 0 if axis_name == 'X' else (1 if axis_name == 'Y' else 2)


def _non_axis_indices(axis_index):
    return [index for index in range(3) if index != axis_index]


def _project_vector(vector, plane_name):
    vector = Vector(vector)
    plane_name = str(plane_name or 'XYZ').upper()
    if plane_name == 'XY':
        return Vector((vector.x, vector.y, 0.0))
    if plane_name == 'XZ':
        return Vector((vector.x, 0.0, vector.z))
    if plane_name == 'YZ':
        return Vector((0.0, vector.y, vector.z))
    return Vector(vector)


def _frame_list(start, end, step):
    start = int(start)
    end = int(end)
    step = max(1, int(step))
    frames = list(range(start, end + 1, step))
    if not frames or frames[-1] != end:
        frames.append(end)
    return frames


def _evaluated_world_location(scene, depsgraph, obj, frame):
    scene.frame_set(int(frame))
    try:
        eval_obj = obj.evaluated_get(depsgraph) if depsgraph is not None else obj
    except Exception:
        eval_obj = obj
    try:
        return eval_obj.matrix_world.translation.copy()
    except Exception:
        try:
            return Vector(eval_obj.location)
        except Exception:
            return Vector((0.0, 0.0, 0.0))


def _group_name(fcurve):
    try:
        group = getattr(fcurve, "group", None)
        return group.name if group is not None else ""
    except Exception:
        return ""


def _curves_for_path(action, datablock, data_path):
    return [fcurve for fcurve in iter_action_fcurves(action, datablock=datablock) if getattr(fcurve, "data_path", "") == data_path]


def _sas_group_curves(action, datablock, data_path, group_name):
    return [fcurve for fcurve in _curves_for_path(action, datablock, data_path) if _group_name(fcurve) == group_name]


def _has_foreign_curves(action, datablock, data_path, group_name):
    for fcurve in _curves_for_path(action, datablock, data_path):
        if _group_name(fcurve) != group_name:
            return True
    return False


def _remove_group_fcurves(action, datablock, data_path, group_name):
    removed = 0
    for fcurve in list(_curves_for_path(action, datablock, data_path)):
        if _group_name(fcurve) != group_name:
            continue
        if remove_action_fcurve(action, fcurve, datablock=datablock):
            removed += 1
    return removed


def _clear_fcurve_keys(fcurve):
    if fcurve is None:
        return
    try:
        fcurve.keyframe_points.clear()
        return
    except Exception:
        pass
    for index in range(len(fcurve.keyframe_points) - 1, -1, -1):
        try:
            fcurve.keyframe_points.remove(fcurve.keyframe_points[index])
        except Exception:
            continue


def _finalize_fcurve(fcurve, interpolation='LINEAR', handle_type='AUTO_CLAMPED'):
    if fcurve is None:
        return
    try:
        for keyframe in fcurve.keyframe_points:
            try:
                keyframe.interpolation = interpolation
            except Exception:
                pass
            try:
                keyframe.handle_left_type = handle_type
                keyframe.handle_right_type = handle_type
            except Exception:
                pass
        fcurve.update()
    except Exception:
        pass


def _set_vector_idprop(obj, prop_name, value):
    try:
        obj[prop_name] = [float(component) for component in Vector(value)[:3]]
    except Exception:
        pass


def _get_vector_idprop(obj, prop_name, fallback):
    try:
        value = obj.get(prop_name)
    except Exception:
        value = None
    # Stored vectors read back as IDPropertyArray, which is not a list or tuple.
    if value is not None and not isinstance(value, str) and hasattr(value, '__len__') and len(value) >= 3:
        try:
            return Vector((float(value[0]), float(value[1]), float(value[2])))
        except Exception:
            pass
    try:
        return Vector(fallback)
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _clear_idprop(obj, prop_name):
    try:
        if prop_name in obj:
            del obj[prop_name]
    except Exception:
        pass


def _wheel_side_sign(obj):
    name = (getattr(obj, "name", "") or "").lower()
    right_tokens = (".r", "_r", "-r", " right", "right_", "right.")
    left_tokens = (".l", "_l", "-l", " left", "left_", "left.")
    if any(token in name for token in right_tokens):
        return -1.0
    if any(token in name for token in left_tokens):
        return 1.0
    return 1.0


def _auto_radius(obj, axis_index):
    try:
        dims = [abs(float(value)) for value in obj.dimensions[:3]]
    except Exception:
        dims = [2.0, 2.0, 2.0]
    other_dims = [dims[index] for index in _non_axis_indices(axis_index)]
    if not other_dims:
        return 1.0
    average_diameter = sum(other_dims) / max(1, len(other_dims))
    radius = average_diameter * 0.5
    return max(1e-4, float(radius))


def _object_sample_positions(scene, depsgraph, obj, frames):
    return {int(frame): _evaluated_world_location(scene, depsgraph, obj, int(frame)) for frame in frames}


def _motion_stretch_values(base_scale, positions, frames, axis_index, plane, strength, squash, max_factor):
    base_scale = Vector(base_scale)
    values = {}
    max_factor = max(1.0, float(max_factor))
    stretch_limit = max(0.0, max_factor - 1.0)
    for index, frame in enumerate(frames):
        prev_frame = frames[max(0, index - 1)]
        next_frame = frames[min(len(frames) - 1, index + 1)]
        frame_span = max(1.0, float(next_frame - prev_frame))
        motion = _project_vector(positions[next_frame] - positions[prev_frame], plane)
        speed = motion.length / frame_span
        stretch_amount = min(stretch_limit, max(0.0, speed * float(strength)))
        stretch_scale = 1.0 + stretch_amount
        squash_scale = max(0.01, 1.0 / (1.0 + stretch_amount * max(0.0, float(squash))))
        sample = Vector(base_scale)
        sample[axis_index] = base_scale[axis_index] * stretch_scale
        for other_index in _non_axis_indices(axis_index):
            sample[other_index] = base_scale[other_index] * squash_scale
        values[int(frame)] = sample
    return values


def _cumulative_distances(positions, frames, plane):
    cumulative = {}
    total = 0.0
    for index, frame in enumerate(frames):
        if index == 0:
            cumulative[int(frame)] = 0.0
            continue
        prev_frame = frames[index - 1]
        delta = _project_vector(positions[frame] - positions[prev_frame], plane)
        total += delta.length
        cumulative[int(frame)] = total
    return cumulative


def _heading_axes(plane_name):
    plane_name = str(plane_name or 'XZ').upper()
    if plane_name == 'XY':
        return 0, 1
    if plane_name == 'YZ':
        return 1, 2
    return 0, 2


def _normalize_angle(angle):
    while angle > math.pi:
        angle -= math.tau
    while angle < -math.pi:
        angle += math.tau
    return angle


def _heading_angle(vector, plane_name):
    axis_a, axis_b = _heading_axes(plane_name)
    try:
        a = float(vector[axis_a])
        b = float(vector[axis_b])
    except Exception:
        return None
    if abs(a) <= 1e-8 and abs(b) <= 1e-8:
        return None
    return math.atan2(b, a)


def _steering_angles(positions, frames, plane_name):
    headings = {}
    last_heading = None
    base_heading = None
    for index, frame in enumerate(frames):
        if index == 0 and len(frames) > 1:
            delta = _project_vector(positions[frames[1]] - positions[frame], plane_name)
        elif index > 0:
            delta = _project_vector(positions[frame] - positions[frames[index - 1]], plane_name)
        else:
            delta = Vector((0.0, 0.0, 0.0))
        heading = _heading_angle(delta, plane_name)
        if heading is None:
            heading = last_heading if last_heading is not None else 0.0
        if base_heading is None and delta.length > 1e-8:
            base_heading = heading
        headings[int(frame)] = heading
        last_heading = heading
    if base_heading is None:
        base_heading = 0.0
    return {int(frame): _normalize_angle(heading - base_heading) for frame, heading in headings.items()}


def _write_vector_curve_samples(action, datablock, data_path, group_name, samples, interpolation='LINEAR', handle_type='AUTO_CLAMPED'):
    written = 0
    for axis_index in range(3):
        fcurve = ensure_action_fcurve(action, datablock, data_path, index=axis_index, group_name=group_name)
        if fcurve is None:
            continue
        _clear_fcurve_keys(fcurve)
        for frame, vector_value in sorted(samples.items()):
            try:
                fcurve.keyframe_points.insert(float(frame), float(vector_value[axis_index]), options={'FAST'})
            except Exception:
                try:
                    fcurve.keyframe_points.insert(float(frame), float(vector_value[axis_index]))
                except Exception:
                    continue
        _finalize_fcurve(fcurve, interpolation=interpolation, handle_type=handle_type)
        written += 1
    return written



def _mesh_targets(context):
    objects = list(getattr(context, 'selected_objects', []) or [])
    active = active_object(context)
    if active is not None and active not in objects:
        objects.append(active)
    return [obj for obj in _unique_objects(objects) if getattr(obj, 'type', '') == 'MESH']



def _find_modifier(obj, name_prefix):
    for modifier in getattr(obj, 'modifiers', []) or []:
        if getattr(modifier, 'name', '').startswith(name_prefix):
            return modifier
    return None



def _remove_modifier(obj, modifier):
    if obj is None or modifier is None:
        return False
    try:
        obj.modifiers.remove(modifier)
        return True
    except Exception:
        return False



def _remove_data_path_curves(action, datablock, data_path_prefix):
    removed = 0
    for fcurve in list(iter_action_fcurves(action, datablock=datablock)):
        if not getattr(fcurve, 'data_path', '').startswith(data_path_prefix):
            continue
        if remove_action_fcurve(action, fcurve, datablock=datablock):
            removed += 1
    return removed



def _roll_origin_name(obj):
    return f"{DEFORM_REVEAL_PREFIX}_Origin_{getattr(obj, 'name', 'Object')}"



def _clear_deformer_reveal_for_object(scene, obj):
    removed_modifiers = 0
    removed_curves = 0
    removed_helpers = 0
    action = getattr(getattr(obj, 'animation_data', None), 'action', None)
    for modifier in list(getattr(obj, 'modifiers', []) or []):
        if getattr(modifier, 'name', '').startswith(DEFORM_REVEAL_PREFIX):
            if action is not None:
                removed_curves += _remove_data_path_curves(action, obj, f'modifiers["{modifier.name}"]')
            if _remove_modifier(obj, modifier):
                removed_modifiers += 1
    origin_name = None
    try:
        origin_name = obj.get('sas_deform_reveal_origin')
    except Exception:
        origin_name = None
    if origin_name:
        helper = bpy.data.objects.get(origin_name)
        if helper is not None:
            try:
                bpy.data.objects.remove(helper, do_unlink=True)
                removed_helpers += 1
            except Exception:
                pass
    _clear_idprop(obj, 'sas_deform_reveal_origin')
    _clear_idprop(obj, 'sas_deform_reveal_mode')
    _clear_idprop(obj, 'sas_deform_reveal_active')
    return removed_modifiers, removed_curves, removed_helpers



def _ensure_roll_origin(scene, obj, axis_name):
    name = _roll_origin_name(obj)
    helper = bpy.data.objects.get(name)
    if helper is None:
        helper = bpy.data.objects.new(name, None)
        try:
            helper.empty_display_type = 'PLAIN_AXES'
        except Exception:
            pass
        try:
            helper.empty_display_size = max(0.05, max(float(value) for value in getattr(obj, 'dimensions', (1.0, 1.0, 1.0))) * 0.25)
        except Exception:
            pass
        linked = False
        for collection in getattr(obj, 'users_collection', []) or []:
            try:
                collection.objects.link(helper)
                linked = True
                break
            except Exception:
                continue
        if not linked:
            try:
                scene.collection.objects.link(helper)
            except Exception:
                pass
    try:
        location = obj.matrix_world.translation.copy()
    except Exception:
        location = Vector(getattr(obj, 'location', (0.0, 0.0, 0.0)))
    axis_index = _axis_index(axis_name)
    try:
        extent = float(getattr(obj, 'dimensions', (1.0, 1.0, 1.0))[axis_index]) * 0.5
    except Exception:
        extent = 0.5
    try:
        location[axis_index] -= extent
    except Exception:
        pass
    try:
        helper.location = location
    except Exception:
        pass
    try:
        helper['sas_deform_reveal_helper'] = True
    except Exception:
        pass
    return helper



def _key_modifier_value(obj, modifier_name, property_name, frame, value):
    modifier = _find_modifier(obj, modifier_name)
    if modifier is None:
        return False
    try:
        setattr(modifier, property_name, value)
    except Exception:
        return False
    data_path = f'modifiers["{modifier.name}"].{property_name}'
    try:
        obj.keyframe_insert(data_path=data_path, frame=float(frame))
        return True
    except Exception:
        return False


class SAS_OT_apply_motion_stretch(Operator):
    bl_idname = "sas.apply_motion_stretch"
    bl_label = "Apply Motion Stretch"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Sample the selected objects through the bake range and generate editable motion-stretch keys on delta scale. This gives you a Blender-friendly superset of smear and motion-stretch helpers while safely skipping objects that already use non-SAS delta-scale animation.",
            "選択オブジェクトをベイク範囲でサンプリングし、delta scale に編集可能なモーションストレッチキーを生成します。スミアや Motion Stretch 系の実用的な Blender 向け上位補助で、既に非 SAS の delta scale アニメーションを使っているオブジェクトは安全のため自動的にスキップします。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        depsgraph = None
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None

        source_objects = list(getattr(context, "selected_objects", []) or [])
        if not source_objects and active_object(context) is not None:
            source_objects = [active_object(context)]
        targets = _unique_objects(source_objects)
        if not targets:
            self.report({'WARNING'}, sas_text("No objects were selected for motion stretch.", "モーションストレッチ対象のオブジェクトが選択されていません。", context))
            add_log(context, "WARN", "Motion Stretch cancelled because no objects were selected.", "対象オブジェクトが選択されていないため Motion Stretch を中止しました。")
            return {'CANCELLED'}

        start, end = get_bake_range(scene, settings)
        frames = _frame_list(start, end, settings.frame_step)
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text("The bake range is too short for motion stretch.", "モーションストレッチにはベイク範囲が短すぎます。", context))
            add_log(context, "WARN", "Motion Stretch cancelled because the bake range was too short.", "ベイク範囲が短すぎるため Motion Stretch を中止しました。")
            return {'CANCELLED'}

        axis_index = _axis_index(settings.motion_stretch_axis)
        current_frame = int(scene.frame_current)
        processed = 0
        skipped_foreign = 0
        skipped_existing = 0
        failed = 0
        total_written = 0

        try:
            for obj in targets:
                action = getattr(getattr(obj, "animation_data", None), "action", None)
                if action is not None and _has_foreign_curves(action, obj, "delta_scale", MOTION_STRETCH_GROUP):
                    skipped_foreign += 1
                    continue

                existing_sas = bool(action and _sas_group_curves(action, obj, "delta_scale", MOTION_STRETCH_GROUP))
                if existing_sas and not settings.motion_stretch_replace_existing:
                    skipped_existing += 1
                    continue

                base_scale = Vector(getattr(obj, "delta_scale", (1.0, 1.0, 1.0)))
                positions = _object_sample_positions(scene, depsgraph, obj, frames)
                samples = _motion_stretch_values(
                    base_scale,
                    positions,
                    frames,
                    axis_index=axis_index,
                    plane=settings.motion_stretch_plane,
                    strength=settings.motion_stretch_strength,
                    squash=settings.motion_stretch_squash,
                    max_factor=settings.motion_stretch_max,
                )

                if settings.preview_only:
                    processed += 1
                    total_written += len(samples) * 3
                    continue

                if action is not None:
                    ensure_action_backup(context, "motion_stretch", obj=obj, action=action)
                action = get_or_create_action_for_object(obj, base_name=f"{obj.name}_MotionStretch")
                if existing_sas and settings.motion_stretch_replace_existing:
                    _remove_group_fcurves(action, obj, "delta_scale", MOTION_STRETCH_GROUP)

                written = _write_vector_curve_samples(
                    action,
                    obj,
                    "delta_scale",
                    MOTION_STRETCH_GROUP,
                    samples,
                    interpolation='LINEAR',
                    handle_type='AUTO_CLAMPED',
                )
                if written < 3:
                    failed += 1
                    continue

                try:
                    obj.delta_scale = base_scale
                except Exception:
                    pass
                _set_vector_idprop(obj, "sas_motion_stretch_base", base_scale)
                obj["sas_motion_stretch_active"] = True
                processed += 1
                total_written += len(samples) * written
        finally:
            scene.frame_set(current_frame)

        if settings.preview_only:
            message_en = f"Motion Stretch Preview — {processed} objects, {len(frames)} sampled frames, {total_written} keyed values, {skipped_foreign} objects skipped for foreign delta-scale curves, {skipped_existing} skipped because Replace Older SAS Stretch is off."
            message_ja = f"Motion Stretch プレビュー — {processed} 個のオブジェクト、{len(frames)} フレームをサンプリング、{total_written} 個のキー値対象、非 SAS の delta scale カーブがある {skipped_foreign} 個を安全のため除外、既存 SAS ストレッチがあり置換オフの {skipped_existing} 個をスキップしました。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        if processed == 0:
            self.report({'WARNING'}, sas_text("No objects were updated. Check the selection and safety filters.", "更新されたオブジェクトはありませんでした。選択状態と安全フィルターを確認してください。", context))
            add_log(context, "WARN", f"Motion Stretch updated no objects. Foreign skips: {skipped_foreign}, existing SAS skips: {skipped_existing}, failures: {failed}.", f"Motion Stretch は更新対象がありませんでした。非 SAS スキップ {skipped_foreign}、既存 SAS スキップ {skipped_existing}、失敗 {failed}。")
            return {'CANCELLED'}

        message_en = f"Applied Motion Stretch to {processed} objects across frames {start}-{end}. Skipped {skipped_foreign} foreign delta-scale objects, {skipped_existing} existing SAS objects, and {failed} write failures."
        message_ja = f"フレーム {start}-{end} で {processed} 個のオブジェクトへ Motion Stretch を適用しました。非 SAS の delta scale がある {skipped_foreign} 個、既存 SAS ストレッチがある {skipped_existing} 個をスキップし、書き込み失敗は {failed} 件でした。"
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_clear_motion_stretch(Operator):
    bl_idname = "sas.clear_motion_stretch"
    bl_label = "Clear Motion Stretch"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation motion-stretch curves from the selected objects and restore each stored delta-scale base value. Only SAS-generated delta-scale keys are cleared, so unrelated animation stays untouched.",
            "選択オブジェクトから Smart Animation のモーションストレッチカーブを削除し、保存していた delta scale の基準値を復元します。削除するのは SAS が生成した delta scale キーだけなので、無関係なアニメーションはそのまま残ります。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        targets = list(getattr(context, "selected_objects", []) or [])
        if not targets and active_object(context) is not None:
            targets = [active_object(context)]
        targets = _unique_objects(targets)
        removed_curves = 0
        restored = 0

        for obj in targets:
            action = getattr(getattr(obj, "animation_data", None), "action", None)
            if action is not None:
                removed_curves += _remove_group_fcurves(action, obj, "delta_scale", MOTION_STRETCH_GROUP)
            if "sas_motion_stretch_base" in obj:
                try:
                    obj.delta_scale = _get_vector_idprop(obj, "sas_motion_stretch_base", getattr(obj, "delta_scale", (1.0, 1.0, 1.0)))
                    restored += 1
                except Exception:
                    pass
            _clear_idprop(obj, "sas_motion_stretch_base")
            _clear_idprop(obj, "sas_motion_stretch_active")

        self.report({'INFO'}, sas_text(f"Cleared Motion Stretch from {restored} objects and removed {removed_curves} SAS curves.", f"{restored} 個のオブジェクトから Motion Stretch を解除し、{removed_curves} 本の SAS カーブを削除しました。", context))
        add_log(context, "INFO", f"Cleared Motion Stretch from {restored} objects and removed {removed_curves} curves.", f"{restored} 個のオブジェクトから Motion Stretch を解除し、{removed_curves} 本のカーブを削除しました。")
        return {'FINISHED'}


class SAS_OT_bake_vehicle_wheel_rotation(Operator):
    bl_idname = "sas.bake_vehicle_wheel_rotation"
    bl_label = "Bake Vehicle Wheel Rotation"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Use the active object as the vehicle motion source and bake wheel spin onto the other selected objects. Optional steering can also be baked from the travel path, giving you a safer Blender-friendly superset of compact Drive-style wheel helpers while skipping objects that already use non-SAS delta-rotation curves.",
            "アクティブオブジェクトを車体の移動ソースとして使い、他の選択オブジェクトへ車輪回転をベイクします。必要なら移動経路からステアリングも追加でき、Drive 系の車輪補助を Blender で安全寄りに再構成した上位補助になります。非 SAS の delta rotation カーブを持つオブジェクトは安全のため自動的にスキップします。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        source = active_object(context)
        if source is None:
            self.report({'WARNING'}, sas_text("Select an active vehicle or root object first.", "先に車体またはルートになるアクティブオブジェクトを選択してください。", context))
            add_log(context, "WARN", "Vehicle Wheel Rotation cancelled because there is no active source object.", "アクティブなソースオブジェクトがないため Vehicle Wheel Rotation を中止しました。")
            return {'CANCELLED'}

        wheel_objects = [obj for obj in list(getattr(context, "selected_objects", []) or []) if obj != source]
        wheel_objects = _unique_objects(wheel_objects)
        if not wheel_objects:
            self.report({'WARNING'}, sas_text("Select one active source object and at least one wheel object.", "アクティブなソース 1 つと、少なくとも 1 つの車輪オブジェクトを選択してください。", context))
            add_log(context, "WARN", "Vehicle Wheel Rotation cancelled because no wheel objects were selected.", "車輪オブジェクトが選択されていないため Vehicle Wheel Rotation を中止しました。")
            return {'CANCELLED'}

        start, end = get_bake_range(scene, settings)
        frames = _frame_list(start, end, settings.frame_step)
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text("The bake range is too short for vehicle wheel rotation.", "車輪回転ベイクにはベイク範囲が短すぎます。", context))
            add_log(context, "WARN", "Vehicle Wheel Rotation cancelled because the bake range was too short.", "ベイク範囲が短すぎるため Vehicle Wheel Rotation を中止しました。")
            return {'CANCELLED'}

        depsgraph = None
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None

        axis_index = _axis_index(settings.vehicle_wheel_axis)
        steering_enabled = bool(getattr(settings, 'vehicle_enable_steering', False))
        steering_axis_index = _axis_index(getattr(settings, 'vehicle_steering_axis', 'Z'))
        steering_same_axis = steering_enabled and steering_axis_index == axis_index
        if steering_same_axis:
            steering_enabled = False
        steering_sign = -1.0 if bool(getattr(settings, 'vehicle_steering_reverse', False)) else 1.0
        steering_max = max(0.0, float(getattr(settings, 'vehicle_steering_max', 0.785398)))
        current_frame = int(scene.frame_current)
        processed = 0
        skipped_foreign = 0
        skipped_existing = 0
        failed = 0
        total_distance = 0.0

        try:
            positions = _object_sample_positions(scene, depsgraph, source, frames)
            cumulative = _cumulative_distances(positions, frames, settings.vehicle_motion_plane)
            steering_values = _steering_angles(positions, frames, settings.vehicle_motion_plane) if steering_enabled else {}
            total_distance = max(cumulative.values()) if cumulative else 0.0

            for wheel in wheel_objects:
                action = getattr(getattr(wheel, "animation_data", None), "action", None)
                if action is not None and _has_foreign_curves(action, wheel, "delta_rotation_euler", VEHICLE_DRIVE_GROUP):
                    skipped_foreign += 1
                    continue

                existing_sas = bool(action and _sas_group_curves(action, wheel, "delta_rotation_euler", VEHICLE_DRIVE_GROUP))
                if existing_sas and not settings.vehicle_replace_existing:
                    skipped_existing += 1
                    continue

                radius = _auto_radius(wheel, axis_index) if settings.vehicle_radius_mode == 'AUTO' else max(1e-4, float(settings.vehicle_wheel_radius))
                sign = 1.0 if settings.vehicle_spin_direction == 'FORWARD' else -1.0
                if settings.vehicle_auto_side_flip:
                    sign *= _wheel_side_sign(wheel)
                base_rotation = Vector(getattr(wheel, "delta_rotation_euler", (0.0, 0.0, 0.0)))
                samples = {}
                for frame in frames:
                    angle = (float(cumulative.get(int(frame), 0.0)) / radius) * sign
                    sample = Vector(base_rotation)
                    sample[axis_index] = base_rotation[axis_index] + angle
                    if steering_enabled:
                        steer_angle = max(-steering_max, min(steering_max, float(steering_values.get(int(frame), 0.0)) * steering_sign))
                        sample[steering_axis_index] = base_rotation[steering_axis_index] + steer_angle
                    samples[int(frame)] = sample

                if settings.preview_only:
                    processed += 1
                    continue

                if action is not None:
                    ensure_action_backup(context, "vehicle_drive", obj=wheel, action=action)
                action = get_or_create_action_for_object(wheel, base_name=f"{wheel.name}_VehicleDrive")
                if existing_sas and settings.vehicle_replace_existing:
                    _remove_group_fcurves(action, wheel, "delta_rotation_euler", VEHICLE_DRIVE_GROUP)

                written = _write_vector_curve_samples(
                    action,
                    wheel,
                    "delta_rotation_euler",
                    VEHICLE_DRIVE_GROUP,
                    samples,
                    interpolation='LINEAR',
                    handle_type='VECTOR',
                )
                if written < 3:
                    failed += 1
                    continue

                try:
                    wheel.delta_rotation_euler = base_rotation
                except Exception:
                    pass
                _set_vector_idprop(wheel, "sas_vehicle_drive_base", base_rotation)
                wheel["sas_vehicle_drive_active"] = True
                wheel["sas_vehicle_drive_radius"] = float(radius)
                processed += 1
        finally:
            scene.frame_set(current_frame)

        if settings.preview_only:
            message_en = f"Vehicle Wheel Rotation Preview — source '{source.name}', {len(wheel_objects)} wheel objects, {len(frames)} sampled frames, travel distance {total_distance:.3f}, steering {'on' if steering_enabled else 'off'}, {skipped_foreign} foreign delta-rotation skips, {skipped_existing} existing SAS skips."
            message_ja = f"Vehicle Wheel Rotation プレビュー — ソース「{source.name}」、車輪 {len(wheel_objects)} 個、{len(frames)} フレームをサンプリング、移動距離 {total_distance:.3f}、ステアリング {'有効' if steering_enabled else '無効'}、非 SAS の delta rotation がある {skipped_foreign} 個を除外、既存 SAS があり置換オフの {skipped_existing} 個をスキップしました。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            if steering_same_axis:
                warning_en = "Vehicle steering was disabled because Steering Axis matched Wheel Axis. Choose different axes to bake both safely."
                warning_ja = "Steering Axis と Wheel Axis が同じだったため、Vehicle steering は無効化されました。安全に両方を焼くには別の軸を選んでください。"
                self.report({'WARNING'}, sas_text(warning_en, warning_ja, context))
                add_log(context, 'WARN', warning_en, warning_ja)
            return {'FINISHED'}

        if processed == 0:
            self.report({'WARNING'}, sas_text("No wheel objects were updated. Check the selection and safety filters.", "更新された車輪オブジェクトはありませんでした。選択状態と安全フィルターを確認してください。", context))
            add_log(context, "WARN", f"Vehicle Wheel Rotation updated no wheel objects. Foreign skips: {skipped_foreign}, existing SAS skips: {skipped_existing}, failures: {failed}.", f"Vehicle Wheel Rotation は更新対象がありませんでした。非 SAS スキップ {skipped_foreign}、既存 SAS スキップ {skipped_existing}、失敗 {failed}。")
            return {'CANCELLED'}

        message_en = f"Baked Vehicle Wheel Rotation from '{source.name}' onto {processed} wheel objects over frames {start}-{end}. Travel distance {total_distance:.3f}, steering {'on' if steering_enabled else 'off'}, foreign skips {skipped_foreign}, existing SAS skips {skipped_existing}, failures {failed}."
        message_ja = f"フレーム {start}-{end} でソース「{source.name}」の移動から {processed} 個の車輪オブジェクトへ Vehicle Wheel Rotation をベイクしました。移動距離 {total_distance:.3f}、ステアリング {'有効' if steering_enabled else '無効'}、非 SAS スキップ {skipped_foreign}、既存 SAS スキップ {skipped_existing}、失敗 {failed}。"
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        if steering_same_axis:
            warning_en = "Vehicle steering was disabled because Steering Axis matched Wheel Axis. Choose different axes to bake both safely."
            warning_ja = "Steering Axis と Wheel Axis が同じだったため、Vehicle steering は無効化されました。安全に両方を焼くには別の軸を選んでください。"
            self.report({'WARNING'}, sas_text(warning_en, warning_ja, context))
            add_log(context, 'WARN', warning_en, warning_ja)
        return {'FINISHED'}


class SAS_OT_clear_vehicle_wheel_rotation(Operator):
    bl_idname = "sas.clear_vehicle_wheel_rotation"
    bl_label = "Clear Vehicle Wheel Rotation"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation wheel-drive curves from the selected objects and restore each stored delta-rotation base value. Only SAS-generated wheel-drive keys are cleared, so unrelated rotation animation stays untouched.",
            "選択オブジェクトから Smart Animation の車輪駆動カーブを削除し、保存していた delta rotation の基準値を復元します。削除するのは SAS が生成した車輪駆動キーだけなので、無関係な回転アニメーションはそのまま残ります。",
            context,
        )

    def execute(self, context):
        targets = list(getattr(context, "selected_objects", []) or [])
        if not targets and active_object(context) is not None:
            targets = [active_object(context)]
        targets = _unique_objects(targets)
        removed_curves = 0
        restored = 0

        for obj in targets:
            action = getattr(getattr(obj, "animation_data", None), "action", None)
            if action is not None:
                removed_curves += _remove_group_fcurves(action, obj, "delta_rotation_euler", VEHICLE_DRIVE_GROUP)
            if "sas_vehicle_drive_base" in obj:
                try:
                    obj.delta_rotation_euler = _get_vector_idprop(obj, "sas_vehicle_drive_base", getattr(obj, "delta_rotation_euler", (0.0, 0.0, 0.0)))
                    restored += 1
                except Exception:
                    pass
            _clear_idprop(obj, "sas_vehicle_drive_base")
            _clear_idprop(obj, "sas_vehicle_drive_radius")
            _clear_idprop(obj, "sas_vehicle_drive_active")

        self.report({'INFO'}, sas_text(f"Cleared Vehicle Wheel Rotation from {restored} objects and removed {removed_curves} SAS curves.", f"{restored} 個のオブジェクトから Vehicle Wheel Rotation を解除し、{removed_curves} 本の SAS カーブを削除しました。", context))
        add_log(context, "INFO", f"Cleared Vehicle Wheel Rotation from {restored} objects and removed {removed_curves} curves.", f"{restored} 個のオブジェクトから Vehicle Wheel Rotation を解除し、{removed_curves} 本のカーブを削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_deformer_reveal(Operator):
    bl_idname = "sas.apply_deformer_reveal"
    bl_label = "Apply Deformer Reveal"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a modifier-based reveal on the selected mesh objects. Build mode gives a compact Transform-style reveal, Roll mode adds a scroll or rolled-sheet reveal using editable Bend keys, and Unfold mode adds a lighter bend-based opening pass for cards and panels.",
            "選択メッシュオブジェクトへモディファイアベースのリビールを作成します。Build モードは Transform 系のコンパクトなリビール、Roll モードは編集可能な Bend キーで巻物やロール状のリビール、Unfold モードはカードやパネル向けの軽量な折り開き風リビールを作ります。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        targets = _mesh_targets(context)
        if not targets:
            self.report({'WARNING'}, sas_text("Select one or more mesh objects first.", "先に 1 つ以上のメッシュオブジェクトを選択してください。", context))
            add_log(context, "WARN", "Deformer Reveal cancelled because no mesh objects were selected.", "メッシュオブジェクトが選択されていないため Deformer Reveal を中止しました。")
            return {'CANCELLED'}

        ordered = list(targets)
        if getattr(settings, 'transform_reveal_order', 'SELECTION') == 'NAME':
            ordered.sort(key=lambda obj: getattr(obj, 'name', '').lower())
        elif getattr(settings, 'transform_reveal_order', 'SELECTION') in {'X', 'Y', 'Z'}:
            axis = {'X': 0, 'Y': 1, 'Z': 2}[settings.transform_reveal_order]
            ordered.sort(key=lambda obj: float(getattr(obj, 'location', (0.0, 0.0, 0.0))[axis]))

        mode = getattr(settings, 'deform_reveal_mode', 'BUILD')
        stagger = max(0, int(getattr(settings, 'transform_reveal_stagger', 0)))
        duration = max(1, int(getattr(settings, 'transform_reveal_duration', 1)))
        replace_existing = bool(getattr(settings, 'deform_reveal_replace_existing', True))
        start_frame = int(scene.frame_current)
        processed = 0
        skipped_existing = 0
        removed_modifiers = 0
        removed_curves = 0
        removed_helpers = 0
        failed = 0

        if settings.preview_only:
            message_en = f"Deformer Reveal Preview — mode {mode}, {len(ordered)} mesh object(s), start {start_frame}, duration {duration}, stagger {stagger}."
            message_ja = f"Deformer Reveal プレビュー — モード {mode}、対象 {len(ordered)} 個、開始 {start_frame}、時間 {duration}、段差 {stagger}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        for index, obj in enumerate(ordered):
            existing = bool(getattr(obj, 'get', lambda _k, _d=None: _d)('sas_deform_reveal_active'))
            if existing and not replace_existing:
                skipped_existing += 1
                continue
            if existing and replace_existing:
                r_mod, r_curves, r_help = _clear_deformer_reveal_for_object(scene, obj)
                removed_modifiers += r_mod
                removed_curves += r_curves
                removed_helpers += r_help

            local_start = start_frame + index * stagger
            local_end = local_start + duration
            try:
                if mode == 'BUILD':
                    modifier = obj.modifiers.new(name=f"{DEFORM_REVEAL_PREFIX}_Build", type='BUILD')
                    modifier.frame_start = int(local_start)
                    modifier.frame_duration = int(duration)
                    try:
                        modifier.use_random_order = False
                    except Exception:
                        pass
                else:
                    action = getattr(getattr(obj, 'animation_data', None), 'action', None)
                    if action is not None:
                        ensure_action_backup(context, 'deformer_reveal', obj=obj, action=action)
                    get_or_create_action_for_object(obj, base_name=f"{obj.name}_Reveal")
                    origin = _ensure_roll_origin(scene, obj, getattr(settings, 'deform_reveal_axis', 'Y'))
                    modifier_label = 'Roll' if mode == 'ROLL' else 'Unfold'
                    modifier = obj.modifiers.new(name=f"{DEFORM_REVEAL_PREFIX}_{modifier_label}", type='SIMPLE_DEFORM')
                    modifier.deform_method = 'BEND'
                    modifier.deform_axis = getattr(settings, 'deform_reveal_axis', 'Y')
                    try:
                        modifier.origin = origin
                    except Exception:
                        pass
                    try:
                        modifier.limits[0] = 0.0
                        modifier.limits[1] = 1.0
                    except Exception:
                        pass
                    start_angle = float(getattr(settings, 'deform_reveal_angle', 6.283185))
                    if mode == 'UNFOLD':
                        start_angle = min(start_angle, math.pi)
                    _key_modifier_value(obj, modifier.name, 'angle', local_start, start_angle)
                    _key_modifier_value(obj, modifier.name, 'angle', local_end, 0.0)
                    action = getattr(getattr(obj, 'animation_data', None), 'action', None)
                    if action is not None:
                        for fcurve in iter_action_fcurves(action, datablock=obj):
                            if getattr(fcurve, 'data_path', '') == f'modifiers["{modifier.name}"].angle':
                                _finalize_fcurve(fcurve, interpolation='LINEAR', handle_type='VECTOR')
                    obj['sas_deform_reveal_origin'] = origin.name
                obj['sas_deform_reveal_active'] = True
                obj['sas_deform_reveal_mode'] = mode
                processed += 1
            except Exception:
                failed += 1
                continue

        if processed == 0:
            self.report({'WARNING'}, sas_text("No objects were updated. Check the selection and replace settings.", "更新されたオブジェクトはありませんでした。選択状態と置換設定を確認してください。", context))
            add_log(context, "WARN", f"Deformer Reveal updated no objects. Existing skips: {skipped_existing}, failures: {failed}.", f"Deformer Reveal は更新対象がありませんでした。既存スキップ {skipped_existing}、失敗 {failed}。")
            return {'CANCELLED'}

        message_en = f"Applied {mode.lower()} Deformer Reveal to {processed} object(s). Removed {removed_modifiers} older modifiers, {removed_curves} older curves, {removed_helpers} helper empties, skipped {skipped_existing}, failures {failed}."
        message_ja = f"{processed} 個のオブジェクトへ {mode} Deformer Reveal を適用しました。古いモディファイア削除 {removed_modifiers}、古いカーブ削除 {removed_curves}、補助 Empty 削除 {removed_helpers}、既存スキップ {skipped_existing}、失敗 {failed}。"
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_clear_deformer_reveal(Operator):
    bl_idname = "sas.clear_deformer_reveal"
    bl_label = "Clear Deformer Reveal"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation modifier-based reveal helpers from the selected mesh objects, including SAS Build or Roll modifiers and their helper empties.",
            "選択メッシュオブジェクトから Smart Animation のモディファイアベース・リビール補助を削除します。SAS Build / Roll モディファイアと補助 Empty をまとめて除去します。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        targets = _mesh_targets(context)
        if not targets:
            self.report({'WARNING'}, sas_text("Select one or more mesh objects first.", "先に 1 つ以上のメッシュオブジェクトを選択してください。", context))
            add_log(context, "WARN", "Clear Deformer Reveal cancelled because no mesh objects were selected.", "メッシュオブジェクトが選択されていないため Deformer Reveal 解除を中止しました。")
            return {'CANCELLED'}

        removed_modifiers = 0
        removed_curves = 0
        removed_helpers = 0
        for obj in targets:
            r_mod, r_curves, r_help = _clear_deformer_reveal_for_object(scene, obj)
            removed_modifiers += r_mod
            removed_curves += r_curves
            removed_helpers += r_help

        self.report({'INFO'}, sas_text(f"Cleared Deformer Reveal from {len(targets)} objects. Removed {removed_modifiers} modifiers, {removed_curves} curves, and {removed_helpers} helper empties.", f"{len(targets)} 個のオブジェクトから Deformer Reveal を解除しました。モディファイア {removed_modifiers}、カーブ {removed_curves}、補助 Empty {removed_helpers} を削除しました。", context))
        add_log(context, "INFO", f"Cleared Deformer Reveal from {len(targets)} objects. Removed {removed_modifiers} modifiers, {removed_curves} curves, and {removed_helpers} helpers.", f"{len(targets)} 個のオブジェクトから Deformer Reveal を解除しました。モディファイア {removed_modifiers}、カーブ {removed_curves}、補助 {removed_helpers} を削除しました。")
        return {'FINISHED'}


OPERATOR_MOTION_FX_CLASSES = (
    SAS_OT_apply_motion_stretch,
    SAS_OT_clear_motion_stretch,
    SAS_OT_bake_vehicle_wheel_rotation,
    SAS_OT_clear_vehicle_wheel_rotation,
    SAS_OT_apply_deformer_reveal,
    SAS_OT_clear_deformer_reveal,
)
