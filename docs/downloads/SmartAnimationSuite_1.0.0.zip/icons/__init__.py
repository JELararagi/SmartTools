# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from pathlib import Path

import bpy

from .icon_rename_map import ICON_RENAME_MAP

_ICON_PREVIEWS = None
_LOADED_ICON_KEYS: set[str] = set()

# Custom PNG icons are kept only where Blender has no standard icon that
# communicates the function clearly enough at toolbar size.
_ICON_FILES = {
    'stage': 'icons/sas_stage.png',
    'recipe': 'icons/sas_recipe.png',
    'precision': 'icons/sas_precision.png',
    'visual': 'icons/sas_visual.png',
    'motion': 'icons/sas_motion.png',
    'locomotion': 'icons/sas_locomotion.png',
    'super': 'icons/sas_super.png',
}

# Blender built-in icons preferred over custom images whenever they match the
# function. These names are used as the fallback path for helper UI functions.
_BUILTIN_ICON_NAMES = {
    'header': 'TEXT',
    'clock': 'TIME',
    'help': 'QUESTION',
    'play': 'PLAY',
    'report': 'TEXT',
    'quality': 'CHECKMARK',
    'graph': 'IPO_BEZIER',
    'physics': 'PHYSICS',
    'shape': 'SHAPEKEY_DATA',
    'ifl': 'IMAGE_DATA',
    'retarget': 'CONSTRAINT',
    'contact': 'SNAP_FACE',
    'timing': 'TIME',
    'coverage': 'TEXT',
}


def _icon_dir() -> Path:
    return Path(__file__).resolve().parent


def builtin_icon_name(key: str, fallback: str = 'NONE') -> str:
    value = _BUILTIN_ICON_NAMES.get(str(key or '').strip())
    return str(value or fallback or 'NONE')


def _normalize_source(source: str) -> str:
    value = str(source or '').strip().replace('\\', '/')
    if not value:
        return ''
    value = value.lstrip('./')
    if value in _ICON_FILES:
        return _ICON_FILES[value]
    if value.startswith('smart_animation_suite/'):
        value = value.split('/', 1)[1]
    if value.startswith('icon/assets/') or value.startswith('icon/easeit/') or value.startswith('icon/'):
        value = 'icons/' + Path(value).name
    if '/' not in value:
        if not value.lower().endswith('.png'):
            value += '.png'
        value = 'icons/' + value
    return value


def mapped_icon_source(source: str) -> str:
    original = _normalize_source(source)
    if not original:
        return ''
    return ICON_RENAME_MAP.get(original, original)


def asset_path_for_source(source: str, *, fallback: str = 'icons/blank.png') -> str:
    mapped = mapped_icon_source(source)
    if mapped:
        path = _icon_dir() / Path(mapped).name
        if path.exists():
            return str(path)
    fallback_mapped = mapped_icon_source(fallback) or fallback
    fallback_path = _icon_dir() / Path(fallback_mapped).name
    return str(fallback_path)


def _load_preview(key: str, source: str):
    previews = _ICON_PREVIEWS
    if previews is None:
        return None
    preview_key = str(key or '').strip()
    if not preview_key:
        return None
    try:
        item = previews.get(preview_key)
        if item:
            return item
    except Exception:
        pass
    path = Path(asset_path_for_source(source))
    if not path.exists():
        return None
    try:
        item = previews.load(preview_key, str(path), 'IMAGE')
        # previews.load only registers the file. Reading the size decodes the
        # image now, so the first draw does not show Blender's loading icon.
        tuple(item.icon_size)
        _LOADED_ICON_KEYS.add(preview_key)
        return item
    except KeyError:
        try:
            return previews.get(preview_key)
        except Exception:
            return None
    except Exception:
        return None


def register() -> None:
    global _ICON_PREVIEWS
    if _ICON_PREVIEWS is not None:
        return
    try:
        import bpy.utils.previews
        _ICON_PREVIEWS = bpy.utils.previews.new()
        _LOADED_ICON_KEYS.clear()
        # Blender 5.1 can redraw UI while mode-switch RNA and color-management
        # state are still settling. Keep custom PNG previews lazy so ordinary
        # N-panel redraws and volatile mode transitions use Blender built-in
        # icons only until a custom-icon section is actually expanded.
    except Exception:
        _ICON_PREVIEWS = None
        _LOADED_ICON_KEYS.clear()


def unregister() -> None:
    global _ICON_PREVIEWS
    if _ICON_PREVIEWS is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_ICON_PREVIEWS)
    except Exception:
        pass
    _ICON_PREVIEWS = None
    _LOADED_ICON_KEYS.clear()


def icon_value(key: str) -> int:
    previews = _ICON_PREVIEWS
    if previews is None:
        return 0
    preview_key = str(key or '').strip()
    if not preview_key or preview_key not in _ICON_FILES:
        return 0
    try:
        item = previews.get(preview_key)
    except Exception:
        item = None
    if item is None:
        source = _ICON_FILES.get(preview_key) or preview_key
        item = _load_preview(preview_key, source)
    try:
        return int(getattr(item, 'icon_id', 0) or 0) if item else 0
    except Exception:
        return 0


def _normal_button_kwargs(text: str, kwargs: dict) -> dict:
    values = dict(kwargs)
    if not str(text or ''):
        values.pop('emboss', None)
    return values


def draw_operator(layout, operator_id: str, *, text: str = '', icon_key: str = '', fallback_icon: str = 'NONE', **kwargs):
    kwargs = _normal_button_kwargs(text, kwargs)
    value = icon_value(icon_key)
    if value:
        return layout.operator(operator_id, text=text, icon='NONE', icon_value=value, **kwargs)
    return layout.operator(operator_id, text=text, icon=builtin_icon_name(icon_key, fallback_icon), **kwargs)


def draw_label(layout, *, text: str = '', icon_key: str = '', fallback_icon: str = 'NONE') -> None:
    value = icon_value(icon_key)
    if value:
        layout.label(text=text, icon='NONE', icon_value=value)
    else:
        layout.label(text=text, icon=builtin_icon_name(icon_key, fallback_icon))
