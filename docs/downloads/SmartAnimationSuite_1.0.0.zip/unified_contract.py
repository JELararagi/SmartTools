"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
EXTENSION_ID = "smart_animation_suite"
CONFIG_FOLDER = "Smart_Animation_Suite"
CONFIG_FILE = "Smart_Animation_Suite.json"
STATE_SAVE_PATH = "scene.sas_settings.npanel_state_auto_save"
SECTION_OPEN_PATH = "scene.sas_settings.show_always_on_toggle_group"
RUNTIME_TOGGLE_PATHS = (
    "scene.sas_settings.sas_always_on_animall_attribute_migration_load_handler",
    "scene.sas_settings.sas_always_on_transform_offset_transform_offset_hotkeys",
    "scene.sas_settings.sas_always_on_bezier_curve_editor_editor_header_callbacks",
    "scene.sas_settings.sas_always_on_sakura_poselib_pose_maintenance",
    "scene.sas_settings.sas_always_on_sakura_poselib_pose_library_hotkeys",
    "scene.sas_settings.sas_always_on_simplify_curves_plus_curve_menu_entries",
    "scene.sas_settings.sas_always_on_storytools_camera_exclusion_watch",
    "scene.sas_settings.sas_always_on_storytools_draw_tool_hotkeys",
    "scene.sas_settings.sas_always_on_storytools_grease_pencil_overlay_options",
    "scene.sas_settings.sas_always_on_storytools_layer_material_sync",
    "scene.sas_settings.sas_always_on_storytools_locked_view_pan_hotkeys",
    "scene.sas_settings.sas_always_on_storytools_main_toolbar_gizmo",
    "scene.sas_settings.sas_always_on_storytools_minimap_draw_handler",
    "scene.sas_settings.sas_always_on_storytools_minimap_toolbar_gizmo",
    "scene.sas_settings.sas_always_on_storytools_scale_figure_draw_handler",
    "scene.sas_settings.sas_always_on_storytools_viewport_storyboard_header",
    "scene.sas_settings.sas_always_on_storytools_tool_preset_gizmo_bar",
)
ROOT_PANEL_IDS = ("SAS_PT_main",)
PERSISTENCE_ROOTS = ("scene.sas_settings",)
# These N-panel settings are registered only after the named integrated tool
# is opened (or one of its always-on features is enabled). Runtime persistence
# subscribes to the new RNA immediately after loader registration.
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    # camera_shakify
    "window_manager.camera_shake_show_utils",
    # animall / storytools / bone offset
    "scene.animall_properties",
    "scene.storytools_settings",
    "scene.storytools_gp_settings",
    "scene.bone_offset_props",
    # bezier_curve_editor portable display/editor options
    "window_manager.tlfc_show_display_settings",
    "window_manager.tlfc_sidebar_width",
    "window_manager.tlfc_outer_pad",
    "window_manager.tlfc_samples",
    "window_manager.tlfc_show_info",
    "window_manager.tlfc_display_size",
    "window_manager.tlfc_h1x",
    "window_manager.tlfc_h1y",
    "window_manager.tlfc_h2x",
    "window_manager.tlfc_h2y",
    "window_manager.tlfc_sidebar_mode",
    "window_manager.tlfc_elastic_amplitude",
    "window_manager.tlfc_elastic_period",
    "window_manager.tlfc_grid_subdiv",
    "window_manager.tlfc_auto_apply",
    "window_manager.tlfc_snap_threshold",
    "window_manager.tlfc_view_zoom",
    "window_manager.tlfc_view_pan_x",
    "window_manager.tlfc_view_pan_y",
    # stop_motion_style_animator
    "scene.sm_*",
)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.sas_settings.bone_map",
    "scene.sas_settings.operation_log",
    "scene.sas_settings.name",
    "object.camera_shakes_active_index",
    "scene.animall_properties.name",
    "scene.bone_offset_props.name",
    "scene.storytools_settings.name",
    "scene.storytools_gp_settings.name",
)

# Native datablock, camera, material-slot, playback and tool settings shown in
# bundled N-panels are document state.  The .blend is authoritative; copying
# these values into the global Smart Animation JSON would overwrite unrelated
# scenes, objects, cameras, brushes or keying preferences on restore.
BLEND_OWNED_NPANEL_PATHS = (
    # Authored selections, poses and Action references belong to this Scene.
    # They are N-panel content, but copying them through a global profile would
    # corrupt unrelated projects; the .blend remains authoritative.
    "scene.sas_settings.selection_sets",
    "scene.sas_settings.selection_set_index",
    "scene.sas_settings.pose_snapshots",
    "scene.sas_settings.pose_snapshot_index",
    "scene.sas_settings.action_library",
    "scene.sas_settings.action_library_index",
    "object.camera_shakes",
    "object.sakura_poselib",
    "object.sakura_poselib.books",
    "object.sakura_poselib.active_book_index",
    "object.sakura_poselib.books[*].poses",
    "object.sakura_poselib.books[*].active_pose_index",
    "object.sakura_poselib.books[*].poses[*].bones",
    "object.sakura_poselib.books[*].poses[*].active_bone_index",
    "scene.st_camera_props",
    "scene.st_camera_props.index",
    "scene.gp_object_props",
    "scene.gp_object_props.index",
    "object.exclude_props.excluded_objects",
    "object.exclude_props.active_object_index",
    "object.exclude_props.excluded_collections",
    "object.exclude_props.active_collection_index",
    "object.active_shape_key.value",
    "object.show_only_shape_key",
    "object.material_slots",
    "object.active_material_index",
    "object.exclude_props",
    "scene.render.film_transparent",
    "scene.view_settings.view_transform",
    "scene.objects",
    "scene.camera.data.ortho_scale",
    "scene.camera.data.angle",
    "scene.camera.data.lens",
    "scene.camera.data.shift_x",
    "scene.camera.data.shift_y",
    "scene.camera.data.clip_start",
    "scene.camera.data.clip_end",
    "scene.camera.data.type",
    "scene.camera.exclude_props.excluded_objects",
    "scene.camera.exclude_props.active_object_index",
    "scene.camera.exclude_props.excluded_collections",
    "scene.camera.exclude_props.active_collection_index",
    "scene.tool_settings.gpencil_paint.color_mode",
    "scene.tool_settings.gpencil_paint.brush.color",
    "scene.tool_settings.use_keyframe_insert_auto",
    "scene.tool_settings.use_keyframe_insert_keyingset",
    "scene.use_preview_range",
    "scene.use_audio_scrub",
    "scene.sync_mode",
)
