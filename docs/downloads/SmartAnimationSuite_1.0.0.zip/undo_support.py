# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Explicit one-operation/one-undo policy for Smart Animation.

Only top-level operators that mutate Blender scene/animation data retain UNDO.
Settings, N-panel state, lazy module lifecycle, diagnostics, navigation, keymap,
configuration and external file I/O never add an undo step.  No manual
``bpy.ops.ed.undo_push`` call is used.
"""

from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

# Deliberately specific.  Generic object/data toggles are not matched because
# visibility, parenting and animation toggles can be legitimate data edits.
_NON_UNDO_ID_FRAGMENTS = (
    'show_help', 'open_help', 'show_popup', 'help_popup',
    'toggle_ui_section', 'toggle_section', 'toggle_editor_mode',
    'set_always_on', 'toggle_persistent_feature', 'save_preferences',
    'load_tool', 'unload_tool', 'refresh_tool', 'reload_tool',
    'save_settings', 'load_settings', 'write_config', 'read_config',
    'export_', 'import_', 'save_to_', 'load_from_', 'save_pose_to_',
    'load_pose_from_', 'prep_file_for_farm', 'open_preset_file',
    'save_preset', 'load_preset', 'browse_', 'pick_file', 'open_url',
    'copy_to_clipboard', 'copy_path', 'diagnostic', 'run_scene_audit',
    'status', 'refresh_status', 'preferences', 'keymap_item',
    'tool_preset_shortcut', 'set_storyboard_workspace', 'sidebar',
    'jump_marker', 'jump_camera_marker', 'apply_playback_preset',
)


def is_operator_class(cls: type) -> bool:
    try:
        return bpy is not None and isinstance(cls, type) and issubclass(cls, bpy.types.Operator)
    except Exception:
        return False


def _option_set(cls: type) -> set[str]:
    try:
        options = getattr(cls, 'bl_options', set())
        if options is None:
            return set()
        if isinstance(options, str):
            return {options}
        return set(options)
    except Exception:
        return set()


def operator_is_non_undo(cls: type) -> bool:
    if bool(getattr(cls, '_sms_no_undo', False) or getattr(cls, '_sas_no_undo', False)):
        return True
    if bool(getattr(cls, '_sas_data_operator', False)):
        return False
    idname = str(getattr(cls, 'bl_idname', '') or '').lower()
    return any(fragment in idname for fragment in _NON_UNDO_ID_FRAGMENTS)


def _invalidate_animation_cache(context=None) -> None:
    try:
        from . import ui
        ui.invalidate_performance_cache(reason='operator_finished', context=context)
    except Exception:
        pass


def _result_finished(value: Any) -> bool:
    try:
        return 'FINISHED' in {str(item) for item in value}
    except Exception:
        return False


def _wrap_explicit_execute(cls: type) -> None:
    """Invalidate only after an explicit successful operation.

    The wrapper is attached before class registration and is exact-class-local;
    no Blender API or already registered class is replaced.
    """
    if bool(vars(cls).get('_sas_cache_invalidation_wrapped', False)):
        return
    original = vars(cls).get('execute')
    if not callable(original):
        return

    def execute(self, context, _original=original):
        result = _original(self, context)
        if _result_finished(result):
            _invalidate_animation_cache(context)
        return result

    execute.__name__ = getattr(original, '__name__', 'execute')
    execute.__doc__ = getattr(original, '__doc__', None)
    setattr(cls, 'execute', execute)
    setattr(cls, '_sas_cache_invalidation_wrapped', True)
    setattr(cls, '_sas_original_execute', original)


def ensure_operator_undo(cls: type) -> type:
    """Apply the effective undo boundary to one exact pre-registration class."""
    if not is_operator_class(cls):
        return cls
    options = _option_set(cls)
    # ``REGISTER`` is what exposes Adjust Last Operation. Capture the original
    # REGISTER+UNDO coexistence before the established undo-boundary policy can
    # remove UNDO from non-data operators, then suppress only that Suite-owned
    # registration flag immediately before Blender sees the class.
    suppress_redo_panel = 'REGISTER' in options and 'UNDO' in options
    if operator_is_non_undo(cls):
        options.discard('UNDO')
        options.discard('UNDO_GROUPED')
    elif bool(getattr(cls, '_sas_data_operator', False)):
        options.discard('UNDO_GROUPED')
        options.add('UNDO')
    else:
        # Preserve an author's explicit top-level data boundary.  Grouped undo
        # would merge independent button presses, so normalize it to one UNDO.
        if 'UNDO_GROUPED' in options:
            options.discard('UNDO_GROUPED')
            options.add('UNDO')
    if suppress_redo_panel:
        options.discard('REGISTER')
    try:
        cls.bl_options = options
    except Exception:
        pass
    _wrap_explicit_execute(cls)
    return cls
