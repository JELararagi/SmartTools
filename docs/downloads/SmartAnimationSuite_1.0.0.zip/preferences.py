# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

# Add-on Preferences are intentionally not registered or exposed.
# Smart Animation keeps all user-facing controls in the 3D View N-panel
# and stores generated settings under Blender CONFIG/Smart_Animation_Suite.

classes = ()

def register() -> None:
    return None

def unregister() -> None:
    return None
