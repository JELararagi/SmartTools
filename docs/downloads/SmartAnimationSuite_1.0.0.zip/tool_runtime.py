# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Finite, explicit runtime for bundled Smart Animation tools."""

from __future__ import annotations

from . import feature_toggle, loader, runtime_persistence, ui_runtime

_REGISTERED = False
_LEDGER = None


def load_enabled_always_on_tools() -> tuple[str, ...]:
    """Synchronously restore only explicitly enabled background tools.

    This is called at registration/load-post/property-update boundaries.  It does
    not create a polling timer or worker and processes a finite alias snapshot.
    """
    loaded: list[str] = []
    failed: list[str] = []
    for alias in tuple(dict.fromkeys(loader.aliases_with_enabled_background_options())):
        if not alias:
            continue
        record = loader.load_tool(alias)
        if isinstance(record, dict) and str(record.get('status') or '') == 'READY':
            # File-load boundaries can clear msgbus subscriptions. Re-apply only
            # explicitly enabled options; each implementation is idempotent and
            # event-driven.
            loader.apply_background_defaults(alias)
            loaded.append(alias)
        else:
            failed.append(alias)
    if failed and _LEDGER is not None:
        try:
            _LEDGER.note_failure('enabled always-on tools degraded: ' + ', '.join(failed[:16]))
        except Exception:
            pass
    ui_runtime.rebuild_panels()
    return tuple(loaded)


def _schedule_enabled_always_on_tools() -> tuple[str, ...]:
    """Compatibility entry point: finite synchronous work, never a timer."""
    return load_enabled_always_on_tools()


def register(*, ledger=None) -> bool:
    """Register finite phases independently and never hard-raise to runtime."""
    global _REGISTERED, _LEDGER
    if _REGISTERED:
        return True
    _LEDGER = ledger
    healthy = True

    def phase(label, callback):
        nonlocal healthy
        try:
            result = callback()
            if result is False:
                healthy = False
                if ledger is not None:
                    ledger.note_failure(f'tool runtime phase returned False: {label}')
            return result
        except Exception as exc:
            healthy = False
            if ledger is not None:
                try:
                    ledger.note_failure(f'tool runtime phase failed {label}: {type(exc).__name__}: {exc}')
                except Exception:
                    pass
            return None

    phase('loader records', lambda: loader.initialize_records(force=False, ledger=ledger))
    phase('runtime persistence', runtime_persistence.register)
    phase(
        'feature toggle UI',
        lambda: feature_toggle.register_ui(
            suite_key='smart_animation_suite', suite_label='Smart Animation Suite',
            category='Smart Animation', ledger=ledger,
        ),
    )
    phase('integrated UI runtime', lambda: ui_runtime.register(ledger=ledger))
    phase('enabled always-on tools', load_enabled_always_on_tools)
    _REGISTERED = True
    return healthy


def unregister(*, ledger_owned: bool = False) -> bool:
    """Release every phase even when one remover fails."""
    global _REGISTERED, _LEDGER
    healthy = True
    for callback in (
        loader.unregister_all,
        lambda: feature_toggle.unregister_all(ledger_owned=ledger_owned),
        lambda: ui_runtime.unregister(ledger_owned=ledger_owned),
        runtime_persistence.unregister,
    ):
        try:
            result = callback()
            if result is False:
                healthy = False
        except Exception:
            healthy = False
    _LEDGER = None
    _REGISTERED = False
    return healthy

