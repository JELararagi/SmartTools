# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import bpy


# -----------------------------------------------------------------------------
# Blender 5.0 Action/Slot compatibility helpers
# -----------------------------------------------------------------------------
# Blender 5.0 removed Action.fcurves/groups/id_root in favor of slotted/layered
# actions. This module keeps the rest of the add-on readable by exposing a small
# compatibility surface for assigning actions, enumerating F-Curves, finding/
# creating/removing curves, and syncing NLA strip slots.
# -----------------------------------------------------------------------------


def supports_legacy_action_api(action):
    """Return True only when the action should be treated as a legacy F-Curve action.

    Blender 5.x can expose compatibility accessors even for empty or layered actions,
    so merely checking for ``action.fcurves`` is too permissive. Prefer the dedicated
    legacy / layered flags when they exist, and only fall back to the old heuristic as
    a last resort.
    """
    if not action:
        return False

    try:
        is_layered = getattr(action, "is_action_layered", None)
        is_legacy = getattr(action, "is_action_legacy", None)
        if isinstance(is_layered, bool) or isinstance(is_legacy, bool):
            if is_layered and not is_legacy:
                return False
            if is_legacy and not is_layered:
                return True
            if is_layered and is_legacy:
                # Empty actions may report both states. Prefer layered handling so the
                # add-on can create slots and keyframe strips explicitly on Blender 5.x.
                return False
    except Exception:
        pass

    try:
        if len(getattr(action, "slots", []) or []) > 0:
            return False
        if len(getattr(action, "layers", []) or []) > 0:
            return False
    except Exception:
        pass

    return bool(hasattr(action, "fcurves"))



def datablock_id_type(datablock, fallback='OBJECT'):
    value = getattr(datablock, "id_type", None)
    if isinstance(value, str) and value:
        return value
    return fallback



def ensure_datablock_animation_data(datablock):
    if datablock is None:
        return None
    anim_data = getattr(datablock, "animation_data", None)
    if anim_data is None and hasattr(datablock, "animation_data_create"):
        try:
            anim_data = datablock.animation_data_create()
        except Exception:
            anim_data = getattr(datablock, "animation_data", None)
    return anim_data



def _slot_label(slot):
    for attr in ("identifier", "name_display", "display_name", "name"):
        value = getattr(slot, attr, None)
        if isinstance(value, str) and value:
            return value
    try:
        return str(slot)
    except Exception:
        return ""



def _slot_type_matches(slot, id_type):
    if not id_type:
        return True
    for attr in ("target_id_type", "id_type", "target_id_type_identifier"):
        value = getattr(slot, attr, None)
        if isinstance(value, str) and value:
            return value == id_type
    # When the type is not exposed, stay permissive.
    return True



def _slot_name_score(slot, datablock=None, name_hint=None):
    label = _slot_label(slot).lower()
    names = []
    if name_hint:
        names.append(str(name_hint).lower())
    if datablock is not None:
        obj_name = getattr(datablock, "name", None)
        if obj_name:
            names.append(str(obj_name).lower())
    score = 0
    for name in names:
        if not name:
            continue
        if label == name:
            score = max(score, 100)
        elif label.endswith(name):
            score = max(score, 90)
        elif name in label:
            score = max(score, 60)
    return score



def find_best_action_slot(action, datablock=None, name_hint=None):
    if not action or not hasattr(action, "slots"):
        return None
    slots = list(action.slots)
    if not slots:
        return None

    anim_data = ensure_datablock_animation_data(datablock) if datablock is not None else None
    active_slot = getattr(anim_data, "action_slot", None) if anim_data is not None else None
    if active_slot is not None:
        try:
            if active_slot in action.slots:
                return active_slot
        except Exception:
            pass

    if len(slots) == 1:
        return slots[0]

    id_type = datablock_id_type(datablock, fallback=None)
    ranked = []
    for slot in slots:
        type_score = 50 if _slot_type_matches(slot, id_type) else 0
        name_score = _slot_name_score(slot, datablock=datablock, name_hint=name_hint)
        ranked.append((type_score + name_score, slot))
    ranked.sort(key=lambda item: item[0], reverse=True)
    if ranked and ranked[0][0] > 0:
        return ranked[0][1]
    return slots[0]



def ensure_action_slot(datablock, action, name_hint=None):
    if datablock is None or action is None or supports_legacy_action_api(action):
        return None

    anim_data = ensure_datablock_animation_data(datablock)
    if anim_data is None:
        return None

    try:
        if anim_data.action is not action:
            anim_data.action = action
    except Exception:
        pass

    slot = getattr(anim_data, "action_slot", None)
    if slot is not None:
        try:
            if slot in action.slots:
                return slot
        except Exception:
            return slot

    slot = find_best_action_slot(action, datablock=datablock, name_hint=name_hint)
    if slot is None:
        try:
            slot = action.slots.new(datablock_id_type(datablock), name_hint or getattr(datablock, "name", "Slot"))
        except Exception:
            slots = list(getattr(action, "slots", []) or [])
            slot = slots[0] if slots else None

    if slot is not None:
        try:
            anim_data.action_slot = slot
        except Exception:
            pass
    return slot



def assign_action_to_datablock(datablock, action, name_hint=None):
    anim_data = ensure_datablock_animation_data(datablock)
    if anim_data is None:
        return None
    anim_data.action = action
    if action is not None and not supports_legacy_action_api(action):
        ensure_action_slot(datablock, action, name_hint=name_hint)
    return action



def clear_action_from_datablock(datablock):
    anim_data = ensure_datablock_animation_data(datablock)
    if anim_data is None:
        return None
    anim_data.action = None
    try:
        anim_data.action_slot = None
    except Exception:
        pass
    return None



def _find_first_keyframe_strip(action):
    if not action or not hasattr(action, "layers"):
        return None
    for layer in action.layers:
        for strip in getattr(layer, "strips", []):
            if hasattr(strip, "channelbag"):
                return strip
    return None



def ensure_action_keyframe_strip(action):
    if action is None or supports_legacy_action_api(action):
        return None
    strip = _find_first_keyframe_strip(action)
    if strip is not None:
        return strip
    try:
        layer = action.layers.new("SAS")
    except Exception:
        layers = list(getattr(action, "layers", []) or [])
        layer = layers[0] if layers else None
    if layer is None:
        return None
    try:
        return layer.strips.new(type='KEYFRAME')
    except Exception:
        try:
            return layer.strips.new('KEYFRAME')
        except Exception:
            return _find_first_keyframe_strip(action)



def get_action_channelbag(action, datablock=None, ensure=False, name_hint=None):
    if action is None or supports_legacy_action_api(action):
        return None

    slot = find_best_action_slot(action, datablock=datablock, name_hint=name_hint)
    if slot is None and datablock is not None and ensure:
        slot = ensure_action_slot(datablock, action, name_hint=name_hint)
    if slot is None:
        slots = list(getattr(action, "slots", []) or [])
        if slots:
            slot = slots[0]
        elif ensure and datablock is not None:
            slot = ensure_action_slot(datablock, action, name_hint=name_hint)
    if slot is None:
        return None

    strip = ensure_action_keyframe_strip(action) if ensure else _find_first_keyframe_strip(action)
    if strip is None:
        return None

    try:
        return strip.channelbag(slot, ensure=ensure)
    except TypeError:
        try:
            return strip.channelbag(slot)
        except Exception:
            return None
    except Exception:
        return None



def _iter_channelbags(action):
    if action is None or supports_legacy_action_api(action) or not hasattr(action, "layers"):
        return []
    seen = set()
    bags = []
    slots = list(getattr(action, "slots", []) or [])
    for layer in action.layers:
        for strip in getattr(layer, "strips", []):
            if not hasattr(strip, "channelbag"):
                continue
            for slot in slots:
                try:
                    bag = strip.channelbag(slot)
                except TypeError:
                    try:
                        bag = strip.channelbag(slot, ensure=False)
                    except Exception:
                        bag = None
                except Exception:
                    bag = None
                if bag is None:
                    continue
                pointer = bag.as_pointer() if hasattr(bag, "as_pointer") else id(bag)
                if pointer in seen:
                    continue
                seen.add(pointer)
                bags.append(bag)
    return bags



def default_action_datablock(action, datablock=None):
    if datablock is not None:
        return datablock
    try:
        obj = bpy.context.active_object
    except Exception:
        obj = None
    if obj is not None:
        anim_data = getattr(obj, "animation_data", None)
        if anim_data is not None and getattr(anim_data, "action", None) == action:
            return obj
    return None



def iter_action_fcurves(action, datablock=None):
    if action is None:
        return []
    if supports_legacy_action_api(action):
        return list(action.fcurves)

    datablock = default_action_datablock(action, datablock=datablock)
    if datablock is not None:
        bag = get_action_channelbag(action, datablock=datablock, ensure=False)
        if bag is not None:
            return list(bag.fcurves)

    curves = []
    seen = set()
    for bag in _iter_channelbags(action):
        for fcurve in bag.fcurves:
            pointer = fcurve.as_pointer() if hasattr(fcurve, "as_pointer") else id(fcurve)
            if pointer in seen:
                continue
            seen.add(pointer)
            curves.append(fcurve)
    return curves



def action_curve_count(action, datablock=None):
    return len(iter_action_fcurves(action, datablock=datablock))



def find_action_fcurve(action, datablock, data_path, index=None):
    if action is None:
        return None
    if supports_legacy_action_api(action):
        try:
            if index is None:
                return action.fcurves.find(data_path)
            return action.fcurves.find(data_path, index=index)
        except Exception:
            for fcurve in action.fcurves:
                if fcurve.data_path == data_path and (index is None or fcurve.array_index == index):
                    return fcurve
            return None

    bag = get_action_channelbag(action, datablock=datablock, ensure=False)
    if bag is None:
        return None
    curves = bag.fcurves
    try:
        if index is None:
            return curves.find(data_path)
        return curves.find(data_path, index=index)
    except Exception:
        for fcurve in curves:
            if fcurve.data_path == data_path and (index is None or fcurve.array_index == index):
                return fcurve
        return None



def ensure_action_fcurve(action, datablock, data_path, index=0, group_name=""):
    if action is None:
        return None
    if supports_legacy_action_api(action):
        existing = find_action_fcurve(action, datablock, data_path, index=index)
        if existing is not None:
            return existing
        try:
            return action.fcurves.new(data_path, index=index, action_group=group_name or "")
        except Exception:
            try:
                return action.fcurves.new(data_path, index=index)
            except Exception:
                return None

    if datablock is not None and hasattr(action, "fcurve_ensure_for_datablock"):
        try:
            return action.fcurve_ensure_for_datablock(datablock, data_path, index=index, group_name=group_name or "")
        except TypeError:
            try:
                return action.fcurve_ensure_for_datablock(datablock, data_path, index)
            except Exception:
                pass
        except Exception:
            pass

    bag = get_action_channelbag(action, datablock=datablock, ensure=True)
    if bag is None:
        return None
    curves = bag.fcurves
    existing = find_action_fcurve(action, datablock, data_path, index=index)
    if existing is not None:
        return existing
    if hasattr(curves, "ensure"):
        try:
            return curves.ensure(data_path, index=index, group_name=group_name or "")
        except TypeError:
            try:
                return curves.ensure(data_path, index)
            except Exception:
                pass
        except Exception:
            pass
    if hasattr(curves, "new"):
        try:
            return curves.new(data_path, index=index, group_name=group_name or "")
        except TypeError:
            try:
                return curves.new(data_path, index=index)
            except Exception:
                pass
        except Exception:
            pass
    return None



def remove_action_fcurve(action, fcurve, datablock=None):
    if action is None or fcurve is None:
        return False
    if supports_legacy_action_api(action):
        try:
            action.fcurves.remove(fcurve)
            return True
        except Exception:
            return False

    datablock = default_action_datablock(action, datablock=datablock)
    checked = []
    bag = get_action_channelbag(action, datablock=datablock, ensure=False) if datablock is not None else None
    if bag is not None:
        checked.append(bag)
    checked.extend([b for b in _iter_channelbags(action) if b not in checked])
    for bag in checked:
        try:
            bag.fcurves.remove(fcurve)
            return True
        except Exception:
            continue
    return False



def sync_nla_strip_action_slot(strip, datablock, action=None):
    if strip is None or datablock is None:
        return None
    action = action or getattr(strip, "action", None)
    if action is None or supports_legacy_action_api(action):
        return None
    slot = find_best_action_slot(action, datablock=datablock)
    if slot is None:
        try:
            slot = action.slots.new(datablock_id_type(datablock), getattr(datablock, "name", "Slot"))
        except Exception:
            return None
    try:
        strip.action_slot = slot
    except Exception:
        pass
    return slot
