# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import math

import bpy
try:
    from bpy.types import Action, ActionSlot, Context
except Exception:
    # Defensive fallback for Blender builds where ActionSlot typing is not exposed
    # at import time. The runtime code still uses Blender's actual action/slot API
    # when it is available.
    Action = getattr(bpy.types, "Action", object)
    ActionSlot = getattr(bpy.types, "ActionSlot", object)
    Context = getattr(bpy.types, "Context", object)

from ..action_compat import iter_action_fcurves


def action_frame_range(action: Action):
    curves = list(iter_action_fcurves(action))
    if not curves:
        return (0.0, 0.0)

    frame_min = None
    frame_max = None
    for curve in curves:
        try:
            cr = curve.range()
        except Exception:
            points = getattr(curve, "keyframe_points", None) or ()
            if not points:
                continue
            xs = [point.co[0] for point in points]
            cr = (min(xs), max(xs))
        frame_min = cr[0] if frame_min is None else min(frame_min, cr[0])
        frame_max = cr[1] if frame_max is None else max(frame_max, cr[1])

    if frame_min is None or frame_max is None:
        return (0.0, 0.0)
    return (frame_min, frame_max)


def action_to_python_data_text(act: Action, text_block_name):
    channels = {}
    act_range = action_frame_range(act)
    for curve in iter_action_fcurves(act):
        baked_keys = []
        for frame in range(int(act_range[0]), int(act_range[1]) + 1):
            baked_keys += [(frame, curve.evaluate(frame))]
        channels[(curve.data_path, curve.array_index)] = baked_keys

    text = "{\n"
    for k in channels:
        text += "  {}: [".format(k)
        for point in channels[k]:
            text += "({}, {:.6f}), ".format(point[0], point[1])
        text += "],\n"
    text += "}\n"

    return bpy.data.texts.new(text_block_name).from_string(text)

# Ensure that an Action with the given name exists, and that it has a layer and
# a keyframe strip.
def ensure_action(action_name) -> Action:
    # Ensure the action exists.
    #
    # The song-and-dance here is to make sure we get a *local* action, not a
    # library-linked action.
    action = None
    for act in bpy.data.actions:
        if act.name == action_name and act.library == None:
            action = act
            break
    if action == None:
        action = bpy.data.actions.new(action_name)
        action.use_fake_user = False

    # Ensure there's at least one layer.
    if len(action.layers) > 0:
        layer = action.layers[0]
    else:
        layer = action.layers.new("Layer")

    # Ensure there's a keyframe strip.
    if len(layer.strips) > 0:
        assert(layer.strips[0].type == 'KEYFRAME')
    else:
        layer.strips.new(type='KEYFRAME')

    return action


# Ensures that a shake with the given name exists as a slot in the given action.
#
# If it doesn't exist, it will be created from the passed `data`.
#
# rot_factor and loc_factor are scaling factors for rotation and location
# values, respectively.
#
# Returns the slot in the action corresponding to the shake.
def ensure_shake_in_action(shake_name, action: Action, data, rot_factor=1.0, loc_factor=1.0) -> ActionSlot:
    slot_identifier = "OB" + shake_name

    # Ensure a slot for the shake exists.
    if slot_identifier in action.slots:
        slot = action.slots[slot_identifier]
    else:
        slot = action.slots.new('OBJECT', shake_name)
    assert(slot.identifier == slot_identifier)

    # If there's already a channelbag for the slot, we assume it's filled with
    # the correct shake animation.
    if action.layers[0].strips[0].channelbag(slot) != None:
        return slot

    # Create channelbag and fill it in with the shake data.
    channelbag = action.layers[0].strips[0].channelbags.new(slot)
    for k in data:
        curve = channelbag.fcurves.new(k[0], index=k[1])
        curve.keyframe_points.add(len(data[k]))
        for i in range(len(data[k])):
            co = [data[k][i][0], data[k][i][1]]
            if k[0].startswith("rotation"):
                co[1] *= rot_factor
            if k[0].startswith("location"):
                co[1] *= loc_factor

            curve.keyframe_points[i].co = co
            curve.keyframe_points[i].handle_left_type = 'AUTO'
            curve.keyframe_points[i].handle_right_type = 'AUTO'
        curve.keyframe_points[-1].co[1] = curve.keyframe_points[0].co[1] # Ensure looping.
        curve.modifiers.new('CYCLES')
        curve.update()

    return slot


def action_slot_frame_range(action: Action, slot: ActionSlot):
    channelbag = action.layers[0].strips[0].channelbag(slot)

    r = [9999999999, -9999999999]
    for curve in channelbag.fcurves:
        cr = curve.range()
        r[0] = min(r[0], cr[0])
        r[1] = max(r[1], cr[1])

    # Ensure integer values.
    r[0] = math.floor(r[0])
    r[1] = math.ceil(r[1])

    return r
