# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Compatibility facade for retired status instrumentation.

Smart Animation 1.5.33 uses :mod:`modal_registry` and :mod:`lifecycle` directly.
The old implementation replaced process-global Blender APIs and polled status at
short intervals; those mechanisms are intentionally absent.  Public symbols are
kept as bounded no-ops so saved scripts importing them do not fail.
"""

from __future__ import annotations

from contextlib import nullcontext
from typing import Any

from . import modal_registry


def instrument_operator_class(cls: type, owner: str = '', label: str = '') -> type:
    del owner, label
    return modal_registry.instrument_operator_class(cls)


def instrument_loaded_package_operators(*_args: Any, **_kwargs: Any) -> tuple[type, ...]:
    return ()


def capture_registration_callbacks(*_args: Any, **_kwargs: Any):
    return nullcontext()


def capture_runtime_resources(*_args: Any, **_kwargs: Any):
    return nullcontext()


def restore_package_handlers(*_args: Any, **_kwargs: Any) -> int:
    return 0


def clear_prefix(*_args: Any, **_kwargs: Any) -> None:
    return None


def set_service(*_args: Any, **_kwargs: Any) -> None:
    return None


def clear_service(*_args: Any, **_kwargs: Any) -> None:
    return None


def get_status(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {'active_modals': modal_registry.active_count(), 'idle_polling': False}


def register() -> None:
    return None


def unregister() -> None:
    return None
