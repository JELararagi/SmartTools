# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import bpy
from bpy.types import Operator

from .translation import sas_text
from .core import (
    active_action,
    active_object,
    add_log,
    assign_action_to_datablock,
    ensure_action_backup,
    filter_editable_fcurves,
    get_timing_range,
    iter_action_fcurves,
    selected_fcurves,
    unique_action_name,
)
from .algorithms import (
    frame_sequence,
    rebuild_curve_range_from_samples,
    simplify_sampled_curve_in_range,
    simulate_spring_values,
)



def _curve_signatures(curves):
    return {(getattr(fcurve, 'data_path', ''), int(getattr(fcurve, 'array_index', 0))) for fcurve in curves}



def _editable_action_curves(context, action, obj=None, signatures=None):
    obj = obj or active_object(context)
    settings = context.scene.sas_settings
    curves = selected_fcurves(context, action, obj=obj)
    if not curves:
        curves = filter_editable_fcurves(iter_action_fcurves(action, datablock=obj), settings)
    if signatures:
        curves = [curve for curve in curves if (getattr(curve, 'data_path', ''), int(getattr(curve, 'array_index', 0))) in signatures]
    return curves



class SAS_OT_bake_limited_animation(Operator):
    bl_idname = "sas.bake_limited_animation"
    bl_label = "Bake Limited Animation"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a safe duplicate of the active action and re-bake it on held steps such as twos or fours. This turns the stepped-preview idea into real editable keys while preserving the original action.",
            "アクティブアクションを安全に複製し、2コマ打ちや4コマ打ちのような保持ステップで実キーとして焼き直します。段階プレビューの見た目を、元アクションを残したまま編集可能な実キーへ変換します。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj)
        settings = context.scene.sas_settings
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to convert.", "変換するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Bake Limited Animation cancelled because there is no active action.", "アクティブアクションがないため Limited Animation Bake を中止しました。")
            return {'CANCELLED'}

        source_curves = _editable_action_curves(context, action, obj=obj)
        if not source_curves:
            self.report({'WARNING'}, sas_text("No editable F-Curves were found.", "編集可能な F カーブが見つかりません。", context))
            add_log(context, "WARN", "Bake Limited Animation found no editable F-Curves.", "編集可能な F カーブがないため Limited Animation Bake を中止しました。")
            return {'CANCELLED'}

        start, end = get_timing_range(context, action, settings)
        bake_step = max(1, int(settings.limited_bake_step))
        frames = frame_sequence(start, end, bake_step, include_end=True)
        if settings.preview_only:
            message_en = f"Limited Animation Preview — {len(source_curves)} curves, {len(frames)} held samples, frames {int(start)}-{int(end)}, step {bake_step}."
            message_ja = f"Limited Animation プレビュー — {len(source_curves)} 本のカーブ、{len(frames)} 個の保持サンプル、範囲 {int(start)}-{int(end)}、ステップ {bake_step}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        duplicate = action.copy()
        duplicate.name = unique_action_name(f"{action.name}_Hold{bake_step}")
        assign_action_to_datablock(obj, duplicate, name_hint=obj.name)

        signatures = _curve_signatures(source_curves)
        target_curves = _editable_action_curves(context, duplicate, obj=obj, signatures=signatures)
        if not target_curves:
            self.report({'ERROR'}, sas_text("The duplicated action could not expose matching curves.", "複製アクション上で一致するカーブを取得できませんでした。", context))
            add_log(context, "ERROR", "Bake Limited Animation failed because the duplicated action exposed no matching curves.", "複製アクション上で一致カーブが取得できず Limited Animation Bake に失敗しました。")
            return {'CANCELLED'}

        interpolation = settings.limited_interpolation
        handle_type = 'VECTOR' if interpolation in {'LINEAR', 'CONSTANT'} else 'AUTO_CLAMPED'
        rebuilt = 0
        key_total = 0
        for fcurve in target_curves:
            samples = {frame: float(fcurve.evaluate(frame)) for frame in frames}
            rebuild_curve_range_from_samples(
                fcurve,
                samples,
                interpolation=interpolation,
                handle_type=handle_type,
                start=start,
                end=end,
            )
            rebuilt += 1
            key_total += len(samples)

        self.report({'INFO'}, sas_text(f"Created limited-animation copy '{duplicate.name}' with {key_total} held keys across {rebuilt} curves.", f"{rebuilt} 本のカーブに {key_total} 個の保持キーを持つ Limited Animation 複製「{duplicate.name}」を作成しました。", context))
        add_log(context, "INFO", f"Created limited-animation duplicate '{duplicate.name}' from '{action.name}' using step {bake_step} across {rebuilt} curves.", f"アクション「{action.name}」からステップ {bake_step} の Limited Animation 複製「{duplicate.name}」を作成し、{rebuilt} 本のカーブを処理しました。")
        return {'FINISHED'}



class SAS_OT_bake_spring_dynamics(Operator):
    bl_idname = "sas.bake_spring_dynamics"
    bl_label = "Bake Spring Dynamics"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Bake a lightweight spring-follow pass onto the current curves. This is a practical superset of overlap, jiggle, drag, and soft follow-through helpers, writing the result back into editable keyframes.",
            "現在のカーブへ、軽量なスプリング追従パスをベイクします。オーバーラップ、ジグル、ドラッグ、やわらかいフォロースルーをまとめた実用的な上位補助で、結果は編集可能なキーフレームとして書き戻されます。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj)
        settings = context.scene.sas_settings
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to process.", "処理するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Bake Spring Dynamics cancelled because there is no active action.", "アクティブアクションがないため Spring Dynamics Bake を中止しました。")
            return {'CANCELLED'}

        curves = _editable_action_curves(context, action, obj=obj)
        if not curves:
            self.report({'WARNING'}, sas_text("No editable F-Curves were found.", "編集可能な F カーブが見つかりません。", context))
            add_log(context, "WARN", "Bake Spring Dynamics found no editable F-Curves.", "編集可能な F カーブがないため Spring Dynamics Bake を中止しました。")
            return {'CANCELLED'}

        start, end = get_timing_range(context, action, settings)
        sample_step = max(1, int(settings.spring_sample_step))
        frames = frame_sequence(start, end, sample_step, include_end=True)
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text("The timing range is too short for spring baking.", "スプリングベイクにはタイミング範囲が短すぎます。", context))
            add_log(context, "WARN", "Bake Spring Dynamics found a timing range that was too short.", "タイミング範囲が短すぎるため Spring Dynamics Bake を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            message_en = f"Spring Dynamics Preview — {len(curves)} curves, {len(frames)} samples, frames {int(start)}-{int(end)}, stiffness {settings.spring_stiffness:.3f}, damping {settings.spring_damping:.3f}."
            message_ja = f"Spring Dynamics プレビュー — {len(curves)} 本のカーブ、{len(frames)} 個のサンプル、範囲 {int(start)}-{int(end)}、剛性 {settings.spring_stiffness:.3f}、減衰 {settings.spring_damping:.3f}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "spring_dynamics", obj=obj, action=action)
        baked_curves = 0
        removed_keys = 0
        for fcurve in curves:
            original_values = [float(fcurve.evaluate(frame)) for frame in frames]
            baked_values = simulate_spring_values(
                original_values,
                stiffness=settings.spring_stiffness,
                damping=settings.spring_damping,
                blend=settings.spring_blend,
            )
            samples = {frame: value for frame, value in zip(frames, baked_values)}
            rebuild_curve_range_from_samples(
                fcurve,
                samples,
                interpolation='BEZIER',
                handle_type='AUTO_CLAMPED',
                start=start,
                end=end,
            )
            if settings.spring_auto_simplify:
                removed_keys += simplify_sampled_curve_in_range(
                    fcurve,
                    tolerance=settings.unbake_tolerance,
                    preserve_extrema=settings.unbake_preserve_extrema,
                    threshold=settings.remove_threshold,
                    start=start,
                    end=end,
                )
            baked_curves += 1

        self.report({'INFO'}, sas_text(f"Baked spring dynamics on {baked_curves} curves and simplified {removed_keys} keys.", f"{baked_curves} 本のカーブへスプリングダイナミクスをベイクし、{removed_keys} 個のキーを簡略化しました。", context))
        add_log(context, "INFO", f"Baked spring dynamics across {baked_curves} curves with stiffness {settings.spring_stiffness:.3f}, damping {settings.spring_damping:.3f}, blend {settings.spring_blend:.3f}; simplified {removed_keys} keys.", f"剛性 {settings.spring_stiffness:.3f}、減衰 {settings.spring_damping:.3f}、ブレンド {settings.spring_blend:.3f} で {baked_curves} 本のカーブへスプリングダイナミクスをベイクし、{removed_keys} 個のキーを簡略化しました。")
        return {'FINISHED'}


OPERATOR_PLUS_CLASSES = (
    SAS_OT_bake_limited_animation,
    SAS_OT_bake_spring_dynamics,
)
