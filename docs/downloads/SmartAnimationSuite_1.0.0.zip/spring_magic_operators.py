# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import math

import bpy
from bpy.types import Operator
from mathutils import Matrix, Quaternion, Vector
from mathutils.bvhtree import BVHTree

from .algorithms import frame_sequence
from .core import (
    add_log,
    ensure_action_backup,
    get_bake_range,
    get_or_create_action_for_object,
    iter_action_fcurves,
    safe_remove_keyframe_points,
)
from .translation import sas_text


_EPS = 1.0e-8


_AXIS_MAP = {
    'X_POS': Vector((1.0, 0.0, 0.0)),
    'X_NEG': Vector((-1.0, 0.0, 0.0)),
    'Y_POS': Vector((0.0, 1.0, 0.0)),
    'Y_NEG': Vector((0.0, -1.0, 0.0)),
    'Z_POS': Vector((0.0, 0.0, 1.0)),
    'Z_NEG': Vector((0.0, 0.0, -1.0)),
}


# -----------------------------------------------------------------------------
# Transform helpers
# -----------------------------------------------------------------------------


def _axis_vector(identifier):
    return _AXIS_MAP.get(identifier, Vector((0.0, 1.0, 0.0))).copy()



def _identity_quaternion():
    return Quaternion((1.0, 0.0, 0.0, 0.0))



def _quaternion_length_squared(quat):
    try:
        return float(quat.w) * float(quat.w) + float(quat.x) * float(quat.x) + float(quat.y) * float(quat.y) + float(quat.z) * float(quat.z)
    except Exception:
        return 0.0



def _normalize_quaternion(quat):
    quat = quat.copy()
    if _quaternion_length_squared(quat) <= (_EPS * _EPS):
        return _identity_quaternion()
    try:
        quat.normalize()
    except Exception:
        return _identity_quaternion()
    if _quaternion_length_squared(quat) <= (_EPS * _EPS):
        return _identity_quaternion()
    return quat



def _quat_from_axis_angle(angle, axis):
    axis = axis.copy()
    if axis.length_squared <= _EPS or abs(float(angle)) <= _EPS:
        return _identity_quaternion()
    axis.normalize()
    return Quaternion(axis, float(angle))



def _rotation_quaternion_from_owner(owner):
    mode = getattr(owner, 'rotation_mode', 'XYZ')
    try:
        if mode == 'QUATERNION':
            return _normalize_quaternion(owner.rotation_quaternion)
        if mode == 'AXIS_ANGLE':
            axis_angle = owner.rotation_axis_angle
            axis = Vector((float(axis_angle[1]), float(axis_angle[2]), float(axis_angle[3])))
            return _normalize_quaternion(_quat_from_axis_angle(float(axis_angle[0]), axis))
        return _normalize_quaternion(owner.rotation_euler.to_quaternion())
    except Exception:
        return _identity_quaternion()



def _pose_bone_local_quaternion(pose_bone):
    mode = getattr(pose_bone, 'rotation_mode', 'XYZ')
    try:
        if mode == 'QUATERNION':
            return _normalize_quaternion(pose_bone.rotation_quaternion)
        if mode == 'AXIS_ANGLE':
            axis_angle = pose_bone.rotation_axis_angle
            axis = Vector((float(axis_angle[1]), float(axis_angle[2]), float(axis_angle[3])))
            return _normalize_quaternion(_quat_from_axis_angle(float(axis_angle[0]), axis))
        return _normalize_quaternion(pose_bone.rotation_euler.to_quaternion())
    except Exception:
        return _identity_quaternion()



def _set_owner_rotation_from_quaternion(owner, quat):
    quat = _normalize_quaternion(quat)
    mode = getattr(owner, 'rotation_mode', 'XYZ')
    try:
        if mode == 'QUATERNION':
            owner.rotation_quaternion = quat
            return True
        if mode == 'AXIS_ANGLE':
            axis, angle = quat.to_axis_angle()
            owner.rotation_axis_angle[0] = float(angle)
            owner.rotation_axis_angle[1] = float(axis.x)
            owner.rotation_axis_angle[2] = float(axis.y)
            owner.rotation_axis_angle[3] = float(axis.z)
            return True
        owner.rotation_euler = quat.to_euler(mode)
        return True
    except Exception:
        try:
            owner.rotation_euler = quat.to_euler('XYZ')
            return True
        except Exception:
            return False



def _twist_angle_from_quaternion(quat, axis_local):
    quat = _normalize_quaternion(quat)
    axis_local = axis_local.copy()
    if axis_local.length_squared <= _EPS:
        return 0.0
    axis_local.normalize()
    vector_part = Vector((quat.x, quat.y, quat.z))
    projected = axis_local * vector_part.dot(axis_local)
    twist = Quaternion((quat.w, projected.x, projected.y, projected.z))
    if _quaternion_length_squared(twist) <= (_EPS * _EPS):
        return 0.0
    try:
        twist.normalize()
    except Exception:
        return 0.0
    try:
        twist_axis, twist_angle = twist.to_axis_angle()
    except Exception:
        return 0.0
    if twist_axis.dot(axis_local) < 0.0:
        twist_angle *= -1.0
    if twist_angle > math.pi:
        twist_angle -= 2.0 * math.pi
    return float(twist_angle)



def _absolute_axis_index(axis_identifier):
    if str(axis_identifier).startswith('X'):
        return 0
    if str(axis_identifier).startswith('Y'):
        return 1
    return 2



def _length_from_object(obj, axis_local):
    axis_local = axis_local.copy()
    if axis_local.length_squared <= _EPS:
        return 1.0
    axis_local.normalize()
    child = None
    try:
        children = list(getattr(obj, 'children', []) or [])
        if children:
            child = children[0]
    except Exception:
        child = None
    if child is not None:
        try:
            delta = child.matrix_world.translation - obj.matrix_world.translation
            if delta.length > _EPS:
                return float(delta.length)
        except Exception:
            pass
    try:
        bbox = [Vector(corner) for corner in obj.bound_box]
        projections = [corner.dot(axis_local) for corner in bbox]
        extent = max(projections) - min(projections)
        if extent > _EPS:
            return float(extent)
    except Exception:
        pass
    dims = getattr(obj, 'dimensions', None)
    if dims is not None:
        try:
            values = [abs(float(dims[0])), abs(float(dims[1])), abs(float(dims[2]))]
            candidate = max(values)
            if candidate > _EPS:
                return float(candidate)
        except Exception:
            pass
    return 1.0



def _matrix_from_translation_rotation_scale(translation, rotation_quat, scale_vec):
    return Matrix.LocRotScale(Vector(translation), _normalize_quaternion(rotation_quat), Vector(scale_vec))



def _curve_indices_in_range(fcurve, start_frame, end_frame):
    indices = []
    for index, key in enumerate(getattr(fcurve, 'keyframe_points', []) or []):
        try:
            frame = float(key.co.x)
        except Exception:
            continue
        if float(start_frame) <= frame <= float(end_frame):
            indices.append(index)
    return indices



def _clear_action_paths_in_range(action, owner_obj, data_paths, start_frame, end_frame):
    if action is None or not data_paths:
        return 0
    removed = 0
    wanted = set(data_paths)
    for fcurve in iter_action_fcurves(action, datablock=owner_obj):
        if getattr(fcurve, 'data_path', '') not in wanted:
            continue
        removed += safe_remove_keyframe_points(fcurve, _curve_indices_in_range(fcurve, start_frame, end_frame))
    return removed


# -----------------------------------------------------------------------------
# Target discovery and sampling
# -----------------------------------------------------------------------------


def _gather_pose_targets(context, axis_identifier):
    armature = getattr(context, 'active_object', None)
    selected = list(getattr(context, 'selected_pose_bones', None) or [])
    if armature is None or getattr(armature, 'type', '') != 'ARMATURE' or not selected:
        return []
    selected_names = {bone.name for bone in selected}
    order = []

    def _visit(bone):
        if bone.name in {entry['target_name'] for entry in order}:
            return
        order.append({
            'id': f'POSE::{armature.name}::{bone.name}',
            'kind': 'POSE',
            'owner_obj': armature,
            'target_name': bone.name,
            'target_ref': bone,
            'parent_id': f'POSE::{armature.name}::{bone.parent.name}' if getattr(bone, 'parent', None) and bone.parent.name in selected_names else None,
            'connected_to_parent': bool(getattr(getattr(bone, 'bone', None), 'use_connect', False)),
            'aim_local': _axis_vector(axis_identifier),
            'length': max(_EPS, float((bone.tail - bone.head).length)),
            'rotation_mode': getattr(bone, 'rotation_mode', 'XYZ'),
            'local_location': Vector(getattr(bone, 'location', Vector((0.0, 0.0, 0.0)))),
            'root': getattr(bone, 'parent', None) is None or bone.parent.name not in selected_names,
        })
        children = sorted(
            [child for child in (getattr(bone, 'children', None) or []) if child.name in selected_names],
            key=lambda item: item.name.lower(),
        )
        for child in children:
            _visit(child)

    roots = sorted([bone for bone in selected if getattr(bone, 'parent', None) is None or bone.parent.name not in selected_names], key=lambda item: item.name.lower())
    for root in roots:
        _visit(root)
    return order



def _gather_object_targets(context, axis_identifier):
    selected = list(getattr(context, 'selected_objects', None) or [])
    if not selected:
        return []
    selected_names = {obj.name for obj in selected}
    order = []
    visited = set()

    def _visit(obj):
        if obj.name in visited:
            return
        visited.add(obj.name)
        order.append({
            'id': f'OBJECT::{obj.name}',
            'kind': 'OBJECT',
            'owner_obj': obj,
            'target_name': obj.name,
            'target_ref': obj,
            'parent_id': f'OBJECT::{obj.parent.name}' if getattr(obj, 'parent', None) and obj.parent.name in selected_names else None,
            'connected_to_parent': bool(getattr(obj, 'parent', None) and obj.parent.name in selected_names),
            'aim_local': _axis_vector(axis_identifier),
            'length': max(_EPS, float(_length_from_object(obj, _axis_vector(axis_identifier)))),
            'rotation_mode': getattr(obj, 'rotation_mode', 'XYZ'),
            'local_location': Vector(getattr(obj, 'location', Vector((0.0, 0.0, 0.0)))),
            'root': getattr(obj, 'parent', None) is None or obj.parent.name not in selected_names,
        })
        children = sorted([child for child in (getattr(obj, 'children', None) or []) if child.name in selected_names], key=lambda item: item.name.lower())
        for child in children:
            _visit(child)

    roots = sorted([obj for obj in selected if getattr(obj, 'parent', None) is None or obj.parent.name not in selected_names], key=lambda item: item.name.lower())
    for root in roots:
        _visit(root)
    return order



def _collect_targets(context, settings):
    if getattr(context, 'mode', '') == 'POSE':
        targets = _gather_pose_targets(context, settings.spring_magic_axis)
    else:
        targets = _gather_object_targets(context, settings.spring_magic_axis)
    by_id = {item['id']: item for item in targets}
    root_count = sum(1 for item in targets if item.get('root'))
    return targets, by_id, root_count



def _sample_target_state(target):
    owner = target['owner_obj']
    if target['kind'] == 'POSE':
        pose_bone = owner.pose.bones.get(target['target_name']) if getattr(owner, 'pose', None) else None
        if pose_bone is None:
            return None
        world_matrix = owner.matrix_world @ pose_bone.matrix.copy()
        world_rot = _normalize_quaternion(world_matrix.to_quaternion())
        head_world = owner.matrix_world @ pose_bone.head
        tail_world = owner.matrix_world @ pose_bone.tail
        local_scale = Vector(getattr(pose_bone, 'scale', Vector((1.0, 1.0, 1.0))))
        local_rotation = _pose_bone_local_quaternion(pose_bone)
        return {
            'world_matrix': world_matrix,
            'world_rotation': world_rot,
            'head_world': head_world,
            'tail_world': tail_world,
            'local_rotation': local_rotation,
            'local_scale': local_scale,
            'local_location': Vector(getattr(pose_bone, 'location', Vector((0.0, 0.0, 0.0)))),
            'parent_world_matrix': (owner.matrix_world @ pose_bone.parent.matrix.copy()) if getattr(pose_bone, 'parent', None) else None,
        }

    obj = target['target_ref']
    world_matrix = obj.matrix_world.copy()
    world_rot = _normalize_quaternion(world_matrix.to_quaternion())
    aim = world_rot @ target['aim_local']
    if aim.length_squared <= _EPS:
        aim = Vector((0.0, 1.0, 0.0))
    aim.normalize()
    head_world = world_matrix.translation.copy()
    tail_world = head_world + aim * float(target['length'])
    return {
        'world_matrix': world_matrix,
        'world_rotation': world_rot,
        'head_world': head_world,
        'tail_world': tail_world,
        'local_rotation': _rotation_quaternion_from_owner(obj),
        'local_scale': Vector(getattr(obj, 'scale', Vector((1.0, 1.0, 1.0)))),
        'local_location': Vector(getattr(obj, 'location', Vector((0.0, 0.0, 0.0)))),
        'parent_world_matrix': obj.parent.matrix_world.copy() if getattr(obj, 'parent', None) else None,
    }



def _collider_objects_from_settings(settings, target_ids, owner_names=None):
    owner_names = set(owner_names or [])
    target_names = set(owner_names)
    for identifier in target_ids:
        if identifier.startswith('OBJECT::'):
            target_names.add(identifier.split('::', 1)[1])

    colliders = []
    seen = set()

    def _add(obj):
        if obj is None:
            return
        name = getattr(obj, 'name', '')
        if not name or name in seen or name in target_names:
            return
        seen.add(name)
        colliders.append(obj)

    if settings.spring_magic_collision_mode in {'COLLECTION', 'BOTH'}:
        collection = getattr(settings, 'spring_magic_collision_collection', None)
        if collection is not None:
            for obj in getattr(collection, 'all_objects', []) or []:
                _add(obj)

    if bool(getattr(settings, 'spring_magic_collision_object_enabled', False)):
        _add(getattr(settings, 'spring_magic_collision_object', None))

    return colliders



def _bvh_from_object(obj, depsgraph):
    try:
        return BVHTree.FromObject(obj, depsgraph, epsilon=0.0)
    except Exception:
        pass
    eval_obj = None
    temp_mesh = None
    try:
        eval_obj = obj.evaluated_get(depsgraph)
        temp_mesh = eval_obj.to_mesh()
        verts = [vertex.co.copy() for vertex in temp_mesh.vertices]
        polygons = [tuple(poly.vertices) for poly in temp_mesh.polygons]
        if verts and polygons:
            return BVHTree.FromPolygons(verts, polygons, all_triangles=False)
    except Exception:
        return None
    finally:
        if eval_obj is not None and temp_mesh is not None:
            try:
                eval_obj.to_mesh_clear()
            except Exception:
                pass
    return None



def _build_collision_state_from_object(obj, depsgraph):
    try:
        matrix_world = obj.matrix_world.copy()
        matrix_inverse = matrix_world.inverted_safe()
    except Exception:
        return None

    bvh = _bvh_from_object(obj, depsgraph)
    if bvh is not None:
        return {
            'name': obj.name,
            'kind': 'BVH',
            'bvh': bvh,
            'matrix_world': matrix_world,
            'matrix_inverse': matrix_inverse,
        }

    try:
        bbox = [Vector(corner) for corner in obj.bound_box]
        if bbox:
            local_min = Vector((min(point.x for point in bbox), min(point.y for point in bbox), min(point.z for point in bbox)))
            local_max = Vector((max(point.x for point in bbox), max(point.y for point in bbox), max(point.z for point in bbox)))
            if (local_max - local_min).length_squared > _EPS:
                return {
                    'name': obj.name,
                    'kind': 'BOX',
                    'matrix_world': matrix_world,
                    'matrix_inverse': matrix_inverse,
                    'local_min': local_min,
                    'local_max': local_max,
                }
    except Exception:
        pass

    radius = 0.0
    dims = getattr(obj, 'dimensions', None)
    if dims is not None:
        try:
            radius = max(radius, 0.5 * max(abs(float(dims[0])), abs(float(dims[1])), abs(float(dims[2]))))
        except Exception:
            pass
    display_size = getattr(obj, 'empty_display_size', None)
    if display_size is not None:
        try:
            radius = max(radius, abs(float(display_size)))
        except Exception:
            pass
    if radius > _EPS:
        return {
            'name': obj.name,
            'kind': 'SPHERE',
            'center': matrix_world.translation.copy(),
            'radius': float(radius),
        }
    return None



def _sample_collider_state(collider_objects, depsgraph):
    states = []
    for obj in collider_objects:
        state = _build_collision_state_from_object(obj, depsgraph)
        if state is not None:
            states.append(state)
    return states



def _sample_all_targets(context, targets, frames, settings):
    scene = context.scene
    original_frame = int(scene.frame_current)
    depsgraph = context.evaluated_depsgraph_get()
    samples_by_frame = {}
    colliders_by_frame = {}
    collider_objects = _collider_objects_from_settings(settings, [target['id'] for target in targets], owner_names={target['owner_obj'].name for target in targets if target.get('owner_obj') is not None})
    try:
        for frame in frames:
            scene.frame_set(int(round(frame)))
            try:
                context.view_layer.update()
            except Exception:
                pass
            frame_samples = {}
            for target in targets:
                frame_samples[target['id']] = _sample_target_state(target)
            samples_by_frame[float(frame)] = frame_samples
            if collider_objects:
                colliders_by_frame[float(frame)] = _sample_collider_state(collider_objects, depsgraph)
    finally:
        scene.frame_set(original_frame)
        try:
            context.view_layer.update()
        except Exception:
            pass
    return samples_by_frame, colliders_by_frame


# -----------------------------------------------------------------------------
# Collision helpers
# -----------------------------------------------------------------------------


def _apply_floor_collision(point, settings):
    if settings.spring_magic_collision_mode not in {'FLOOR', 'BOTH'}:
        return point, False, None
    corrected = point.copy()
    floor_height = float(settings.spring_magic_floor_height)
    limit = floor_height + max(0.0, float(settings.spring_magic_collision_radius)) + max(0.0, float(settings.spring_magic_collision_margin))
    if corrected.z < limit:
        corrected.z = limit
        return corrected, True, Vector((0.0, 0.0, 1.0))
    return corrected, False, None



def _apply_bvh_collision(point, collider, radius):
    corrected = point.copy()
    try:
        local_point = collider['matrix_inverse'] @ corrected
        nearest = collider['bvh'].find_nearest(local_point)
    except Exception:
        return corrected, False, None
    if not nearest:
        return corrected, False, None
    nearest_point, normal, _face_index, distance = nearest
    if nearest_point is None or normal is None:
        return corrected, False, None
    try:
        distance = float(distance)
    except Exception:
        return corrected, False, None
    if distance > radius:
        return corrected, False, None
    push_normal = Vector(normal)
    if push_normal.length_squared <= _EPS:
        push_normal = local_point - Vector(nearest_point)
    if push_normal.length_squared <= _EPS:
        return corrected, False, None
    push_normal.normalize()
    local_corrected = Vector(nearest_point) + push_normal * radius
    try:
        corrected = collider['matrix_world'] @ local_corrected
        world_normal = collider['matrix_world'].to_3x3() @ push_normal
    except Exception:
        return point.copy(), False, None
    if world_normal.length_squared > _EPS:
        world_normal.normalize()
    return corrected, True, world_normal



def _apply_box_collision(point, collider, radius):
    corrected = point.copy()
    try:
        local_point = collider['matrix_inverse'] @ corrected
    except Exception:
        return corrected, False, None

    local_min = collider['local_min']
    local_max = collider['local_max']
    closest = Vector((
        min(max(local_point.x, local_min.x), local_max.x),
        min(max(local_point.y, local_min.y), local_max.y),
        min(max(local_point.z, local_min.z), local_max.z),
    ))
    inside = (
        local_min.x <= local_point.x <= local_max.x and
        local_min.y <= local_point.y <= local_max.y and
        local_min.z <= local_point.z <= local_max.z
    )

    if inside:
        distances = [
            (abs(local_point.x - local_min.x), Vector((-1.0, 0.0, 0.0)), local_min.x),
            (abs(local_max.x - local_point.x), Vector((1.0, 0.0, 0.0)), local_max.x),
            (abs(local_point.y - local_min.y), Vector((0.0, -1.0, 0.0)), local_min.y),
            (abs(local_max.y - local_point.y), Vector((0.0, 1.0, 0.0)), local_max.y),
            (abs(local_point.z - local_min.z), Vector((0.0, 0.0, -1.0)), local_min.z),
            (abs(local_max.z - local_point.z), Vector((0.0, 0.0, 1.0)), local_max.z),
        ]
        _distance_to_face, local_normal, face_value = min(distances, key=lambda item: item[0])
        local_corrected = local_point.copy()
        axis_index = 0 if abs(local_normal.x) > 0.5 else (1 if abs(local_normal.y) > 0.5 else 2)
        local_corrected[axis_index] = face_value + float(local_normal[axis_index]) * radius
    else:
        delta = local_point - closest
        distance = delta.length
        if distance > radius:
            return corrected, False, None
        if distance <= _EPS:
            local_normal = Vector((0.0, 0.0, 1.0))
        else:
            local_normal = delta / distance
        local_corrected = closest + local_normal * radius

    try:
        corrected = collider['matrix_world'] @ local_corrected
        world_normal = collider['matrix_world'].to_3x3() @ local_normal
    except Exception:
        return point.copy(), False, None
    if world_normal.length_squared > _EPS:
        world_normal.normalize()
    return corrected, True, world_normal



def _apply_sphere_collision(point, collider, radius):
    corrected = point.copy()
    center = Vector(collider['center'])
    total_radius = max(_EPS, float(collider['radius']) + float(radius))
    offset = corrected - center
    distance = offset.length
    if distance >= total_radius:
        return corrected, False, None
    if distance <= _EPS:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal = offset / distance
    corrected = center + normal * total_radius
    return corrected, True, normal



def _apply_surface_collisions(point, collider_states, settings):
    corrected = point.copy()
    radius = max(0.0, float(settings.spring_magic_collision_radius)) + max(0.0, float(settings.spring_magic_collision_margin))
    if radius <= _EPS:
        return corrected, 0, None
    hits = 0
    last_normal = None
    for collider in collider_states or []:
        kind = collider.get('kind')
        if kind == 'BVH':
            corrected, hit, normal = _apply_bvh_collision(corrected, collider, radius)
        elif kind == 'BOX':
            corrected, hit, normal = _apply_box_collision(corrected, collider, radius)
        elif kind == 'SPHERE':
            corrected, hit, normal = _apply_sphere_collision(corrected, collider, radius)
        else:
            hit = False
            normal = None
        if hit:
            hits += 1
            last_normal = normal
    return corrected, hits, last_normal



def _push_velocity_out_of_surface(velocity, normal):
    if velocity is None:
        return None
    velocity = Vector(velocity)
    normal = Vector(normal) if normal is not None else None
    if normal is None or normal.length_squared <= _EPS:
        return velocity
    normal.normalize()
    inward_speed = velocity.dot(normal)
    if inward_speed < 0.0:
        velocity = velocity - normal * inward_speed
        velocity *= 0.8
    return velocity



def _solve_collisions(point, velocity, collider_states, settings, iterations):
    corrected = point.copy()
    velocity_out = Vector(velocity) if velocity is not None else None
    total_hits = 0
    for _pass in range(max(1, int(iterations))):
        pass_hits = 0
        corrected, floor_hit, floor_normal = _apply_floor_collision(corrected, settings)
        if floor_hit:
            total_hits += 1
            pass_hits += 1
            velocity_out = _push_velocity_out_of_surface(velocity_out, floor_normal)
        corrected, mesh_hits, mesh_normal = _apply_surface_collisions(corrected, collider_states, settings)
        if mesh_hits:
            total_hits += int(mesh_hits)
            pass_hits += int(mesh_hits)
            velocity_out = _push_velocity_out_of_surface(velocity_out, mesh_normal)
        if pass_hits == 0:
            break
    return corrected, total_hits, velocity_out


# -----------------------------------------------------------------------------
# Simulation helpers
# -----------------------------------------------------------------------------


def _simulate_scalar_step(state_value, state_velocity, target_value, stiffness, damping):
    velocity = (float(state_velocity) + (float(target_value) - float(state_value)) * float(stiffness)) * float(damping)
    value = float(state_value) + velocity
    return value, velocity



def _simulate_scalar_step_dt(state_value, state_velocity, target_value, stiffness, damping, delta_time):
    dt = max(_EPS, float(delta_time))
    damping = max(0.0, min(0.999999, float(damping)))
    damping_step = math.pow(damping, dt) if damping > 0.0 else 0.0
    velocity = (float(state_velocity) + (float(target_value) - float(state_value)) * float(stiffness) * dt) * damping_step
    value = float(state_value) + velocity * dt
    return value, velocity



def _safe_direction(vector, fallback):
    vector = Vector(vector)
    if vector.length_squared <= _EPS:
        fallback = Vector(fallback)
        if fallback.length_squared <= _EPS:
            return Vector((0.0, 1.0, 0.0))
        fallback.normalize()
        return fallback
    vector.normalize()
    return vector



def _float_lerp(start_value, end_value, factor):
    factor = float(factor)
    return float(start_value) + (float(end_value) - float(start_value)) * factor



def _scale_with_stretch(original_scale, axis_identifier, stretch_factor):
    scale = Vector(original_scale)
    stretch_factor = max(0.001, float(stretch_factor))
    axis_index = _absolute_axis_index(axis_identifier)
    squash_factor = 1.0 / math.sqrt(max(stretch_factor, _EPS))
    for index in range(3):
        base = float(scale[index])
        sign = -1.0 if base < 0.0 else 1.0
        magnitude = abs(base) if abs(base) > _EPS else 1.0
        if index == axis_index:
            scale[index] = sign * magnitude * stretch_factor
        else:
            scale[index] = sign * magnitude * squash_factor
    return scale



def _apply_clear_range_if_needed(context, settings, targets, start_frame, end_frame, include_scale):
    if not bool(getattr(settings, 'spring_magic_clear_range', True)):
        return 0
    owner_to_paths = {}
    for target in targets:
        owner = target['owner_obj']
        if target['kind'] == 'POSE':
            ref = owner.pose.bones.get(target['target_name']) if getattr(owner, 'pose', None) else None
            rotation_mode = getattr(ref, 'rotation_mode', 'XYZ') if ref is not None else target.get('rotation_mode', 'XYZ')
            prefix = f'pose.bones["{target["target_name"]}"].'
            if rotation_mode == 'QUATERNION':
                rotation_path = prefix + 'rotation_quaternion'
            elif rotation_mode == 'AXIS_ANGLE':
                rotation_path = prefix + 'rotation_axis_angle'
            else:
                rotation_path = prefix + 'rotation_euler'
            paths = [rotation_path]
            if include_scale:
                paths.append(prefix + 'scale')
        else:
            ref = target['target_ref']
            rotation_mode = getattr(ref, 'rotation_mode', 'XYZ') if ref is not None else target.get('rotation_mode', 'XYZ')
            if rotation_mode == 'QUATERNION':
                rotation_path = 'rotation_quaternion'
            elif rotation_mode == 'AXIS_ANGLE':
                rotation_path = 'rotation_axis_angle'
            else:
                rotation_path = 'rotation_euler'
            paths = [rotation_path]
            if include_scale:
                paths.append('scale')
        owner_to_paths.setdefault(owner, set()).update(paths)
    removed = 0
    for owner, paths in owner_to_paths.items():
        action = getattr(getattr(owner, 'animation_data', None), 'action', None)
        if action is None:
            continue
        removed += _clear_action_paths_in_range(action, owner, paths, start_frame, end_frame)
    if removed:
        add_log(context, 'INFO', f'Cleared {removed} existing Spring Magic keys in the bake range before writing new motion.', f'新しいモーションを書き込む前に、ベイク範囲内の既存 Spring Magic 対象キーを {removed} 個削除しました。')
    return removed



def _ensure_action_backups(context, targets):
    owners = []
    seen = set()
    for target in targets:
        owner = target['owner_obj']
        if owner is None or owner.name in seen:
            continue
        seen.add(owner.name)
        owners.append(owner)
    for owner in owners:
        action = getattr(getattr(owner, 'animation_data', None), 'action', None)
        if action is not None:
            ensure_action_backup(context, 'spring_magic', obj=owner, action=action)



def _key_target_frame(target, frame, include_scale=False):
    group_name = target['target_name']
    if target['kind'] == 'POSE':
        owner = target['owner_obj']
        pose_bone = owner.pose.bones.get(target['target_name']) if getattr(owner, 'pose', None) else None
        if pose_bone is None:
            return 0
        keyed = 0
        try:
            if getattr(pose_bone, 'rotation_mode', 'XYZ') == 'QUATERNION':
                pose_bone.keyframe_insert(data_path='rotation_quaternion', frame=frame, group=group_name)
            elif getattr(pose_bone, 'rotation_mode', 'XYZ') == 'AXIS_ANGLE':
                pose_bone.keyframe_insert(data_path='rotation_axis_angle', frame=frame, group=group_name)
            else:
                pose_bone.keyframe_insert(data_path='rotation_euler', frame=frame, group=group_name)
            keyed += 1
        except Exception:
            pass
        if include_scale:
            try:
                pose_bone.keyframe_insert(data_path='scale', frame=frame, group=group_name)
                keyed += 1
            except Exception:
                pass
        return keyed

    obj = target['target_ref']
    keyed = 0
    try:
        if getattr(obj, 'rotation_mode', 'XYZ') == 'QUATERNION':
            obj.keyframe_insert(data_path='rotation_quaternion', frame=frame, group=group_name)
        elif getattr(obj, 'rotation_mode', 'XYZ') == 'AXIS_ANGLE':
            obj.keyframe_insert(data_path='rotation_axis_angle', frame=frame, group=group_name)
        else:
            obj.keyframe_insert(data_path='rotation_euler', frame=frame, group=group_name)
        keyed += 1
    except Exception:
        pass
    if include_scale:
        try:
            obj.keyframe_insert(data_path='scale', frame=frame, group=group_name)
            keyed += 1
        except Exception:
            pass
    return keyed



def _apply_object_transform(target, local_rotation, local_scale, local_location=None):
    obj = target['target_ref']
    if local_location is not None:
        try:
            obj.location = Vector(local_location)
        except Exception:
            pass
    _set_owner_rotation_from_quaternion(obj, local_rotation)
    try:
        obj.scale = Vector(local_scale)
    except Exception:
        pass



def _apply_pose_transform(context, target, armature_space_matrix, local_scale):
    owner = target['owner_obj']
    pose_bone = owner.pose.bones.get(target['target_name']) if getattr(owner, 'pose', None) else None
    if pose_bone is None:
        return False
    try:
        pose_bone.matrix = armature_space_matrix
    except Exception:
        return False
    if local_scale is not None:
        try:
            pose_bone.scale = Vector(local_scale)
        except Exception:
            pass
    try:
        context.view_layer.update()
    except Exception:
        pass
    return True



def _run_spring_magic_bake(context, settings, targets, targets_by_id, frames, samples_by_frame, colliders_by_frame):
    stiffness = max(0.0, float(settings.spring_stiffness))
    damping = max(0.0, min(0.9999, float(settings.spring_damping)))
    blend = max(0.0, min(1.0, float(settings.spring_blend)))
    include_twist = settings.spring_magic_mode in {'SWING_TWIST', 'SWING_TWIST_SCALE'}
    include_scale = settings.spring_magic_mode == 'SWING_TWIST_SCALE'
    twist_strength = max(0.0, float(settings.spring_magic_twist_strength))
    scale_strength = max(0.0, float(settings.spring_magic_scale_strength))
    scale_max = max(1.0, float(settings.spring_magic_scale_max))
    substeps = max(1, int(getattr(settings, 'spring_magic_substeps', 1)))
    collision_iterations = max(1, int(getattr(settings, 'spring_magic_collision_iterations', 1)))

    states = {}
    first_frame_value = float(frames[0])
    for target in targets:
        first_sample = samples_by_frame[first_frame_value][target['id']]
        aim_world = first_sample['world_rotation'] @ target['aim_local']
        initial_direction = _safe_direction(aim_world, first_sample['tail_world'] - first_sample['head_world'])
        initial_twist = _twist_angle_from_quaternion(first_sample['local_rotation'], target['aim_local'])
        states[target['id']] = {
            'tail_world': first_sample['tail_world'].copy(),
            'velocity': Vector((0.0, 0.0, 0.0)),
            'twist': initial_twist,
            'twist_velocity': 0.0,
            'length': max(_EPS, float(target['length'])),
            'initial_direction': initial_direction,
            'prev_head_world': first_sample['head_world'].copy(),
            'prev_source_direction': initial_direction.copy(),
            'prev_source_twist': initial_twist,
        }

    keyed_count = 0
    collision_hits = 0
    scene = context.scene
    original_frame = int(scene.frame_current)
    previous_frame_value = first_frame_value
    try:
        for frame_index, frame in enumerate(frames):
            frame_value = float(frame)
            scene.frame_set(int(round(frame_value)))
            try:
                context.view_layer.update()
            except Exception:
                pass

            frame_samples = samples_by_frame[frame_value]
            frame_colliders = colliders_by_frame.get(frame_value, [])
            final_world_matrices = {}
            final_world_tails = {}
            frame_delta = max(_EPS, frame_value - previous_frame_value) if frame_index > 0 else 0.0
            substep_dt = frame_delta / float(substeps) if frame_index > 0 else 0.0

            for target in targets:
                sample = frame_samples.get(target['id'])
                if sample is None:
                    continue
                parent_id = target.get('parent_id')
                linked = bool(parent_id and parent_id in final_world_matrices)
                state = states[target['id']]
                chain_length = state['length']

                if target['kind'] == 'POSE':
                    if linked and target.get('connected_to_parent', False):
                        head_world = final_world_tails[parent_id].copy()
                    else:
                        head_world = sample['head_world'].copy()
                else:
                    if linked:
                        parent_world = final_world_matrices[parent_id]
                        local_head = Vector((float(sample['local_location'].x), float(sample['local_location'].y), float(sample['local_location'].z), 1.0))
                        head_world = (parent_world @ local_head).to_3d()
                    else:
                        head_world = sample['head_world'].copy()

                source_world_rot = sample['world_rotation']
                source_direction = _safe_direction(source_world_rot @ target['aim_local'], sample['tail_world'] - sample['head_world'])
                desired_tail = head_world + source_direction * chain_length
                source_twist = _twist_angle_from_quaternion(sample['local_rotation'], target['aim_local']) if include_twist else 0.0

                if frame_index > 0:
                    head_start = state['prev_head_world'].copy()
                    direction_start = state['prev_source_direction'].copy()
                    twist_start = float(state.get('prev_source_twist', source_twist))
                    for substep_index in range(1, substeps + 1):
                        factor = float(substep_index) / float(substeps)
                        sub_head = head_start.lerp(head_world, factor)
                        sub_source_direction = _safe_direction(direction_start.lerp(source_direction, factor), source_direction)
                        sub_desired_tail = sub_head + sub_source_direction * chain_length

                        head_delta = sub_head - state['prev_head_world']
                        state['tail_world'] = state['tail_world'] + head_delta
                        state['prev_head_world'] = sub_head.copy()

                        damping_step = math.pow(damping, substep_dt) if damping > 0.0 else 0.0
                        state['velocity'] = state['velocity'] + (sub_desired_tail - state['tail_world']) * (stiffness * substep_dt)
                        state['velocity'] = state['velocity'] * damping_step
                        state['tail_world'] = state['tail_world'] + state['velocity'] * substep_dt

                        sub_direction = _safe_direction(state['tail_world'] - sub_head, sub_source_direction)
                        state['tail_world'] = sub_head + sub_direction * chain_length
                        corrected_tail, sub_hits, corrected_velocity = _solve_collisions(state['tail_world'], state['velocity'], frame_colliders, settings, collision_iterations)
                        collision_hits += int(sub_hits)
                        state['tail_world'] = corrected_tail
                        if corrected_velocity is not None:
                            state['velocity'] = corrected_velocity
                        post_collision_direction = _safe_direction(state['tail_world'] - sub_head, sub_direction)
                        state['tail_world'] = sub_head + post_collision_direction * chain_length

                        if include_twist:
                            sub_twist_target = _float_lerp(twist_start, source_twist, factor)
                            state['twist'], state['twist_velocity'] = _simulate_scalar_step_dt(state['twist'], state['twist_velocity'], sub_twist_target, stiffness, damping, substep_dt)
                else:
                    state['prev_head_world'] = head_world.copy()
                    state['tail_world'] = desired_tail.copy()
                    state['velocity'] = Vector((0.0, 0.0, 0.0))
                    state['twist'] = source_twist
                    state['twist_velocity'] = 0.0

                state['prev_head_world'] = head_world.copy()
                state['prev_source_direction'] = source_direction.copy()
                state['prev_source_twist'] = source_twist

                simulated_tail = state['tail_world'].copy()
                blended_tail = desired_tail.lerp(simulated_tail, blend)
                blended_direction = _safe_direction(blended_tail - head_world, source_direction)
                blended_tail = head_world + blended_direction * chain_length
                blended_tail, final_hits, _velocity_unused = _solve_collisions(blended_tail, None, frame_colliders, settings, collision_iterations)
                collision_hits += int(final_hits)
                final_direction = _safe_direction(blended_tail - head_world, blended_direction)
                blended_tail = head_world + final_direction * chain_length

                try:
                    align_quat = source_direction.rotation_difference(final_direction)
                except Exception:
                    align_quat = _identity_quaternion()
                final_world_rot = _normalize_quaternion(align_quat @ source_world_rot)

                if include_twist:
                    twist_offset = (state['twist'] - source_twist) * blend * twist_strength
                    final_world_rot = _normalize_quaternion(_quat_from_axis_angle(twist_offset, final_direction) @ final_world_rot)

                local_scale = Vector(sample['local_scale'])
                if include_scale:
                    lag_ratio = min(scale_max - 1.0, max(0.0, (desired_tail - simulated_tail).length / max(chain_length, _EPS)) * scale_strength)
                    stretch_factor = 1.0 + (lag_ratio * blend)
                    local_scale = _scale_with_stretch(local_scale, settings.spring_magic_axis, stretch_factor)

                if target['kind'] == 'OBJECT':
                    parent_world_matrix = final_world_matrices.get(parent_id) if linked else sample.get('parent_world_matrix')
                    if parent_world_matrix is not None:
                        parent_rot = _normalize_quaternion(parent_world_matrix.to_quaternion())
                        local_rot = _normalize_quaternion(parent_rot.inverted() @ final_world_rot)
                        final_world_matrix = parent_world_matrix @ _matrix_from_translation_rotation_scale(sample['local_location'], local_rot, local_scale)
                    else:
                        local_rot = final_world_rot
                        final_world_matrix = _matrix_from_translation_rotation_scale(sample['local_location'], local_rot, local_scale)
                    _apply_object_transform(target, local_rot, local_scale, local_location=sample['local_location'])
                    keyed_count += _key_target_frame(target, frame_value, include_scale=include_scale)
                    final_world_matrices[target['id']] = final_world_matrix
                    final_world_tails[target['id']] = blended_tail.copy()
                    continue

                world_matrix = _matrix_from_translation_rotation_scale(head_world, final_world_rot, local_scale)
                armature_space = target['owner_obj'].matrix_world.inverted_safe() @ world_matrix
                if _apply_pose_transform(context, target, armature_space, local_scale):
                    keyed_count += _key_target_frame(target, frame_value, include_scale=include_scale)
                    pose_bone = target['owner_obj'].pose.bones.get(target['target_name'])
                    if pose_bone is not None:
                        final_world_matrices[target['id']] = target['owner_obj'].matrix_world @ pose_bone.matrix.copy()
                        final_world_tails[target['id']] = target['owner_obj'].matrix_world @ pose_bone.tail
                    else:
                        final_world_matrices[target['id']] = world_matrix
                        final_world_tails[target['id']] = blended_tail.copy()
            try:
                context.view_layer.update()
            except Exception:
                pass
            previous_frame_value = frame_value
    finally:
        scene.frame_set(original_frame)
        try:
            context.view_layer.update()
        except Exception:
            pass
    return keyed_count, collision_hits


# -----------------------------------------------------------------------------
# Operator
# -----------------------------------------------------------------------------


class SAS_OT_bake_spring_magic(Operator):
    bl_idname = 'sas.bake_spring_magic'
    bl_label = 'Bake Spring Magic'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if getattr(context, 'mode', '') == 'POSE':
            return bool(getattr(context, 'selected_pose_bones', None)) and getattr(getattr(context, 'active_object', None), 'type', '') == 'ARMATURE'
        return bool(getattr(context, 'selected_objects', None))

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Bake Spring Magic style secondary motion on selected object or pose-bone chains, with optional twist, squash-stretch, finer internal substeps, and collision support against floor, collection, and explicit object colliders. This is designed as a Blender-friendly answer to Spring Magic style quick secondary animation for linked objects and bones.",
            "選択したオブジェクトまたはポーズボーンのチェーンへ、Spring Magic 風のセカンダリモーションをベイクします。必要に応じてツイスト、スクワッシュ＆ストレッチ、より細かい内部サブステップ、床・コレクション・明示オブジェクトコライダーへの衝突にも対応します。リンクオブジェクトやボーンに素早く二次モーションを与える Spring Magic 系ワークフローを、Blender 向けに扱いやすく再構成した機能です。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        targets, targets_by_id, root_count = _collect_targets(context, settings)
        if not targets:
            self.report({'WARNING'}, sas_text('Select object chains or pose-bone chains first.', '先にオブジェクトチェーンまたはポーズボーンチェーンを選択してください。', context))
            add_log(context, 'WARN', 'Bake Spring Magic cancelled because no valid targets were selected.', '有効なターゲットが選択されていないため Bake Spring Magic を中止しました。')
            return {'CANCELLED'}

        start_frame, end_frame = get_bake_range(context.scene, settings)
        sample_step = max(1, int(settings.spring_sample_step))
        frames = frame_sequence(start_frame, end_frame, sample_step, include_end=True)
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text('The bake range is too short for Spring Magic.', 'Spring Magic にはベイク範囲が短すぎます。', context))
            add_log(context, 'WARN', 'Bake Spring Magic found a bake range that was too short.', 'ベイク範囲が短すぎるため Bake Spring Magic を中止しました。')
            return {'CANCELLED'}

        collider_count = len(_collider_objects_from_settings(settings, [target['id'] for target in targets], owner_names={target['owner_obj'].name for target in targets if target.get('owner_obj') is not None}))
        if settings.preview_only:
            message_en = (
                f"Spring Magic Preview — {len(targets)} targets across {root_count} chain roots, {len(frames)} samples, "
                f"frames {int(start_frame)}-{int(end_frame)}, axis {settings.spring_magic_axis}, mode {settings.spring_magic_mode}, "
                f"colliders {collider_count}, floor {'on' if settings.spring_magic_collision_mode in {'FLOOR', 'BOTH'} else 'off'}, substeps {max(1, int(getattr(settings, 'spring_magic_substeps', 1)))}, iterations {max(1, int(getattr(settings, 'spring_magic_collision_iterations', 1)))}."
            )
            message_ja = (
                f"Spring Magic プレビュー — {len(targets)} 個のターゲット、{root_count} 本のチェーン、{len(frames)} 個のサンプル、"
                f"範囲 {int(start_frame)}-{int(end_frame)}、軸 {settings.spring_magic_axis}、モード {settings.spring_magic_mode}、"
                f"コライダー {collider_count} 個、床 {'有効' if settings.spring_magic_collision_mode in {'FLOOR', 'BOTH'} else '無効'}、サブステップ {max(1, int(getattr(settings, 'spring_magic_substeps', 1)))}、反復 {max(1, int(getattr(settings, 'spring_magic_collision_iterations', 1)))}。"
            )
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, 'INFO', message_en, message_ja)
            return {'FINISHED'}

        if settings.spring_magic_collision_mode in {'COLLECTION', 'BOTH'} and getattr(settings, 'spring_magic_collision_collection', None) is None and not bool(getattr(settings, 'spring_magic_collision_object_enabled', False) and getattr(settings, 'spring_magic_collision_object', None) is not None):
            self.report({'WARNING'}, sas_text('Choose a collision collection, enable a collider object, or switch Collision to Floor/None.', '衝突コレクションを選ぶか、コライダーオブジェクトを有効にするか、Collision を Floor または None に変更してください。', context))
            add_log(context, 'WARN', 'Bake Spring Magic cancelled because collision mode required a collection but neither a collection nor an explicit collider object was set.', '衝突モードでコレクションが必要ですが、コレクションも明示コライダーオブジェクトも未設定のため Bake Spring Magic を中止しました。')
            return {'CANCELLED'}

        _ensure_action_backups(context, targets)
        include_scale = settings.spring_magic_mode == 'SWING_TWIST_SCALE'
        # Sample the source motion before the clear step removes the keys that define it.
        samples_by_frame, colliders_by_frame = _sample_all_targets(context, targets, frames, settings)
        removed = _apply_clear_range_if_needed(context, settings, targets, start_frame, end_frame, include_scale=include_scale)
        for target in targets:
            get_or_create_action_for_object(target['owner_obj'], base_name=f"{target['owner_obj'].name}_Action")
        keyed_count, collision_hits = _run_spring_magic_bake(context, settings, targets, targets_by_id, frames, samples_by_frame, colliders_by_frame)

        message_en = (
            f"Baked Spring Magic on {len(targets)} targets across {root_count} chain roots using {len(frames)} samples; "
            f"wrote {keyed_count} key blocks, cleared {removed} existing keys, and resolved {collision_hits} collision pushes."
        )
        message_ja = (
            f"{len(targets)} 個のターゲット、{root_count} 本のチェーンへ Spring Magic をベイクしました。"
            f"{len(frames)} 個のサンプルを使い、{keyed_count} 個のキーブロックを書き込み、{removed} 個の既存キーを削除し、"
            f"{collision_hits} 回の衝突補正を行いました。"
        )
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, 'INFO', message_en, message_ja)
        return {'FINISHED'}


OPERATOR_SPRING_MAGIC_CLASSES = (
    SAS_OT_bake_spring_magic,
)
