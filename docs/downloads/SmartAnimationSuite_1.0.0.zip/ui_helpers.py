# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

from .translation import sas_text
from .plus_operators import SAS_OT_bake_limited_animation, SAS_OT_bake_spring_dynamics
from .spring_magic_operators import SAS_OT_bake_spring_magic
from .motion_fx_operators import (
    SAS_OT_apply_motion_stretch,
    SAS_OT_clear_motion_stretch,
    SAS_OT_bake_vehicle_wheel_rotation,
    SAS_OT_clear_vehicle_wheel_rotation,
    SAS_OT_apply_deformer_reveal,
    SAS_OT_clear_deformer_reveal,
)
from .signal_fx_operators import (
    SAS_OT_apply_motion_signal,
    SAS_OT_clear_motion_signal,
)
from .workflow_operators import SAS_OT_bake_rigid_body_keys
from .operators import (
    SAS_OT_apply_selection_set,
    SAS_OT_apply_pose_snapshot,
    SAS_OT_assign_library_action,
    SAS_OT_push_library_action_to_nla,
)



def draw_curve_safety_filters(layout, context, settings):
    box = layout.box()
    box.label(text=sas_text("Curve Safety Filters", "カーブ安全フィルター", context), icon='LOCKED')
    row = box.row(align=True)
    row.prop(settings, "skip_locked_curves", text=sas_text("Skip Locked", "ロックを除外", context), toggle=True)
    row.prop(settings, "skip_muted_curves", text=sas_text("Skip Muted", "ミュートを除外", context), toggle=True)
    row.prop(settings, "skip_hidden_curves", text=sas_text("Skip Hidden", "非表示を除外", context), toggle=True)
    return box



def draw_advanced_procedural_helpers(layout, context, settings):
    box = layout.box()
    box.label(text=sas_text("Advanced Baked Helpers", "高度なベイク補助", context), icon='MODIFIER')

    limited = box.box()
    limited.label(text=sas_text("Limited Animation Bake", "リミテッドアニメーションベイク", context), icon='IPO_CONSTANT')
    row = limited.row(align=True)
    row.prop(settings, "limited_bake_step", text=sas_text("Limited Step", "保持ステップ", context))
    row.prop(settings, "limited_interpolation", text=sas_text("Interpolation", "補間", context))
    limited.operator(SAS_OT_bake_limited_animation.bl_idname, text=sas_text("Bake Limited Copy", "リミテッド複製を作成", context), icon='CHECKMARK')

    spring = box.box()
    spring.label(text=sas_text("Spring Dynamics Bake", "スプリングダイナミクスベイク", context), icon='CON_TRACKTO')
    row = spring.row(align=True)
    row.prop(settings, "spring_stiffness", text=sas_text("Stiffness", "剛性", context))
    row.prop(settings, "spring_damping", text=sas_text("Damping", "減衰", context))
    row.prop(settings, "spring_blend", text=sas_text("Blend", "ブレンド", context))
    row = spring.row(align=True)
    row.prop(settings, "spring_sample_step", text=sas_text("Sample Step", "サンプル間隔", context))
    row.prop(settings, "spring_auto_simplify", text=sas_text("Auto Simplify", "自動簡略化", context))
    spring.operator(SAS_OT_bake_spring_dynamics.bl_idname, text=sas_text("Bake Spring Dynamics", "スプリングダイナミクスをベイク", context), icon='CHECKMARK')

    magic = box.box()
    magic.label(text=sas_text("Spring Magic Bake", "Spring Magic ベイク", context), icon='CON_TRACKTO')
    row = magic.row(align=True)
    row.prop(settings, "spring_magic_axis", text=sas_text("Axis", "軸", context))
    row.prop(settings, "spring_magic_mode", text=sas_text("Mode", "モード", context))
    row.prop(settings, "spring_magic_clear_range", text=sas_text("Clear Range", "範囲消去", context))
    row = magic.row(align=True)
    row.prop(settings, "spring_stiffness", text=sas_text("Stiffness", "剛性", context))
    row.prop(settings, "spring_damping", text=sas_text("Damping", "減衰", context))
    row.prop(settings, "spring_blend", text=sas_text("Blend", "ブレンド", context))
    row = magic.row(align=True)
    row.prop(settings, "spring_sample_step", text=sas_text("Sample Step", "サンプル間隔", context))
    row.prop(settings, "spring_magic_substeps", text=sas_text("Substeps", "サブステップ", context))
    row.prop(settings, "spring_magic_collision_iterations", text=sas_text("Iterations", "反復", context))
    row = magic.row(align=True)
    row.prop(settings, "spring_magic_twist_strength", text=sas_text("Twist", "ツイスト", context))
    row.prop(settings, "spring_magic_scale_strength", text=sas_text("Scale", "スケール", context))
    row.prop(settings, "spring_magic_scale_max", text=sas_text("Scale Max", "最大スケール", context))
    row = magic.row(align=True)
    row.prop(settings, "spring_magic_collision_mode", text=sas_text("Collision", "衝突", context))
    row.prop(settings, "spring_magic_collision_radius", text=sas_text("Radius", "半径", context))
    row.prop(settings, "spring_magic_collision_margin", text=sas_text("Margin", "余白", context))
    if settings.spring_magic_collision_mode in {'FLOOR', 'BOTH'}:
        magic.prop(settings, "spring_magic_floor_height", text=sas_text("Floor Height", "床高さ", context))
    if settings.spring_magic_collision_mode in {'COLLECTION', 'BOTH'}:
        magic.prop(settings, "spring_magic_collision_collection", text=sas_text("Collider Collection", "コライダーコレクション", context))
    row = magic.row(align=True)
    row.prop(settings, "spring_magic_collision_object_enabled", text=sas_text("Use Object", "オブジェクト使用", context), toggle=True)
    if settings.spring_magic_collision_object_enabled:
        magic.prop(settings, "spring_magic_collision_object", text=sas_text("Collider Object", "コライダーオブジェクト", context))
    magic.operator(SAS_OT_bake_spring_magic.bl_idname, text=sas_text("Bake Spring Magic", "Spring Magic をベイク", context), icon='CHECKMARK')

    physics = box.box()
    physics.label(text=sas_text("Physics Bake", "物理ベイク", context), icon='PHYSICS')
    row = physics.row(align=True)
    row.prop(settings, "bake_range", text=sas_text("Bake Range", "ベイク範囲", context))
    row.prop(settings, "frame_step", text=sas_text("Bake Step", "ベイク間隔", context))
    row.prop(settings, "physics_bake_clear_range", text=sas_text("Clear Existing Range", "既存範囲を消去", context))
    physics.operator(SAS_OT_bake_rigid_body_keys.bl_idname, text=sas_text("Bake Rigid Body Keys", "リジッドボディキーをベイク", context), icon='CHECKMARK')

    signal = box.box()
    signal.label(text=sas_text("Motion Signal", "モーションシグナル", context), icon='DRIVER')
    row = signal.row(align=True)
    row.prop(settings, "signal_mode", text=sas_text("Mode", "モード", context))
    row.prop(settings, "signal_target", text=sas_text("Target", "対象", context))
    row.prop(settings, "signal_axes", text=sas_text("Axes", "軸", context))
    row = signal.row(align=True)
    row.prop(settings, "signal_time_mode", text=sas_text("Time", "時間", context))
    if settings.signal_time_mode == 'BPM':
        row.prop(settings, "signal_bpm", text=sas_text("BPM", "BPM", context))
    else:
        row.prop(settings, "signal_frequency", text=sas_text("Frequency", "周波数", context))
    row.prop(settings, "signal_amplitude", text=sas_text("Amplitude", "振幅", context))
    row = signal.row(align=True)
    row.prop(settings, "signal_phase", text=sas_text("Phase", "位相", context))
    row.prop(settings, "signal_object_phase_offset", text=sas_text("Per Object", "オブジェクトごと", context))
    row.prop(settings, "signal_order", text=sas_text("Order", "順序", context))
    if settings.signal_mode == 'STEP':
        signal.prop(settings, "signal_step_frames", text=sas_text("Step Frames", "保持フレーム", context))
    if settings.signal_mode == 'NOISE':
        signal.prop(settings, "signal_noise_seed", text=sas_text("Noise Seed", "ノイズシード", context))
    signal.prop(settings, "signal_replace_existing", text=sas_text("Replace SAS", "SAS を置換", context))
    row = signal.row(align=True)
    row.operator(SAS_OT_apply_motion_signal.bl_idname, text=sas_text("Apply Motion Signal", "モーションシグナル適用", context), icon='CHECKMARK')
    row.operator(SAS_OT_clear_motion_signal.bl_idname, text=sas_text("Clear Motion Signal", "モーションシグナル解除", context), icon='X')

    stretch = box.box()
    stretch.label(text=sas_text("Motion Stretch", "モーションストレッチ", context), icon='MOD_SIMPLEDEFORM')
    row = stretch.row(align=True)
    row.prop(settings, "motion_stretch_axis", text=sas_text("Axis", "軸", context))
    row.prop(settings, "motion_stretch_plane", text=sas_text("Plane", "平面", context))
    row.prop(settings, "motion_stretch_strength", text=sas_text("Strength", "強さ", context))
    row = stretch.row(align=True)
    row.prop(settings, "motion_stretch_squash", text=sas_text("Squash", "スクワッシュ", context))
    row.prop(settings, "motion_stretch_max", text=sas_text("Max", "最大", context))
    row.prop(settings, "motion_stretch_replace_existing", text=sas_text("Replace SAS", "SAS を置換", context))
    row = stretch.row(align=True)
    row.operator(SAS_OT_apply_motion_stretch.bl_idname, text=sas_text("Apply Motion Stretch", "モーションストレッチ適用", context), icon='CHECKMARK')
    row.operator(SAS_OT_clear_motion_stretch.bl_idname, text=sas_text("Clear Motion Stretch", "モーションストレッチ解除", context), icon='X')

    drive = box.box()
    drive.label(text=sas_text("Vehicle Wheel Drive", "車輪ドライブ", context), icon='DRIVER')
    row = drive.row(align=True)
    row.prop(settings, "vehicle_wheel_axis", text=sas_text("Axis", "軸", context))
    row.prop(settings, "vehicle_motion_plane", text=sas_text("Plane", "平面", context))
    row.prop(settings, "vehicle_radius_mode", text=sas_text("Radius", "半径", context))
    if settings.vehicle_radius_mode == 'MANUAL':
        drive.prop(settings, "vehicle_wheel_radius", text=sas_text("Manual Wheel Radius", "手動ホイール半径", context))
    row = drive.row(align=True)
    row.prop(settings, "vehicle_spin_direction", text=sas_text("Direction", "方向", context))
    row.prop(settings, "vehicle_auto_side_flip", text=sas_text("Auto Side Flip", "自動左右反転", context))
    row.prop(settings, "vehicle_replace_existing", text=sas_text("Replace SAS", "SAS を置換", context))
    drive.prop(settings, "vehicle_enable_steering", text=sas_text("Enable Steering", "ステアリングを有効", context))
    if settings.vehicle_enable_steering:
        row = drive.row(align=True)
        row.prop(settings, "vehicle_steering_axis", text=sas_text("Steering Axis", "ステアリング軸", context))
        row.prop(settings, "vehicle_steering_max", text=sas_text("Max Steering", "最大ステアリング", context))
        row.prop(settings, "vehicle_steering_reverse", text=sas_text("Reverse Steering", "ステアリング反転", context))
    row = drive.row(align=True)
    row.operator(SAS_OT_bake_vehicle_wheel_rotation.bl_idname, text=sas_text("Bake Vehicle Wheel Rotation", "車輪回転をベイク", context), icon='CHECKMARK')
    row.operator(SAS_OT_clear_vehicle_wheel_rotation.bl_idname, text=sas_text("Clear Vehicle Wheel Rotation", "車輪回転を解除", context), icon='X')


    deform = box.box()
    deform.label(text=sas_text("Deformer Reveal FX", "デフォーマーリビール FX", context), icon='MOD_BUILD')
    row = deform.row(align=True)
    row.prop(settings, "deform_reveal_mode", text=sas_text("Mode", "モード", context))
    row.prop(settings, "deform_reveal_axis", text=sas_text("Axis", "軸", context))
    row.prop(settings, "deform_reveal_replace_existing", text=sas_text("Replace SAS", "SAS を置換", context))
    if settings.deform_reveal_mode != 'BUILD':
        deform.prop(settings, "deform_reveal_angle", text=sas_text("Start Angle", "開始角度", context))
    row = deform.row(align=True)
    row.prop(settings, "transform_reveal_order", text=sas_text("Reveal Order", "順序", context))
    row.prop(settings, "transform_reveal_stagger", text=sas_text("Reveal Stagger", "段差", context))
    row.prop(settings, "transform_reveal_duration", text=sas_text("Reveal Duration", "時間", context))
    row = deform.row(align=True)
    row.operator(SAS_OT_apply_deformer_reveal.bl_idname, text=sas_text("Apply Deformer Reveal", "デフォーマーリビール適用", context), icon='CHECKMARK')
    row.operator(SAS_OT_clear_deformer_reveal.bl_idname, text=sas_text("Clear Deformer Reveal", "デフォーマーリビール解除", context), icon='X')
    return box



def draw_selection_set_quick_picker(layout, context, settings, max_buttons=8):
    if not getattr(settings, "selection_sets", None):
        return None
    box = layout.box()
    box.label(text=sas_text("Quick Picker", "クイックピッカー", context), icon='RESTRICT_SELECT_OFF')
    grid = box.grid_flow(columns=2, even_columns=True, even_rows=True, align=True)
    for index, item in enumerate(list(settings.selection_sets)[:max_buttons]):
        op = grid.operator(SAS_OT_apply_selection_set.bl_idname, text=item.name or sas_text("Selection", "選択", context), translate=False, icon='CHECKMARK')
        op.set_index = index
    if len(settings.selection_sets) > max_buttons:
        box.label(text=sas_text(f"Showing {max_buttons} buttons. Use the list below for the rest.", f"最初の {max_buttons} 個を表示しています。残りは下の一覧から使ってください。", context))
    return box


def draw_pose_snapshot_quick_picker(layout, context, settings, max_buttons=8):
    if not getattr(settings, "pose_snapshots", None):
        return None
    box = layout.box()
    box.label(text=sas_text("Pose Quick Palette", "ポーズクイックパレット", context), icon='POSE_HLT')
    grid = box.grid_flow(columns=2, even_columns=True, even_rows=True, align=True)
    for index, item in enumerate(list(settings.pose_snapshots)[:max_buttons]):
        op = grid.operator(SAS_OT_apply_pose_snapshot.bl_idname, text=item.name or sas_text("Pose", "ポーズ", context), translate=False, icon='CHECKMARK')
        op.set_index = index
    if len(settings.pose_snapshots) > max_buttons:
        box.label(text=sas_text(f"Showing {max_buttons} buttons. Use the list below for the rest.", f"最初の {max_buttons} 個を表示しています。残りは下の一覧から使ってください。", context))
    return box



def draw_action_library_quick_picker(layout, context, settings, max_buttons=6):
    if not getattr(settings, "action_library", None):
        return None
    box = layout.box()
    box.label(text=sas_text("Quick Library", "クイックライブラリ", context), icon='ASSET_MANAGER')
    col = box.column(align=True)
    for index, item in enumerate(list(settings.action_library)[:max_buttons]):
        row = col.row(align=True)
        label = item.action_name or sas_text("Action", "アクション", context)
        op = row.operator(SAS_OT_assign_library_action.bl_idname, text=label, translate=False, icon='CHECKMARK')
        op.set_index = index
        op = row.operator(SAS_OT_push_library_action_to_nla.bl_idname, text="", icon='NLA')
        op.set_index = index
    if len(settings.action_library) > max_buttons:
        box.label(text=sas_text(f"Showing {max_buttons} entries. Use the main list below for the rest.", f"最初の {max_buttons} 件を表示しています。残りは下の一覧から使ってください。", context))
    return box
