# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Smart Animation Suite extension entry point.

Registration is delegated to :mod:`runtime`, which owns one generation-scoped
exact-identity ledger.  No Blender process-global API is replaced here.
"""

from __future__ import annotations

from . import runtime as _runtime

ensure_runtime_initialized = _runtime.ensure_runtime_initialized
preflight_cleanup = _runtime.preflight_cleanup
repair_runtime = _runtime.repair_runtime
get_preferences = _runtime.get_preferences


def register() -> None:
    try:
        _runtime.register()
    except BaseException as exc:
        try:
            _runtime.registration_boundary_fallback(exc)
        except BaseException:
            pass
    return None


def unregister() -> None:
    try:
        _runtime.unregister()
    except BaseException as exc:
        try:
            _runtime.unregister_boundary_fallback(exc)
        except BaseException:
            pass
    return None


if __name__ == '__main__':
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
