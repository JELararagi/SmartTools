# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Read-only Smart Tools Manager placement and runtime bridge.

This module never imports, patches, refreshes, or mutates Manager internals.  A
Panel ``poll`` call performs only a bounded read of already-loaded modules and
invokes a documented public placement/current-cell API when one is available.
Runtime callbacks use the separate public workspace aggregate and fail open
while Manager is absent, unready, stale, or temporarily unavailable.
"""

import sys
from typing import Any, Callable, Iterator

_TOOL_KEY = 'SMART_ANIMATION'
_SUPPORTED_LOGICAL_EDITORS = frozenset({
    'VIEW_3D', 'IMAGE_EDITOR', 'UV_EDITOR', 'SHADER_EDITOR', 'COMPOSITOR',
    'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR', 'VIDEO_SEQUENCER',
    'MOVIE_CLIP_EDITOR', 'DOPE_SHEET', 'GRAPH_EDITOR', 'DRIVERS', 'NLA_EDITOR',
    'TEXT_EDITOR', 'ASSET_BROWSER', 'FILE_BROWSER', 'SPREADSHEET',
})
_PHYSICAL_TO_DEFAULT = {
    'VIEW_3D': 'VIEW_3D',
    'IMAGE_EDITOR': 'IMAGE_EDITOR',
    'NODE_EDITOR': 'SHADER_EDITOR',
    'SEQUENCE_EDITOR': 'VIDEO_SEQUENCER',
    'CLIP_EDITOR': 'MOVIE_CLIP_EDITOR',
    'DOPESHEET_EDITOR': 'DOPE_SHEET',
    'GRAPH_EDITOR': 'GRAPH_EDITOR',
    'NLA_EDITOR': 'NLA_EDITOR',
    'TEXT_EDITOR': 'TEXT_EDITOR',
    'FILE_BROWSER': 'FILE_BROWSER',
    'SPREADSHEET': 'SPREADSHEET',
}
_PUBLIC_RULE_NAMES = ('placement_allowed',)
_PUBLIC_RUNTIME_NAMES = ('workspace_tool_allowed',)
_PUBLIC_API_NAMES = _PUBLIC_RULE_NAMES + _PUBLIC_RUNTIME_NAMES
_PUBLIC_GENERATION_NAMES = (
    'get_public_generation',
    'public_generation',
    'get_current_cell_generation',
    'current_cell_generation',
    'get_rule_generation',
    'rule_generation',
)


def _text(value: Any) -> str:
    try:
        return str(value or '').strip().upper()
    except Exception:
        return ''


def logical_editor_key(context: Any, physical_hint: str = '') -> str:
    """Map Blender's 11 physical editor types to the Manager's 17 logical keys."""
    area = getattr(context, 'area', None)
    space = getattr(context, 'space_data', None)
    area_type = _text(getattr(area, 'type', None) or physical_hint)
    ui_type = _text(getattr(area, 'ui_type', None) or getattr(space, 'ui_type', None))

    if area_type == 'IMAGE_EDITOR':
        mode = _text(getattr(space, 'mode', None))
        if ui_type in {'UV', 'UV_EDITOR', 'UV_EDIT', 'UVS'} or mode in {'UV', 'UV_EDITOR', 'UV_EDIT', 'UVS'}:
            return 'UV_EDITOR'
        return 'IMAGE_EDITOR'

    if area_type == 'NODE_EDITOR':
        tree_type = _text(getattr(space, 'tree_type', None) or ui_type)
        shader_type = _text(getattr(space, 'shader_type', None))
        if 'COMPOSIT' in tree_type:
            return 'COMPOSITOR'
        if 'GEOMETRY' in tree_type:
            return 'GEOMETRY_NODE_EDITOR'
        if 'TEXTURE' in tree_type:
            return 'TEXTURE_NODE_EDITOR'
        if 'SHADER' in tree_type or shader_type:
            return 'SHADER_EDITOR'
        return 'SHADER_EDITOR'

    if area_type == 'GRAPH_EDITOR':
        mode = _text(getattr(space, 'mode', None) or ui_type)
        return 'DRIVERS' if mode in {'DRIVERS', 'DRIVER'} else 'GRAPH_EDITOR'

    if area_type == 'FILE_BROWSER':
        browse_mode = _text(
            getattr(space, 'browse_mode', None)
            or getattr(getattr(space, 'params', None), 'display_type', None)
            or ui_type
        )
        return 'ASSET_BROWSER' if 'ASSET' in browse_mode or 'ASSET' in ui_type else 'FILE_BROWSER'

    if area_type == 'DOPESHEET_EDITOR':
        # Timeline is physically a Dope Sheet editor but does not expose a Sidebar
        # in the same way.  When a panel is queried here, DOPE_SHEET is the stable
        # Manager cell and no data/mode mutation is performed.
        return 'DOPE_SHEET'

    return _PHYSICAL_TO_DEFAULT.get(area_type, _PHYSICAL_TO_DEFAULT.get(_text(physical_hint), ''))


def _manager_public_modules() -> Iterator[Any]:
    """Yield only fixed, already-loaded Manager public API modules.

    Smart Tools Manager historically exposed the public placement functions
    either on its package module or on the package's already-loaded ``manager``
    submodule.  Both locations are checked by fixed name; ``sys.modules`` is
    never enumerated and no import, refresh, registration, or Manager mutation is
    performed from Panel.poll.
    """
    package = str(__package__ or '').strip()
    package_candidates = [
        'smart_tools_manager',
        'bl_ext.user_default.smart_tools_manager',
        'bl_ext.blender_org.smart_tools_manager',
    ]
    parts = package.split('.')
    if len(parts) >= 3 and parts[0] == 'bl_ext':
        package_candidates.insert(0, '.'.join(parts[:2] + ['smart_tools_manager']))

    candidates: list[str] = []
    for base in package_candidates:
        candidates.append(base)
        candidates.append(f'{base}.manager')

    seen: set[int] = set()
    for name in candidates:
        module = sys.modules.get(name)
        if module is None or id(module) in seen:
            continue
        seen.add(id(module))
        if any(callable(getattr(module, item, None)) for item in _PUBLIC_API_NAMES):
            yield module


def _public_generation_value(module: Any) -> int | str | None:
    for name in _PUBLIC_GENERATION_NAMES:
        value = getattr(module, name, None)
        try:
            generation = value() if callable(value) else value
        except Exception:
            continue
        if isinstance(generation, (int, str)):
            return generation
    return None


def _call_public_rule(
    fn: Callable[..., Any], context: Any, editor_key: str,
    generation: int | str | None = None,
) -> bool:
    """Call one documented public rule through bounded signature variants."""
    attempts = []
    if generation is not None:
        attempts.extend((
            lambda: fn(_TOOL_KEY, context=context, editor_key=editor_key, generation=generation),
            lambda: fn(tool_key=_TOOL_KEY, context=context, editor_key=editor_key, generation=generation),
            lambda: fn(_TOOL_KEY, context=context, logical_editor_key=editor_key, generation=generation),
            lambda: fn(tool_key=_TOOL_KEY, context=context, logical_editor_key=editor_key, generation=generation),
            lambda: fn(_TOOL_KEY, context, editor_key, generation),
        ))
    attempts.extend((
        lambda: fn(_TOOL_KEY, context=context, editor_key=editor_key),
        lambda: fn(tool_key=_TOOL_KEY, context=context, editor_key=editor_key),
        lambda: fn(_TOOL_KEY, context=context, logical_editor_key=editor_key),
        lambda: fn(tool_key=_TOOL_KEY, context=context, logical_editor_key=editor_key),
        lambda: fn(_TOOL_KEY, context, editor_key),
        lambda: fn(_TOOL_KEY, context=context),
    ))
    last_type_error: Exception | None = None
    for attempt in attempts:
        try:
            return bool(attempt())
        except TypeError as exc:
            last_type_error = exc
            continue
    if last_type_error is not None:
        raise last_type_error
    return False

def panel_rule_allows_context(context: Any, *, editor_key: str = '') -> bool:
    """Pure read-only placement query used by every Suite-owned root Panel.

    Standalone use is fail-open when no Manager public API is loaded. Once an
    authoritative public rule function is present, its current-cell result is
    authoritative; an exception or generation/signature mismatch fails closed so
    an OFF cell never leaves a surviving native category root.
    """
    logical = _text(editor_key) or logical_editor_key(context)
    if logical not in _SUPPORTED_LOGICAL_EDITORS:
        return False
    modules = tuple(_manager_public_modules())
    if not modules:
        return True
    shared_generation = None
    for module in modules:
        shared_generation = _public_generation_value(module)
        if shared_generation is not None:
            break
    public_api_found = False
    for module in modules:
        generation = _public_generation_value(module)
        if generation is None:
            generation = shared_generation

        # Smart Tools Manager 1.5.57 exposes placement_allowed() as the canonical
        # read-only current-cell rule. Call it first and never import, refresh,
        # mutate, register, or relabel Manager-owned data from Panel.poll.
        placement_allowed = getattr(module, 'placement_allowed', None)
        if callable(placement_allowed):
            public_api_found = True
            try:
                return _call_public_rule(placement_allowed, context, logical, generation)
            except Exception:
                return False

    return not public_api_found


def workspace_runtime_allows_context(context: Any) -> bool:
    """Return Manager's workspace-wide Smart Animation runtime decision.

    Only the fixed, already-loaded public Manager modules are queried.  A
    missing API, an older/unready Manager, a transient stale state, or a call
    failure must not falsely stop an otherwise enabled standalone Suite.
    """
    for module in _manager_public_modules():
        workspace_tool_allowed = getattr(module, 'workspace_tool_allowed', None)
        if not callable(workspace_tool_allowed):
            continue
        try:
            decision = workspace_tool_allowed(_TOOL_KEY, context=context)
        except Exception:
            return True
        return decision if isinstance(decision, bool) else True
    return True


def manager_generation_snapshot() -> tuple[str, int | str | None]:
    """Return immutable diagnostics for audits without retaining a Manager module."""
    for module in _manager_public_modules():
        return (str(getattr(module, '__name__', '') or ''), _public_generation_value(module))
    return ('', None)


def apply_smart_animation_panel_compat() -> bool:
    """Backward-compatible no-op retained for older callers.

    Older builds modified Manager private sets and scheduled proxy refreshes here.
    That behavior is intentionally removed.  Returning ``True`` means the native
    Suite-owned root panel strategy is active.
    """
    return True
