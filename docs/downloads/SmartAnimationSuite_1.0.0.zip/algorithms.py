# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import math

from .core import safe_remove_keyframe_points, simplify_point_indices


def frame_sequence(start, end, step=1, include_end=True):
    step = max(1, int(step))
    start = float(start)
    end = float(end)
    if end < start:
        start, end = end, start
    values = []
    frame = int(round(start))
    end_frame = int(round(end))
    while frame <= end_frame:
        values.append(float(frame))
        frame += step
    if include_end and values:
        if not math.isclose(values[-1], float(end_frame)):
            values.append(float(end_frame))
    elif include_end and not values:
        values.append(float(end_frame))
    return values



def key_indices_in_range(fcurve, start, end):
    indices = []
    for index, key in enumerate(getattr(fcurve, 'keyframe_points', [])):
        try:
            frame = float(key.co.x)
        except Exception:
            continue
        if start <= frame <= end:
            indices.append(index)
    return indices



def rebuild_curve_range_from_samples(fcurve, samples, interpolation='BEZIER', handle_type='AUTO_CLAMPED', start=None, end=None):
    if fcurve is None:
        return 0
    ordered = sorted((float(frame), float(value)) for frame, value in samples.items())
    if not ordered:
        return 0
    start = float(start if start is not None else ordered[0][0])
    end = float(end if end is not None else ordered[-1][0])
    removed = safe_remove_keyframe_points(fcurve, key_indices_in_range(fcurve, start, end))
    inserted = 0
    for frame, value in ordered:
        try:
            key = fcurve.keyframe_points.insert(frame, value, options={'FAST'})
        except Exception:
            try:
                key = fcurve.keyframe_points.insert(frame, value)
            except Exception:
                continue
        inserted += 1
        try:
            key.interpolation = interpolation
        except Exception:
            pass
        for attr in ('handle_left_type', 'handle_right_type'):
            try:
                setattr(key, attr, handle_type)
            except Exception:
                pass
    try:
        fcurve.update()
    except Exception:
        pass
    return removed + inserted



def simplify_sampled_curve_in_range(fcurve, tolerance, preserve_extrema=True, threshold=1e-4, start=None, end=None):
    if fcurve is None:
        return 0
    in_range = []
    for index, key in enumerate(getattr(fcurve, 'keyframe_points', [])):
        try:
            frame = float(key.co.x)
            value = float(key.co.y)
        except Exception:
            continue
        if start is not None and frame < float(start):
            continue
        if end is not None and frame > float(end):
            continue
        in_range.append((index, frame, value))
    if len(in_range) <= 2:
        return 0
    keep_local = simplify_point_indices([(frame, value) for _idx, frame, value in in_range], tolerance, preserve_extrema=preserve_extrema, threshold=threshold)
    remove_global = [global_index for local_index, (global_index, _frame, _value) in enumerate(in_range) if local_index not in keep_local]
    return safe_remove_keyframe_points(fcurve, remove_global)



def simulate_spring_values(values, stiffness=0.28, damping=0.82, blend=1.0):
    if not values:
        return []
    stiffness = max(0.0, float(stiffness))
    damping = max(0.0, min(0.9999, float(damping)))
    blend = max(0.0, min(1.0, float(blend)))
    follower = float(values[0])
    velocity = 0.0
    baked = []
    for target in values:
        target = float(target)
        velocity = (velocity + (target - follower) * stiffness) * damping
        follower += velocity
        baked.append(target + (follower - target) * blend)
    return baked



def speed_values_from_points(points, frame_step=1):
    if not points:
        return []
    frame_step = max(1.0, float(frame_step))
    speeds = [0.0]
    for prev, current in zip(points, points[1:]):
        dx = float(current[0]) - float(prev[0])
        dy = float(current[1]) - float(prev[1])
        dz = float(current[2]) - float(prev[2])
        speeds.append(math.sqrt(dx * dx + dy * dy + dz * dz) / frame_step)
    return speeds



def radii_from_speeds(base_radius, speeds, mode='CONSTANT', scale=1.0, min_factor=0.35, max_factor=2.25):
    base_radius = max(0.0, float(base_radius))
    if not speeds:
        return []
    if mode != 'SPEED':
        return [base_radius for _value in speeds]
    peak = max(float(value) for value in speeds) or 1.0
    radii = []
    for value in speeds:
        normalized = max(0.0, float(value) / peak)
        factor = 1.0 + normalized * float(scale)
        factor = max(float(min_factor), min(float(max_factor), factor))
        radii.append(base_radius * factor)
    return radii



def smoothstep01(value):
    value = max(0.0, min(1.0, float(value)))
    return value * value * (3.0 - 2.0 * value)



def catmull_rom_value(p0, p1, p2, p3, t):
    t = float(t)
    t2 = t * t
    t3 = t2 * t
    return 0.5 * (
        (2.0 * float(p1))
        + (-float(p0) + float(p2)) * t
        + (2.0 * float(p0) - 5.0 * float(p1) + 4.0 * float(p2) - float(p3)) * t2
        + (-float(p0) + 3.0 * float(p1) - 3.0 * float(p2) + float(p3)) * t3
    )



def advanced_tween_value(previous_previous, previous, nxt, next_next, factor, mode='LINEAR'):
    previous = float(previous)
    nxt = float(nxt)
    factor = float(factor)
    mode = str(mode or 'LINEAR').upper()

    if mode == 'EASE':
        if 0.0 <= factor <= 1.0:
            factor = smoothstep01(factor)
        return previous + (nxt - previous) * factor

    if mode == 'HERMITE':
        p0 = previous if previous_previous is None else float(previous_previous)
        p1 = previous
        p2 = nxt
        p3 = nxt if next_next is None else float(next_next)
        return catmull_rom_value(p0, p1, p2, p3, factor)

    return previous + (nxt - previous) * factor
