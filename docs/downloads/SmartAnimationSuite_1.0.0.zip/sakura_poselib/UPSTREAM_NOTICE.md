# Sakura PoseLib — upstream attribution and source notice

Original project: Sakura PoseLib by Kafuji Sato.

Source: https://github.com/kafuji/Sakura_Poselib

Audited upstream snapshot: `db6b4cb01ad53deeab8a6ec09f6e9bf8e4ab7282`,
manifest version 1.4.4. The exact originally acquired archive has not been
identified.

## Upstream declarations

- README: ©2021-2024 Kafuji Sato.
- `blender_manifest.toml`: 2023-2024 Kafuji Sato; SPDX: GPL-3.0-or-later.
- `translation.py`: Copyright (c) 2022 by Kafuji Sato; GNU General Public License v3.0.
- The complete upstream license is included in `UPSTREAM_LICENSE_GPL-3.0.txt`,
  copied without modification from the pinned upstream LICENSE.

Smart Animation contains an adapted Sakura PoseLib subtree. `ops.py`
corresponds to `operators.py`, `prefs.py` to `preferences.py`, and
`lang/ja_JP/ui.tsv` to `language/ja_JP/ui.tsv`; other mapped filenames
correspond directly. The source review records the integration changes.

The integration project is JELararagi. The seller reports human ideation and
AI implementation. This notice does not claim that JELararagi authored the
original Sakura PoseLib or manually wrote the integration code, and does not
grant permission to remove upstream notices or impose proprietary restrictions
on GPL-covered material. Whole-package licensing and distribution clearance
require separate review.
