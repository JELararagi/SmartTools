# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Event-driven Sakura PoseLib maintenance.

No periodic object/PoseLib scan is registered. RNA message-bus notifications add
only context-relevant armature names to a bounded scalar queue. One finite,
one-shot timer drains the complete queue and returns ``None``. Disabling the
feature removes the exact subscription/timer and clears every pending name.
"""

from __future__ import annotations

from collections import deque
from typing import Any

import bpy

from .spl import ensure_proxy_obj, get_poselib

_BACKGROUND_ENABLED = False
_MSGBUS_OWNER = object()
_DIRTY_NAMES: deque[str] = deque()
_DIRTY_SET: set[str] = set()
_MAX_DIRTY_NAMES = 256


def _timer_registered() -> bool:
    try:
        return bool(bpy.app.timers.is_registered(_flush_dirty_queue))
    except Exception:
        return False


def _unregister_flush_timer() -> None:
    try:
        if bpy.app.timers.is_registered(_flush_dirty_queue):
            bpy.app.timers.unregister(_flush_dirty_queue)
    except Exception:
        pass


def _schedule_flush() -> None:
    if not _BACKGROUND_ENABLED or not _DIRTY_NAMES or _timer_registered():
        return
    try:
        result = bpy.app.timers.register(_flush_dirty_queue, first_interval=0.0)
        if result is False:
            return
    except Exception:
        # The bounded queue remains dirty. A later explicit event retries.
        return


def _queue_name(name: str) -> None:
    text = str(name or '').strip()
    if not text or text in _DIRTY_SET:
        return
    if len(_DIRTY_NAMES) >= _MAX_DIRTY_NAMES:
        removed = _DIRTY_NAMES.popleft()
        _DIRTY_SET.discard(removed)
    _DIRTY_NAMES.append(text)
    _DIRTY_SET.add(text)


def _queue_relevant_context_armatures() -> int:
    """Queue active/selected armatures without scanning ``bpy.data.objects``."""
    queued = 0
    seen: set[int] = set()
    try:
        context = bpy.context
        values = (getattr(context, 'object', None),) + tuple(
            getattr(context, 'selected_objects', ()) or ()
        )
    except Exception:
        values = ()
    for obj in values:
        if obj is None or getattr(obj, 'type', '') != 'ARMATURE' or id(obj) in seen:
            continue
        seen.add(id(obj))
        before = len(_DIRTY_SET)
        _queue_name(str(getattr(obj, 'name', '') or ''))
        queued += int(len(_DIRTY_SET) > before)
    return queued


def mark_armature_dirty(value: Any = None, *, all_armatures: bool = False) -> None:
    """Queue one armature or the finite current-context armature set.

    ``all_armatures`` is retained for API compatibility but deliberately means
    "all relevant armatures in the current event context". It never initiates a
    database-wide object or PoseLib scan.
    """
    if all_armatures:
        _queue_relevant_context_armatures()
    else:
        name = value if isinstance(value, str) else getattr(value, 'name', '')
        _queue_name(str(name or ''))
    _schedule_flush()


def _process_armature_object(arm: Any) -> None:
    if arm is None or getattr(arm, 'type', '') != 'ARMATURE':
        return
    data = getattr(arm, 'data', None)
    if data is None:
        return

    if getattr(data, 'library', None) is not None or getattr(data, 'override_library', None) is not None:
        ensure_proxy_obj(arm)

    poselib = get_poselib(arm)
    if poselib is not None:
        poselib.ensure_actions()

    if getattr(data, 'library', None) is not None or getattr(data, 'override_library', None) is not None:
        return
    for bone in tuple(getattr(data, 'bones', ()) or ()):
        old_name = bone.get('spl_bone_name_backup', None)
        if old_name is None:
            bone['spl_bone_name_backup'] = bone.name
            continue
        if bone.name == old_name:
            continue
        if poselib is not None:
            for book in tuple(getattr(poselib, 'books', ()) or ()):
                for pose in tuple(getattr(book, 'poses', ()) or ()):
                    for bone_data in tuple(getattr(pose, 'bones', ()) or ()):
                        if bone_data.name == old_name:
                            bone_data.name = bone.name
        bone['spl_bone_name_backup'] = bone.name


def _flush_dirty_queue():
    """Drain the bounded queue once and always stop the app timer."""
    if not _BACKGROUND_ENABLED:
        _DIRTY_NAMES.clear()
        _DIRTY_SET.clear()
        return None
    while _DIRTY_NAMES:
        name = _DIRTY_NAMES.popleft()
        _DIRTY_SET.discard(name)
        try:
            arm = bpy.data.objects.get(name)
        except Exception:
            arm = None
        try:
            _process_armature_object(arm)
        except Exception:
            pass
    return None


def timed_handler_every_second():
    """Compatibility symbol retained for old generations; never reschedules."""
    return None


def on_bone_rename(*_args):
    if not _BACKGROUND_ENABLED:
        return None
    _queue_relevant_context_armatures()
    _schedule_flush()
    return None


_MSG_HANDLERS = (
    ((bpy.types.Bone, 'name'), on_bone_rename),
    ((bpy.types.PoseBone, 'name'), on_bone_rename),
)


def register_msgbus() -> bool:
    if not _BACKGROUND_ENABLED:
        return False
    unregister_msgbus()
    acquired = False
    try:
        for datapath, callback in _MSG_HANDLERS:
            result = bpy.msgbus.subscribe_rna(
                owner=_MSGBUS_OWNER, key=datapath, args=(), notify=callback,
            )
            if result is False:
                unregister_msgbus()
                return False
            acquired = True
    except Exception:
        unregister_msgbus()
        return False
    return acquired


def unregister_msgbus() -> None:
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass


def on_load(_dummy=None):
    """Finite explicit load-boundary refresh; not installed as a handler here."""
    if not _BACKGROUND_ENABLED:
        return None
    register_msgbus()
    mark_armature_dirty(all_armatures=True)
    return None


def enable_background_handlers() -> bool:
    global _BACKGROUND_ENABLED
    _BACKGROUND_ENABLED = True
    if not register_msgbus():
        _BACKGROUND_ENABLED = False
        return False
    mark_armature_dirty(all_armatures=True)
    return True


def disable_background_handlers() -> bool:
    global _BACKGROUND_ENABLED
    _BACKGROUND_ENABLED = False
    _unregister_flush_timer()
    unregister_msgbus()
    _DIRTY_NAMES.clear()
    _DIRTY_SET.clear()
    return True


def register() -> bool:
    disable_background_handlers()
    return True


def unregister() -> bool:
    disable_background_handlers()
    return True
