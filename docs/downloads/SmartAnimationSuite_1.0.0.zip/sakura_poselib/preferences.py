# Description: Integrated runtime default settings

import bpy
from bpy.props import *

# Integrated runtime settings proxy
class SPL_Preferences:
    bl_idname = __package__

    # dev_mode : bpy.props.BoolProperty(
    #     name = 'Developer Mode',
    #     description = 'Show developer UI items',
    #     default = DEV_MODE,
    # )

    show_alt_pose_names: BoolProperty(
		name="Show Alt Names",
		description="Show alternative pose names. Mainly intended for translation. Not used as identifier in blender",
		default=True, 
		)

    show_apply_buttons: BoolProperty(
        name="Show Apply Buttons",
        description="Show apply buttons in the pose list",
        default=False,
    )

    show_select_bones_buttons: BoolProperty(
        name="Show Select Bones Buttons",
        description="Show select bones buttons in the pose list",
        default=False,
    )

    show_replace_buttons: BoolProperty(
        name="Show Replace Buttons",
        description="Show replace buttons in the pose list",
        default=True,
    )

    activate_poses_on_book_change: BoolProperty(
        name="Activate Poses on Book Change",
        description="Activate the poses on the active book when the active book is changed",
        default=False,
    )

    confirm_on_replace: BoolProperty(
        name="Confirm on Replace Pose",
        description="Show a confirmation dialog when replacing a pose",
        default=False,
    )

    def draw(self,context: bpy.types.Context):
        layout:bpy.types.UILayout = self.layout

        # Pose List Display Settings
        box = layout.box()
        box.label(text="Pose List Display Settings")
        flow = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
        flow.prop(self, "show_alt_pose_names", icon='TEXT')
        flow.prop(self, "show_apply_buttons", icon='VIEWZOOM')
        flow.prop(self, "show_select_bones_buttons", icon='RESTRICT_SELECT_OFF' )
        flow.prop(self, "show_replace_buttons", icon='GREASEPENCIL')

        # Basic Behaviour Settings
        box = layout.box()
        box.label(text="Basic Behaviour Settings")
        box.prop(self, "activate_poses_on_book_change", icon='FILE_REFRESH')
        box.prop(self, "confirm_on_replace", icon='CHECKMARK')

        # Developer Settings
        # box = layout.box()
        # box.label(text="Developer Settings")
        # box.prop(self, "dev_mode")

        return

_classes = (
    SPL_Preferences,
)


# Register & Unregister
def register():
    # Add-on Preferences are not registered in the integrated Smart Animation build.
    return None

def unregister():
    return None

