# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import csv
import os
from pathlib import Path

import bpy

_trans_table = {}
_trans_dir = 'language'
_delimiters = {'.csv': ',', '.tsv': '\t'}
_TRANSLATION_OWNER = None
_MAX_TRANSLATION_FILE_BYTES = 2 * 1024 * 1024
_MAX_TRANSLATION_ROWS = 20000


def _load_translation_table() -> dict:
    table: dict = {}
    root = Path(__file__).resolve().parent / _trans_dir
    if not root.is_dir():
        return table
    rows_seen = 0
    for locale in sorted((entry for entry in root.iterdir() if entry.is_dir()), key=lambda item: item.name):
        locale_map = table.setdefault(locale.name, {})
        for entry in sorted(locale.iterdir(), key=lambda item: item.name):
            delimiter = _delimiters.get(entry.suffix.lower())
            if delimiter is None or not entry.is_file():
                continue
            try:
                if entry.stat().st_size > _MAX_TRANSLATION_FILE_BYTES:
                    continue
                with entry.open('r', encoding='utf-8-sig', newline='') as handle:
                    reader = csv.reader(handle, delimiter=delimiter)
                    next(reader, None)
                    for row in reader:
                        rows_seen += 1
                        if rows_seen > _MAX_TRANSLATION_ROWS:
                            return table
                        if len(row) < 3:
                            continue
                        category, english, translated = (str(row[0]).strip(), str(row[1]).strip(), str(row[2]).strip())
                        if not english or not translated:
                            continue
                        if category == '':
                            category = '*'
                        elif category == 'O':
                            category = 'Operator'
                        locale_map[(category, english)] = translated
            except (OSError, UnicodeError, csv.Error):
                continue
        if not locale_map:
            table.pop(locale.name, None)
    return table


def register():
    global _trans_table, _TRANSLATION_OWNER
    _trans_table = _load_translation_table()
    if not _trans_table:
        _TRANSLATION_OWNER = None
        return True
    owner = f'{__name__}.g{id(register):x}'
    try:
        result = bpy.app.translations.register(owner, _trans_table)
    except Exception:
        result = False
    if result is False:
        _TRANSLATION_OWNER = None
        _trans_table = {}
        return False
    _TRANSLATION_OWNER = owner
    return True


def unregister():
    global _TRANSLATION_OWNER
    owner = _TRANSLATION_OWNER
    if owner:
        try:
            bpy.app.translations.unregister(owner)
        except Exception:
            pass
    _TRANSLATION_OWNER = None
    return True
