# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import math

import bpy
from bpy.types import Operator
from mathutils import Vector

from .translation import sas_error_reason, sas_text
from .action_compat import sync_nla_strip_action_slot
from .core import (
    active_action,
    active_object,
    add_log,
    ensure_action_backup,
    ensure_object_animation_data,
    filter_editable_fcurves,
    fcurve_is_editable,
    get_or_create_action_for_object,
    get_bake_range,
    get_timing_range,
    iter_action_fcurves,
    safe_remove_keyframe_points,
    selected_fcurves,
    unique_nla_track_name,
)


# -----------------------------------------------------------------------------
# Local helpers
# -----------------------------------------------------------------------------


def _editable_action_curves(context, action, obj=None, only_location=False):
    obj = obj or active_object(context)
    settings = context.scene.sas_settings
    curves = selected_fcurves(context, action, obj=obj)
    if not curves:
        curves = filter_editable_fcurves(iter_action_fcurves(action, datablock=obj), settings)
    if only_location:
        curves = [curve for curve in curves if "location" in getattr(curve, "data_path", "")]
    return curves



def _remove_track_collection_item(collection, item):
    try:
        collection.remove(item)
        return True
    except Exception:
        pass
    try:
        index = list(collection).index(item)
        collection.remove(index)
        return True
    except Exception:
        return False



def _remove_tracks_by_prefix(anim_data, prefixes):
    removed = 0
    tracks = getattr(anim_data, "nla_tracks", None)
    if tracks is None:
        return removed
    prefixes = tuple(prefixes)
    for track in list(tracks):
        if getattr(track, "name", "").startswith(prefixes):
            if _remove_track_collection_item(tracks, track):
                removed += 1
    return removed



def _selected_cameras(context):
    cameras = [obj for obj in (context.selected_objects or []) if getattr(obj, "type", "") == 'CAMERA']
    active = active_object(context)
    if active is not None and getattr(active, "type", "") == 'CAMERA' and active not in cameras:
        cameras.append(active)
    if not cameras and getattr(context.scene, "camera", None) is not None:
        cameras = [context.scene.camera]
    return cameras



def _remove_existing_sas_shot_markers(scene):
    removed = 0
    markers = getattr(scene, "timeline_markers", None)
    if markers is None:
        return removed
    for marker in list(markers):
        has_camera = getattr(marker, "camera", None) is not None
        if getattr(marker, "name", "").startswith("SAS_SHOT_") or has_camera and getattr(marker, "name", "").startswith("SAS_CAM_"):
            try:
                markers.remove(marker)
                removed += 1
            except Exception:
                pass
    return removed



def _curve_key_indices_in_span(fcurve, start_frame, end_frame):
    indices = []
    for index, key in enumerate(getattr(fcurve, "keyframe_points", []) or []):
        try:
            frame = float(key.co.x)
        except Exception:
            continue
        if float(start_frame) <= frame <= float(end_frame):
            indices.append(index)
    return indices



def _find_or_insert_key(fcurve, frame, value):
    for key in getattr(fcurve, "keyframe_points", []) or []:
        try:
            if abs(float(key.co.x) - float(frame)) <= 1.0e-6:
                key.co.y = float(value)
                return key
        except Exception:
            continue
    try:
        return fcurve.keyframe_points.insert(float(frame), float(value), options={'FAST'})
    except Exception:
        try:
            return fcurve.keyframe_points.insert(float(frame), float(value))
        except Exception:
            return None



def _apply_hold_span_to_curve(fcurve, start_frame, end_frame, hold_value):
    if fcurve is None or end_frame <= start_frame:
        return 0
    removed = safe_remove_keyframe_points(fcurve, _curve_key_indices_in_span(fcurve, start_frame, end_frame))
    start_key = _find_or_insert_key(fcurve, start_frame, hold_value)
    end_key = _find_or_insert_key(fcurve, end_frame, hold_value)
    inserted = int(start_key is not None) + int(end_key is not None)
    if start_key is not None:
        try:
            start_key.interpolation = 'CONSTANT'
        except Exception:
            pass
        for attr in ('handle_left_type', 'handle_right_type'):
            try:
                setattr(start_key, attr, 'VECTOR')
            except Exception:
                pass
    if end_key is not None:
        try:
            end_key.interpolation = 'BEZIER'
        except Exception:
            pass
        for attr in ('handle_left_type', 'handle_right_type'):
            try:
                setattr(end_key, attr, 'AUTO_CLAMPED')
            except Exception:
                pass
    try:
        fcurve.update()
    except Exception:
        pass
    return removed + inserted



def _detect_low_motion_spans(samples, threshold, min_hold_frames):
    spans = []
    if len(samples) < 2:
        return spans
    start_index = None
    last_index = None
    for index in range(1, len(samples)):
        delta = abs(float(samples[index]) - float(samples[index - 1]))
        if delta <= float(threshold):
            if start_index is None:
                start_index = index - 1
            last_index = index
        else:
            if start_index is not None and last_index is not None:
                if (last_index - start_index + 1) >= int(min_hold_frames):
                    spans.append((start_index, last_index))
            start_index = None
            last_index = None
    if start_index is not None and last_index is not None:
        if (last_index - start_index + 1) >= int(min_hold_frames):
            spans.append((start_index, last_index))
    return spans



def _axis_vector(identifier):
    mapping = {
        'X_POS': Vector((1.0, 0.0, 0.0)),
        'X_NEG': Vector((-1.0, 0.0, 0.0)),
        'Y_POS': Vector((0.0, 1.0, 0.0)),
        'Y_NEG': Vector((0.0, -1.0, 0.0)),
        'Z_POS': Vector((0.0, 0.0, 1.0)),
        'Z_NEG': Vector((0.0, 0.0, -1.0)),
    }
    return mapping.get(identifier, Vector((0.0, 0.0, 1.0)))



def _ordered_selected_objects(context, mode='SELECTION'):
    objects = list(context.selected_objects or [])
    if mode == 'NAME':
        objects.sort(key=lambda obj: getattr(obj, 'name', '').lower())
    elif mode in {'X', 'Y', 'Z'}:
        axis = {'X': 0, 'Y': 1, 'Z': 2}[mode]

        def _coord(obj):
            try:
                return float(obj.location[axis])
            except Exception:
                return 0.0

        objects.sort(key=_coord)
    return objects




def _area_window_region(area):
    for region in getattr(area, 'regions', []) or []:
        if getattr(region, 'type', '') == 'WINDOW':
            return region
    return None



def _find_screen_area(context, area_type='VIEW_3D'):
    area = getattr(context, 'area', None)
    if area is not None and getattr(area, 'type', '') == area_type:
        return area
    for candidate in getattr(getattr(context, 'screen', None), 'areas', []) or []:
        if getattr(candidate, 'type', '') == area_type:
            return candidate
    return None



def _configure_review_view(area, scene, camera_view=False, lock_camera=True):
    if area is None:
        return False
    try:
        area.type = 'VIEW_3D'
    except Exception:
        return False
    for space in getattr(area, 'spaces', []) or []:
        if getattr(space, 'type', '') != 'VIEW_3D':
            continue
        if camera_view:
            if getattr(scene, 'camera', None) is not None:
                try:
                    space.region_3d.view_perspective = 'CAMERA'
                except Exception:
                    pass
            try:
                space.lock_camera = bool(lock_camera)
            except Exception:
                pass
        else:
            try:
                if getattr(space, 'region_3d', None) and getattr(space.region_3d, 'view_perspective', '') == 'CAMERA':
                    space.region_3d.view_perspective = 'PERSP'
            except Exception:
                pass
            try:
                space.lock_camera = False
            except Exception:
                pass
        return True
    return False



def _clear_object_transform_keys_in_range(context, obj, action, start_frame, end_frame):
    if action is None:
        return 0
    settings = context.scene.sas_settings
    removed = 0
    transform_paths = {'location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale'}
    for fcurve in iter_action_fcurves(action, datablock=obj):
        if getattr(fcurve, 'data_path', '') not in transform_paths:
            continue
        if not fcurve_is_editable(fcurve, settings):
            continue
        removed += safe_remove_keyframe_points(fcurve, _curve_key_indices_in_span(fcurve, start_frame, end_frame))
    return removed


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


class SAS_OT_build_camera_sequence(Operator):
    bl_idname = "sas.build_camera_sequence"
    bl_label = "Build Camera Sequence"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a compact camera-shot marker sequence from the selected cameras, or the scene camera when nothing else is selected. This gives Blender a practical Camera Animator / shot-board style setup without hand-placing every cut marker.",
            "選択カメラ、または未選択時はシーンカメラから、コンパクトなカメラショット用マーカー列を作成します。すべてのカットマーカーを手で置かなくても、Blender で実用的な Camera Animator / ショットボード風セットアップを作れます。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        cameras = _selected_cameras(context)
        if not cameras:
            self.report({'WARNING'}, sas_text("No camera was found. Select one or more cameras, or assign a scene camera first.", "カメラが見つかりません。1 つ以上のカメラを選択するか、先にシーンカメラを設定してください。", context))
            add_log(context, "WARN", "Build Camera Sequence cancelled because no camera could be resolved.", "対象カメラを解決できないため Camera Sequence 作成を中止しました。")
            return {'CANCELLED'}

        shot_length = max(1, int(settings.camera_sequence_shot_length))
        gap = max(0, int(settings.camera_sequence_gap))
        start_frame = int(settings.camera_sequence_start)
        end_frame = start_frame + len(cameras) * shot_length + max(0, len(cameras) - 1) * gap - 1

        if settings.preview_only:
            message_en = f"Camera Sequence Preview — {len(cameras)} shot(s), frames {start_frame}-{end_frame}, shot length {shot_length}, gap {gap}."
            message_ja = f"Camera Sequence プレビュー — {len(cameras)} ショット、範囲 {start_frame}-{end_frame}、ショット長 {shot_length}、ギャップ {gap}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        removed = 0
        if settings.camera_sequence_clear_existing:
            removed = _remove_existing_sas_shot_markers(scene)

        current_frame = start_frame
        created = 0
        for index, camera in enumerate(cameras, start=1):
            marker_name = f"SAS_SHOT_{index:03d}_{camera.name}"
            try:
                marker = scene.timeline_markers.new(marker_name, frame=current_frame)
                marker.camera = camera
                created += 1
            except Exception:
                continue
            current_frame += shot_length + gap

        if created == 0:
            self.report({'ERROR'}, sas_text("No shot markers could be created.", "ショットマーカーを作成できませんでした。", context))
            add_log(context, "ERROR", "Build Camera Sequence failed because Blender did not create any markers.", "Blender がマーカーを 1 つも作成できなかったため Camera Sequence 作成に失敗しました。")
            return {'CANCELLED'}

        if settings.camera_sequence_set_preview:
            try:
                scene.use_preview_range = True
                scene.frame_preview_start = start_frame
                scene.frame_preview_end = end_frame
            except Exception:
                pass

        self.report({'INFO'}, sas_text(f"Created {created} camera shot marker(s) from frame {start_frame} to {end_frame}.", f"フレーム {start_frame} から {end_frame} にかけて {created} 個のカメラショットマーカーを作成しました。", context))
        add_log(context, "INFO", f"Built {created} camera-shot markers with length {shot_length} and gap {gap}; removed {removed} older SAS markers.", f"ショット長 {shot_length}、ギャップ {gap} で {created} 個のカメラショットマーカーを作成し、古い SAS マーカー {removed} 個を整理しました。")
        return {'FINISHED'}


class SAS_OT_sequence_library_actions(Operator):
    bl_idname = "sas.sequence_library_actions"
    bl_label = "Sequence Library to NLA"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Lay out every stored motion-library action as sequential NLA clips on the active object. This is a compact Story / Motion Mixer style assembler for quickly blocking a longer shot from reusable motion clips.",
            "保存済みモーションライブラリアクションを、アクティブオブジェクト上で順番に NLA クリップ化します。再利用モーションから長めのショットを素早く組み立てるための、コンパクトな Story / Motion Mixer 風アセンブラです。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        if obj is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "Sequence Library to NLA cancelled because no active object exists.", "アクティブオブジェクトがないため Library Sequence を中止しました。")
            return {'CANCELLED'}
        if not settings.action_library:
            self.report({'WARNING'}, sas_text("The motion library is empty.", "モーションライブラリが空です。", context))
            add_log(context, "WARN", "Sequence Library to NLA cancelled because the motion library is empty.", "モーションライブラリが空のため Library Sequence を中止しました。")
            return {'CANCELLED'}

        clips = []
        missing = 0
        for item in settings.action_library:
            action = bpy.data.actions.get(item.action_name)
            if action is None:
                missing += 1
                continue
            try:
                action_range = getattr(action, 'frame_range', None)
                span = max(1, int(math.ceil(float(action_range[1]) - float(action_range[0])))) if action_range else 1
            except Exception:
                span = 1
            clips.append((action, span))

        if not clips:
            self.report({'WARNING'}, sas_text("No valid actions were found in the motion library.", "モーションライブラリ内に有効なアクションが見つかりません。", context))
            add_log(context, "WARN", "Sequence Library to NLA found no valid actions after skipping missing entries.", "欠損エントリを除外した結果、有効なライブラリアクションがありませんでした。")
            return {'CANCELLED'}

        start_frame = int(settings.library_sequence_start)
        gap = max(0, int(settings.library_sequence_gap))
        total_end = start_frame + sum(span for _action, span in clips) + gap * max(0, len(clips) - 1)

        if settings.preview_only:
            message_en = f"Library Sequence Preview — {len(clips)} clip(s), frames {start_frame}-{total_end}, gap {gap}, missing {missing}."
            message_ja = f"Library Sequence プレビュー — {len(clips)} クリップ、範囲 {start_frame}-{total_end}、ギャップ {gap}、欠損 {missing}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        anim_data = ensure_object_animation_data(obj)
        if anim_data is None:
            self.report({'ERROR'}, sas_text("Animation data could not be created on the active object.", "アクティブオブジェクトにアニメーションデータを作成できませんでした。", context))
            add_log(context, "ERROR", "Sequence Library to NLA failed because animation data could not be created.", "アニメーションデータを作成できないため Library Sequence に失敗しました。")
            return {'CANCELLED'}

        removed_tracks = 0
        if settings.library_sequence_clear_existing:
            removed_tracks = _remove_tracks_by_prefix(anim_data, ("SAS_SEQ_", "SAS_STORY_"))

        track = anim_data.nla_tracks.new()
        track.name = unique_nla_track_name(anim_data, "SAS_SEQ")
        cursor = start_frame
        created = 0
        for action, span in clips:
            try:
                strip = track.strips.new(action.name, cursor, action)
                strip.frame_start = cursor
                strip.frame_end = max(cursor + 1, cursor + span)
                try:
                    strip.blend_type = settings.nla_blend_mode
                except Exception:
                    pass
                sync_nla_strip_action_slot(strip, obj, action=action)
                created += 1
                cursor = int(math.ceil(float(strip.frame_end))) + gap
            except Exception:
                continue

        if created == 0:
            try:
                anim_data.nla_tracks.remove(track)
            except Exception:
                pass
            self.report({'ERROR'}, sas_text("No NLA clips could be created from the motion library.", "モーションライブラリから NLA クリップを作成できませんでした。", context))
            add_log(context, "ERROR", "Sequence Library to NLA failed because no strips were created.", "ストリップを 1 つも作成できないため Library Sequence に失敗しました。")
            return {'CANCELLED'}

        self.report({'INFO'}, sas_text(f"Sequenced {created} library clip(s) to NLA from frame {start_frame} to {cursor - gap}.", f"フレーム {start_frame} から {cursor - gap} にかけて {created} 個のライブラリクリップを NLA へ並べました。", context))
        add_log(context, "INFO", f"Sequenced {created} motion-library actions onto '{obj.name}' using NLA gap {gap}; skipped {missing} missing entries and removed {removed_tracks} older SAS sequence tracks.", f"NLA ギャップ {gap} で '{obj.name}' に {created} 個のモーションライブラリアクションを並べ、欠損 {missing} 件をスキップし、古い SAS シーケンストラック {removed_tracks} 本を整理しました。")
        return {'FINISHED'}


class SAS_OT_auto_fulcrum_cleanup(Operator):
    bl_idname = "sas.auto_fulcrum_cleanup"
    bl_label = "Auto Fulcrum Cleanup"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Detect low-motion spans across the current timing range and convert them into planted holds. This is a practical Fulcrum / foot-slide cleanup helper for translation curves when you want contacts to stay locked without manually setting every hold range.",
            "現在のタイミング範囲内で低移動スパンを検出し、接地ホールドへ変換します。毎回手動で保持範囲を設定しなくても、平行移動カーブのコンタクトをロックしやすくする、実用的な Fulcrum / 足滑りクリーンアップ補助です。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj)
        settings = context.scene.sas_settings
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to clean.", "整理するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Auto Fulcrum Cleanup cancelled because there is no active action.", "アクティブアクションがないため Auto Fulcrum Cleanup を中止しました。")
            return {'CANCELLED'}

        curves = _editable_action_curves(context, action, obj=obj, only_location=settings.fulcrum_only_location)
        if not curves:
            self.report({'WARNING'}, sas_text("No eligible curves were found. Try selecting location curves or disable Location Only.", "対象カーブが見つかりません。位置カーブを選択するか、Location Only を無効にしてください。", context))
            add_log(context, "WARN", "Auto Fulcrum Cleanup found no eligible curves.", "対象カーブがないため Auto Fulcrum Cleanup を中止しました。")
            return {'CANCELLED'}

        start, end = get_timing_range(context, action, settings)
        frames = list(range(int(math.floor(start)), int(math.ceil(end)) + 1))
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text("The timing range is too short for automatic fulcrum cleanup.", "自動フルクラム整理にはタイミング範囲が短すぎます。", context))
            add_log(context, "WARN", "Auto Fulcrum Cleanup found a timing range that was too short.", "タイミング範囲が短すぎるため Auto Fulcrum Cleanup を中止しました。")
            return {'CANCELLED'}

        threshold = max(0.0, float(settings.fulcrum_velocity_threshold))
        min_hold = max(2, int(settings.fulcrum_min_hold))
        span_total = 0
        affected_curves = 0
        pending = []
        for fcurve in curves:
            samples = [float(fcurve.evaluate(frame)) for frame in frames]
            spans = _detect_low_motion_spans(samples, threshold, min_hold)
            if not spans:
                continue
            localized = []
            for start_index, end_index in spans:
                span_frames = frames[start_index:end_index + 1]
                span_samples = samples[start_index:end_index + 1]
                if len(span_frames) < min_hold:
                    continue
                localized.append((span_frames[0], span_frames[-1], sum(span_samples) / max(1, len(span_samples))))
            if localized:
                pending.append((fcurve, localized))
                affected_curves += 1
                span_total += len(localized)

        if span_total == 0:
            self.report({'INFO'}, sas_text("No low-motion spans matched the current fulcrum settings.", "現在のフルクラム設定に一致する低移動スパンは見つかりませんでした。", context))
            add_log(context, "INFO", "Auto Fulcrum Cleanup found no low-motion spans.", "Auto Fulcrum Cleanup では低移動スパンが見つかりませんでした。")
            return {'CANCELLED'}

        if settings.preview_only:
            message_en = f"Fulcrum Cleanup Preview — {span_total} hold span(s) across {affected_curves} curve(s), threshold {threshold:.4f}, minimum hold {min_hold} frames."
            message_ja = f"Fulcrum Cleanup プレビュー — {affected_curves} 本のカーブ上に {span_total} 個の保持スパン、しきい値 {threshold:.4f}、最小保持 {min_hold} フレーム。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "fulcrum_cleanup", obj=obj, action=action)
        modified = 0
        for fcurve, spans in pending:
            for start_frame, end_frame, hold_value in reversed(spans):
                modified += _apply_hold_span_to_curve(fcurve, start_frame, end_frame, hold_value)

        self.report({'INFO'}, sas_text(f"Converted {span_total} low-motion span(s) into planted holds across {affected_curves} curve(s).", f"{affected_curves} 本のカーブ上で {span_total} 個の低移動スパンを接地ホールドへ変換しました。", context))
        add_log(context, "INFO", f"Auto Fulcrum Cleanup converted {span_total} spans into planted holds across {affected_curves} curves; modified {modified} key items with threshold {threshold:.4f} and minimum hold {min_hold}.", f"しきい値 {threshold:.4f}、最小保持 {min_hold} で {affected_curves} 本のカーブ上の {span_total} スパンを接地ホールドへ変換し、{modified} 個のキー項目を変更しました。")
        return {'FINISHED'}


class SAS_OT_transform_reveal(Operator):
    bl_idname = "sas.transform_reveal"
    bl_label = "Transform Reveal"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a compact reveal animation by offsetting selected objects from an axis and keying them back into place with per-object stagger. This is a Blender-friendly transform-board helper inspired by batch motion tools used in motion graphics and previs workflows.",
            "選択オブジェクトを指定軸方向へオフセットした状態から、段差付きで元位置へ戻すコンパクトなリビールアニメーションを作成します。モーショングラフィックスやプリビズで使われる一括モーション系ツールを、Blender で扱いやすく寄せた Transform ボード補助です。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        objects = _ordered_selected_objects(context, mode=settings.transform_reveal_order)
        if not objects:
            self.report({'WARNING'}, sas_text("Select one or more objects first.", "先に 1 つ以上のオブジェクトを選択してください。", context))
            add_log(context, "WARN", "Transform Reveal cancelled because no objects were selected.", "オブジェクトが選択されていないため Transform Reveal を中止しました。")
            return {'CANCELLED'}

        start_frame = int(scene.frame_current)
        distance = float(settings.transform_reveal_distance)
        stagger = max(0, int(settings.transform_reveal_stagger))
        duration = max(1, int(settings.transform_reveal_duration))
        axis_vector = _axis_vector(settings.transform_reveal_axis) * distance
        end_frame = start_frame + max(0, len(objects) - 1) * stagger + duration

        if settings.preview_only:
            message_en = f"Transform Reveal Preview — {len(objects)} object(s), frames {start_frame}-{end_frame}, distance {distance:.3f}, stagger {stagger}, duration {duration}."
            message_ja = f"Transform Reveal プレビュー — {len(objects)} オブジェクト、範囲 {start_frame}-{end_frame}、距離 {distance:.3f}、段差 {stagger}、時間 {duration}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        original_locations = {obj: obj.location.copy() for obj in objects}
        backed_up = 0
        keyed = 0
        for index, obj in enumerate(objects):
            action = active_action(context, obj)
            if action is not None:
                backup = ensure_action_backup(context, "transform_reveal", obj=obj, action=action)
                if backup is not None:
                    backed_up += 1
            get_or_create_action_for_object(obj, base_name=f"{obj.name}_Reveal")
            reveal_start = start_frame + index * stagger
            reveal_end = reveal_start + duration
            final_location = original_locations[obj].copy()
            try:
                obj.location = final_location + axis_vector
                obj.keyframe_insert(data_path="location", frame=reveal_start)
                keyed += 1
                obj.location = final_location
                obj.keyframe_insert(data_path="location", frame=reveal_end)
                keyed += 1
            except Exception:
                continue
            finally:
                try:
                    obj.location = final_location
                except Exception:
                    pass

        self.report({'INFO'}, sas_text(f"Created a transform reveal for {len(objects)} object(s) from frame {start_frame} to {end_frame}.", f"フレーム {start_frame} から {end_frame} にかけて {len(objects)} オブジェクトの Transform Reveal を作成しました。", context))
        add_log(context, "INFO", f"Created a transform reveal for {len(objects)} selected objects with distance {distance:.3f}, stagger {stagger}, duration {duration}, and {backed_up} action backups.", f"距離 {distance:.3f}、段差 {stagger}、時間 {duration} で {len(objects)} 個の選択オブジェクトに Transform Reveal を作成し、{backed_up} 件のアクションバックアップを作成しました。")
        return {'FINISHED'}


class SAS_OT_create_camera_review_split(Operator):
    bl_idname = "sas.create_camera_review_split"
    bl_label = "Create Camera Review Split"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Split the current 3D View into a free review view and a locked camera view so you can pose from one side while judging the shot from the other. This is a compact Blender answer to Tear Off Viewport style shot review.",
            "現在の 3D ビューを自由レビュー用と固定カメラ用に分割し、片側でポーズを触りながら、もう片側でショットの見え方を判断できるようにします。Tear Off Viewport 風ショット確認へのコンパクトな Blender 解です。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        area = _find_screen_area(context, 'VIEW_3D')
        if area is None:
            self.report({'WARNING'}, sas_text("Open a 3D View area first.", "先に 3D ビュー領域を開いてください。", context))
            add_log(context, "WARN", "Create Camera Review Split cancelled because no 3D View area was available.", "利用可能な 3D ビュー領域がないため Camera Review Split を中止しました。")
            return {'CANCELLED'}
        if getattr(scene, 'camera', None) is None:
            self.report({'WARNING'}, sas_text("Assign a scene camera first.", "先にシーンカメラを設定してください。", context))
            add_log(context, "WARN", "Create Camera Review Split cancelled because the scene camera was missing.", "シーンカメラが未設定のため Camera Review Split を中止しました。")
            return {'CANCELLED'}

        factor = max(0.20, min(0.80, float(settings.camera_review_split_factor)))
        direction = getattr(settings, 'camera_review_split_direction', 'VERTICAL')
        lock_camera = bool(getattr(settings, 'camera_review_lock_camera', True))

        if settings.preview_only:
            message_en = f"Camera Review Split Preview — direction {direction}, ratio {factor:.2f}, camera lock {'On' if lock_camera else 'Off'}."
            message_ja = f"Camera Review Split プレビュー — 方向 {direction}、比率 {factor:.2f}、カメラ固定 {'有効' if lock_camera else '無効'}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        before_pointers = {existing.as_pointer() for existing in context.screen.areas}
        override = {"window": context.window, "screen": context.screen, "area": area}
        window_region = _area_window_region(area)
        if window_region is not None:
            override["region"] = window_region

        try:
            with context.temp_override(**override):
                bpy.ops.screen.area_split(direction=direction, factor=factor)
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"View split failed: {exc}", f"ビュー分割に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Create Camera Review Split failed: {exc}", f"カメラ確認用の分割に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}

        new_area = next((candidate for candidate in context.screen.areas
                         if candidate.as_pointer() not in before_pointers), None)
        configured_camera = _configure_review_view(new_area, scene, camera_view=True, lock_camera=lock_camera)
        if configured_camera:
            _configure_review_view(area, scene, camera_view=False, lock_camera=False)

        if not configured_camera:
            self.report({'WARNING'}, sas_text("The view was split, but the new camera side could not be configured cleanly.", "ビューは分割されましたが、新しいカメラ側を正常に設定できませんでした。", context))
            add_log(context, "WARN", "Camera Review Split created a split but could not fully configure the camera side.", "Camera Review Split で分割はできましたが、カメラ側の設定を完全には行えませんでした。")
            return {'CANCELLED'}

        self.report({'INFO'}, sas_text("Created a dual review layout with a camera view and a free view.", "カメラビューと自由ビューの 2 画面レビューを作成しました。", context))
        add_log(context, "INFO", f"Created a camera review split with direction {direction}, ratio {factor:.2f}, and camera lock {'On' if lock_camera else 'Off'}.", f"方向 {direction}、比率 {factor:.2f}、カメラ固定 {'有効' if lock_camera else '無効'} で Camera Review Split を作成しました。")
        return {'FINISHED'}


class SAS_OT_bake_rigid_body_keys(Operator):
    bl_idname = "sas.bake_rigid_body_keys"
    bl_label = "Bake Rigid Body Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Sample selected rigid-body objects over the chosen bake range and write the result as editable transform keys. This gives Blender a practical baked-dynamics / ragdoll handoff step without leaving the Smart Animation workspace.",
            "選択したリジッドボディオブジェクトを指定ベイク範囲でサンプリングし、編集可能な変形キーとして書き出します。Smart Animation ワークスペースから離れず、実用的な Baked Dynamics / ラグドール受け渡し工程を作れます。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        objects = [obj for obj in (context.selected_objects or []) if getattr(obj, 'rigid_body', None) is not None]
        active = active_object(context)
        if not objects and active is not None and getattr(active, 'rigid_body', None) is not None:
            objects = [active]
        if not objects:
            self.report({'WARNING'}, sas_text("Select one or more rigid-body objects first.", "先に 1 つ以上のリジッドボディオブジェクトを選択してください。", context))
            add_log(context, "WARN", "Bake Rigid Body Keys cancelled because no rigid-body objects were selected.", "リジッドボディオブジェクトが選択されていないため Rigid Body キーベイクを中止しました。")
            return {'CANCELLED'}

        start_frame, end_frame = get_bake_range(scene, settings)
        step = max(1, int(settings.frame_step))

        if settings.preview_only:
            message_en = f"Rigid Body Bake Preview — {len(objects)} object(s), frames {start_frame}-{end_frame}, step {step}, clear existing range {'On' if settings.physics_bake_clear_range else 'Off'}."
            message_ja = f"Rigid Body ベイクプレビュー — {len(objects)} オブジェクト、範囲 {start_frame}-{end_frame}、間隔 {step}、既存範囲消去 {'有効' if settings.physics_bake_clear_range else '無効'}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        original_frame = int(getattr(scene, 'frame_current', start_frame))
        backed_up = 0
        removed = 0
        keyed = 0
        failures = 0

        try:
            for obj in objects:
                existing_action = active_action(context, obj=obj)
                if existing_action is not None:
                    backup = ensure_action_backup(context, "rigidbody_bake", obj=obj, action=existing_action)
                    if backup is not None:
                        backed_up += 1
                action = get_or_create_action_for_object(obj, base_name=f"{obj.name}_Physics")
                if settings.physics_bake_clear_range:
                    removed += _clear_object_transform_keys_in_range(context, obj, action, start_frame, end_frame)

            for frame in range(start_frame, end_frame + 1, step):
                scene.frame_set(frame)
                try:
                    context.view_layer.update()
                except Exception:
                    pass
                for obj in objects:
                    rotation_path = 'rotation_quaternion' if getattr(obj, 'rotation_mode', 'XYZ') == 'QUATERNION' else ('rotation_axis_angle' if getattr(obj, 'rotation_mode', 'XYZ') == 'AXIS_ANGLE' else 'rotation_euler')
                    try:
                        obj.keyframe_insert(data_path='location', frame=frame, options={'INSERTKEY_VISUAL'})
                    except Exception:
                        try:
                            obj.keyframe_insert(data_path='location', frame=frame)
                        except Exception:
                            failures += 1
                            continue
                    for data_path in (rotation_path, 'scale'):
                        try:
                            obj.keyframe_insert(data_path=data_path, frame=frame, options={'INSERTKEY_VISUAL'})
                        except Exception:
                            try:
                                obj.keyframe_insert(data_path=data_path, frame=frame)
                            except Exception:
                                failures += 1
                                continue
                    keyed += 3

            self.report({'INFO'}, sas_text(f"Baked rigid-body motion for {len(objects)} objects into editable keys from frame {start_frame} to {end_frame}.", f"フレーム {start_frame} から {end_frame} にかけて {len(objects)} 個のリジッドボディ動作を編集可能キーへベイクしました。", context))
            add_log(context, "INFO", f"Baked rigid-body motion for {len(objects)} objects across frames {start_frame}-{end_frame}, inserted about {keyed} transform keys, removed {removed} old keys, and created {backed_up} backups with {failures} insert failures.", f"フレーム {start_frame}-{end_frame} で {len(objects)} 個のリジッドボディ動作をベイクし、約 {keyed} 個の変形キーを挿入、古いキーを {removed} 個削除し、{backed_up} 件のバックアップを作成しました。挿入失敗は {failures} 件でした。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Rigid-body bake failed: {exc}", f"リジッドボディベイクに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Bake Rigid Body Keys failed: {exc}", f"リジッドボディのキーのベイクに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        finally:
            try:
                scene.frame_set(original_frame)
            except Exception:
                pass



OPERATOR_WORKFLOW_CLASSES = (
    SAS_OT_build_camera_sequence,
    SAS_OT_create_camera_review_split,
    SAS_OT_sequence_library_actions,
    SAS_OT_bake_rigid_body_keys,
    SAS_OT_auto_fulcrum_cleanup,
    SAS_OT_transform_reveal,
)
