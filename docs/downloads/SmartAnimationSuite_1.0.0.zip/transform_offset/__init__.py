# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Animation Transform Offset",
    "description": "Offset entire animation when transforming objects",
    "author": "JELararagi",
    "version": (1, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Animation > Animation Offset",
    "category": "Animation",
    "doc_url": "https://extensions.blender.org/add-ons/Animation-Transform-Offset/",
    "tracker_url": "https://github.com/softyoda/Animation-Transform-Offset",
}

import bpy
from mathutils import Vector
from math import degrees, radians

from ..action_compat import iter_action_fcurves



def _iter_object_action_fcurves(obj):
    animation_data = getattr(obj, 'animation_data', None)
    action = getattr(animation_data, 'action', None) if animation_data else None
    if action is None:
        return []
    return list(iter_action_fcurves(action, datablock=obj))



def _safe_scale_factor(current_value, start_value):
    start = float(start_value)
    if abs(start) < 1e-8:
        return 1.0
    return float(current_value) / start



class ANIMOFFSET_OT_grab(bpy.types.Operator):
    """Grab objects and offset their entire animation by the same amount"""
    bl_idname = "anim_offset.grab"
    bl_label = "Grab and Offset Animation"
    bl_options = {'UNDO'}

    start_locs = {}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            for obj in context.selected_objects:
                if obj not in self.start_locs:
                    continue
                delta = obj.location - self.start_locs[obj]
                for fc in _iter_object_action_fcurves(obj):
                    if fc.data_path != "location":
                        continue
                    for kp in fc.keyframe_points:
                        kp.co.y += delta[fc.array_index]
                    fc.update()
            return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            for obj in context.selected_objects:
                if obj in self.start_locs:
                    obj.location = self.start_locs[obj]
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        animated_objects = False
        self.start_locs.clear()
        for obj in context.selected_objects:
            if getattr(getattr(obj, 'animation_data', None), 'action', None) is None:
                continue
            animated_objects = True
            self.start_locs[obj] = obj.location.copy()

        if not animated_objects:
            self.report({'WARNING'}, "Select at least one animated object")
            return {'CANCELLED'}

        context.window_manager.modal_handler_add(self)
        bpy.ops.transform.translate('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}



class ANIMOFFSET_OT_rotate(bpy.types.Operator):
    """Rotate objects and offset their entire animation by the same amount"""
    bl_idname = "anim_offset.rotate"
    bl_label = "Rotate and Offset Animation"
    bl_options = {'UNDO'}

    start_rots = {}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            for obj in context.selected_objects:
                if obj not in self.start_rots:
                    continue
                delta = Vector((
                    degrees(obj.rotation_euler.x - self.start_rots[obj].x),
                    degrees(obj.rotation_euler.y - self.start_rots[obj].y),
                    degrees(obj.rotation_euler.z - self.start_rots[obj].z),
                ))
                for fc in _iter_object_action_fcurves(obj):
                    if fc.data_path != "rotation_euler":
                        continue
                    for kp in fc.keyframe_points:
                        kp.co.y += radians(delta[fc.array_index])
                    fc.update()
            return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            for obj in context.selected_objects:
                if obj in self.start_rots:
                    obj.rotation_euler = self.start_rots[obj].copy()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        animated_objects = False
        self.start_rots.clear()
        for obj in context.selected_objects:
            if getattr(getattr(obj, 'animation_data', None), 'action', None) is None:
                continue
            animated_objects = True
            self.start_rots[obj] = obj.rotation_euler.copy()

        if not animated_objects:
            self.report({'WARNING'}, "Select at least one animated object")
            return {'CANCELLED'}

        context.window_manager.modal_handler_add(self)
        bpy.ops.transform.rotate('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}



class ANIMOFFSET_OT_scale(bpy.types.Operator):
    """Scale objects and offset their entire animation by the same factor"""
    bl_idname = "anim_offset.scale"
    bl_label = "Scale and Offset Animation"
    bl_options = {'UNDO'}

    start_scales = {}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            for obj in context.selected_objects:
                if obj not in self.start_scales:
                    continue
                scale_factors = Vector((
                    _safe_scale_factor(obj.scale[0], self.start_scales[obj][0]),
                    _safe_scale_factor(obj.scale[1], self.start_scales[obj][1]),
                    _safe_scale_factor(obj.scale[2], self.start_scales[obj][2]),
                ))
                for fc in _iter_object_action_fcurves(obj):
                    if fc.data_path != "scale":
                        continue
                    factor = scale_factors[fc.array_index]
                    for kp in fc.keyframe_points:
                        kp.co.y *= factor
                    fc.update()
            return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            for obj in context.selected_objects:
                if obj in self.start_scales:
                    obj.scale = self.start_scales[obj].copy()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        animated_objects = False
        self.start_scales.clear()
        for obj in context.selected_objects:
            if getattr(getattr(obj, 'animation_data', None), 'action', None) is None:
                continue
            animated_objects = True
            self.start_scales[obj] = obj.scale.copy()

        if not animated_objects:
            self.report({'WARNING'}, "Select at least one animated object")
            return {'CANCELLED'}

        context.window_manager.modal_handler_add(self)
        bpy.ops.transform.resize('INVOKE_DEFAULT')
        return {'RUNNING_MODAL'}



class ANIMOFFSET_PT_panel(bpy.types.Panel):
    """Panel for Animation Offset tools"""
    bl_label = "Animation Offset"
    bl_idname = "ANIMOFFSET_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Animation Offset")
        box.operator("anim_offset.grab", text="Grab and Offset Animation")
        box.operator("anim_offset.rotate", text="Rotate and Offset Animation")
        box.operator("anim_offset.scale", text="Scale and Offset Animation")
        box.label(text="Or use Shift+G/R/S")


classes = (
    ANIMOFFSET_OT_grab,
    ANIMOFFSET_OT_rotate,
    ANIMOFFSET_OT_scale,
    ANIMOFFSET_PT_panel,
)

addon_keymaps = []


def _remove_hotkeys():
    for km, kmi in list(addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


def enable_hotkeys():
    """Enable optional Shift+G/Shift+R/Shift+S animation offset hotkeys from the central always-on switch."""
    _remove_hotkeys()
    wm = bpy.context.window_manager
    kc = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
    if kc:
        km = kc.keymaps.new(name='Object Mode')

        kmi = km.keymap_items.new(
            ANIMOFFSET_OT_grab.bl_idname,
            type='G',
            value='PRESS',
            shift=True,
        )
        addon_keymaps.append((km, kmi))

        kmi = km.keymap_items.new(
            ANIMOFFSET_OT_rotate.bl_idname,
            type='R',
            value='PRESS',
            shift=True,
        )
        addon_keymaps.append((km, kmi))

        kmi = km.keymap_items.new(
            ANIMOFFSET_OT_scale.bl_idname,
            type='S',
            value='PRESS',
            shift=True,
        )
        addon_keymaps.append((km, kmi))


def disable_hotkeys():
    """Disable optional animation offset hotkeys from the central always-on switch."""
    _remove_hotkeys()



def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    disable_hotkeys()




def unregister():
    disable_hotkeys()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
