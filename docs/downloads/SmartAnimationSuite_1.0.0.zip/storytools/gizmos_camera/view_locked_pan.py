import bpy

from bpy.types import Operator
from bpy.app.handlers import persistent

class STORYTOOLS_OT_lock_view(Operator):
    bl_idname = "storytools.lock_view"
    bl_label = 'Lock Current View'
    bl_description = "Lock current viewport orbit navigation"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        r3d = context.space_data.region_3d
        r3d.lock_rotation = not r3d.lock_rotation
        return {"FINISHED"}

class VIEW3D_OT_locked_pan(bpy.types.Operator):
    bl_idname = "view3d.locked_pan"
    bl_label = "Locked Pan"
    bl_description = "Locked Pan, a wrapper for pan operation\
                    \nOnly valid when viewport has locked rotation (region_3d.lock_rotation)"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        # context.area.type == 'VIEW_3D'
        return context.space_data.region_3d.lock_rotation

    def execute(self, context):
        # print("Locked rotation - Pan wrapper") # Dbg
        bpy.ops.view3d.move("INVOKE_DEFAULT")
        return {'FINISHED'}

## --- KEYMAPS

addon_keymaps = []
def register_keymaps():
    # print("Register locked pan keymaps") #Dbg
    wm = getattr(bpy.context, 'window_manager', None)
    addon = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
    if addon is None:
        return

    ## Scan current keymaps to replicate
    user_keymaps = getattr(getattr(getattr(wm, 'keyconfigs', None), 'user', None), 'keymaps', None)
    user_km = user_keymaps.get('3D View') if user_keymaps is not None else None
    if not user_km:
        ## During Blender loading, user km are not reachable, return silently here (will be registered afterward by handler)
        # print('-- Storytools could not reach user keymap') #Dbg
        return

    if len(addon_keymaps):
        ## Skip if keymaps are already registered, avoid duplicates
        # print("-- View lock pan Keymap already registered")
        return

    for skmi in user_km.keymap_items:
        # Only replicate view3d.rotate (orbit) shortcut
        if skmi.idname != 'view3d.rotate':
            continue

        # skmi.show_expanded = True #Dbg

        ## By default 3 shortcut exists : MOUSEROTATE, MIDDLEMOUSE, TRACKPADPAN
        ## Trackball shortcut skip (?)
        if skmi.type == 'MOUSEROTATE':
            continue

        ## Check if duplicates exists (/!\ seems duplicate can be found, but actually removed right away on loading)
        # km_dup = next((k for k in user_km.keymap_items 
        #                 if k.idname == "view3d.locked_pan"
        #                 and all(getattr(skmi, x) == getattr(k, x) for x in key_props)), None)
        # if km_dup:
        #     print(f'--> "{skmi.name} > {skmi.type} > {skmi.value}" shortcut already have a lock pan equivalent') # Dbg
        #     continue
        
        # print(f'>-> Create {skmi.name} > {skmi.type} > {skmi.value}" shortcut to lock pan') # Dbg
        ## Create duplicate
        km = addon.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi = km.keymap_items.new(
            idname="view3d.locked_pan",
            type=skmi.type,
            value=skmi.value,
            ctrl=skmi.ctrl,
            alt=skmi.alt,
            shift=skmi.shift,
            oskey=skmi.oskey,
            any=skmi.any,
            key_modifier=skmi.key_modifier,
            )

        addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in list(addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()

@persistent
def set_lockpan_km(dummy):
    register_keymaps()


def _append_load_post_once(handler):
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    if handler not in load_post:
        load_post.append(handler)


def _remove_load_post(handler):
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    try:
        while handler in load_post:
            load_post.remove(handler)
    except Exception:
        pass


def enable_view_locked_pan_hotkeys():
    """Enable Storytools locked-view pan hotkeys from the central always-on switch."""
    register_keymaps()
    _append_load_post_once(set_lockpan_km)


def disable_view_locked_pan_hotkeys():
    """Disable Storytools locked-view pan hotkeys from the central always-on switch."""
    unregister_keymaps()
    _remove_load_post(set_lockpan_km)

classes=(
    STORYTOOLS_OT_lock_view,
    VIEW3D_OT_locked_pan,
)

def register(): 
    for cls in classes:
        bpy.utils.register_class(cls)

    disable_view_locked_pan_hotkeys()


def unregister():
    disable_view_locked_pan_hotkeys()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

