import bpy
import gpu
import blf

import numpy as np

from bpy.types import Operator, PropertyGroup
from mathutils import Vector, Matrix
from mathutils.geometry import intersect_line_plane
from bpy.props import FloatProperty, IntProperty, EnumProperty, BoolProperty, StringProperty
from gpu_extras.batch import batch_for_shader
from bpy_extras.view3d_utils import location_3d_to_region_2d, region_2d_to_vector_3d, region_2d_to_location_3d

from .. import fn
from ...translation import sas_text
from ... import smart_tools_manager_compat as manager_compat
from . create_static_storyboard import notes_default_bodys


class STORYTOOLS_OT_storyboard_offset_panel_modal(Operator):
    bl_idname = "storytools.storyboard_offset_panel_modal"
    bl_label = "Storyboard Offset Panels (Modal)"
    bl_description = "Interactive panel offset - click panels to select start and end"
    bl_options = {'UNDO'}

    mode : EnumProperty(
        name="Mode",
        description="Operation mode",
        items=(
            ('INSERT', "Insert", "Insert new panel"),
            ('DELETE', "Delete", "Delete panel"),
            ('SWAP', "Swap", "Swap two panels"),
        ),
        default='INSERT'
    )

    read_direction : EnumProperty(
        name="Read Direction",
        description="Reading Frame direction",
        items=(
            ('RIGHT', "Left To Right", "Read direction first left to right then top to bottom"),
            ('DOWN', "Top To Bottom", "Read direction first top to bottom then left to right"),
        ),
        default='RIGHT'
    )

    def invoke(self, context, event):
        ## Init variables
        self.panels = []
        self.panel_coords = []
        self.selected_start = None
        self.selected_end = None
        self.draw_handle_3d = None
        self.draw_handle_2d = None
        self.mouse_pos = (0, 0)
        self.material_index = None
        self.number_of_panels = 0

        if not context.object or context.object.type != 'GREASEPENCIL':
            self.report({'ERROR'}, "No Storyboard Grease Pencil object selected")
            return {'CANCELLED'}

        board_obj = context.object
        self.material_index = next((i for i, ms in enumerate(board_obj.material_slots) if ms.material and ms.material.name == 'Panels'), None)
        if self.material_index is None:
            self.report({'ERROR'}, 'Could not find "Panels" material')
            return {'CANCELLED'}

        grid = board_obj.data.layers.get('Frames')
        if not grid:
            self.report({'ERROR'}, 'No "Frames" layer found')
            return {'CANCELLED'}

        frame = grid.current_frame()
        if frame is None:
            self.report({'WARNING'}, sas_text(
                "The storyboard Frames layer has no drawing at the current frame.",
                "現在のフレームではストーリーボードの「Frames」レイヤーに描画がありません。", context))
            return {'CANCELLED'}
        dr = frame.drawing
        panel_strokes = [s for s in dr.strokes if s.material_index == self.material_index and len(s.points) == 4]
        if not panel_strokes:
            self.report({'ERROR'}, 'No panel strokes found')
            return {'CANCELLED'}

        self.panels = panel_strokes
        self.number_of_panels = len(panel_strokes)
        self.panel_coords = []

        # Get panel coordinates in 3D space
        for stroke in panel_strokes:
            coords = [p.position for p in stroke.points]
            min_corner, max_corner = fn.get_min_max_corner(coords.copy())
            center = (min_corner + max_corner) / 2

            # Calculate panel normal (assuming XZ plane)
            # For a rectangular panel in XZ plane, normal is Y-axis
            normal = Vector((0, 1, 0))

            # Store 3D coordinates for intersection testing
            self.panel_coords.append({
                'world_coords': coords,
                'min_corner': min_corner,
                'max_corner': max_corner,
                'center': center,
                'normal': normal
            })

        # Add two draw handlers: one for 3D and one for 2D elements
        self.draw_handle_3d = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_3d, (context,), 'WINDOW', 'POST_VIEW'
        )
        self.draw_handle_2d = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_2d, (context,), 'WINDOW', 'POST_PIXEL'
        )

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'MOUSEMOVE'}:
            self.mouse_pos = (event.mouse_region_x, event.mouse_region_y)

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            # Check if click is on a panel
            clicked_panel = self.get_panel_at_mouse(context, self.mouse_pos)
            if clicked_panel is not None:
                if self.selected_start is None:
                    self.selected_start = clicked_panel
                elif self.selected_end is None and clicked_panel != self.selected_start:
                    self.selected_end = clicked_panel
                    # Execute the operation
                    if self.mode == 'SWAP':
                        self.execute_swap(context)
                    else:
                        self.execute_offset(context)
                    return self.finish_modal(context)
                elif clicked_panel == self.selected_start:
                    # Clicking same panel again
                    if self.mode == 'SWAP':
                        # In swap mode, clicking same panel does nothing
                        pass
                    else:
                        # In insert/delete mode, execute with last panel as range
                        self.selected_end = len(self.panel_coords) - 1  # Last panel
                        self.execute_offset(context)
                        return self.finish_modal(context)
                elif clicked_panel == self.selected_end:
                    # Cancel end selection
                    self.selected_end = None

        elif event.type == 'RET' and event.value == 'PRESS':
            # Enter key pressed - execute with last panel as range if one panel selected
            if self.selected_start is not None and self.selected_end is None and self.mode != 'SWAP':
                self.selected_end = len(self.panel_coords) - 1  # Last panel
                self.execute_offset(context)
                return self.finish_modal(context)

        elif event.type == 'R' and event.value == 'PRESS':
            # Toggle read direction
            self.read_direction = 'DOWN' if self.read_direction == 'RIGHT' else 'RIGHT'

        elif event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.type.startswith('NUMPAD'):
            # Pass through navigation
            return {'PASS_THROUGH'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            return self.finish_modal(context)

        return {'RUNNING_MODAL'}

    def get_panel_at_mouse(self, context, mouse_pos):
        """Use 3D ray casting to detect panel clicks"""
        region = context.region
        rv3d = context.region_data

        # Get 3D ray from mouse position
        view_vector = region_2d_to_vector_3d(region, rv3d, mouse_pos)
        ray_origin = region_2d_to_location_3d(region, rv3d, mouse_pos, view_vector)

        for i, panel in enumerate(self.panel_coords):
            center = panel['center']
            normal = panel['normal']
            min_corner = panel['min_corner']
            max_corner = panel['max_corner']

            # Find intersection with panel plane
            intersection = intersect_line_plane(ray_origin, ray_origin + view_vector * 1000, center, normal)

            if intersection:
                # Check if intersection point is within panel bounds
                if (min_corner.x <= intersection.x <= max_corner.x and
                    min_corner.z <= intersection.z <= max_corner.z):
                    return i
        return None

    def draw_callback_3d(self, context):
        """Draw 3D panel rectangles in world space"""
        if not manager_compat.workspace_runtime_allows_context(bpy.context):
            return
        # Set up GPU state
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(10.0)

        # Draw panel rectangles in 3D space
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')

        blue = (0.2, 0.8, 1.0, 0.8)
        blue_light = (0.2, 0.8, 1.0, 0.6)
        red = (1.0, 0.3, 0.3, 0.8)
        red_light = (1.0, 0.3, 0.3, 0.6)
        orange = (1.0, 0.6, 0.2, 0.8)
        orange_light = (1.0, 0.6, 0.2, 0.6)

        for i, panel in enumerate(self.panel_coords):
            coords = panel['world_coords']
            if len(coords) == 4:
                # Create vertices for rectangle outline
                vertices = [(coord.x, coord.y, coord.z) for coord in coords]
                vertices.append(vertices[0])  # Close the rectangle

                # Set color based on selection state
                if i == self.selected_start:
                    if self.mode == 'INSERT':
                        color = blue
                    elif self.mode == 'DELETE':
                        color = red
                    else:  # SWAP
                        color = orange
                elif i == self.selected_end:
                    if self.mode == 'INSERT':
                        color = blue
                    elif self.mode == 'DELETE':
                        color = red
                    else:  # SWAP
                        color = orange
                else:
                    if self.mode == 'INSERT':
                        color = blue_light
                    elif self.mode == 'DELETE':
                        color = red_light
                    else:  # SWAP
                        color = orange_light

                # Draw filled rectangle for selected panels
                if i == self.selected_start or i == self.selected_end:
                    # Draw filled rectangle
                    indices = [(0, 1, 2), (0, 2, 3)]
                    batch = batch_for_shader(shader, 'TRIS', {"pos": vertices[:-1]}, indices=indices)
                    shader.bind()
                    shader.uniform_float("color", (color[0], color[1], color[2], 0.3))
                    batch.draw(shader)

                # Draw outline
                batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": vertices})
                shader.bind()
                shader.uniform_float("color", color)
                batch.draw(shader)

        # Restore GPU state
        gpu.state.blend_set('NONE')
        gpu.state.line_width_set(1.0)

    def draw_callback_2d(self, context):
        """Draw 2D UI text in screen space"""
        if not manager_compat.workspace_runtime_allows_context(bpy.context):
            return
        # Draw instruction text
        font_id = 0
        start_x = int(context.region.width * 0.12)
        start_y = context.region.height - int(context.region.height * 0.12)
        blf.size(font_id, 20)

        # Set color based on mode
        if self.mode == 'INSERT':
            blf.color(font_id, 0.2, 0.8, 1.0, 1.0)
        elif self.mode == 'DELETE':
            blf.color(font_id, 1.0, 0.3, 0.3, 1.0)
        else:  # SWAP
            blf.color(font_id, 1.0, 0.6, 0.2, 1.0)

        # First line: Read direction info (only for INSERT/DELETE modes)
        if self.mode != 'SWAP':
            read_dir_text = "Left to Right" if self.read_direction == 'RIGHT' else "Top to Bottom"
            first_line = f"Read Direction: {read_dir_text} (Press R to toggle)"
            show_read_direction = True
        else:
            first_line = None
            show_read_direction = False

        # Second line: Main instruction
        if self.mode == 'INSERT':
            second_line = "Click panel to insert new (insert before selection)"
        elif self.mode == 'DELETE':
            second_line = "Click panel to remove"
        else:  # SWAP
            second_line = "Click first panel to swap"

        # Third line: Additional instruction (when panel is selected)
        third_line = None
        if self.selected_start is not None:
            if self.mode == 'INSERT':
                second_line = "Click second panel to set how far to push"
                third_line = "Click same panel again to push until last panel"
            elif self.mode == 'DELETE':
                second_line = "Click second panel to set how far to pull back"
                third_line = "Click same panel again to pull back all subsequent panels"
            else:  # SWAP
                second_line = "Click second panel to swap with"

        # Draw lines based on mode
        current_y = start_y

        # Draw first line (read direction) if needed
        if show_read_direction:
            blf.position(font_id, start_x, current_y, 0)
            blf.draw(font_id, first_line)
            width, height = blf.dimensions(font_id, first_line)
            current_y -= height + 7

        # Draw second line (main instruction)
        blf.position(font_id, start_x, current_y, 0)
        blf.draw(font_id, second_line)

        # Draw third line if it exists
        if third_line:
            width, height = blf.dimensions(font_id, second_line)
            current_y -= height + 7
            blf.position(font_id, start_x, current_y, 0)
            blf.draw(font_id, third_line)

    def get_page_and_index(self, index, page_list):
        """From global index, return index of page and index of panel in that page"""
        ct = 0
        for page_index, panels in enumerate(page_list):
            for i in range(len(panels)):
                if ct + i == index:
                    return page_index, i
            ct += len(panels)
        return None, None

    def execute_offset(self, context):
        if self.selected_start is None or self.selected_end is None:
            return

        board_obj = context.object

        # Sort indices to ensure proper start/end order
        start_idx = min(self.selected_start, self.selected_end)
        end_idx = max(self.selected_start, self.selected_end)

        # Convert to 1-based indices for the offset logic
        insert_index = start_idx + 1
        stop_index = end_idx#  + 1
        offset_direction = 'FORWARD' if self.mode == 'INSERT' else 'BACKWARD'

        # Validation
        if offset_direction == 'FORWARD' and insert_index >= self.number_of_panels:
            self.report({'ERROR'}, 'Cannot insert panel at or beyond current total panels')
            return

        if offset_direction == 'BACKWARD' and insert_index > self.number_of_panels:
            self.report({'ERROR'}, 'Cannot remove a panel that doesn\'t exist')
            return

        if stop_index >= self.number_of_panels:
            self.report({'ERROR'}, 'Cannot stop offset at or beyond current total panels')
            return

        # Get all frames
        scn = context.scene
        grid = board_obj.data.layers.get('Frames')
        dr = grid.current_frame().drawing
        panel_strokes = [s for s in dr.strokes if s.material_index == self.material_index and len(s.points) == 4]
        frame_corners = [fn.get_min_max_corner([p.position for p in s.points]) for s in panel_strokes]

        # Add center as a third element in list
        frames_coords = [(f[0], f[1], ((f[0] + f[1]) / 2)) for f in frame_corners]

        # Group by pages (camera boundaries)
        page_markers = [m for m in scn.timeline_markers if m.camera and m.name.startswith('stb_')]
        page_list = []
        for marker in page_markers:
            panel_framing = []
            camera = marker.camera
            cam_frame = fn.get_cam_frame_world(camera, scene=scn)
            cam_min, cam_max = fn.get_min_max_corner(cam_frame)

            for i in range(len(frames_coords)-1,-1,-1):
                frame_coord = frames_coords[i]
                if fn.any_point_in_box(frame_coord, cam_min, cam_max):
                    panel_framing.append(frames_coords.pop(i))

            page_list.append(panel_framing)

        # Sort by read direction in each group
        for frames_list in page_list:
            if self.read_direction == 'RIGHT':
                frames_list.sort(key=lambda vecs: (-vecs[2].z, vecs[2].x))
            else:
                frames_list.sort(key=lambda vecs: (vecs[2].x, -vecs[2].z))

        # Get storyboard collection objects
        stb_collection = scn.collection.children.get('Storyboard')
        all_objects = []
        if stb_collection:
            all_objects = [o for o in stb_collection.all_objects if o.type != 'CAMERA' and o != board_obj]

        # Concatenate all groups
        panels = [coords for pages in page_list for coords in pages]

        if not panels:
            self.report({'ERROR'}, 'No panels found to offset')
            return

        # Find insertion point (1-based index from user input)
        insert_index = min(insert_index - 1, len(panels) - 1)
        end_index = min(stop_index - 1, len(panels) - 1)

        moved_text_objects = {}
        to_remove_text_objects = []

        # Precalculate iteration parameters based on direction
        if offset_direction == 'FORWARD':
            start_idx = end_index
            stop_idx = insert_index - 1
            step = -1
            get_source_idx = lambda i: i
            get_target_idx = lambda i: i + 1
            panel_duplication_index = insert_index
            panel_to_remove_index = stop_index
        else:  # BACKWARD
            start_idx = insert_index
            stop_idx = end_index + 1
            step = 1
            get_source_idx = lambda i: i + 1
            get_target_idx = lambda i: i
            panel_duplication_index = stop_index
            panel_to_remove_index = insert_index

        # Store text in panels
        if panel_duplication_index == panel_to_remove_index:
            self.report({'ERROR'}, 'Cannot duplicate and remove the same panel at the same time')
            return

        for ob in all_objects:
            if ob.type == 'FONT':
                loc = ob.matrix_world.translation
                if fn.any_point_in_box([loc],
                        panels[panel_duplication_index][0], panels[panel_duplication_index][1]):
                    moved_text_objects[ob] = ob.location.copy()

                if fn.any_point_in_box([loc],
                        panels[panel_to_remove_index][0], panels[panel_to_remove_index][1]):
                    to_remove_text_objects.append(ob)

        # In delete mode, remove content from the panel to be deleted before offsetting
        if self.mode == 'DELETE':
            panel_to_clear = panels[panel_to_remove_index]
            clear_min, clear_max, clear_center = panel_to_clear

            for layer in board_obj.data.layers:
                if layer.name == 'Frames':
                    continue
                frame = layer.current_frame()
                if frame is None:
                    continue
                drawing = frame.drawing
                strokes_to_remove = []

                for sid, stroke in enumerate(drawing.strokes):
                    if any(clear_min.x <= p.position.x <= clear_max.x and
                           clear_min.z <= p.position.z <= clear_max.z for p in stroke.points):
                        strokes_to_remove.append(sid)

                if strokes_to_remove:
                    drawing.remove_strokes(indices=strokes_to_remove)

        # Single loop for both directions
        for i in range(start_idx, stop_idx, step):
            source_idx = get_source_idx(i)
            target_idx = get_target_idx(i)
            pass  # Console-silent bundled-tool diagnostic.

            # Skip if source panel doesn't exist
            if source_idx >= len(panels):
                continue

            source_panel = panels[source_idx]
            target_panel = panels[target_idx]

            source_min, source_max, source_center = source_panel
            target_min, target_max, target_center = target_panel

            # Calculate offset vector (from source to target)
            offset_vector = target_center - source_center

            # Find grease pencil strokes to move from source panel
            strokes_to_move = []
            for layer in board_obj.data.layers:
                if layer.name == 'Frames':
                    continue
                frame = layer.current_frame()
                if frame is None:
                    continue
                drawing = frame.drawing
                for stroke in drawing.strokes:
                    if any(source_min.x <= p.position.x <= source_max.x and
                           source_min.z <= p.position.z <= source_max.z for p in stroke.points):
                        strokes_to_move.append(stroke)

            # Apply offset to grease pencil strokes
            for stroke in strokes_to_move:
                for point in stroke.points:
                    point.position += offset_vector

            # Move 3D objects from source panel
            if all_objects:
                objects_to_move = []

                # Iterate backward through objects to safely remove during iteration
                for ob_idx in range(len(all_objects)-1, -1, -1):
                    obj = all_objects[ob_idx]

                    # Check if object origin is within source panel bounds
                    world_pos = obj.location
                    if (source_min.x <= world_pos.x <= source_max.x and
                        source_min.z <= world_pos.z <= source_max.z):
                        objects_to_move.append(all_objects.pop(ob_idx))

                # Apply panel offset to 3D objects
                for obj in objects_to_move:
                    obj.location += offset_vector

        # Add / remove text where needed
        stb_settings = board_obj.get('stb_settings')
        for obj, loc in moved_text_objects.items():
            new_obj = obj.copy()
            new_obj.data = obj.data.copy()
            obj.users_collection[0].objects.link(new_obj)
            new_obj.location = loc

            # Reset to initial text
            if stb_settings:
                content = None
                if new_obj.name.startswith("stb_shot_num"):
                    content = stb_settings.get("panel_header_left")
                elif new_obj.name.startswith("stb_panel_num"):
                    content = stb_settings.get("panel_header_right")
                elif new_obj.name.startswith("panel_"):
                    content = notes_default_bodys.get(stb_settings.get("note_text_format",''))

                if content is not None:
                    new_obj.data.body = content

        # Remove text in destination panel after offset to avoid duplication
        for obj in reversed(to_remove_text_objects):
            page_id, page_panel_id = self.get_page_and_index(panel_to_remove_index, page_list)
            if page_id and page_panel_id:
                pass  # Console-silent bundled-tool diagnostic.
            bpy.data.objects.remove(obj, do_unlink=True)

        # Success message
        if self.mode == 'INSERT':
            self.report({'INFO'}, bpy.app.translations.pgettext("Inserted panel at position {}").format(start_idx + 1))
        else:
            self.report({'INFO'}, bpy.app.translations.pgettext("Removed panel at position {}").format(start_idx + 1))

    def execute_swap(self, context):
        """Swap content between two selected panels"""
        if self.selected_start is None or self.selected_end is None:
            return

        board_obj = context.object

        # Get panel coordinates
        panel_a = self.panel_coords[self.selected_start]
        panel_b = self.panel_coords[self.selected_end]

        # Get panel bounds
        min_a, max_a = panel_a['min_corner'], panel_a['max_corner']
        min_b, max_b = panel_b['min_corner'], panel_b['max_corner']
        center_a, center_b = panel_a['center'], panel_b['center']

        # Calculate offset vectors
        offset_a_to_b = center_b - center_a
        offset_b_to_a = center_a - center_b

        # Collect strokes from both panels
        strokes_a = []
        strokes_b = []

        for layer in board_obj.data.layers:
            if layer.name == 'Frames':
                continue
            frame = layer.current_frame()
            if frame is None:
                continue
            drawing = frame.drawing

            for stroke in drawing.strokes:
                # Check if stroke is in panel A
                if any(min_a.x <= p.position.x <= max_a.x and
                       min_a.z <= p.position.z <= max_a.z for p in stroke.points):
                    strokes_a.append(stroke)
                # Check if stroke is in panel B
                elif any(min_b.x <= p.position.x <= max_b.x and
                         min_b.z <= p.position.z <= max_b.z for p in stroke.points):
                    strokes_b.append(stroke)

        # Apply swaps
        for stroke in strokes_a:
            for point in stroke.points:
                point.position += offset_a_to_b

        for stroke in strokes_b:
            for point in stroke.points:
                point.position += offset_b_to_a

        # Swap 3D objects
        scn = context.scene
        stb_collection = scn.collection.children.get('Storyboard')
        if stb_collection:
            all_objects = [o for o in stb_collection.all_objects if o.type != 'CAMERA' and o != board_obj]

            objects_a = []
            objects_b = []

            for obj in all_objects:
                world_pos = obj.location
                # Check if object is in panel A
                if (min_a.x <= world_pos.x <= max_a.x and
                    min_a.z <= world_pos.z <= max_a.z):
                    objects_a.append(obj)
                # Check if object is in panel B
                elif (min_b.x <= world_pos.x <= max_b.x and
                      min_b.z <= world_pos.z <= max_b.z):
                    objects_b.append(obj)

            # Apply swaps to objects
            for obj in objects_a:
                obj.location += offset_a_to_b

            for obj in objects_b:
                obj.location += offset_b_to_a

        # Success message
        self.report({'INFO'}, bpy.app.translations.pgettext("Swapped panels {} and {}").format(self.selected_start + 1, self.selected_end + 1))

    def finish_modal(self, context):
        if hasattr(self, 'draw_handle_3d') and self.draw_handle_3d:
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle_3d, 'WINDOW')
            self.draw_handle_3d = None
        if hasattr(self, 'draw_handle_2d') and self.draw_handle_2d:
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle_2d, 'WINDOW')
            self.draw_handle_2d = None
        context.area.tag_redraw()
        return {'FINISHED'}


classes = (
    STORYTOOLS_OT_storyboard_offset_panel_modal,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
