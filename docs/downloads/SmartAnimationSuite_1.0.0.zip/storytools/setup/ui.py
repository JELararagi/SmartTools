import bpy
from .. import fn


def _operator_id_available(op_id):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return False
    group_name, op_name = op_id.split('.', 1)
    group = getattr(bpy.ops, group_name, None)
    if group is None:
        return False
    try:
        op = getattr(group, op_name)
    except Exception:
        return False
    try:
        op.get_rna_type()
        return True
    except AttributeError:
        return callable(op)
    except Exception:
        return False


def _safe_popover(layout, panel_id, **kwargs):
    panel_id = str(panel_id or '').strip()
    if not panel_id or not hasattr(bpy.types, panel_id):
        return False
    try:
        layout.popover(panel=panel_id, **kwargs)
        return True
    except Exception:
        return False


def _safe_operator(layout, op_id, **kwargs):
    if not _operator_id_available(op_id):
        return None
    try:
        return layout.operator(op_id, **kwargs)
    except Exception:
        return None

class STORYTOOLS_PT_viewport_setup(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    # bl_region_type = "HEADER"
    bl_region_type = "UI"
    bl_category = 'Smart Animation'
    bl_label = "Viewport Setup"
    bl_options = {"INSTANCED"}

    # @classmethod
    # def poll(cls, context):
    #     return not fn.is_minimap_viewport(context)

    def draw_header(self, context):
        return None
    def draw(self, context):
        col = self.layout.column()

        if fn.is_minimap_viewport(context):
            ## Minimap view operators
            if context.region.type != "HEADER":
                ## Hack: Disabled col property to avoid clicking on propertie
                sub = col.row()
                op = sub.operator('storytools.info_note', text='Minimap Options', emboss=False)
                op.text = ''
                op.title = ''
                sub.enabled = True
            col.label(text='Recenter Map:')
            col.operator("storytools.map_frame_objects", text='Frame GP Objects and Camera').target = 'ALL' # default
            col.operator("storytools.map_frame_objects", text='Frame GP Objects').target = 'GP'
            col.operator("storytools.map_frame_objects", text='Frame Active Object').target = 'ACTIVE'
            col.separator()
            col.operator("view3d.view_all", text='Frame All')

            if context.region.type == "HEADER":
                col.separator()
                col.operator("storytools.disable_minimap_viewport", text='Disable Minimap Viewport', icon='LOOP_BACK')

        else:
            ## settings 
            # col.label(text='Draw settings')
            # col.operator('storytools.setup_drawing', text='Quick UI Reset', icon='GREASEPENCIL')

            ## -- Smart Animation centralizes user-facing controls in the N-panel.
            
            ## -- Workspace load
            # if context.window.workspace.name != 'Storyboarding':
            col.label(text='Workspace:')
            col.operator('storytools.set_storyboard_workspace', text='Set Storyboard Workspace', icon='WORKSPACE')

            ## Minimap
            col.separator()
            if not fn.is_minimap_viewport(context):
                col.label(text='Minimap Setup:')
                col.operator('storytools.setup_minimap_viewport', text='Viewport To Minimap', icon='WORLD').split_viewport = False
                col.operator('storytools.setup_minimap_viewport', text='Split With Minimap', icon='SPLIT_HORIZONTAL').split_viewport = True
                col.operator('storytools.setup_minimap_on_pointed_editor', text='Pick Editor To Minimap', icon='RESTRICT_SELECT_OFF').split_editor = False
                ## point and split is bugged
                # col.operator('storytools.setup_minimap_on_pointed_editor', text='Pick And Split Editor', icon='SPLIT_HORIZONTAL').split_editor = True

            ## Static storyboard layout generator
            col.separator()
            col.label(text='Static Storyboard:')
            # Keep the root column unchanged.  Reassigning ``col`` to its own
            # child makes every following sibling one level deeper and produces
            # the staircase/right-shift effect when sections are expanded.
            storyboard_col = col.column(align=True)
            row = storyboard_col.row(align=True)
            row.operator("storytools.create_static_storyboard_pages", text='Create Storyboard Pages', icon='GRID')
            row.menu("STORYTOOLS_MT_static_storyboard_options", text="", icon='TOOL_SETTINGS') # menu for presets management and animatic creation
            if context.object and context.object.type == 'GREASEPENCIL' and context.object.get('stb_settings'):
                subcol = storyboard_col.column(align=True)
                subcol.label(text='Storyboard Management:')
                subcol.operator("storytools.storyboard_add_pages", text='Add Pages', icon='ADD')
                subcol.separator()
                subcol.operator("storytools.storyboard_offset_panel_modal", text='Insert A Panel', icon='ADD').mode = 'INSERT'
                subcol.operator("storytools.storyboard_offset_panel_modal", text='Remove A Panel', icon='REMOVE').mode = 'DELETE'
                subcol.operator("storytools.storyboard_offset_panel_modal", text='Swap Two Panels', icon='AREA_SWAP').mode = 'SWAP'
                storyboard_col.separator()
            storyboard_col.operator("storytools.render_storyboard_images", text='Render StoryBoard', icon='RESTRICT_RENDER_OFF')

            # if show_workspace_switch or show_storypencil_setup:        
            #     col.separator()
            #     col.label(text='Workspace:')

            #     if show_workspace_switch:
            #         col.operator('storytools.set_storyboard_workspace', text='Storyboard Workspace', icon='WORKSPACE')

            #     if show_storypencil_setup: # Experimental Dual setup
            #         col.operator('storytools.setup_storypencil', text='Setup Storypencil (dual window)', icon='WORKSPACE')


## --- Marker management in Timeline

class STORYTOOLS_PT_marker_management(bpy.types.Panel):
    bl_space_type = "DOPESHEET_EDITOR"
    bl_region_type = "HEADER"
    bl_label = "Marker Management"
    bl_options = {"INSTANCED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text="Scale markers:")
        column = layout.column(align=True)
        column.operator("storytools.time_compression", text="Compress Spacing", icon="REMOVE").direction = 'COMPRESS'
        column.operator("storytools.time_compression", text="Dilate", icon="ADD").direction = 'DILATE'

def marker_management_ui(self, context):
    """Add a panel to the marker management UI"""

    if not context.scene.storytools_settings.show_marker_management:
        return

    layout = self.layout
    layout.label(text="Markers:")
    row = layout.row(align=True)
    row.operator("storytools.push_markers", text="", icon="TRIA_LEFT").direction = 'LEFT'
    row.operator("storytools.push_markers", text="", icon="TRIA_RIGHT").direction = 'RIGHT'
    if hasattr(bpy.types, "STORYTOOLS_PT_marker_management"):
        row.operator("wm.call_panel", text="", icon='DOWNARROW_HLT').name = "STORYTOOLS_PT_marker_management"

## Options related to static storyboard
class STORYTOOLS_MT_static_storyboard_options(bpy.types.Menu):
    bl_label = "Static Storyboard Options"

    def draw(self, context):
        layout = self.layout
            
        layout.label(text='Animatic:')
        layout.operator("storytools.create_animatic_from_board", text='Create Animatic Scene', icon='SCENE_DATA') # SCENE_DATA, MARKER_HLT ## idea of animatic
        layout.prop(context.scene.storytools_settings, "show_marker_management", text="Show Marker Management In Timeline")
        ## TODO: add a quick way to change frame radius size (to avoid getting in animatic frame)
        # frame_material = bpy.data.materials.get('Frames')

## Options related to static storyboard
def drawing_setup_ui(self, context):
    """Drawing Setup pop-up to set in viewport header"""
    layout = self.layout
    if _safe_popover(layout, 'STORYTOOLS_PT_viewport_setup', text=''):
        return
    _safe_operator(layout, 'storytools.setup_drawing', text='', icon='GREASEPENCIL')


classes = (
    STORYTOOLS_PT_marker_management,
    STORYTOOLS_MT_static_storyboard_options,
    STORYTOOLS_PT_viewport_setup,
)

def _hide_sidebar_panels():
    fn.hide_view3d_sidebar_panel(STORYTOOLS_PT_viewport_setup)

_HEADER_CALLBACKS_ENABLED = False


def _append_header_once(header_type, callback):
    try:
        header_type.remove(callback)
    except Exception:
        pass
    try:
        header_type.append(callback)
    except Exception:
        pass


def _remove_header_callback(header_type, callback):
    try:
        header_type.remove(callback)
    except Exception:
        pass


def enable_header_callbacks():
    """Enable optional Storytools header buttons from the central always-on switch."""
    global _HEADER_CALLBACKS_ENABLED
    _HEADER_CALLBACKS_ENABLED = True
    _append_header_once(bpy.types.VIEW3D_HT_header, drawing_setup_ui)
    _append_header_once(bpy.types.DOPESHEET_HT_header, marker_management_ui)


def disable_header_callbacks():
    """Disable optional Storytools header buttons from the central always-on switch."""
    global _HEADER_CALLBACKS_ENABLED
    _HEADER_CALLBACKS_ENABLED = False
    _remove_header_callback(bpy.types.VIEW3D_HT_header, drawing_setup_ui)
    _remove_header_callback(bpy.types.DOPESHEET_HT_header, marker_management_ui)



def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    _hide_sidebar_panels()
    disable_header_callbacks()


def unregister():
    disable_header_callbacks()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
