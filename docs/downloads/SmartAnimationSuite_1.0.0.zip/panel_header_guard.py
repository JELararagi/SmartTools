# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Blender 5.1 UI/operator callback hardening for Smart Animation Suite.

Blender panel and operator callbacks are entered from native UI/event code.  In
5.x, rapid mode changes can temporarily expose partial context/RNA state before
Python can produce a traceback.  These guards keep suite-owned callbacks
conservative: bundled panels get a context-independent help preset before
registration, non-root panel poll/draw is exception-safe, and operator/menu/UIList callbacks
report and cancel instead of leaking exceptions back into Blender's native event
loop. The eleven native Manager roots are declared statically and are never
rewritten by this module.
"""

from __future__ import annotations

from inspect import signature
from typing import Iterable

import bpy

_HEADER_CALLBACK_NAMES = ("draw_header", "draw_header_preset")
_BUNDLED_PANEL_HELP_TOPICS = frozenset({
    'animall', 'camera_shakify', 'easeit', 'offset', 'sakura_poselib',
    'stop_motion_style_animator', 'storytools', 'transform_offset',
})
_EMPTY_HEADER_MARKER = "_sas_safe_empty_panel_header"
_SAFE_PANEL_MARKER = "_sas_safe_panel_callbacks_wrapped"
_SAFE_OPERATOR_MARKER = "_sas_safe_operator_callbacks_wrapped"
_SAFE_MENU_MARKER = "_sas_safe_menu_callbacks_wrapped"
_SAFE_UILIST_MARKER = "_sas_safe_uilist_callbacks_wrapped"
_ORIGINAL_DRAW_NAME = "_sas_original_draw"
_ORIGINAL_POLL_NAME = "_sas_original_poll"
_ORIGINAL_OPERATOR_PREFIX = "_sas_original_operator_"
_ORIGINAL_MENU_DRAW_NAME = "_sas_original_menu_draw"
_ORIGINAL_UILIST_DRAW_ITEM_NAME = "_sas_original_uilist_draw_item"

# Mesh/curve/sculpt edit contexts can invalidate RNA data while Blender is still
# redrawing the Sidebar.  The suite is animation-focused, so the standard N-panel
# remains available in Object/Pose and Grease Pencil animation contexts only.
_VOLATILE_VIEW3D_MODES = {
    'EDIT_MESH',
    'EDIT_CURVE',
    'EDIT_SURFACE',
    'EDIT_TEXT',
    'EDIT_ARMATURE',
    'EDIT_METABALL',
    'EDIT_LATTICE',
    'SCULPT',
    'PAINT_VERTEX',
    'PAINT_WEIGHT',
    'PAINT_TEXTURE',
    'PARTICLE',
}


def _safe_subclass(cls: type, base_name: str) -> bool:
    try:
        base = getattr(bpy.types, base_name, None)
        return base is not None and isinstance(cls, type) and issubclass(cls, base)
    except Exception:
        return False


def is_panel_class(cls: type) -> bool:
    return _safe_subclass(cls, 'Panel')


def is_operator_class(cls: type) -> bool:
    return _safe_subclass(cls, 'Operator')


def is_menu_class(cls: type) -> bool:
    return _safe_subclass(cls, 'Menu')


def is_uilist_class(cls: type) -> bool:
    return _safe_subclass(cls, 'UIList')


def _context_is_basically_valid(context) -> bool:
    try:
        if context is None:
            return False
        # Access through getattr only; Blender may expose partial context during
        # mode transitions. Missing scene/window_manager is treated as unsafe for
        # panel draw because most Smart Animation UI needs at least these roots.
        if getattr(context, 'scene', None) is None:
            return False
        if getattr(context, 'window_manager', None) is None:
            return False
        return True
    except Exception:
        return False


def _context_mode_is_safe_for_panel(cls: type, context) -> bool:
    if not _context_is_basically_valid(context):
        return False
    try:
        if str(getattr(cls, 'bl_space_type', '') or '') != 'VIEW_3D':
            return True
        mode = str(getattr(context, 'mode', '') or 'OBJECT')
        return mode not in _VOLATILE_VIEW3D_MODES
    except Exception:
        return False


def _custom_poll_for_class(cls: type):
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
        operator_base = getattr(bpy.types, 'Operator', None)
        for base in getattr(cls, '__mro__', ()) or ():
            if (panel_base is not None and base is panel_base) or (operator_base is not None and base is operator_base):
                break
            if 'poll' in getattr(base, '__dict__', {}):
                return getattr(cls, 'poll', None)
    except Exception:
        pass
    return None


def _guard_text(en_text: str, ja_text: str) -> str:
    try:
        if str(bpy.app.translations.locale or '').startswith('ja'):
            return ja_text
    except Exception:
        pass
    return en_text


def _draw_panel_guard_message(layout, _context) -> None:
    try:
        layout.label(
            text=_guard_text('Smart Animation UI is hidden while the current View3D mode is changing or unsupported.', 'モードの切り替え中か対応していないモードのため、Smart Animation の画面を隠しています。'),
        )
    except Exception:
        pass


def _short_error(exc: Exception) -> str:
    try:
        text = str(exc)
    except Exception:
        text = type(exc).__name__
    try:
        from .translation import sas_error_reason
        return _guard_text(text[:240], sas_error_reason(text))
    except Exception:
        return text[:240]


def _report_callback_error(owner, context, exc: Exception, *, fallback: str = 'Callback failed') -> None:
    message = _short_error(exc) or fallback
    try:
        owner.report({'ERROR'}, message)
        return
    except Exception:
        pass
    try:
        pass  # Console-silent bundled-tool diagnostic.
    except Exception:
        pass


def disable_panel_header_callbacks(cls: type) -> type:
    """Remove panel header callbacks before registration."""
    if not is_panel_class(cls):
        return cls
    for callback_name in _HEADER_CALLBACK_NAMES:
        try:
            if callback_name not in getattr(cls, '__dict__', {}):
                continue
            if getattr(vars(cls)[callback_name], '_sas_safe_help_header', False):
                continue
            original_attr_name = f"_sas_original_{callback_name}"
            if not hasattr(cls, original_attr_name):
                setattr(cls, original_attr_name, getattr(cls, callback_name, None))
            try:
                delattr(cls, callback_name)
            except Exception:
                try:
                    setattr(cls, callback_name, None)
                except Exception:
                    pass
            setattr(cls, f"{callback_name}{_EMPTY_HEADER_MARKER}", True)
        except Exception:
            pass
    return cls


def _install_bundled_panel_help(cls: type) -> None:
    package_prefix = __package__ + '.'
    module = cls.__module__
    if not module.startswith(package_prefix):
        return
    topic = module[len(package_prefix):].partition('.')[0]
    if topic not in _BUNDLED_PANEL_HELP_TOPICS:
        return
    options = getattr(cls, 'bl_options', None) or ()
    if 'HIDE_HEADER' in options or 'INSTANCED' in options or getattr(cls, 'bl_region_type', '') == 'HEADER':
        return

    def draw_header_preset(self, _context):
        # The native header can draw during an editor or mode transition.
        # The help dispatcher reads its catalog only when the user opens it.
        try:
            button = self.layout.operator('sas.show_help', text='', icon='QUESTION')
            button.topic_key = f'tool:{topic}'
        except (AttributeError, ReferenceError, RuntimeError):
            return

    draw_header_preset._sas_safe_help_header = True
    cls.draw_header_preset = draw_header_preset


def harden_panel_callbacks(cls: type) -> type:
    """Make non-root Panel callbacks exception-safe before registration.

    Native Smart Tools Manager roots provide their own guarded poll/draw methods
    and must retain byte-stable class metadata and callbacks across generations.
    """
    if not is_panel_class(cls):
        return cls
    try:
        if vars(cls).get('_smart_tools_manager_native_npanel_root', False) is True:
            return cls
    except Exception:
        pass
    disable_panel_header_callbacks(cls)
    try:
        if getattr(cls, _SAFE_PANEL_MARKER, False):
            return cls
    except Exception:
        return cls

    _install_bundled_panel_help(cls)

    try:
        original_poll = _custom_poll_for_class(cls)
        if not hasattr(cls, _ORIGINAL_POLL_NAME):
            setattr(cls, _ORIGINAL_POLL_NAME, original_poll)

        @classmethod
        def _sas_safe_poll(inner_cls, context):
            if not _context_mode_is_safe_for_panel(inner_cls, context):
                return False
            stored_poll = getattr(inner_cls, _ORIGINAL_POLL_NAME, None)
            if not callable(stored_poll):
                return True
            try:
                return bool(stored_poll(context))
            except Exception:
                return False

        cls.poll = _sas_safe_poll
    except Exception:
        pass

    try:
        original_draw = getattr(cls, 'draw', None)
        if callable(original_draw) and not hasattr(cls, _ORIGINAL_DRAW_NAME):
            setattr(cls, _ORIGINAL_DRAW_NAME, original_draw)

            panel_cls = cls

            def _sas_safe_draw(self, context):
                layout = getattr(self, 'layout', None)
                # Resolve against the class captured during hardening.  Besides
                # being safer for Manager proxy drawing, this also supports
                # Blender-style unbound callback validation where ``self`` is a
                # lightweight proxy rather than an actual Panel instance.
                if not _context_mode_is_safe_for_panel(panel_cls, context):
                    if layout is not None:
                        _draw_panel_guard_message(layout, context)
                    return None
                draw_fn = getattr(panel_cls, _ORIGINAL_DRAW_NAME, None)
                if not callable(draw_fn):
                    return None
                try:
                    return draw_fn(self, context)
                except Exception as exc:
                    try:
                        box = layout.box() if layout is not None else None
                        if box is not None:
                            box.alert = True
                            box.label(text=_guard_text('Panel draw skipped to prevent Blender UI crash.', '画面の描画を止めました。'), icon='ERROR')
                            box.label(text=_short_error(exc), translate=False)
                    except Exception:
                        pass
                    return None

            cls.draw = _sas_safe_draw
    except Exception:
        pass

    try:
        setattr(cls, _SAFE_PANEL_MARKER, True)
    except Exception:
        pass
    return cls


def harden_operator_callbacks(cls: type) -> type:
    """Make Operator callbacks exception-safe without changing successful paths."""
    if not is_operator_class(cls):
        return cls
    try:
        if getattr(cls, _SAFE_OPERATOR_MARKER, False):
            return cls
    except Exception:
        return cls

    try:
        original_poll = _custom_poll_for_class(cls)
        if original_poll is not None and not hasattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'poll'):
            setattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'poll', original_poll)

            @classmethod
            def _sas_operator_safe_poll(inner_cls, context):
                stored_poll = getattr(inner_cls, _ORIGINAL_OPERATOR_PREFIX + 'poll', None)
                if not callable(stored_poll):
                    return True
                try:
                    return bool(stored_poll(context))
                except Exception:
                    return False

            cls.poll = _sas_operator_safe_poll
    except Exception:
        pass

    try:
        original_description = getattr(cls, 'description', None)
        if callable(original_description) and not hasattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'description'):
            setattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'description', original_description)

            @classmethod
            def _sas_operator_safe_description(inner_cls, context, properties):
                stored = getattr(inner_cls, _ORIGINAL_OPERATOR_PREFIX + 'description', None)
                if callable(stored):
                    try:
                        return str(stored(context, properties) or '')
                    except Exception:
                        pass
                try:
                    return str(getattr(inner_cls, 'bl_description', '') or getattr(inner_cls, 'bl_label', '') or '')
                except Exception:
                    return ''

            cls.description = _sas_operator_safe_description
    except Exception:
        pass

    def _store_original_callback(callback_name: str):
        try:
            original = getattr(cls, callback_name, None)
            if not callable(original):
                return None
            original_name = _ORIGINAL_OPERATOR_PREFIX + callback_name
            if not hasattr(cls, original_name):
                setattr(cls, original_name, original)
            return original_name
        except Exception:
            return None

    def _call_stored_operator_callback(self, original_name: str, fallback, context, *args):
        stored = getattr(type(self), original_name, None)
        if not callable(stored):
            return fallback
        try:
            return stored(self, context, *args)
        except Exception as exc:
            _report_callback_error(self, context, exc, fallback='Operator callback failed')
            return fallback

    execute_original = _store_original_callback('execute')
    if execute_original:
        def _sas_operator_safe_execute(self, context):
            return _call_stored_operator_callback(self, execute_original, {'CANCELLED'}, context)
        cls.execute = _sas_operator_safe_execute

    invoke_original = _store_original_callback('invoke')
    if invoke_original:
        def _sas_operator_safe_invoke(self, context, event):
            return _call_stored_operator_callback(self, invoke_original, {'CANCELLED'}, context, event)
        cls.invoke = _sas_operator_safe_invoke

    modal_original = _store_original_callback('modal')
    if modal_original:
        def _sas_operator_safe_modal(self, context, event):
            return _call_stored_operator_callback(self, modal_original, {'CANCELLED'}, context, event)
        cls.modal = _sas_operator_safe_modal

    try:
        original_draw = getattr(cls, 'draw', None)
        if callable(original_draw) and not hasattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'draw'):
            setattr(cls, _ORIGINAL_OPERATOR_PREFIX + 'draw', original_draw)

            def _sas_operator_safe_draw(self, context):
                stored = getattr(type(self), _ORIGINAL_OPERATOR_PREFIX + 'draw', None)
                if not callable(stored):
                    return None
                try:
                    return stored(self, context)
                except Exception as exc:
                    try:
                        layout = getattr(self, 'layout', None)
                        if layout is not None:
                            box = layout.box()
                            box.alert = True
                            box.label(text='Operator draw skipped to prevent UI error.', icon='ERROR')
                            box.label(text=_short_error(exc), translate=False)
                    except Exception:
                        pass
                    return None

            cls.draw = _sas_operator_safe_draw
    except Exception:
        pass

    try:
        setattr(cls, _SAFE_OPERATOR_MARKER, True)
    except Exception:
        pass
    return cls


def harden_menu_callbacks(cls: type) -> type:
    if not is_menu_class(cls):
        return cls
    try:
        if getattr(cls, _SAFE_MENU_MARKER, False):
            return cls
    except Exception:
        return cls
    try:
        original_draw = getattr(cls, 'draw', None)
        if callable(original_draw) and not hasattr(cls, _ORIGINAL_MENU_DRAW_NAME):
            setattr(cls, _ORIGINAL_MENU_DRAW_NAME, original_draw)

            def _sas_safe_menu_draw(self, context):
                stored = getattr(type(self), _ORIGINAL_MENU_DRAW_NAME, None)
                if not callable(stored):
                    return None
                try:
                    return stored(self, context)
                except Exception as exc:
                    try:
                        layout = getattr(self, 'layout', None)
                        if layout is not None:
                            layout.label(text='Menu draw skipped.', icon='ERROR')
                            layout.label(text=_short_error(exc), translate=False)
                    except Exception:
                        pass
                    return None

            cls.draw = _sas_safe_menu_draw
    except Exception:
        pass
    try:
        setattr(cls, _SAFE_MENU_MARKER, True)
    except Exception:
        pass
    return cls


def harden_uilist_callbacks(cls: type) -> type:
    if not is_uilist_class(cls):
        return cls
    try:
        if getattr(cls, _SAFE_UILIST_MARKER, False):
            return cls
    except Exception:
        return cls
    try:
        original_draw_item = getattr(cls, 'draw_item', None)
        if callable(original_draw_item) and not hasattr(cls, _ORIGINAL_UILIST_DRAW_ITEM_NAME):
            # RNA supports callbacks with neither optional argument, index
            # alone, or both index and flt_flag. Select the arity before draw.
            parameters = signature(original_draw_item)
            for argument_count in (10, 9, 8):
                try:
                    parameters.bind(*([None] * argument_count))
                except TypeError:
                    continue
                break
            else:
                return cls
            setattr(cls, _ORIGINAL_UILIST_DRAW_ITEM_NAME, original_draw_item)

            # Blender validates UIList.draw_item by inspecting the Python
            # callable signature during register_class. A variadic wrapper
            # such as *args/**kwargs is rejected in Blender 5.1, so keep the
            # standard explicit signature and make only the body exception-safe.
            def _sas_safe_draw_item(
                self,
                context,
                layout,
                data,
                item,
                icon,
                active_data,
                active_propname,
                index=0,
                flt_flag=0,
            ):
                stored = getattr(type(self), _ORIGINAL_UILIST_DRAW_ITEM_NAME, None)
                if not callable(stored):
                    return None
                try:
                    arguments = (
                        self,
                        context,
                        layout,
                        data,
                        item,
                        icon,
                        active_data,
                        active_propname,
                        index,
                        flt_flag,
                    )
                    return stored(*arguments[:argument_count])
                except Exception:
                    return None

            cls.draw_item = _sas_safe_draw_item
    except Exception:
        pass
    try:
        setattr(cls, _SAFE_UILIST_MARKER, True)
    except Exception:
        pass
    return cls


def harden_class_callbacks(cls: type) -> type:
    """Apply every safe callback guard relevant to a Blender RNA class."""
    try:
        harden_panel_callbacks(cls)
        harden_operator_callbacks(cls)
        harden_menu_callbacks(cls)
        harden_uilist_callbacks(cls)
    except Exception:
        pass
    return cls


def disable_many_panel_header_callbacks(classes: Iterable[type]) -> None:
    for cls in tuple(classes or ()):  # copy so callers can pass generators safely
        try:
            disable_panel_header_callbacks(cls)
        except Exception:
            pass


def harden_many_panel_callbacks(classes: Iterable[type]) -> None:
    for cls in tuple(classes or ()):
        try:
            harden_panel_callbacks(cls)
        except Exception:
            pass


def harden_many_class_callbacks(classes: Iterable[type]) -> None:
    for cls in tuple(classes or ()):
        try:
            harden_class_callbacks(cls)
        except Exception:
            pass
