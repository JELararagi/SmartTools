# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

import math

import bpy
from bpy.types import Operator
from mathutils import Vector

from .translation import sas_text
from .core import (
    active_object,
    add_log,
    ensure_action_backup,
    get_bake_range,
    get_or_create_action_for_object,
)
from .motion_fx_operators import (
    _axis_index,
    _frame_list,
    _has_foreign_curves,
    _remove_group_fcurves,
    _sas_group_curves,
    _set_vector_idprop,
    _get_vector_idprop,
    _clear_idprop,
    _unique_objects,
    _write_vector_curve_samples,
)


SIGNAL_GROUP = "SAS_MotionSignal"


def _ordered_targets(context, order_mode):
    targets = list(getattr(context, "selected_objects", []) or [])
    active = active_object(context)
    if not targets and active is not None:
        targets = [active]
    targets = _unique_objects(targets)
    order_mode = str(order_mode or 'SELECTION').upper()
    if order_mode == 'NAME':
        targets.sort(key=lambda obj: getattr(obj, 'name', '').lower())
    elif order_mode in {'X', 'Y', 'Z'}:
        axis_index = _axis_index(order_mode)
        targets.sort(key=lambda obj: float(getattr(obj, 'location', (0.0, 0.0, 0.0))[axis_index]))
    return targets


def _signal_target_info(target_mode):
    target_mode = str(target_mode or 'LOCATION').upper()
    if target_mode == 'ROTATION':
        return 'delta_rotation_euler', Vector((0.0, 0.0, 0.0))
    if target_mode == 'SCALE':
        return 'delta_scale', Vector((1.0, 1.0, 1.0))
    return 'delta_location', Vector((0.0, 0.0, 0.0))


def _signal_axes(axis_mode):
    axis_mode = str(axis_mode or 'X').upper()
    mapping = {
        'X': [0],
        'Y': [1],
        'Z': [2],
        'XY': [0, 1],
        'XZ': [0, 2],
        'YZ': [1, 2],
        'XYZ': [0, 1, 2],
    }
    return mapping.get(axis_mode, [0])


def _signal_cycles(frame, start, fps, settings, object_index):
    fps = max(1e-6, float(fps))
    seconds = (float(frame) - float(start)) / fps
    phase = float(getattr(settings, 'signal_phase', 0.0)) + float(getattr(settings, 'signal_object_phase_offset', 0.0)) * float(object_index)
    time_mode = str(getattr(settings, 'signal_time_mode', 'HZ') or 'HZ').upper()
    if time_mode == 'BPM':
        bpm = max(0.0, float(getattr(settings, 'signal_bpm', 120.0)))
        return seconds * (bpm / 60.0) + phase
    frequency = max(0.0, float(getattr(settings, 'signal_frequency', 1.0)))
    return seconds * frequency + phase


def _pseudo_noise(cycles, seed):
    seed = float(seed)
    value = (
        math.sin(math.tau * (cycles + seed * 0.017)) * 0.62
        + math.sin(math.tau * (cycles * 2.371 + seed * 0.113)) * 0.26
        + math.sin(math.tau * (cycles * 5.117 + seed * 0.271)) * 0.12
    )
    return max(-1.0, min(1.0, value))


def _base_wave(cycles, mode, seed=0):
    mode = str(mode or 'SINE').upper()
    if mode == 'NOISE':
        return _pseudo_noise(cycles, seed)
    if mode == 'PULSE':
        frac = cycles - math.floor(cycles)
        return 1.0 if frac < 0.5 else -1.0
    return math.sin(math.tau * cycles)


def _signal_wave(frame, start, fps, settings, object_index):
    mode = str(getattr(settings, 'signal_mode', 'SINE') or 'SINE').upper()
    seed = int(getattr(settings, 'signal_noise_seed', 0)) + int(object_index) * 17
    if mode == 'STEP':
        step_frames = max(1, int(getattr(settings, 'signal_step_frames', 2)))
        held_frame = int(start) + ((int(frame) - int(start)) // step_frames) * step_frames
        held_cycles = _signal_cycles(held_frame, start, fps, settings, object_index)
        return _base_wave(held_cycles, 'SINE', seed=seed)
    cycles = _signal_cycles(frame, start, fps, settings, object_index)
    return _base_wave(cycles, mode, seed=seed)


def _signal_samples(base_value, frames, start, fps, settings, object_index):
    base_value = Vector(base_value)
    axes = _signal_axes(getattr(settings, 'signal_axes', 'X'))
    amplitude = float(getattr(settings, 'signal_amplitude', 0.25))
    target_mode = str(getattr(settings, 'signal_target', 'LOCATION') or 'LOCATION').upper()
    samples = {}
    for frame in frames:
        wave = _signal_wave(frame, start, fps, settings, object_index)
        sample = Vector(base_value)
        if target_mode == 'SCALE':
            factor = max(0.001, 1.0 + wave * amplitude)
            for axis_index in axes:
                sample[axis_index] = base_value[axis_index] * factor
        else:
            for axis_index in axes:
                sample[axis_index] = base_value[axis_index] + wave * amplitude
        samples[int(frame)] = sample
    return samples


class SAS_OT_apply_motion_signal(Operator):
    bl_idname = "sas.apply_motion_signal"
    bl_label = "Apply Motion Signal"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Generate editable delta-transform keys from a compact procedural signal. This acts like a Blender-friendly superset of Signal-style loop, noise, pulse, and stop-motion helpers while safely skipping objects that already use non-SAS animation on the chosen delta channel.",
            "コンパクトなプロシージャル信号から、編集可能な delta 変換キーを生成します。Signal 系のループ、ノイズ、パルス、ストップモーション補助を Blender 向けにまとめた実務寄り上位機能で、選択した delta チャンネルに非 SAS アニメーションがあるオブジェクトは安全のため自動的にスキップします。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        targets = _ordered_targets(context, getattr(settings, 'signal_order', 'SELECTION'))
        if not targets:
            self.report({'WARNING'}, sas_text("No objects were selected for Motion Signal.", "Motion Signal の対象オブジェクトが選択されていません。", context))
            add_log(context, "WARN", "Motion Signal cancelled because no objects were selected.", "対象オブジェクトが選択されていないため Motion Signal を中止しました。")
            return {'CANCELLED'}

        start, end = get_bake_range(scene, settings)
        frames = _frame_list(start, end, settings.frame_step)
        if len(frames) < 2:
            self.report({'WARNING'}, sas_text("The bake range is too short for Motion Signal.", "Motion Signal にはベイク範囲が短すぎます。", context))
            add_log(context, "WARN", "Motion Signal cancelled because the bake range was too short.", "ベイク範囲が短すぎるため Motion Signal を中止しました。")
            return {'CANCELLED'}

        fps = float(getattr(getattr(scene, 'render', None), 'fps', 24.0) or 24.0)
        data_path, default_base = _signal_target_info(getattr(settings, 'signal_target', 'LOCATION'))
        base_attr = data_path
        processed = 0
        skipped_foreign = 0
        skipped_existing = 0
        failed = 0
        total_written = 0
        current_frame = int(scene.frame_current)

        try:
            for object_index, obj in enumerate(targets):
                action = getattr(getattr(obj, 'animation_data', None), 'action', None)
                if action is not None and _has_foreign_curves(action, obj, data_path, SIGNAL_GROUP):
                    skipped_foreign += 1
                    continue

                existing_sas = bool(action and _sas_group_curves(action, obj, data_path, SIGNAL_GROUP))
                if existing_sas and not settings.signal_replace_existing:
                    skipped_existing += 1
                    continue

                try:
                    base_value = Vector(getattr(obj, base_attr, default_base))
                except Exception:
                    base_value = Vector(default_base)
                samples = _signal_samples(base_value, frames, start, fps, settings, object_index)

                if settings.preview_only:
                    processed += 1
                    total_written += len(samples) * 3
                    continue

                if action is not None:
                    ensure_action_backup(context, 'motion_signal', obj=obj, action=action)
                action = get_or_create_action_for_object(obj, base_name=f"{obj.name}_MotionSignal")
                if existing_sas and settings.signal_replace_existing:
                    _remove_group_fcurves(action, obj, data_path, SIGNAL_GROUP)

                interpolation = 'CONSTANT' if str(getattr(settings, 'signal_mode', 'SINE')).upper() in {'STEP', 'PULSE'} else 'LINEAR'
                handle_type = 'VECTOR' if interpolation == 'CONSTANT' else 'AUTO_CLAMPED'
                written = _write_vector_curve_samples(
                    action,
                    obj,
                    data_path,
                    SIGNAL_GROUP,
                    samples,
                    interpolation=interpolation,
                    handle_type=handle_type,
                )
                if written < 3:
                    failed += 1
                    continue

                try:
                    setattr(obj, base_attr, base_value)
                except Exception:
                    pass
                _set_vector_idprop(obj, 'sas_motion_signal_base', base_value)
                obj['sas_motion_signal_target'] = data_path
                obj['sas_motion_signal_active'] = True
                processed += 1
                total_written += len(samples) * written
        finally:
            scene.frame_set(current_frame)

        if settings.preview_only:
            message_en = (
                f"Motion Signal Preview — target {data_path}, mode {settings.signal_mode}, {processed} objects, "
                f"{len(frames)} sampled frames, {total_written} keyed values, {skipped_foreign} foreign-channel skips, "
                f"{skipped_existing} existing SAS skips."
            )
            message_ja = (
                f"Motion Signal プレビュー — 対象 {data_path}、モード {settings.signal_mode}、{processed} 個のオブジェクト、"
                f"{len(frames)} フレームをサンプリング、{total_written} 個のキー値対象、非 SAS チャンネル {skipped_foreign} 件、"
                f"既存 SAS スキップ {skipped_existing} 件。"
            )
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, 'INFO', message_en, message_ja)
            return {'FINISHED'}

        if processed == 0:
            self.report({'WARNING'}, sas_text("No objects were updated. Check the selection and safety filters.", "更新されたオブジェクトはありませんでした。選択状態と安全フィルターを確認してください。", context))
            add_log(context, 'WARN', f"Motion Signal updated no objects. Foreign skips: {skipped_foreign}, existing SAS skips: {skipped_existing}, failures: {failed}.", f"Motion Signal は更新対象がありませんでした。非 SAS スキップ {skipped_foreign}、既存 SAS スキップ {skipped_existing}、失敗 {failed}。")
            return {'CANCELLED'}

        message_en = (
            f"Applied Motion Signal to {processed} objects on {data_path} over frames {start}-{end}. "
            f"Mode {settings.signal_mode}, foreign skips {skipped_foreign}, existing SAS skips {skipped_existing}, failures {failed}."
        )
        message_ja = (
            f"フレーム {start}-{end} で {processed} 個のオブジェクトへ {data_path} の Motion Signal を適用しました。"
            f"モード {settings.signal_mode}、非 SAS スキップ {skipped_foreign}、既存 SAS スキップ {skipped_existing}、失敗 {failed}。"
        )
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, 'INFO', message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_clear_motion_signal(Operator):
    bl_idname = "sas.clear_motion_signal"
    bl_label = "Clear Motion Signal"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation Motion Signal curves from the selected objects and restore the stored delta-transform base value. Only SAS-generated delta animation is removed, so unrelated animation stays untouched.",
            "選択オブジェクトから Smart Animation の Motion Signal カーブを削除し、保存していた delta 変換の基準値を復元します。削除するのは SAS が生成した delta アニメーションだけなので、無関係なアニメーションはそのまま残ります。",
            context,
        )

    def execute(self, context):
        targets = list(getattr(context, 'selected_objects', []) or [])
        active = active_object(context)
        if not targets and active is not None:
            targets = [active]
        targets = _unique_objects(targets)
        removed_curves = 0
        restored = 0

        for obj in targets:
            action = getattr(getattr(obj, 'animation_data', None), 'action', None)
            if action is not None:
                for data_path in ('delta_location', 'delta_rotation_euler', 'delta_scale'):
                    removed_curves += _remove_group_fcurves(action, obj, data_path, SIGNAL_GROUP)
            target_path = None
            try:
                target_path = obj.get('sas_motion_signal_target')
            except Exception:
                target_path = None
            if target_path and 'sas_motion_signal_base' in obj:
                try:
                    setattr(obj, target_path, _get_vector_idprop(obj, 'sas_motion_signal_base', (0.0, 0.0, 0.0)))
                    restored += 1
                except Exception:
                    pass
            _clear_idprop(obj, 'sas_motion_signal_base')
            _clear_idprop(obj, 'sas_motion_signal_target')
            _clear_idprop(obj, 'sas_motion_signal_active')

        self.report({'INFO'}, sas_text(f"Cleared Motion Signal from {restored} objects and removed {removed_curves} SAS curves.", f"{restored} 個のオブジェクトから Motion Signal を解除し、{removed_curves} 本の SAS カーブを削除しました。", context))
        add_log(context, 'INFO', f"Cleared Motion Signal from {restored} objects and removed {removed_curves} curves.", f"{restored} 個のオブジェクトから Motion Signal を解除し、{removed_curves} 本のカーブを削除しました。")
        return {'FINISHED'}


OPERATOR_SIGNAL_FX_CLASSES = (
    SAS_OT_apply_motion_signal,
    SAS_OT_clear_motion_signal,
)
