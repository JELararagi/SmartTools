# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
from collections import OrderedDict
import re
import textwrap
from typing import Any

import bpy

from . import icons as sas_icons, loader as loader, registry as registry
try:
    from .panel_header_guard import harden_class_callbacks
except Exception:
    def harden_class_callbacks(cls):
        return cls
from .translation import sas_error_reason, sas_text, sanitize_bilingual_text, sas_localize_text, sas_english_source_text, sas_is_japanese

_STATIC_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_REBUILD_TIMER_PENDING = False
_LOAD_TIMER_PENDING = False
_LOAD_QUEUE: set[str] = set()
_IN_PANEL_DRAW = 0
_DRAW_ORIGINAL_MIGRATED_PANELS = False
_CENTRALIZED_ALWAYS_ON_PROPERTY_NAMES = {
    'active_toolbar',
    'active_presetbar',
}



_REGION_PRIORITY: dict[str, tuple[str, ...]] = {
    'PROPERTIES': ('WINDOW',),
    'PREFERENCES': ('WINDOW',),
    'VIEW_3D': ('WINDOW', 'UI', 'HEADER'),
    'IMAGE_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'NODE_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'SEQUENCE_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'CLIP_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'GRAPH_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'DOPESHEET_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'NLA_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'TEXT_EDITOR': ('WINDOW', 'UI', 'HEADER'),
    'FILE_BROWSER': ('WINDOW', 'UI', 'HEADER'),
    'SPREADSHEET': ('WINDOW', 'UI', 'HEADER'),
}


def _t(context, en_text: str, ja_text: str) -> str:
    return sanitize_bilingual_text(sas_text(en_text, ja_text, context), context)


def _static_t(en_text: str, ja_text: str) -> str:
    # Static Blender identifiers are registered in English and translated by the
    # translation table. This prevents class labels/categories from being
    # frozen in whichever language was active during registration.
    return str(en_text)




def _custom_icon_value(key: str) -> int:
    try:
        return int(sas_icons.icon_value(key) or 0)
    except Exception:
        return 0


def _draw_help_button(layout, context, topic_key: str):
    key = str(topic_key or '').strip()
    if not key:
        return None
    try:
        help_row = layout.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
        op = help_row.operator('sas.show_help', text='', icon=sas_icons.builtin_icon_name('help', 'QUESTION'))
        op.topic_key = key
        return op
    except Exception:
        return None


class _SASRuntimeNullLayout:
    __slots__ = ()

    def __getattr__(self, _name):
        return self

    def __setattr__(self, _name, _value):
        return None

    def __call__(self, *args, **kwargs):
        return self

    def __bool__(self):
        return False


_RUNTIME_NULL_LAYOUT = _SASRuntimeNullLayout()


def _runtime_settings(context):
    try:
        return getattr(getattr(context, 'scene', None), 'sas_settings', None)
    except Exception:
        return None


def _runtime_section_storage_key(section_key: str) -> str:
    value = str(section_key or '').strip()
    value = re.sub(r'[^0-9A-Za-z_]+', '_', value).strip('_').lower()
    if not value:
        value = 'section'
    if value == 'show_always_on_toggle_group':
        return value
    if value.startswith('ui_section_'):
        return value
    if value.startswith('section_'):
        return 'ui_' + value
    return 'ui_section_' + value


def _runtime_section_state(context, section_key: str, default: bool = True) -> bool:
    settings = _runtime_settings(context)
    key = _runtime_section_storage_key(section_key)
    if settings is None:
        return bool(default)
    try:
        if hasattr(settings, key):
            return bool(getattr(settings, key))
    except Exception:
        pass
    try:
        return bool(settings.get(key, default))
    except Exception:
        pass
    try:
        return bool(settings[key])
    except Exception:
        return bool(default)


def _runtime_toggle_op(row, context, *, section_key: str, label: str, default_state: bool, text: str = '', icon: str = 'NONE', emboss: bool = True, depress: bool = False):
    try:
        op = row.operator('sas.toggle_ui_section', text=text, icon=icon, emboss=emboss, depress=depress)
    except TypeError:
        op = row.operator('sas.toggle_ui_section', text=text, icon=icon, emboss=emboss)
    op.section_key = str(section_key or '')
    op.label = str(label or '')
    op.default_state = bool(default_state)
    return op


def _runtime_panel_id(section_key: str) -> str:
    value = re.sub(r'[^0-9A-Za-z_]+', '_', str(section_key or '').strip()).strip('_').lower()
    if not value:
        value = 'section'
    return f'sas_runtime_child_{value}'


def _setup_runtime_body(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


_MAX_RUNTIME_SECTION_DRAW_STATE_CACHE = 256
_RUNTIME_SECTION_DRAW_STATE_CACHE: OrderedDict[tuple[int, str], bool] = OrderedDict()


def _runtime_ensure_section_bool_idprop(settings, storage_key: str, default: bool) -> str:
    """Return an RNA BoolProperty defined before class registration."""
    del default
    storage_key = str(storage_key or '').strip()
    if not storage_key or settings is None:
        return ''
    try:
        return storage_key if hasattr(settings, storage_key) else ''
    except Exception:
        return ''


def _runtime_maybe_save_section_state(settings, storage_key: str, expanded: bool, *, context=None) -> None:
    # Compatibility no-op. Native panel_prop changes the registered BoolProperty
    # through its update callback; draw itself performs no RNA/IDProperty/JSON
    # mutation and never infers state changes from layout output.
    del settings, storage_key, expanded, context
    return None


def _draw_runtime_standard_header(header, context, label: str, icon: str, topic_key: str):
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    try:
        header.label(text=label, icon=icon)
    except Exception:
        try:
            header.label(text=label)
        except Exception:
            pass
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(header, context, topic_key)


def _begin_runtime_section(layout, context, section_key: str, en_text: str, ja_text: str, icon: str, topic_key: str, *, default: bool = True):
    if not layout:
        return _RUNTIME_NULL_LAYOUT
    label = _t(context, en_text, ja_text)
    settings = _runtime_settings(context)
    storage_key = _runtime_section_storage_key(section_key)
    prop_name = _runtime_ensure_section_bool_idprop(settings, storage_key, default)

    # Integrated/runtime child sections also use Blender's native collapsible
    # sub-panel control where possible, matching the requested standard ">"
    # disclosure behavior for all non-top-level sections.
    if settings is not None and prop_name:
        try:
            header, panel = layout.panel_prop(settings, prop_name)
            if header is not None:
                _draw_runtime_standard_header(header, context, label, icon, topic_key)
            expanded = panel is not None
            if not expanded:
                return _RUNTIME_NULL_LAYOUT
            return _setup_runtime_body(panel)
        except Exception:
            pass

    header, panel = layout.panel(
        idname=f'sas_runtime_child_{storage_key}',
        default_closed=not _runtime_section_state(context, section_key, default),
    )
    _draw_runtime_standard_header(header, context, label, icon, topic_key)
    if panel is None:
        return _RUNTIME_NULL_LAYOUT
    return _setup_runtime_body(panel)


def _draw_box_header_with_help(box, context, en_text: str, ja_text: str, icon: str, topic_key: str):
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    row.label(text='', icon='BLANK1')
    row.label(text=_t(context, en_text, ja_text), icon=icon)
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(row, context, topic_key)
    return row



def _operator_id_available(op_id: str) -> bool:
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return False
    group_name, op_name = op_id.split('.', 1)
    group = getattr(bpy.ops, group_name, None)
    if group is None:
        return False
    try:
        op = getattr(group, op_name)
    except Exception:
        return False
    try:
        op.get_rna_type()
        return True
    except AttributeError:
        return callable(op)
    except Exception:
        return False


class _MissingUILayoutCallProxy:
    def __getattr__(self, _name):
        return self

    def __setattr__(self, _name, _value):
        return None

    def __call__(self, *args, **kwargs):
        return {'CANCELLED'}


def _guard_missing_layout_target(layout, name: str, args: list, kwargs: dict, context=None):
    if name == 'operator':
        op_id = str(args[0] if args else kwargs.get('operator', '') or '').strip()
        if op_id and not _operator_id_available(op_id):
            fallback_text = kwargs.get('text')
            if fallback_text is None and len(args) > 1:
                fallback_text = args[1]
            fallback_text = str(fallback_text or op_id)
            try:
                layout.label(text=sas_localize_text(fallback_text, context), icon='ERROR')
            except Exception:
                pass
            return _MissingUILayoutCallProxy()
    elif name == 'popover':
        panel_id = str(kwargs.get('panel') or (args[0] if args else '') or '').strip()
        if panel_id and not hasattr(bpy.types, panel_id):
            return _MissingUILayoutCallProxy()
    return None

class _LocalizedLayoutProxy:
    _CHAIN_METHODS = {'row', 'column', 'box', 'split', 'grid_flow', 'column_flow', 'menu_pie'}
    _POSITIONAL_TEXT_INDEX = {
        'label': 0,
        'operator': 1,
        'menu': 1,
        'popover': 1,
        'operator_menu_enum': 2,
        'prop': 2,
        'prop_menu_enum': 2,
        'prop_with_menu': 2,
        'prop_enum': 2,
    }
    _TEXT_METHODS = {
        'label',
        'operator',
        'menu',
        'popover',
        'operator_menu_enum',
        'prop',
        'prop_search',
        'prop_tabs_enum',
        'prop_menu_enum',
        'prop_with_menu',
        'prop_enum',
        'template_search',
    }

    def __init__(self, layout, context=None):
        object.__setattr__(self, '_layout', layout)
        object.__setattr__(self, '_context', context)

    def __getattr__(self, name):
        attr = getattr(self._layout, name)
        if callable(attr):
            def _wrapper(*args, **kwargs):
                args = list(args)
                positional_index = self._POSITIONAL_TEXT_INDEX.get(name)
                if positional_index is not None and len(args) > positional_index and isinstance(args[positional_index], str):
                    args[positional_index] = sas_localize_text(args[positional_index], self._context)
                for key in ('text', 'placeholder', 'heading'):
                    if key in kwargs and isinstance(kwargs.get(key), str):
                        kwargs[key] = sas_localize_text(kwargs.get(key), self._context)
                guarded = _guard_missing_layout_target(self._layout, name, args, kwargs, self._context)
                if guarded is not None:
                    return guarded
                result = attr(*args, **kwargs)
                if name in self._CHAIN_METHODS:
                    return _LocalizedLayoutProxy(result, self._context)
                return result
            return _wrapper
        return attr

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


def _localized_layout(layout, context=None):
    return _LocalizedLayoutProxy(layout, context)


class _PanelDrawProxy:
    """Ephemeral Python proxy for the opt-in original-panel preview path.

    It supplies a localized layout and resolves panel helper methods through their
    descriptors without assigning to the registered Blender Panel class.
    """

    __slots__ = ('layout', '_panel_cls')

    def __init__(self, panel_cls, layout):
        object.__setattr__(self, '_panel_cls', panel_cls)
        object.__setattr__(self, 'layout', layout)

    def __getattr__(self, name):
        value = getattr(self._panel_cls, name)
        descriptor_get = getattr(value, '__get__', None)
        if callable(descriptor_get):
            try:
                return descriptor_get(self, self._panel_cls)
            except Exception:
                pass
        return value


def _call_draw(draw_fn, panel_cls, layout, context):
    """Call an unbound Panel.draw using a non-RNA, non-persistent proxy."""
    proxy = _PanelDrawProxy(panel_cls, _localized_layout(layout, context))
    return draw_fn(proxy, context)


def _append_unique(items: list[str], value: str | None) -> None:
    text = str(value or '').strip()
    if text and text not in items:
        items.append(text)


def _iter_candidate_area_overrides(context, spaces: list[str] | tuple[str, ...]):
    wm = getattr(context, 'window_manager', None)
    windows = list(getattr(wm, 'windows', ()) or ())
    current_window = getattr(context, 'window', None)
    if current_window and current_window not in windows:
        windows.insert(0, current_window)
    elif current_window:
        windows = [current_window] + [win for win in windows if win != current_window]

    for space in [str(item or '').strip() for item in (spaces or ()) if str(item or '').strip()]:
        priorities = _REGION_PRIORITY.get(space, ('WINDOW', 'UI', 'HEADER'))
        for window in windows:
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()):
                if getattr(area, 'type', None) != space:
                    continue
                region = None
                for region_type in priorities:
                    region = next((reg for reg in getattr(area, 'regions', ()) if getattr(reg, 'type', None) == region_type), None)
                    if region is not None:
                        break
                if region is None:
                    region = next(iter(getattr(area, 'regions', ()) or ()), None)
                override = {'window': window, 'screen': screen, 'area': area}
                if region is not None:
                    override['region'] = region
                try:
                    space_data = getattr(getattr(area, 'spaces', None), 'active', None)
                    if space_data is not None:
                        override['space_data'] = space_data
                except Exception:
                    pass
                yield override


def _context_proxy_for_space(context, space_type: str | None, region_type: str | None = None):
    del space_type, region_type
    # Standard N-panel UI: keep Blender's native context unchanged.
    return context


def _preferred_spaces(record: dict, target_kind: str, target_id: str) -> list[str]:
    spec = record.get('spec') or {}
    panels = record.get('panels', ()) or ()
    spaces: list[str] = []
    op_group = str(target_id or '').split('.', 1)[0].strip().lower()
    heuristic = {
        'graph': ('GRAPH_EDITOR',),
        'action': ('DOPESHEET_EDITOR',),
        'anim': ('DOPESHEET_EDITOR',),
        'nla': ('NLA_EDITOR',),
        'view3d': ('VIEW_3D',),
        'object': ('VIEW_3D',),
        'mesh': ('VIEW_3D',),
        'curve': ('VIEW_3D',),
        'pose': ('VIEW_3D',),
        'gpencil': ('VIEW_3D',),
        'grease_pencil': ('VIEW_3D',),
        'boneoffset': ('VIEW_3D',),
        'anim_offset': ('VIEW_3D',),
        'tlfc': ('DOPESHEET_EDITOR',),
        'spl': ('VIEW_3D', 'PROPERTIES'),
        'storytools': ('VIEW_3D', 'DOPESHEET_EDITOR'),
        'wm': ('PROPERTIES', 'VIEW_3D', 'GRAPH_EDITOR', 'DOPESHEET_EDITOR'),
    }.get(op_group, ())
    for item in heuristic:
        _append_unique(spaces, item)
    for cls in panels:
        _append_unique(spaces, getattr(cls, 'bl_space_type', None))
    for item in spec.get('spaces', ()) or ():
        _append_unique(spaces, item)
    if target_kind == 'menu' and not spaces:
        for item in ('PROPERTIES', 'VIEW_3D', 'GRAPH_EDITOR', 'DOPESHEET_EDITOR'):
            _append_unique(spaces, item)
    return spaces


def _temp_override_call(callable_obj, context, spaces: list[str] | tuple[str, ...]):
    last_error = None
    for override in _iter_candidate_area_overrides(context, spaces):
        try:
            with bpy.context.temp_override(**override):
                return callable_obj()
        except Exception as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    return callable_obj()


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SAS_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()



def _safe_register_static_class(cls: type, *, ledger=None) -> None:
    if cls in _STATIC_CLASSES:
        return
    harden_class_callbacks(cls)
    if ledger is not None:
        ledger.register_class(cls, required=True)
    else:
        bpy.utils.register_class(cls)
    _STATIC_CLASSES.append(cls)




def _safe_unregister_class(cls: type) -> None:
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass



def _clear_dynamic_ui_state() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()



def _clear_all_registered_classes() -> None:
    _clear_dynamic_ui_state()
    for cls in reversed(_STATIC_CLASSES):
        _safe_unregister_class(cls)
    _STATIC_CLASSES.clear()




def refresh_all_suites(context=None) -> None:
    del context
    return None


def _schedule_rebuild() -> None:
    global _REBUILD_TIMER_PENDING
    if _REBUILD_TIMER_PENDING:
        return
    _REBUILD_TIMER_PENDING = True
    try:
        rebuild_panels()
    finally:
        _REBUILD_TIMER_PENDING = False


def _queue_alias_load(alias: str) -> None:
    # Forward-compatible alias used by the overview task update callback.
    # _schedule_tool_load is defined later in this module and is resolved at call time.
    _schedule_tool_load(str(alias or '').strip())


def request_overview_alias_load(alias: str) -> None:
    _queue_alias_load(alias)


def request_overview_task_load(task_identifier: str) -> None:
    # UI selection must remain display-only. Do not import/register bundled tools
    # merely because the Overview Task dropdown changed. Tools are loaded only by
    # an explicit Load/Start action or by pressing one of their actual commands.
    del task_identifier
    try:
        loader.initialize_records(force=False)
        _collect_records()
    except Exception:
        pass
    return None



def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE', context=None) -> None:
    text = sanitize_bilingual_text(str(text or '').strip(), context)
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)



def _status_text(record: dict, context=None) -> str:
    status = str(record.get('status') or '')
    if status == 'READY':
        return _t(context, 'Loaded', '読み込み済み')
    if status == 'AVAILABLE':
        return _t(context, 'Ready (Not Loaded)', '使用時に読み込み')
    if status == 'UNSUPPORTED_PLATFORM':
        return _t(context, 'Unsupported platform', '現在の OS・CPU では無効')
    if status == 'FAILED':
        return _t(context, 'Load failed', '読み込み失敗')
    if status == 'DISABLED':
        return _t(context, 'Disabled', '無効')
    return sanitize_bilingual_text(status or _t(context, 'Unknown', '不明'), context)



def _addon_help_en(spec: dict, status: str) -> str:
    overview = str(spec.get('overview_en') or spec.get('description') or spec.get('display_name') or '').strip()
    usage = str(spec.get('usage_en') or '').strip()
    if status == 'READY':
        prefix = 'This tool is currently loaded for the Overview Task N-panel section. '
    else:
        prefix = 'This tool is available from the Smart Animation Overview Task N-panel menu. '
    if not usage:
        usage = 'Choose a category from Overview Task, then use the migrated panels, commands, properties, or settings shown directly in the N-panel.'
    if overview:
        return prefix + f'Function: {overview}. How to use: {usage}'
    return prefix + f'How to use: {usage}'



def _addon_help_ja(spec: dict, status: str) -> str:
    name = str(spec.get('display_name') or 'Integrated Tool').strip()
    overview = str(spec.get('overview_ja') or spec.get('description_ja') or spec.get('overview_en') or spec.get('description') or '').strip()
    usage = str(spec.get('usage_ja') or '').strip()
    if status == 'READY':
        prefix = 'このツールは現在、概要タスクのNパネル表示用に読み込まれています。'
    else:
        prefix = 'このツールは Smart Animation の概要タスクNパネルメニューから利用できます。'
    if not usage:
        usage = '概要タスクで該当カテゴリを選び、Nパネル内に表示される移植済みパネル、コマンド、プロパティ、設定から操作してください。'
    if overview:
        return prefix + f'機能: {name} の元機能を概要タスクへ統合しています。内容: {overview}。使い方: {usage}'
    return prefix + f'機能: {name} の元機能を概要タスクへ統合しています。使い方: {usage}'



def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Integrated Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} from the Overview Task N-panel section. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command from the Overview Task N-panel section. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )



def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or '統合ツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: 概要タスクのNパネル表示から移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すと概要タスクのNパネル表示から移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )



def _addon_help(spec: dict, status: str, context=None) -> str:
    return _addon_help_ja(spec, status) if sas_is_japanese(context) else _addon_help_en(spec, status)



def _target_help(kind: str, label: str, desc: str, context=None, *, is_pie: bool = False) -> str:
    return _target_help_ja(kind, label, desc, is_pie=is_pie) if sas_is_japanese(context) else _target_help_en(kind, label, desc, is_pie=is_pie)



def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''



_OWNER_ACCESSORS = {
    'Scene': lambda context: getattr(context, 'scene', None),
    'WindowManager': lambda context: getattr(context, 'window_manager', None),
    'Window': lambda context: getattr(context, 'window', None),
    'Screen': lambda context: getattr(getattr(context, 'window', None), 'screen', None),
    'Object': lambda context: getattr(context, 'object', None) or getattr(context, 'active_object', None),
    'Material': lambda context: getattr(getattr(context, 'object', None) or getattr(context, 'active_object', None), 'active_material', None),
    'Armature': lambda context: getattr(getattr(context, 'object', None) or getattr(context, 'active_object', None), 'data', None) if getattr(getattr(context, 'object', None) or getattr(context, 'active_object', None), 'type', None) == 'ARMATURE' else None,
    'PoseBone': lambda context: getattr(context, 'active_pose_bone', None),
    'Bone': lambda context: getattr(context, 'active_bone', None),
    'Camera': lambda context: getattr(getattr(context, 'scene', None), 'camera', None),
}


def _owner_target(context, owner_name: str):
    fn = _OWNER_ACCESSORS.get(str(owner_name or '').strip())
    if not callable(fn):
        return None
    try:
        return fn(context)
    except Exception:
        return None


def _owner_prop_meta(owner_obj, prop_name: str):
    props = getattr(getattr(owner_obj, 'bl_rna', None), 'properties', None)
    if props is None:
        return None
    try:
        return props[prop_name]
    except Exception:
        pass
    for prop in props:
        try:
            if getattr(prop, 'identifier', '') == prop_name:
                return prop
        except Exception:
            continue
    return None


def _draw_rna_pointer_properties(layout, ptr, *, depth: int = 0, max_depth: int = 1) -> None:
    props = getattr(getattr(ptr, 'bl_rna', None), 'properties', None)
    if props is None:
        layout.label(text=_t(getattr(bpy, 'context', None), 'No RNA properties available.', 'RNA プロパティを取得できません。'))
        return
    drawn = 0
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '').strip()
        except Exception:
            ident = ''
        if not ident or ident == 'rna_type':
            continue
        if bool(getattr(prop, 'is_hidden', False)) or bool(getattr(prop, 'is_readonly', False)):
            continue
        if ident in _CENTRALIZED_ALWAYS_ON_PROPERTY_NAMES:
            continue
        ptype = str(getattr(prop, 'type', '') or '').upper()
        if ptype == 'POINTER':
            if depth >= max_depth:
                continue
            child = getattr(ptr, ident, None)
            if child is None:
                continue
            sub = layout.box()
            sub.label(text=str(getattr(prop, 'name', ident) or ident), icon='PROPERTIES')
            _draw_rna_pointer_properties(sub, child, depth=depth + 1, max_depth=max_depth)
            drawn += 1
            continue
        if ptype == 'COLLECTION':
            try:
                length = len(getattr(ptr, ident))
            except Exception:
                length = '?'
            layout.label(text=f"{str(getattr(prop, 'name', ident) or ident)}: {length}", icon='PRESET')
            drawn += 1
            continue
        try:
            layout.prop(ptr, ident)
            drawn += 1
        except Exception:
            pass
    if drawn == 0:
        layout.label(text=_t(getattr(bpy, 'context', None), 'No editable properties detected.', '編集可能なプロパティが見つかりません。'))


def _draw_registered_property_entry(layout, context, item: dict) -> None:
    owner_name = str(item.get('owner') or '').strip()
    prop_name = str(item.get('name') or '').strip()
    owner_obj = _owner_target(context, owner_name)
    if owner_obj is None:
        layout.label(text=_t(getattr(bpy, 'context', None), 'This setting is not available now.', 'この設定は今は使えません。'))
        return
    if not hasattr(owner_obj, prop_name):
        layout.label(text=_t(getattr(bpy, 'context', None), 'This setting is not available now.', 'この設定は今は使えません。'))
        return
    prop_meta = _owner_prop_meta(owner_obj, prop_name)
    ptype = str(getattr(prop_meta, 'type', '') or '').upper() if prop_meta is not None else ''
    if ptype == 'POINTER':
        child = getattr(owner_obj, prop_name, None)
        box = layout.box()
        title = str(getattr(prop_meta, 'name', prop_name) or prop_name)
        if title != prop_name:
            box.label(text=title, icon='PROPERTIES')
        if child is None:
            box.label(text=_t(getattr(bpy, 'context', None), 'Pointer target is not available.', 'ポインター先がありません。'))
            return
        _draw_rna_pointer_properties(box, child, depth=0, max_depth=1)
        return
    if ptype == 'COLLECTION':
        try:
            length = len(getattr(owner_obj, prop_name))
        except Exception:
            length = '?'
        layout.label(text=f'{bpy.app.translations.pgettext(str(getattr(prop_meta, "name", "") or prop_name))}: {length}', translate=False, icon='PRESET')
        return
    try:
        if ptype in {'ENUM', 'STRING'}:
            column = layout.column(align=True)
            column.label(text=str(getattr(prop_meta, 'name', '') or prop_name))
            column.prop(owner_obj, prop_name, text='')
        else:
            layout.prop(owner_obj, prop_name)
        return
    except Exception:
        pass
    value = getattr(owner_obj, prop_name, None)
    layout.label(text=f'{bpy.app.translations.pgettext(str(getattr(prop_meta, "name", "") or prop_name))}: {value}', translate=False)



def _readable_identifier(identifier: str) -> str:
    tail = str(identifier or '').rsplit('.', 1)[-1]
    for mark in ('_MT_', '_PT_', '_OT_'):
        if mark in tail:
            tail = tail.split(mark, 1)[1]
    return tail.replace('_', ' ').strip().title()



def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or getattr(cls, '__name__', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = str(getattr(cls, 'bl_label', '') or _readable_identifier(menu_id)).strip()
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or _readable_identifier(menu_id), is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items



def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen:
            continue
        try:
            if 'INTERNAL' in set(getattr(cls, 'bl_options', set()) or set()):
                continue
        except Exception:
            pass
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or '').strip() or _readable_identifier(op_id)
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items



def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick



def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    try:
        op = layout.operator(SMART_ANIMATION_SUITE_9E95E0_OT_integrated_invoke.bl_idname, text=label, icon=icon)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=label)



def _draw_tool_list(layout, record: dict, compact: bool = False, context=None) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=_t(context, 'No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。'),
        )
        return

    if menus:
        box = _begin_runtime_section(layout, context, f'tool_{alias}_menus', 'Menus', 'メニュー', 'MENU_PANEL', f'tool:{alias}', default=False)
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        box = _begin_runtime_section(layout, context, f'tool_{alias}_operators', 'Operators', 'オペレーター', 'TOOL_SETTINGS', f'tool:{alias}', default=False)
        flow = box.grid_flow(row_major=True, columns=1 if compact else 2, even_columns=True, even_rows=False, align=True)
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)



def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _tag_redraw_npanel_areas() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in list(getattr(wm, 'windows', ()) or ()):  # type: ignore[attr-defined]
            screen = getattr(window, 'screen', None)
            for area in list(getattr(screen, 'areas', ()) or ()):  # type: ignore[attr-defined]
                if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _process_load_queue():
    # Compatibility symbol retained; no background load timer is registered.
    return None


def _schedule_tool_load(alias: str) -> None:
    global _LOAD_TIMER_PENDING
    alias = str(alias or '').strip()
    if not alias or _LOAD_TIMER_PENDING:
        return
    record = loader.get_record(alias)
    if not isinstance(record, dict):
        return
    status = str(record.get('status') or '')
    if status in {'READY', 'DISABLED', 'UNSUPPORTED_PLATFORM', 'FAILED'}:
        return
    record['_sas_load_queued'] = True
    _LOAD_TIMER_PENDING = True
    try:
        loader.load_tool(alias)
        _collect_records()
    finally:
        record.pop('_sas_load_queued', None)
        _LOAD_QUEUE.discard(alias)
        _LOAD_TIMER_PENDING = False
        _tag_redraw_npanel_areas()

def _overview_record(alias: str) -> dict[str, Any]:
    """Pure cached lookup used by Panel.draw; registration occurs elsewhere."""
    alias = str(alias or '').strip()
    if not alias:
        return {}
    record = _RECORDS_BY_ALIAS.get(alias)
    return record if isinstance(record, dict) else {}


def _load_overview_record(alias: str) -> dict[str, Any]:
    """Load a bundled tool only from an explicit user action.

    Loading tool modules while Blender is already inside Panel.draw is unsafe on
    some Blender/Python builds because registration, polls, and draw callbacks can
    be rebuilt while the region layout is being evaluated.  Keep this helper out
    of normal draw paths.
    """
    alias = str(alias or '').strip()
    record = _overview_record(alias)
    if not record:
        return {}
    status = str(record.get('status') or '')
    if status not in {'READY', 'DISABLED', 'UNSUPPORTED_PLATFORM'}:
        try:
            loader.load_tool(alias)
        except Exception:
            pass
        try:
            _collect_records()
        except Exception:
            pass
        record = _overview_record(alias)
    return record if isinstance(record, dict) else {}


def _ensure_overview_record(alias: str, *, allow_load: bool = False) -> dict[str, Any]:
    alias = str(alias or '').strip()
    record = _overview_record(alias)
    if not record:
        return {}
    status = str(record.get('status') or '')
    if status not in {'READY', 'DISABLED', 'UNSUPPORTED_PLATFORM', 'FAILED'}:
        if allow_load and _IN_PANEL_DRAW <= 0:
            return _load_overview_record(alias)
        # Display-only mode: drawing the N-panel must not queue imports, timers,
        # class registration, or third-party add-on startup work.
        return record if isinstance(record, dict) else {}
    return record if isinstance(record, dict) else {}


def _draw_overview_background(layout, context, alias: str) -> None:
    background_entries = loader.tool_background_entries(alias)
    if not background_entries:
        return
    bg_box = _begin_runtime_section(layout, context, f'tool_{alias}_background', 'Background Callbacks', '常駐コールバック', 'SETTINGS', f'tool:{alias}', default=False)
    for item in background_entries:
        item_box = bg_box.box()
        label = _t(context, str(item.get('label_en', '') or ''), str(item.get('label_ja', '') or ''))
        item_box.label(text=label, icon='CHECKBOX_HLT' if bool(item.get('enabled')) else 'CHECKBOX_DEHLT')


def _draw_overview_panels(layout, context, record: dict) -> None:
    panels = tuple(record.get('panels', ()) or ())
    if not panels:
        return
    alias = str(record.get('spec', {}).get('alias') or '')
    box = _begin_runtime_section(layout, context, f'tool_{alias}_original_panels', 'Original Panels', '元パネル', 'MENU_PANEL', f'tool:{alias}', default=False)
    if not _DRAW_ORIGINAL_MIGRATED_PANELS:
        for index, panel_cls in enumerate(panels, start=1):
            title = sanitize_bilingual_text(str(getattr(panel_cls, 'bl_label', '') or _readable_identifier(getattr(panel_cls, '__name__', '')) or f'Panel {index}'), context)
            box.label(text=title, icon='DOT')
        return

    # Emergency opt-in path kept disabled by default. Do not enable in normal builds.
    for index, panel_cls in enumerate(panels, start=1):
        title = sanitize_bilingual_text(str(getattr(panel_cls, 'bl_label', '') or _readable_identifier(getattr(panel_cls, '__name__', '')) or f'Panel {index}'), context)
        panel_box = box.box()
        panel_box.label(text=title, icon='TRIA_DOWN')
        draw_fn = getattr(panel_cls, 'draw', None)
        if not callable(draw_fn):
            panel_box.label(text=_t(context, 'Original panel has no draw function.', '元パネルに draw 関数がありません。'))
            continue
        panel_context = _context_proxy_for_space(context, getattr(panel_cls, 'bl_space_type', None), getattr(panel_cls, 'bl_region_type', None))
        poll_fn = getattr(panel_cls, 'poll', None)
        if callable(poll_fn):
            try:
                if not bool(poll_fn(panel_context)):
                    _wrap_lines(panel_box, _t(context, 'This panel is not active in the current context.', '現在のコンテキストではこのパネルは有効になっていません。'), width=72, icon='NONE', context=context)
                    continue
            except Exception as exc:
                panel_box.label(text=_t(context, f'Panel poll failed: {exc}', f'パネルの有効判定に失敗しました: {sas_error_reason(exc)}'), icon='ERROR')
                continue
        try:
            _call_draw(draw_fn, panel_cls, panel_box, context)
        except Exception as exc:
            message = str(exc)
            if 'VIEW_3D' in message and ('Tool' in message or 'ツール' in message):
                panel_box.label(text=_t(context, 'Select a valid 3D View tool first.', '有効な3Dビューのツールを先に選択してください。'))
            else:
                panel_box.label(text=_t(context, f'Panel draw failed: {exc}', f'パネル描画に失敗しました: {sas_error_reason(exc)}'), icon='ERROR')

_INTERNAL_RUNTIME_PROPERTIES = registry.INTERNAL_RUNTIME_PROPERTIES


def _draw_overview_properties(layout, context, record: dict) -> None:
    grouped: dict[str, list[dict]] = {}
    for item in record.get('registered_props', ()) or ():
        owner_name = str(item.get('owner') or '').strip()
        if owner_name not in {'Scene', 'WindowManager'}:
            continue
        if str(item.get('name') or '').strip() in _INTERNAL_RUNTIME_PROPERTIES:
            continue
        grouped.setdefault(owner_name, []).append(item)
    if not grouped:
        return
    alias = str(record.get('spec', {}).get('alias') or '')
    box = _begin_runtime_section(layout, context, f'tool_{alias}_runtime_properties', 'Runtime Properties', '実行時プロパティ', 'PROPERTIES', f'tool:{alias}', default=False)
    for owner_name in sorted(grouped.keys()):
        owner_box = box.box()
        owner_box.label(text=_t(context, 'Scene', 'シーン') if owner_name == 'Scene' else _t(context, 'Window', 'ウィンドウ'), icon='PROPERTIES')
        for item in grouped[owner_name]:
            _draw_registered_property_entry(owner_box, context, item)



def _draw_overview_preferences(layout, context, record: dict) -> None:
    # Add-on Preferences properties are intentionally not rendered or proxied.
    # All user-facing Smart Animation settings live in the N-panel runtime UI.
    return

def _draw_integrated_overview_task(layout, context, alias: str) -> None:
    # Drawing must never import/register bundled tool modules directly.
    # Non-loaded tools stay metadata-only until an explicit Load Tool or command action.
    record = _ensure_overview_record(alias, allow_load=False)
    if not record:
        layout.label(text=_t(context, 'The selected migrated tool was not found.', '選択された移植済みツールが見つかりません。'), icon='ERROR')
        return
    spec = record.get('spec') or {}
    status = str(record.get('status') or '')
    display_name = str(spec.get('display_name') or alias or 'Integrated Tool')

    layout.use_property_split = False
    layout.use_property_decorate = False

    header = _begin_runtime_section(layout, context, f'tool_{alias}', display_name, display_name, 'TOOL_SETTINGS', f'tool:{alias}', default=False)
    if not header:
        return
    row = header.row(align=True)
    row.label(text=_t(context, f'Status: {_status_text(record, context)}', f'状態: {_status_text(record, context)}'))
    row = header.row(align=True)
    row.label(text=sas_localize_text(f"Panels: {len(record.get('panels', ()) or ())}", context))
    row.label(text=sas_localize_text(f"Commands: {len(record.get('operators', ()) or ()) + len(record.get('menus', ()) or ())}", context))

    if status == 'FAILED':
        excerpt = _trace_excerpt(record.get('error', ''))
        warn = header.box()
        warn.alert = True
        _wrap_lines(warn, _t(context, f'Load error: {excerpt or record.get("error", "")}', f'読み込みエラー: {sas_error_reason(excerpt or record.get("error", ""))}'), width=74, icon='ERROR', context=context)
        return
    if status == 'UNSUPPORTED_PLATFORM':
        header.label(text=_t(context, 'This bundled tool is disabled on the current OS or CPU.', 'この同梱ツールは現在の OS または CPU では無効です。'))
        return
    if status == 'DISABLED':
        header.label(text=_t(context, 'This bundled tool is not available because a duplicate or superseded version was skipped.', 'この同梱ツールは重複または上位互換により無効化されています。'))
        return
    if status != 'READY':
        load_box = header.box()
        try:
            op = load_box.operator(
                SMART_ANIMATION_SUITE_9E95E0_OT_integrated_load_tool.bl_idname,
                text=_t(context, 'Load Tool', 'ツールを読み込む'),
                icon='IMPORT',
            )
            op.addon_alias = alias
        except Exception:
            pass
        return

    quick = _quick_entries(record, limit=8)
    if quick:
        quick_box = _begin_runtime_section(header, context, f'tool_{alias}_quick_access', 'Quick Access', 'クイックアクセス', 'TOOL_SETTINGS', f'tool:{alias}', default=False)
        col = quick_box.column(align=True)
        for kind, item_id, label, desc, is_pie in quick:
            _invoke_operator(col, addon_alias=alias, target_kind=kind, target_id=item_id, label=label, desc=desc, is_pie=is_pie)

    _draw_tool_list(header, record, compact=True, context=context)
    _draw_overview_properties(header, context, record)
    _draw_overview_panels(header, context, record)


def draw_integrated_overview_task(layout, context, alias: str) -> None:
    global _IN_PANEL_DRAW
    _IN_PANEL_DRAW += 1
    try:
        _draw_integrated_overview_task(_localized_layout(layout, context), context, str(alias or ''))
    finally:
        _IN_PANEL_DRAW = max(0, _IN_PANEL_DRAW - 1)


class SMART_ANIMATION_SUITE_9E95E0_OT_integrated_load_tool(bpy.types.Operator):
    bl_idname = 'smart_animation_suite.integrated_load_tool'
    bl_label = 'Load Integrated Tool'
    bl_options = {'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _overview_record(alias)
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        name = sanitize_bilingual_text(str(spec.get('display_name') or alias or 'Integrated Tool'), _context)
        return _t(
            _context,
            f'Load {name} now and display its migrated commands, properties, and settings in the Smart Animation N-panel. This is done only on demand to keep startup and normal panel drawing light.',
            f'{name} を今読み込み、移植済みコマンド、プロパティ、設定を Smart Animation Nパネルに表示します。起動時と通常表示を軽くするため、必要な時だけ実行します。',
        )

    def execute(self, context):
        alias = str(getattr(self, 'addon_alias', '') or '').strip()
        if not alias:
            self.report({'WARNING'}, _t(context, 'The target tool is unknown.', '対象ツールが不明です。'))
            return {'CANCELLED'}
        record = _load_overview_record(alias)
        try:
            _collect_records()
        except Exception:
            pass
        if not record or str(record.get('status') or '') == 'FAILED':
            self.report({'ERROR'}, _t(context, 'Tool load failed.', 'ツールの読み込みに失敗しました。'))
            return {'CANCELLED'}
        name = str((record.get('spec') or {}).get('display_name') or alias)
        self.report({'INFO'}, _t(context, f'Loaded: {name}', f'読み込みました: {name}'))
        _tag_redraw_npanel_areas()
        return {'FINISHED'}


class SMART_ANIMATION_SUITE_9E95E0_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'smart_animation_suite.integrated_addon_info'
    bl_label = 'Integrated Add-on Info'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, _context) if isinstance(record, dict) else _t(_context, 'Unknown', '不明')
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help(spec, str(record.get('status') or ''), _context),
            sas_localize_text(f'Status: {status}', _context),
        ]
        if note:
            lines.append(_t(_context, f'Note: {note}', f'メモ: {note}'))
        return ' '.join(str(line) for line in lines if line)

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, _context) if isinstance(record, dict) else _t(_context, 'Unknown', '不明')
        self.report({'INFO'}, f"{sanitize_bilingual_text(str(spec.get('display_name', alias)), _context)} - {sanitize_bilingual_text(status, _context)}")
        return {'FINISHED'}


class SMART_ANIMATION_SUITE_9E95E0_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'smart_animation_suite.integrated_invoke'
    bl_label = 'Integrated Tool'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _target_help(kind, label, desc, _context, is_pie=is_pie)

    def execute(self, context):
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        alias = str(self.addon_alias or '').strip()
        if not target_id:
            self.report({'WARNING'}, _t(context, 'No integrated tool was selected.', '統合ツールが選択されていません。'))
            return {'CANCELLED'}
        record = _RECORDS_BY_ALIAS.get(alias, {})
        if alias and (not isinstance(record, dict) or str(record.get('status') or '') != 'READY'):
            try:
                loader.load_tool(alias)
            except Exception:
                pass
            try:
                _schedule_rebuild()
            except Exception:
                pass
            record = _RECORDS_BY_ALIAS.get(alias, record)
        spaces = _preferred_spaces(record if isinstance(record, dict) else {}, kind, target_id)
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return _temp_override_call(lambda: bpy.ops.wm.call_menu_pie(name=target_id), context, spaces)
                return _temp_override_call(lambda: bpy.ops.wm.call_menu(name=target_id), context, spaces)
            except Exception as exc:
                self.report({'ERROR'}, _t(context, f'The menu could not be opened: {exc}', f'メニューを開けませんでした: {sas_error_reason(exc)}'))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _t(context, f'This command is not available: {_readable_identifier(target_id)}', f'この操作は今は使えません: {_readable_identifier(target_id)}'))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = _temp_override_call(lambda: op_callable(*args), context, spaces)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _t(context, f'The command could not be started: {_readable_identifier(target_id)} ({last_error})', f'操作を開始できませんでした: {_readable_identifier(target_id)}（{sas_error_reason(last_error)}）'))
        return {'CANCELLED'}

class SMART_ANIMATION_SUITE_9E95E0_OT_integrated_overview_task(bpy.types.Operator):
    bl_idname = 'smart_animation_suite.integrated_overview_task'
    bl_label = 'Integrated Overview Task'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _overview_record(alias)
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = str(record.get('status') or '') if isinstance(record, dict) else ''
        base = _addon_help(spec, status, _context) if spec else _t(_context, 'Show the migrated bundled tool group inside the Overview Task N-panel section.', '概要タスクのNパネル表示内に移植済み同梱ツールグループを表示します。')
        return sanitize_bilingual_text(base, _context)

    def invoke(self, context, _event):
        return self.execute(context)

    def execute(self, context):
        record = _load_overview_record(self.addon_alias)
        try:
            _collect_records()
        except Exception:
            pass
        if not record:
            self.report({'WARNING'}, _t(context, 'The selected migrated tool was not found.', '選択された移植済みツールが見つかりません。'))
            return {'CANCELLED'}
        spec = record.get('spec') or {}
        alias = str(self.addon_alias or '').strip()
        group = registry.TOOL_OVERVIEW_GROUPS.get(alias, '')
        settings = getattr(getattr(context, 'scene', None), 'sas_settings', None)
        if settings is not None and group:
            try:
                settings.compact_diag_mode = registry.overview_group_identifier(group)
            except Exception:
                pass
        self.report({'INFO'}, sanitize_bilingual_text(str(spec.get('display_name') or self.addon_alias), context))
        return {'FINISHED'}

    def draw(self, context):
        _draw_integrated_overview_task(_localized_layout(self.layout, context), context, str(self.addon_alias or ''))


# Dynamic legacy host panels were intentionally removed.
# The suite now exposes a normal Blender N-panel through ui.SAS_PT_main only;
# integrated add-on controls are rendered on demand inside the Overview Task N-panel section.

def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)



def rebuild_panels() -> None:
    _clear_dynamic_ui_state()
    _collect_records()


def register(*, ledger=None) -> None:
    for cls in (
        SMART_ANIMATION_SUITE_9E95E0_OT_integrated_load_tool,
        SMART_ANIMATION_SUITE_9E95E0_OT_integrated_addon_info,
        SMART_ANIMATION_SUITE_9E95E0_OT_integrated_invoke,
        SMART_ANIMATION_SUITE_9E95E0_OT_integrated_overview_task,
    ):
        _safe_register_static_class(cls, ledger=ledger)
    rebuild_panels()


def unregister(*, ledger_owned: bool = False) -> None:
    global _LOAD_TIMER_PENDING, _REBUILD_TIMER_PENDING
    _LOAD_QUEUE.clear()
    _LOAD_TIMER_PENDING = False
    _REBUILD_TIMER_PENDING = False
    _RUNTIME_SECTION_DRAW_STATE_CACHE.clear()
    if ledger_owned:
        _clear_dynamic_ui_state()
        _STATIC_CLASSES.clear()
    else:
        _clear_all_registered_classes()
