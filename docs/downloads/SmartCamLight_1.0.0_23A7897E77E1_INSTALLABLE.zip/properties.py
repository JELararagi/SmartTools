# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from . import lifecycle, scene_index, settings_store, translation as tr


def _enum(items):
    return [(ident, tr.add(en, ja), tr.add(desc_en, desc_ja)) for ident, en, ja, desc_en, desc_ja in items]


def _light_object_poll(self, obj):
    return bool(obj and getattr(obj, 'type', None) in {'EMPTY', 'MESH', 'CAMERA', 'LIGHT'})


def _dynamic_sun_object_poll(self, obj):
    return bool(obj and getattr(obj, 'type', None) == 'LIGHT')


def _runtime_module():
    try:
        from . import runtime
        return runtime
    except Exception:
        return None


def _update_live_runtime(self=None, context=None) -> None:
    module = _runtime_module()
    if module is None:
        return
    try:
        module.on_settings_changed(getattr(context, 'scene', None) if context is not None else None)
    except Exception:
        pass


def _sync_dynamic_sky_if_enabled(self=None, context=None) -> None:
    try:
        enabled = bool(getattr(self, 'live_dynamic_sky_monitor', False))
        scene = getattr(context, 'scene', None) if context is not None else None
        if not enabled and scene is not None:
            enabled = bool(getattr(getattr(scene, 'smart_camlight_suite', None), 'live_dynamic_sky_monitor', False))
    except Exception:
        enabled = False
        scene = None
    if not enabled:
        return
    module = _runtime_module()
    if module is None:
        return
    try:
        module.queue_scene_dirty(scene, 'dynamic_sky_settings')
    except Exception:
        pass


def _update_dynamic_sky_monitor(self, context) -> None:
    _update_live_runtime(self, context)
    _sync_dynamic_sky_if_enabled(self, context)


def _update_dynamic_sky_value(self, context) -> None:
    _sync_dynamic_sky_if_enabled(self, context)


_TARGET_SIZE_MIN = 0.001


def _target_size_value(value, fallback: float) -> float:
    try:
        size = float(value)
    except Exception:
        size = float(fallback)
    return max(_TARGET_SIZE_MIN, size)


def _scene_from_context(context=None):
    try:
        return getattr(context or bpy.context, 'scene', None)
    except Exception:
        return None


def _update_camera_target_size(self, context) -> None:
    scene = _scene_from_context(context)
    cam = scene_index.camera_object_for_settings(self, scene)
    if cam is None:
        return
    source_uuid = scene_index.persistent_uuid(cam, 'OBJECT', ensure=True)
    display_size = _target_size_value(getattr(self, 'rig_target_size', 0.04), 0.04)
    for helper in scene_index.owned_helpers_for_source(scene, source_uuid, 'camera_rig_target'):
        try:
            helper.empty_display_size = display_size
        except Exception:
            pass


def _update_light_target_size(self, context) -> None:
    scene = _scene_from_context(context)
    display_size = _target_size_value(getattr(self, 'target_size', 0.05), 0.05)
    for light in scene_index.light_objects_for_settings(self, scene):
        source_uuid = scene_index.persistent_uuid(light, 'OBJECT', ensure=True)
        for helper in scene_index.owned_helpers_for_source(scene, source_uuid, 'light_target'):
            try:
                helper.empty_display_size = display_size
            except Exception:
                pass


def _update_light_max_bounces(self, context) -> None:
    scene = _scene_from_context(context)
    value = max(0, min(1024, int(getattr(self, 'max_bounces', 1024))))
    seen = set()
    for light in scene_index.light_objects_for_settings(self, scene):
        data = getattr(light, 'data', None)
        pointer = id(data)
        if data is None or pointer in seen:
            continue
        seen.add(pointer)
        cycles = getattr(data, 'cycles', None)
        if cycles is not None and hasattr(cycles, 'max_bounces'):
            try:
                cycles.max_bounces = value
            except Exception:
                pass


def sync_target_display_sizes(context=None) -> int:
    """Apply helper sizes with one indexed pass per Scene."""
    count = 0
    scenes = tuple(getattr(getattr(bpy, 'data', None), 'scenes', ()) or ())
    for scene in scenes:
        index = scene_index.get_index(scene) or scene_index.rebuild_scene(scene, ensure_uuids=True)
        if index is None:
            continue
        for cam in index.cameras:
            try:
                source_uuid = scene_index.persistent_uuid(cam, 'OBJECT', ensure=True)
                size = _target_size_value(cam.data.smart_camlight_settings.rig_target_size, 0.04)
                for helper in index.owned_helpers.get((source_uuid, 'camera_rig_target'), ()):
                    if abs(float(getattr(helper, 'empty_display_size', size)) - size) > 1.0e-9:
                        helper.empty_display_size = size
                        count += 1
            except Exception:
                pass
        for light in index.lights:
            try:
                source_uuid = scene_index.persistent_uuid(light, 'OBJECT', ensure=True)
                size = _target_size_value(light.data.smart_camlight_light.target_size, 0.05)
                for helper in index.owned_helpers.get((source_uuid, 'light_target'), ()):
                    if abs(float(getattr(helper, 'empty_display_size', size)) - size) > 1.0e-9:
                        helper.empty_display_size = size
                        count += 1
            except Exception:
                pass
    return count


def sync_light_native_settings(scene=None) -> int:
    """Apply persisted light helper values at a finite lifecycle boundary."""
    scenes = (scene,) if scene is not None else tuple(getattr(getattr(bpy, 'data', None), 'scenes', ()) or ())
    changed = 0
    seen = set()
    for target_scene in scenes:
        index = scene_index.get_index(target_scene) or scene_index.rebuild_scene(target_scene, ensure_uuids=True)
        if index is None:
            continue
        for obj in index.lights:
            data = getattr(obj, 'data', None)
            pointer = id(data)
            if data is None or pointer in seen:
                continue
            seen.add(pointer)
            lset = getattr(data, 'smart_camlight_light', None)
            cycles = getattr(data, 'cycles', None)
            if lset is None or cycles is None or not hasattr(cycles, 'max_bounces'):
                continue
            value = max(0, min(1024, int(getattr(lset, 'max_bounces', 1024))))
            try:
                if int(getattr(cycles, 'max_bounces')) != value:
                    cycles.max_bounces = value
                    changed += 1
            except Exception:
                pass
    return changed


FRAME_RANGE_ITEMS = _enum([
    ('PER_CAMERA', 'Per-Camera Range', 'カメラ別範囲', 'Use the start, end, and step stored on this camera.', 'このカメラに保存した開始、終了、ステップを使用します。'),
    ('TIMELINE_MARKERS', 'Timeline Markers', 'タイムラインマーカー', 'Use timeline markers bound to this camera to derive render ranges and active-camera switching.', 'このカメラにバインドされたタイムラインマーカーからレンダー範囲とアクティブカメラ切替を決定します。'),
])

OUTPUT_FORMAT_ITEMS = _enum([
    ('PNG', 'PNG', 'PNG', 'Save still images as PNG with optional 8-bit or 16-bit color depth.', '静止画をPNGで保存し、8bitまたは16bitの色深度を選べます。'),
    ('JPEG', 'JPEG', 'JPEG', 'Save still images as JPEG using the per-camera quality value.', 'カメラ別の品質値を使って静止画をJPEGで保存します。'),
    ('OPEN_EXR', 'OpenEXR', 'OpenEXR', 'Save high dynamic range still images as OpenEXR.', '高ダイナミックレンジの静止画をOpenEXRで保存します。'),
    ('H264_MP4', 'H.264 MP4', 'H.264 MP4', 'Render animation output as MP4 using H.264 video settings.', 'H.264動画設定を使ってアニメーションをMP4で出力します。'),
    ('H264_MKV', 'H.264 MKV', 'H.264 MKV', 'Render animation output as MKV using H.264 video settings.', 'H.264動画設定を使ってアニメーションをMKVで出力します。'),
    ('PRORES_MOV', 'ProRes MOV', 'ProRes MOV', 'Render animation output as QuickTime ProRes when the Blender FFmpeg build supports it.', 'BlenderのFFmpegビルドが対応している場合、QuickTime ProResでアニメーションを出力します。'),
])

COLOR_DEPTH_ITEMS = _enum([
    ('8', '8 bit', '8 bit', 'Use 8-bit color channels for smaller files.', '小さなファイル用に8bitチャンネルを使用します。'),
    ('16', '16 bit', '16 bit', 'Use 16-bit color channels for smoother gradients.', '滑らかな階調用に16bitチャンネルを使用します。'),
])

EXR_DEPTH_ITEMS = _enum([
    ('16', 'Half Float', '半精度Float', 'Use 16-bit half float OpenEXR channels.', '16bit半精度FloatのOpenEXRチャンネルを使用します。'),
    ('32', 'Full Float', '単精度Float', 'Use 32-bit float OpenEXR channels.', '32bit FloatのOpenEXRチャンネルを使用します。'),
])

EXR_CODEC_ITEMS = _enum([
    ('NONE', 'None', 'なし', 'Disable OpenEXR compression.', 'OpenEXR圧縮を無効にします。'),
    ('PXR24', 'PXR24', 'PXR24', 'Use PXR24 lossy OpenEXR compression.', 'PXR24の非可逆OpenEXR圧縮を使用します。'),
    ('ZIP', 'ZIP', 'ZIP', 'Use ZIP lossless OpenEXR compression.', 'ZIPの可逆OpenEXR圧縮を使用します。'),
    ('PIZ', 'PIZ', 'PIZ', 'Use PIZ wavelet OpenEXR compression.', 'PIZウェーブレットOpenEXR圧縮を使用します。'),
    ('RLE', 'RLE', 'RLE', 'Use run-length OpenEXR compression.', 'ランレングスOpenEXR圧縮を使用します。'),
    ('ZIPS', 'ZIPS', 'ZIPS', 'Use per-scanline ZIP OpenEXR compression.', 'スキャンライン単位のZIP OpenEXR圧縮を使用します。'),
    ('DWAA', 'DWAA', 'DWAA', 'Use DWAA lossy OpenEXR compression.', 'DWAAの非可逆OpenEXR圧縮を使用します。'),
    ('DWAB', 'DWAB', 'DWAB', 'Use DWAB lossy OpenEXR compression.', 'DWABの非可逆OpenEXR圧縮を使用します。'),
])

VIDEO_QUALITY_ITEMS = _enum([
    ('LOSSLESS', 'Lossless', 'ロスレス', 'Use lossless FFmpeg video quality when supported.', '対応している場合、ロスレスのFFmpeg動画品質を使用します。'),
    ('PERC_LOSSLESS', 'Perceptually Lossless', '視覚上ロスレス', 'Use visually lossless FFmpeg video quality.', '視覚上ロスレスに近いFFmpeg動画品質を使用します。'),
    ('HIGH', 'High', '高', 'Use high quality FFmpeg video output.', '高品質のFFmpeg動画出力を使用します。'),
    ('MEDIUM', 'Medium', '中', 'Use medium quality FFmpeg video output.', '中品質のFFmpeg動画出力を使用します。'),
    ('LOW', 'Low', '低', 'Use low quality FFmpeg video output for small preview files.', '小さなプレビューファイル用に低品質のFFmpeg動画出力を使用します。'),
])

AUDIO_CODEC_ITEMS = _enum([
    ('NONE', 'No Audio', '音声なし', 'Do not include audio in the rendered movie.', 'レンダームービーに音声を含めません。'),
    ('AAC', 'AAC', 'AAC', 'Encode audio as AAC when available.', '利用できる場合は音声をAACでエンコードします。'),
    ('MP3', 'MP3', 'MP3', 'Encode audio as MP3 when available.', '利用できる場合は音声をMP3でエンコードします。'),
])

OVERSCAN_MODE_ITEMS = _enum([
    ('PERCENT', 'Percentage', '比率', 'Expand the render resolution by a percentage while preserving aspect ratio.', '縦横比を維持しながらレンダー解像度を比率で拡張します。'),
    ('PIXELS', 'Extra Pixels', '追加ピクセル', 'Add the specified number of pixels to both width and height.', '幅と高さの両方に指定ピクセル数を追加します。'),
    ('SPECIFIC', 'Specific Resolution', '指定解像度', 'Set the render resolution to an exact overscan size.', 'レンダー解像度を指定したオーバースキャンサイズに設定します。'),
])

MOTION_MODE_ITEMS = _enum([
    ('SHUTTER_SPEED', 'Shutter Speed', 'シャッタースピード', 'Convert a photographic shutter speed such as 1/48 into Blender motion blur shutter time.', '1/48などの写真用シャッタースピードをBlenderのモーションブラーシャッター時間へ変換します。'),
    ('SHUTTER_ANGLE', 'Shutter Angle', 'シャッター角', 'Convert a cinema shutter angle such as 180 degrees into Blender motion blur shutter time.', '180度などの映画用シャッター角をBlenderのモーションブラーシャッター時間へ変換します。'),
])

CAMERA_RIG_ITEMS = _enum([
    ('SIMPLE_TARGET', 'Target Rig', 'ターゲットリグ', 'Create a camera target empty and a Track To constraint for aim control.', '照準制御用のターゲットEmptyとTrack Toコンストレイントを作成します。'),
    ('DOLLY_TARGET', 'Dolly Target Rig', 'ドリーターゲットリグ', 'Create a parent dolly empty plus a target empty so the camera can be moved and aimed separately.', '親ドリーEmptyとターゲットEmptyを作成し、カメラ移動と照準を分けて制御できます。'),
])

LIGHT_TYPE_ITEMS = _enum([
    ('POINT', 'Point', 'ポイント', 'Create omnidirectional point lights.', '全方向のポイントライトを作成します。'),
    ('SUN', 'Sun', 'サン', 'Create directional sun lights.', '平行光のサンライトを作成します。'),
    ('SPOT', 'Spot', 'スポット', 'Create spot lights that point toward the target.', 'ターゲットへ向くスポットライトを作成します。'),
    ('AREA', 'Area', 'エリア', 'Create soft area lights for studio setups.', 'スタジオ設定用の柔らかいエリアライトを作成します。'),
])

AREA_SHAPE_ITEMS = _enum([
    ('SQUARE', 'Square', '正方形', 'Use a square area-light emitter.', '正方形のエリアライト発光面を使用します。'),
    ('RECTANGLE', 'Rectangle', '長方形', 'Use a rectangular area-light emitter with separate X and Y size.', 'X/Y別サイズの長方形エリアライト発光面を使用します。'),
    ('DISK', 'Disk', '円盤', 'Use a disk area-light emitter when supported by Blender.', 'Blenderが対応している場合は円盤エリアライト発光面を使用します。'),
    ('ELLIPSE', 'Ellipse', '楕円', 'Use an ellipse area-light emitter when supported by Blender.', 'Blenderが対応している場合は楕円エリアライト発光面を使用します。'),
])

LIGHT_DISTRIBUTION_ITEMS = _enum([
    ('CIRCLE', 'Circle', '円形', 'Distribute generated lights around the target on a circle.', '生成ライトをターゲット周囲の円形に配置します。'),
    ('GRID', 'Grid', 'グリッド', 'Distribute generated lights on a front-facing grid.', '生成ライトを正面向きグリッドに配置します。'),
    ('RANDOM', 'Random', 'ランダム', 'Distribute generated lights randomly around the target.', '生成ライトをターゲット周囲にランダム配置します。'),
    ('LINE', 'Line', 'ライン', 'Distribute generated lights along a horizontal line.', '生成ライトを水平ライン上に配置します。'),
])

STUDIO_PRESET_ITEMS = _enum([
    ('THREE_POINT', 'Three Point', 'スリーポイント', 'Create key, fill, and rim lights for a standard character or product setup.', '標準的な人物・商品用にキー、フィル、リムライトを作成します。'),
    ('SOFT_STUDIO', 'Soft Studio', 'ソフトスタジオ', 'Create large soft area lights for clean product and turntable lighting.', '商品やターンテーブル照明用に大きな柔らかいエリアライトを作成します。'),
    ('RIM_CIRCLE', 'Rim Circle', 'リム円形', 'Create multiple rim lights around the target.', 'ターゲット周囲に複数のリムライトを作成します。'),
    ('PRODUCT_STRIP', 'Product Strip', '商品ストリップ', 'Create vertical strip lights suited to reflective products.', '反射のある商品向けの縦ストリップライトを作成します。'),
    ('SKY_FILL', 'Sky Fill', 'スカイフィル', 'Create a broad sky-fill area light and optional procedural sky world.', '広いスカイフィル用エリアライトと必要に応じてプロシージャルスカイを作成します。'),
])

GUIDE_STYLE_ITEMS = _enum([
    ('SOLID', 'Solid', '実線', 'Draw guide curves as solid camera-space lines.', 'カメラ空間の実線ガイドカーブとして描画します。'),
    ('DASHED', 'Dashed', '破線', 'Create shorter guide segments to approximate dashed lines.', '短いガイドセグメントで破線に近い表示を作成します。'),
])


class SCLSCameraSettings(PropertyGroup):
    persistent_uuid: StringProperty(
        name=tr.add('Persistent Camera UUID', 'カメラ永続UUID'),
        description=tr.add('Internal persistent identity used to keep JSON camera settings bound to this exact Camera datablock instead of its name.', 'JSONカメラ設定を名前ではなく、このCameraデータブロックそのものへ結び付けるための内部永続識別子です。'),
        default='',
        options={'HIDDEN'},
    )
    enable_custom_settings: BoolProperty(
        name=tr.add('Enable Custom Camera Settings', 'カメラ別設定を有効化'),
        description=tr.add('Enable per-camera render, output, guide, overscan, motion-blur, review, and rig settings for this camera. Turn this on before applying camera-specific settings to the scene render context.', 'このカメラ用のレンダー、出力、ガイド、オーバースキャン、モーションブラー、レビュー、リグ設定を有効化します。シーンのレンダー状態へ反映する前に有効にしてください。'),
        default=False,
    )
    resolution_x: IntProperty(
        name=tr.add('Width', '幅'),
        description=tr.add('Horizontal render resolution used when this camera applies its custom render settings.', 'このカメラのカスタムレンダー設定を適用したときに使う横解像度です。'),
        default=1920,
        min=1,
        subtype='PIXEL',
    )
    resolution_y: IntProperty(
        name=tr.add('Height', '高さ'),
        description=tr.add('Vertical render resolution used when this camera applies its custom render settings.', 'このカメラのカスタムレンダー設定を適用したときに使う縦解像度です。'),
        default=1080,
        min=1,
        subtype='PIXEL',
    )
    resolution_percentage: IntProperty(
        name=tr.add('Scale', 'スケール'),
        description=tr.add('Render resolution percentage for this camera. Use lower values for previews and 100 percent or more for final output.', 'このカメラ用のレンダー解像度倍率です。プレビューでは低め、最終出力では100%以上を使用します。'),
        default=100,
        min=1,
        max=400,
        subtype='PERCENTAGE',
    )
    pixel_aspect_x: FloatProperty(
        name=tr.add('Pixel Aspect X', 'ピクセル比率X'),
        description=tr.add('Horizontal pixel aspect ratio applied with the camera resolution.', 'カメラ解像度と一緒に適用する横方向のピクセル比率です。'),
        default=1.0,
        min=0.01,
    )
    pixel_aspect_y: FloatProperty(
        name=tr.add('Pixel Aspect Y', 'ピクセル比率Y'),
        description=tr.add('Vertical pixel aspect ratio applied with the camera resolution.', 'カメラ解像度と一緒に適用する縦方向のピクセル比率です。'),
        default=1.0,
        min=0.01,
    )
    frame_range_mode: EnumProperty(
        name=tr.add('Frame Range Mode', 'フレーム範囲モード'),
        description=tr.add('Choose whether this camera uses its own frame range or timeline camera markers.', 'このカメラが独自フレーム範囲を使うか、タイムラインカメラマーカーを使うかを選びます。'),
        items=FRAME_RANGE_ITEMS,
        default='PER_CAMERA',
    )
    frame_start: IntProperty(
        name=tr.add('Start', '開始'),
        description=tr.add('First frame for this camera when per-camera frame range mode is active.', 'カメラ別フレーム範囲モードが有効なとき、このカメラで使用する開始フレームです。'),
        default=1,
    )
    frame_end: IntProperty(
        name=tr.add('End', '終了'),
        description=tr.add('Last frame for this camera when per-camera frame range mode is active.', 'カメラ別フレーム範囲モードが有効なとき、このカメラで使用する終了フレームです。'),
        default=250,
    )
    frame_step: IntProperty(
        name=tr.add('Step', 'ステップ'),
        description=tr.add('Frame step used for renders and animation review output from this camera.', 'このカメラのレンダーとアニメーションレビュー出力で使用するフレームステップです。'),
        default=1,
        min=1,
    )
    sync_frame_range: BoolProperty(
        name=tr.add('Sync Timeline Range', 'タイムライン範囲を同期'),
        description=tr.add('When enabled, applying this camera also updates the scene timeline start, end, and step to match this camera.', '有効にすると、このカメラを適用したときにシーンのタイムライン開始、終了、ステップもこのカメラに合わせます。'),
        default=False,
    )
    output_path: StringProperty(
        name=tr.add('Output Path', '出力パス'),
        description=tr.add('Root directory for this camera output. Blender relative paths such as // are supported.', 'このカメラの出力ルートディレクトリです。//などのBlender相対パスに対応します。'),
        default='//',
        subtype='DIR_PATH',
    )
    output_subfolder: StringProperty(
        name=tr.add('Subfolder', 'サブフォルダー'),
        description=tr.add('Optional subfolder created under the output path for this camera.', 'このカメラ用に出力パス下へ作成する任意のサブフォルダーです。'),
        default='',
    )
    output_filename: StringProperty(
        name=tr.add('File Name', 'ファイル名'),
        description=tr.add('Base output file name used when this camera applies file output settings.', 'このカメラのファイル出力設定を適用するときに使う基本ファイル名です。'),
        default='camera_render',
    )
    output_format: EnumProperty(
        name=tr.add('Format', '形式'),
        description=tr.add('Image or movie format applied to Blender render settings for this camera.', 'このカメラ用にBlenderのレンダー設定へ適用する画像またはムービー形式です。'),
        items=OUTPUT_FORMAT_ITEMS,
        default='PNG',
    )
    png_color_depth: EnumProperty(
        name=tr.add('PNG Color Depth', 'PNG色深度'),
        description=tr.add('Color depth used when this camera renders PNG stills.', 'このカメラでPNG静止画をレンダーするときの色深度です。'),
        items=COLOR_DEPTH_ITEMS,
        default='8',
    )
    png_compression: IntProperty(
        name=tr.add('PNG Compression', 'PNG圧縮'),
        description=tr.add('PNG compression level. Higher values reduce file size but can take longer to save.', 'PNG圧縮レベルです。値を高くするとファイルサイズは減りますが保存に時間がかかる場合があります。'),
        default=15,
        min=0,
        max=100,
        subtype='PERCENTAGE',
    )
    jpeg_quality: IntProperty(
        name=tr.add('JPEG Quality', 'JPEG品質'),
        description=tr.add('JPEG quality level for this camera. Higher values preserve more detail and create larger files.', 'このカメラのJPEG品質です。値を高くするとディテールを保ちますがファイルが大きくなります。'),
        default=90,
        min=1,
        max=100,
        subtype='PERCENTAGE',
    )
    exr_color_depth: EnumProperty(
        name=tr.add('EXR Color Depth', 'EXR色深度'),
        description=tr.add('OpenEXR channel precision used by this camera.', 'このカメラで使うOpenEXRチャンネル精度です。'),
        items=EXR_DEPTH_ITEMS,
        default='16',
    )
    exr_codec: EnumProperty(
        name=tr.add('EXR Codec', 'EXRコーデック'),
        description=tr.add('OpenEXR compression codec used by this camera.', 'このカメラで使うOpenEXR圧縮コーデックです。'),
        items=EXR_CODEC_ITEMS,
        default='ZIP',
    )
    exr_preview: BoolProperty(
        name=tr.add('Save EXR Preview', 'EXRプレビューを保存'),
        description=tr.add('Reserve a per-camera flag for EXR preview workflows. Use it to mark cameras that should also create preview stills in pipeline scripts.', 'EXRプレビュー用のカメラ別フラグです。パイプラインスクリプトでプレビュー静止画も作成したいカメラの目印に使います。'),
        default=False,
    )
    video_quality: EnumProperty(
        name=tr.add('Video Quality', '動画品質'),
        description=tr.add('FFmpeg quality preset used when this camera renders movie output.', 'このカメラでムービー出力をレンダーするときに使うFFmpeg品質プリセットです。'),
        items=VIDEO_QUALITY_ITEMS,
        default='HIGH',
    )
    video_bitrate: IntProperty(
        name=tr.add('Video Bitrate', '動画ビットレート'),
        description=tr.add('Target video bitrate in kilobits per second for camera movie output.', 'このカメラのムービー出力で使う目標動画ビットレートです。'),
        default=6000,
        min=1,
        max=100000,
    )
    video_gopsize: IntProperty(
        name=tr.add('GOP Size', 'GOPサイズ'),
        description=tr.add('Distance between keyframes for FFmpeg movie output.', 'FFmpegムービー出力でのキーフレーム間隔です。'),
        default=12,
        min=0,
        max=500,
    )
    use_audio: BoolProperty(
        name=tr.add('Include Audio', '音声を含める'),
        description=tr.add('Include scene audio when this camera renders movie output.', 'このカメラでムービー出力をレンダーするとき、シーン音声を含めます。'),
        default=False,
    )
    audio_codec: EnumProperty(
        name=tr.add('Audio Codec', '音声コーデック'),
        description=tr.add('Audio codec used for this camera movie output.', 'このカメラのムービー出力で使う音声コーデックです。'),
        items=AUDIO_CODEC_ITEMS,
        default='NONE',
    )
    audio_bitrate: IntProperty(
        name=tr.add('Audio Bitrate', '音声ビットレート'),
        description=tr.add('Audio bitrate in kilobits per second for this camera movie output.', 'このカメラのムービー出力で使う音声ビットレートです。'),
        default=192,
        min=32,
        max=384,
    )
    overwrite_existing: BoolProperty(
        name=tr.add('Overwrite Existing Files', '既存ファイルを上書き'),
        description=tr.add('Allow renders from this camera to overwrite files that already exist at the output path.', 'このカメラのレンダーで出力先に既存ファイルがある場合の上書きを許可します。'),
        default=True,
    )
    include_camera_name: BoolProperty(
        name=tr.add('Include Camera Name', 'カメラ名を含める'),
        description=tr.add('Append the camera object name to the output path so batch renders stay separated by camera.', 'バッチレンダー時にカメラ別で出力を分けやすいよう、出力パスへカメラオブジェクト名を追加します。'),
        default=True,
    )
    burn_metadata: BoolProperty(
        name=tr.add('Enable Burn-In Metadata', '焼き込みメタデータを有効化'),
        description=tr.add('Enable Blender stamp metadata such as frame and camera name for animation review renders.', 'アニメーションレビュー用レンダーで、フレームやカメラ名などのBlenderスタンプメタデータを有効にします。'),
        default=False,
    )
    film_transparent: BoolProperty(
        name=tr.add('Transparent Film', '透過フィルム'),
        description=tr.add('Apply transparent film output for this camera when the active render engine supports it.', 'アクティブなレンダーエンジンが対応している場合、このカメラに透過フィルム出力を適用します。'),
        default=False,
    )
    guide_thirds: BoolProperty(
        name=tr.add('Rule of Thirds', '三分割法'),
        description=tr.add('Create vertical and horizontal thirds lines parented to the camera for composition checking.', '構図確認用に、カメラへ親子付けされた縦横の三分割線を作成します。'),
        default=True,
    )
    guide_center: BoolProperty(
        name=tr.add('Center Cross', '中央十字'),
        description=tr.add('Create a center cross guide parented to the camera.', 'カメラへ親子付けされた中央十字ガイドを作成します。'),
        default=True,
    )
    guide_safe_area: BoolProperty(
        name=tr.add('Safe Area', 'セーフエリア'),
        description=tr.add('Create an action/title safe-area rectangle inside the camera frame.', 'カメラフレーム内にアクション/タイトル用のセーフエリア矩形を作成します。'),
        default=True,
    )
    guide_safe_percentage: FloatProperty(
        name=tr.add('Safe Area Percentage', 'セーフエリア比率'),
        description=tr.add('Percentage of the camera frame occupied by the generated safe-area rectangle.', '生成するセーフエリア矩形がカメラフレーム内で占める比率です。'),
        default=90.0,
        min=1.0,
        max=100.0,
        subtype='PERCENTAGE',
    )
    guide_color: FloatVectorProperty(
        name=tr.add('Guide Color', 'ガイド色'),
        description=tr.add('Viewport color assigned to generated camera composition guide curves.', '生成したカメラ構図ガイドカーブに割り当てるビューポート色です。'),
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 0.8, 0.1, 1.0),
    )
    guide_line_width: FloatProperty(
        name=tr.add('Guide Line Width', 'ガイド線幅'),
        description=tr.add('Curve bevel width used for generated camera guides. Increase it when the guide is difficult to see in the viewport.', '生成カメラガイドに使うカーブのベベル幅です。ビューポートで見づらい場合は大きくします。'),
        default=0.004,
        precision=3,
        min=0.0001,
        max=0.1,
    )
    guide_line_style: EnumProperty(
        name=tr.add('Guide Line Style', 'ガイド線スタイル'),
        description=tr.add('Choose solid guide lines or segmented guide lines for camera composition overlays.', 'カメラ構図オーバーレイで実線または分割線を選びます。'),
        items=GUIDE_STYLE_ITEMS,
        default='SOLID',
    )
    guide_render_enabled: BoolProperty(
        name=tr.add('Render Guides', 'ガイドをレンダー表示'),
        description=tr.add('Allow generated guide objects to be visible to final renders. Leave disabled for viewport-only composition checks.', '生成ガイドオブジェクトを最終レンダーにも表示します。構図確認だけなら無効のままにします。'),
        default=False,
    )
    overscan_enable: BoolProperty(
        name=tr.add('Enable Overscan', 'オーバースキャンを有効化'),
        description=tr.add('Use overscan whenever this camera is applied or rendered from the panel. The Apply button in this section works either way.', 'パネルからこのカメラを適用・レンダーするときにオーバースキャンを使います。この欄の「適用」ボタンは入切にかかわらず働きます。'),
        default=False,
    )
    overscan_view_factor: FloatProperty(
        name=tr.add('Overscan View Factor', 'オーバースキャンの視野倍率'),
        description=tr.add('Internal factor by which overscan currently widens this camera view. Revert Overscan uses it to restore the lens.', 'オーバースキャンがこのカメラの視野を今どれだけ広げているかを示す内部の倍率です。「オーバースキャンを戻す」がレンズの復元に使います。'),
        default=1.0,
        min=0.0001,
    )
    overscan_mode: EnumProperty(
        name=tr.add('Overscan Mode', 'オーバースキャンモード'),
        description=tr.add('Choose how this camera expands the render resolution for overscan.', 'このカメラがどの方法でレンダー解像度をオーバースキャン拡張するかを選びます。'),
        items=OVERSCAN_MODE_ITEMS,
        default='PERCENT',
    )
    overscan_percentage: FloatProperty(
        name=tr.add('Overscan Percentage', 'オーバースキャン比率'),
        description=tr.add('Percentage used to expand render resolution when overscan mode is Percentage.', 'オーバースキャンモードが比率の場合にレンダー解像度を拡張する割合です。'),
        default=10.0,
        min=0.0,
        max=300.0,
        subtype='PERCENTAGE',
    )
    overscan_extra_pixels: IntProperty(
        name=tr.add('Extra Pixels', '追加ピクセル'),
        description=tr.add('Number of pixels added to both dimensions when overscan mode is Extra Pixels.', 'オーバースキャンモードが追加ピクセルの場合、両方向へ追加するピクセル数です。'),
        default=128,
        min=0,
        subtype='PIXEL',
    )
    overscan_specific_x: IntProperty(
        name=tr.add('Specific Width', '指定幅'),
        description=tr.add('Exact horizontal resolution applied when overscan mode is Specific Resolution.', 'オーバースキャンモードが指定解像度の場合に適用する正確な横解像度です。'),
        default=2048,
        min=1,
        subtype='PIXEL',
    )
    overscan_specific_y: IntProperty(
        name=tr.add('Specific Height', '指定高さ'),
        description=tr.add('Exact vertical resolution applied when overscan mode is Specific Resolution.', 'オーバースキャンモードが指定解像度の場合に適用する正確な縦解像度です。'),
        default=1152,
        min=1,
        subtype='PIXEL',
    )
    motion_blur_enable: BoolProperty(
        name=tr.add('Enable Physical Motion Blur', '物理モーションブラーを有効化'),
        description=tr.add('Enable camera-level photographic motion blur conversion and apply it to Blender render settings.', 'カメラ別の写真・映画式モーションブラー変換を有効化し、Blenderのレンダー設定へ適用します。'),
        default=False,
    )
    motion_blur_mode: EnumProperty(
        name=tr.add('Motion Blur Mode', 'モーションブラーモード'),
        description=tr.add('Choose whether motion blur is controlled by shutter speed or shutter angle.', 'モーションブラーをシャッタースピードまたはシャッター角のどちらで制御するかを選びます。'),
        items=MOTION_MODE_ITEMS,
        default='SHUTTER_ANGLE',
    )
    shutter_speed: StringProperty(
        name=tr.add('Shutter Speed', 'シャッタースピード'),
        description=tr.add('Photographic shutter speed such as 1/48, 1/60, or 0.02 seconds. The value is converted using the scene frame rate.', '1/48、1/60、0.02秒などの写真式シャッタースピードです。シーンのフレームレートを使って変換します。'),
        default='1/48',
    )
    shutter_angle: FloatProperty(
        name=tr.add('Shutter Angle', 'シャッター角'),
        description=tr.add('Cinema shutter angle in degrees. 180 degrees equals half-frame exposure.', '映画式シャッター角です。180度は半フレーム露光に相当します。'),
        default=180.0,
        min=0.0,
        max=360.0,
    )
    review_use_stamp: BoolProperty(
        name=tr.add('Use Review Stamps', 'レビュースタンプを使用'),
        description=tr.add('Enable visible review metadata stamps for viewport or final animation review renders.', 'ビューポートまたは最終アニメーションレビュー用レンダーで、表示用レビューメタデータスタンプを有効にします。'),
        default=True,
    )
    review_stamp_camera: BoolProperty(
        name=tr.add('Stamp Camera Name', 'カメラ名をスタンプ'),
        description=tr.add('Show the camera name in Blender render stamp metadata.', 'Blenderのレンダースタンプメタデータにカメラ名を表示します。'),
        default=True,
    )
    review_stamp_frame: BoolProperty(
        name=tr.add('Stamp Frame', 'フレームをスタンプ'),
        description=tr.add('Show the current frame in Blender render stamp metadata.', 'Blenderのレンダースタンプメタデータに現在フレームを表示します。'),
        default=True,
    )
    review_stamp_scene: BoolProperty(
        name=tr.add('Stamp Scene', 'シーン名をスタンプ'),
        description=tr.add('Show the scene name in Blender render stamp metadata.', 'Blenderのレンダースタンプメタデータにシーン名を表示します。'),
        default=False,
    )
    review_resolution_percentage: IntProperty(
        name=tr.add('Review Scale', 'レビュースケール'),
        description=tr.add('Temporary resolution percentage used for viewport animation review renders.', 'ビューポートのアニメーションレビュー用レンダーで使う一時的な解像度倍率です。'),
        default=50,
        min=1,
        max=100,
        subtype='PERCENTAGE',
    )
    rig_type: EnumProperty(
        name=tr.add('Rig Type', 'リグタイプ'),
        description=tr.add('Choose the type of camera rig created by the rig operator.', 'リグ作成オペレーターが作成するカメラリグの種類を選びます。'),
        items=CAMERA_RIG_ITEMS,
        default='DOLLY_TARGET',
    )
    rig_target_distance: FloatProperty(
        name=tr.add('Target Distance', 'ターゲット距離'),
        description=tr.add('Distance in front of the camera where the rig target empty will be created.', 'リグターゲットEmptyをカメラ前方に作成する距離です。'),
        default=5.0,
        min=0.01,
    )
    rig_target_size: FloatProperty(
        name=tr.add('Target Size', 'ターゲットサイズ'),
        description=tr.add('Viewport display size of the camera rig target Empty. Lower values keep the target unobtrusive, and changing this updates existing Smart CamLight camera targets for this camera.', 'カメラリグターゲットEmptyのビューポート表示サイズです。小さい値にするとターゲットが邪魔になりにくくなり、この値を変更すると、このカメラの既存Smart CamLight カメラターゲットにも反映されます。'),
        default=0.04,
        min=0.001,
        update=_update_camera_target_size,
    )
    rig_create_dof: BoolProperty(
        name=tr.add('Use Target for DOF', 'ターゲットをDOFに使用'),
        description=tr.add('Assign the created target empty to the camera depth-of-field focus object.', '作成したターゲットEmptyをカメラの被写界深度フォーカスオブジェクトへ割り当てます。'),
        default=True,
    )
    pov_export_depth: BoolProperty(
        name=tr.add('Include Depth of Field in POV Text', 'POVテキストにDOFを含める'),
        description=tr.add('Include simple aperture and focal-distance values when creating a POV-compatible camera text block.', 'POV互換カメラテキストブロックを作成するときに、簡易的な絞りと焦点距離の値を含めます。'),
        default=True,
    )
    pov_note: StringProperty(
        name=tr.add('POV Note', 'POVメモ'),
        description=tr.add('Optional comment stored at the top of the generated POV camera text block.', '生成するPOVカメラテキストブロックの先頭に保存する任意コメントです。'),
        default='Smart CamLight Suite camera export',
    )
    show_camera_data: BoolProperty(
        name=tr.add('Show Camera Data', 'カメラデータを表示'),
        description=tr.add('Expand the Camera Data child section for this camera. The section contains transform, lens, clipping, sensor, and depth-of-field controls.', 'このカメラの「カメラデータ」子セクションを展開します。トランスフォーム、レンズ、クリッピング、センサー、被写界深度の操作を表示します。'),
        default=True,
    )
    show_resolution_settings: BoolProperty(
        name=tr.add('Show Resolution', '解像度を表示'),
        description=tr.add('Expand the per-camera resolution and aspect-preset child section.', 'カメラ別の解像度と縦横比プリセットの子セクションを展開します。'),
        default=True,
    )
    show_frame_range: BoolProperty(
        name=tr.add('Show Frame Range', 'フレーム範囲を表示'),
        description=tr.add('Expand the per-camera frame-range and timeline-marker child section.', 'カメラ別フレーム範囲とタイムラインマーカーの子セクションを展開します。'),
        default=False,
    )
    show_file_output: BoolProperty(
        name=tr.add('Show File Output', 'ファイル出力を表示'),
        description=tr.add('Expand the per-camera output path, subfolder, file-name, and overwrite child section.', 'カメラ別の出力パス、サブフォルダー、ファイル名、上書き設定の子セクションを展開します。'),
        default=False,
    )
    show_format_settings: BoolProperty(
        name=tr.add('Show File Format', 'ファイル形式を表示'),
        description=tr.add('Expand the per-camera still-image or movie format child section.', 'カメラ別の静止画または動画形式の子セクションを展開します。'),
        default=False,
    )
    show_guides: BoolProperty(
        name=tr.add('Show Composition Guides', '構図ガイドを表示'),
        description=tr.add('Expand the composition-guide creation and removal child section.', '構図ガイドの作成・削除を行う子セクションを展開します。'),
        default=False,
    )
    show_rig: BoolProperty(
        name=tr.add('Show Camera Rig', 'カメラリグを表示'),
        description=tr.add('Expand camera target, dolly, path, key, fly-view, and bake controls.', 'カメラターゲット、ドリー、パス、キー、フライビュー、ベイク操作を展開します。'),
        default=False,
    )
    show_review: BoolProperty(
        name=tr.add('Show Animation Review', 'アニメーションレビューを表示'),
        description=tr.add('Expand review stamp and viewport animation-render controls.', 'レビュースタンプとビューポートアニメーションレンダー操作を展開します。'),
        default=False,
    )
    show_overscan: BoolProperty(
        name=tr.add('Show Overscan', 'オーバースキャンを表示'),
        description=tr.add('Expand per-camera overscan setup, apply, and revert controls.', 'カメラ別オーバースキャンの設定、適用、復元操作を展開します。'),
        default=False,
    )
    show_motion_blur: BoolProperty(
        name=tr.add('Show Physical Motion Blur', '物理モーションブラーを表示'),
        description=tr.add('Expand shutter-speed and shutter-angle conversion controls.', 'シャッタースピードとシャッター角の変換操作を展開します。'),
        default=False,
    )
    show_pov: BoolProperty(
        name=tr.add('Show POV Export Helper', 'POV書き出し補助を表示'),
        description=tr.add('Expand controls that create a POV-compatible camera text block.', 'POV互換カメラテキストブロックを作成する操作を展開します。'),
        default=False,
    )


class SCLSObjectSettings(PropertyGroup):
    persistent_uuid: StringProperty(
        name=tr.add('Persistent Object UUID', 'オブジェクト永続UUID'),
        description=tr.add('Internal persistent identity used for exact Smart CamLight object ownership and JSON matching.', 'Smart CamLight オブジェクトの正確な所有判定とJSON照合に使う内部永続識別子です。'),
        default='',
        options={'HIDDEN'},
    )
    is_generated_light: BoolProperty(
        name=tr.add('Generated Light', '生成ライト'),
        description=tr.add('Marks lights created by Smart CamLight Suite so they can be cleared without touching manually created lights.', 'Smart CamLight Suite が作成したライトを示し、手作業で作成したライトを触らずに削除できるようにします。'),
        default=False,
    )
    locked_light: BoolProperty(
        name=tr.add('Lock Light Controls', 'ライト操作をロック'),
        description=tr.add('Disable Smart CamLight editing controls for this light to prevent accidental energy, color, or transform changes.', 'このライトのエネルギー、色、トランスフォームの誤変更を防ぐため、Smart CamLight の編集操作を無効化します。'),
        default=False,
    )


class SCLSLightSettings(PropertyGroup):
    persistent_uuid: StringProperty(
        name=tr.add('Persistent Light UUID', 'ライト永続UUID'),
        description=tr.add('Internal persistent identity used to keep JSON light settings bound to this exact Light datablock instead of its name.', 'JSONライト設定を名前ではなく、このLightデータブロックそのものへ結び付けるための内部永続識別子です。'),
        default='',
        options={'HIDDEN'},
    )
    target_size: FloatProperty(
        name=tr.add('Target Size', 'ターゲットサイズ'),
        description=tr.add('Viewport display size of the Empty target created for this light. Lower values keep the light target unobtrusive, and changing this updates existing Smart CamLight light targets for this light.', 'このライト用に作成するEmptyターゲットのビューポート表示サイズです。小さい値にするとライトターゲットが邪魔になりにくくなり、この値を変更すると、このライトの既存Smart CamLight ライトターゲットにも反映されます。'),
        default=0.05,
        min=0.001,
        update=_update_light_target_size,
    )
    max_bounces: IntProperty(
        name=tr.add('Max Bounces', '最大バウンス'),
        description=tr.add('Cycles light max-bounce helper value. When available, it is applied to the light cycles settings.', 'Cyclesライトの最大バウンス補助値です。利用できる場合はライトのCycles設定へ適用します。'),
        default=1024,
        min=0,
        max=1024,
        update=_update_light_max_bounces,
    )
    show_light_data: BoolProperty(
        name=tr.add('Show Light Data', 'ライトデータを表示'),
        description=tr.add('Expand transform, energy, color, shape, target, mirror, lock, and isolate controls for this light.', 'このライトのトランスフォーム、エネルギー、カラー、形状、ターゲット、ミラー、ロック、分離表示操作を展開します。'),
        default=True,
    )
    show_linking: BoolProperty(
        name=tr.add('Show Light Linking', 'ライトリンキングを表示'),
        description=tr.add('Expand receiver, blocker, link-state, and linked-object display controls for this light.', 'このライトの受光、遮光、リンク状態、リンク済みオブジェクト表示操作を展開します。'),
        default=True,
    )
    show_generator: BoolProperty(
        name=tr.add('Show Light Generator', 'ライト生成を表示'),
        description=tr.add('Compatibility state retained for earlier Smart CamLight files. Scene-level generator visibility is stored separately.', '以前のSmart CamLight ファイルとの互換性用に保持する状態です。シーン単位のライト生成表示状態は別に保存されます。'),
        default=False,
    )
    show_sky: BoolProperty(
        name=tr.add('Show Dynamic Sky', 'ダイナミックスカイを表示'),
        description=tr.add('Compatibility state retained for earlier Smart CamLight files. Scene-level dynamic-sky visibility is stored separately.', '以前のSmart CamLight ファイルとの互換性用に保持する状態です。シーン単位のダイナミックスカイ表示状態は別に保存されます。'),
        default=False,
    )


class SCLSSceneSettings(PropertyGroup):
    persistent_scene_uuid: StringProperty(
        name=tr.add('Persistent Scene UUID', 'シーン永続UUID'),
        description=tr.add('Internal persistent identity used to bind saved settings to this exact Scene.', '保存設定をこのSceneそのものへ結び付けるための内部永続識別子です。'),
        default='',
        options={'HIDDEN'},
    )
    persistent_blend_uuid: StringProperty(
        name=tr.add('Persistent Blend UUID', 'Blend永続UUID'),
        description=tr.add('Internal file identity shared by Smart CamLight scenes and combined with the blend file identity for JSON isolation.', 'JSONを別blendから隔離するため、blendファイル識別子と組み合わせて使うSmart CamLight シーン共通の内部識別子です。'),
        default='',
        options={'HIDDEN'},
    )
    dynamic_sky_previous_world: PointerProperty(
        name=tr.add('Previous Dynamic Sky World', 'ダイナミックスカイ変更前World'),
        description=tr.add('Internal exact pointer to the World assigned before Smart CamLight Dynamic Sky was enabled.', 'Smart CamLight ダイナミックスカイを有効にする前に割り当てられていたWorldへの内部正確ポインターです。'),
        type=bpy.types.World,
        options={'HIDDEN'},
    )
    dynamic_sky_owned_world: PointerProperty(
        name=tr.add('Owned Dynamic Sky World', '所有ダイナミックスカイWorld'),
        description=tr.add('Internal exact pointer to the separate World owned by this Scene Dynamic Sky workflow.', 'このSceneのダイナミックスカイ処理が所有する分離Worldへの内部正確ポインターです。'),
        type=bpy.types.World,
        options={'HIDDEN'},
    )
    dynamic_sky_owned_sun: PointerProperty(
        name=tr.add('Owned Dynamic Sky Sun', '所有ダイナミックスカイSun'),
        description=tr.add('Internal exact pointer to the companion Sun owned by this Scene Dynamic Sky workflow.', 'このSceneのダイナミックスカイ処理が所有する連動Sunへの内部正確ポインターです。'),
        type=bpy.types.Object,
        poll=_dynamic_sun_object_poll,
        options={'HIDDEN'},
    )
    ui_section_always_on: BoolProperty(
        name=tr.add('Show Always-on Toggles', '常時起動切り替えを表示'),
        description=tr.add('Expand the top-level section containing N-panel persistence and optional event-driven services.', 'Nパネル永続化と任意のイベント駆動サービスを含む最上層セクションを展開します。'),
        default=False,
    )
    ui_section_camera: BoolProperty(
        name=tr.add('Show Camera Section', 'カメラセクションを表示'),
        description=tr.add('Expand the top-level camera list and all camera workflow child sections.', '最上層のカメラリストと全カメラワークフロー子セクションを展開します。'),
        default=True,
    )
    ui_section_light: BoolProperty(
        name=tr.add('Show Light Section', 'ライトセクションを表示'),
        description=tr.add('Expand the top-level light list, linking, generator, and dynamic-sky child sections.', '最上層のライトリスト、リンキング、ライト生成、ダイナミックスカイ子セクションを展開します。'),
        default=True,
    )
    n_panel_state_save: BoolProperty(
        name=tr.add('N-panel State Save', 'Nパネル状態保存'),
        description=tr.add('Controls when portable Smart CamLight N-panel options are saved to the canonical JSON. When enabled, each change is saved immediately. When disabled, the validated in-memory change is committed at a .blend save/load boundary, add-on disable, Blender exit, or when this option is enabled again. Datablock-specific camera, light, object, and transform content remains owned by the .blend file.', 'Smart CamLight の移植可能なNパネル設定を正規JSONへ保存するタイミングを制御します。有効時は変更ごとに即時保存し、無効時は検証済みのメモリ内変更を.blendの保存・読込境界、アドオン無効化、Blender終了、またはこの項目を再び有効にした時に確定保存します。カメラ、ライト、オブジェクト、トランスフォーム固有の内容は.blendファイル側で保持します。'),
        default=True,
    )
    auto_active_camera: BoolProperty(
        name=tr.add('Auto Active Camera', '自動アクティブカメラ'),
        description=tr.add('When enabled, an active-object message-bus event makes a selected camera the Scene active camera. The subscription exists only while this option is enabled and performs no idle polling.', '有効にすると、アクティブオブジェクトのメッセージバスイベント時に選択カメラをSceneのアクティブカメラへ設定します。この購読は有効中だけ存在し、アイドルポーリングは行いません。'),
        default=False,
        update=_update_live_runtime,
    )
    live_per_camera_sync: BoolProperty(
        name=tr.add('Live Per-Camera Sync', 'カメラ別設定の常時同期'),
        description=tr.add('Continuously applies the active camera custom resolution, output, frame range, stamps, overscan, and motion-blur settings during frame changes and camera switches.', 'フレーム変更やカメラ切替時に、アクティブカメラのカスタム解像度、出力、フレーム範囲、スタンプ、オーバースキャン、モーションブラー設定を継続適用します。'),
        default=False,
        update=_update_live_runtime,
    )
    live_marker_camera_switch: BoolProperty(
        name=tr.add('Timeline Marker Camera Switch', 'タイムラインマーカーでカメラ切替'),
        description=tr.add('On frame changes, use the last timeline marker bound to a camera to set the scene active camera automatically.', 'フレーム変更時に、カメラへバインドされた直前のタイムラインマーカーを使ってシーンのアクティブカメラを自動設定します。'),
        default=False,
        update=_update_live_runtime,
    )
    live_motion_blur_sync: BoolProperty(
        name=tr.add('Live Physical Motion Blur', '物理モーションブラー常時同期'),
        description=tr.add('On frame changes, refresh photographic shutter speed or shutter angle conversion for the active camera.', 'フレーム変更時に、アクティブカメラの写真式シャッタースピードまたは映画式シャッター角変換を更新します。'),
        default=False,
        update=_update_live_runtime,
    )
    live_light_link_monitor: BoolProperty(
        name=tr.add('Light Linking Monitor', 'ライトリンク監視'),
        description=tr.add('On relevant depsgraph events, clear a linked-object selection only when its object was deleted. No recurring timer or idle scan is used.', '関連するdepsgraphイベント時だけ、選択中のリンク済みオブジェクトが削除されていた場合に選択を解除します。定期タイマーやアイドル走査は使用しません。'),
        default=False,
        update=_update_live_runtime,
    )
    live_dynamic_sky_monitor: BoolProperty(
        name=tr.add('Dynamic Sky Monitor', 'ダイナミックスカイ監視'),
        description=tr.add('Refresh the Smart CamLight world and companion sun only after a sky setting, Scene.world, or relevant depsgraph event. The monitor has no recurring timer and no idle polling.', 'スカイ設定、Scene.world、または関連するdepsgraphイベントが発生した時だけ、Smart CamLight ワールドと連動サンを更新します。定期タイマーやアイドルポーリングは行いません。'),
        default=False,
        update=_update_dynamic_sky_monitor,
    )
    live_proxy_maintenance: BoolProperty(
        name=tr.add('Automatic Proxy Maintenance', 'プロキシ自動メンテナンス'),
        description=tr.add('On relevant depsgraph updates, remove only stale helper IDs carrying the exact Smart CamLight owner UUID, instance UUID, role, and source UUID. Disable this to stop automatic cleanup; no recurring timer or idle scan is used.', '関連するdepsgraph更新時に、Smart CamLight の正確な所有UUID、インスタンスUUID、役割、ソースUUIDを持つ古い補助IDだけを整理します。無効にすると自動整理を停止し、定期タイマーやアイドル走査は行いません。'),
        default=False,
        update=_update_live_runtime,
    )
    active_camera_name: StringProperty(
        name=tr.add('Active Camera Name', 'アクティブカメラ名'),
        description=tr.add('Name of the camera currently selected in the Smart CamLight camera list.', 'Smart CamLight のカメラリストで現在選択されているカメラ名です。'),
        default='',
    )
    active_light_name: StringProperty(
        name=tr.add('Active Light Name', 'アクティブライト名'),
        description=tr.add('Name of the light currently selected in the Smart CamLight light list.', 'Smart CamLight のライトリストで現在選択されているライト名です。'),
        default='',
    )
    active_linked_object_name: StringProperty(
        name=tr.add('Active Linked Object Name', 'アクティブリンクオブジェクト名'),
        description=tr.add('Name of the receiver or blocker object selected from the light/shadow linking lists.', 'ライト/シャドウリンキングリストから選択された受光または遮光オブジェクト名です。'),
        default='',
    )
    show_custom_cameras_only: BoolProperty(
        name=tr.add('Show Custom Cameras Only', 'カスタムカメラのみ表示'),
        description=tr.add('Filter the camera list to cameras that have Smart CamLight custom settings enabled.', 'Smart CamLight のカスタム設定が有効なカメラだけをカメラリストに表示します。'),
        default=False,
    )
    show_generated_lights_only: BoolProperty(
        name=tr.add('Show Generated Lights Only', '生成ライトのみ表示'),
        description=tr.add('Filter the light list to lights created by Smart CamLight Suite.', 'Smart CamLight Suite が作成したライトだけをライトリストに表示します。'),
        default=False,
    )
    overscan_original_x: IntProperty(
        name=tr.add('Stored Overscan Width', '保存済みオーバースキャン幅'),
        description=tr.add('Internal width snapshot used by Revert Overscan. It is not written to the portable JSON profile.', 'オーバースキャンを戻す操作で使う内部の幅スナップショットです。移植用JSONプロファイルには保存しません。'),
        default=0,
    )
    overscan_original_y: IntProperty(
        name=tr.add('Stored Overscan Height', '保存済みオーバースキャン高さ'),
        description=tr.add('Internal height snapshot used by Revert Overscan. It is not written to the portable JSON profile.', 'オーバースキャンを戻す操作で使う内部の高さスナップショットです。移植用JSONプロファイルには保存しません。'),
        default=0,
    )
    overscan_original_percentage: IntProperty(
        name=tr.add('Stored Overscan Scale', '保存済みオーバースキャン倍率'),
        description=tr.add('Internal resolution-scale snapshot used by Revert Overscan. It is not written to the portable JSON profile.', 'オーバースキャンを戻す操作で使う内部の解像度倍率スナップショットです。移植用JSONプロファイルには保存しません。'),
        default=0,
    )
    overscan_applied_x: IntProperty(
        name=tr.add('Applied Overscan Width', '適用済みオーバースキャン幅'),
        description=tr.add('Internal width written by the last overscan application, used to notice later resolution changes. It is not written to the portable JSON profile.', '直前のオーバースキャン適用で書いた内部の幅で、その後の解像度の変更に気づくために使います。移植用JSONプロファイルには保存しません。'),
        default=0,
    )
    overscan_applied_y: IntProperty(
        name=tr.add('Applied Overscan Height', '適用済みオーバースキャン高さ'),
        description=tr.add('Internal height written by the last overscan application, used to notice later resolution changes. It is not written to the portable JSON profile.', '直前のオーバースキャン適用で書いた内部の高さで、その後の解像度の変更に気づくために使います。移植用JSONプロファイルには保存しません。'),
        default=0,
    )
    light_count: IntProperty(
        name=tr.add('Light Count', 'ライト数'),
        description=tr.add('Number of lights generated by the Smart CamLight light generator.', 'Smart CamLight ライト生成で作成するライト数です。'),
        default=3,
        min=1,
        max=128,
    )
    light_distance: FloatProperty(
        name=tr.add('Distance', '距離'),
        description=tr.add('Distance from the target center used when generated lights are arranged in a circle, line, grid, or random pattern.', '生成ライトを円形、ライン、グリッド、ランダムに配置するときのターゲット中心からの距離です。'),
        default=5.0,
        min=0.01,
    )
    light_randomness: FloatProperty(
        name=tr.add('Randomness', 'ランダム量'),
        description=tr.add('Random offset strength applied to generated light positions and power values.', '生成ライトの位置やパワー値に適用するランダムオフセット量です。'),
        default=0.25,
        min=0.0,
        max=10.0,
    )
    light_z_offset: FloatProperty(
        name=tr.add('Z Offset', 'Zオフセット'),
        description=tr.add('Vertical offset added to generated lights relative to the target center.', 'ターゲット中心を基準として生成ライトへ追加する高さオフセットです。'),
        default=2.0,
    )
    light_type: EnumProperty(
        name=tr.add('Light Type', 'ライトタイプ'),
        description=tr.add('Blender light type created by generator and add-light operators.', '生成およびライト追加オペレーターが作成するBlenderライトタイプです。'),
        items=LIGHT_TYPE_ITEMS,
        default='AREA',
    )
    area_shape: EnumProperty(
        name=tr.add('Area Shape', 'エリア形状'),
        description=tr.add('Shape used for generated area lights when the selected light type is Area.', '選択ライトタイプがエリアの場合に生成ライトへ使用する形状です。'),
        items=AREA_SHAPE_ITEMS,
        default='SQUARE',
    )
    light_size: FloatProperty(
        name=tr.add('Light Size', 'ライトサイズ'),
        description=tr.add('Size or radius used by generated point, spot, and area lights.', '生成するポイント、スポット、エリアライトで使うサイズまたは半径です。'),
        default=3.0,
        min=0.001,
    )
    area_size_x: FloatProperty(
        name=tr.add('Area Size X', 'エリアサイズX'),
        description=tr.add('Horizontal size for rectangular or elliptical area lights.', '長方形または楕円エリアライトの横サイズです。'),
        default=3.0,
        min=0.001,
    )
    area_size_y: FloatProperty(
        name=tr.add('Area Size Y', 'エリアサイズY'),
        description=tr.add('Vertical size for rectangular or elliptical area lights.', '長方形または楕円エリアライトの縦サイズです。'),
        default=1.5,
        min=0.001,
    )
    power_min: FloatProperty(
        name=tr.add('Power Min', '最小パワー'),
        description=tr.add('Minimum energy value used when generated light power is randomized.', '生成ライトのパワーをランダム化するときに使う最小エネルギー値です。'),
        default=250.0,
        min=0.0,
    )
    power_max: FloatProperty(
        name=tr.add('Power Max', '最大パワー'),
        description=tr.add('Maximum energy value used when generated light power is randomized.', '生成ライトのパワーをランダム化するときに使う最大エネルギー値です。'),
        default=650.0,
        min=0.0,
    )
    randomize_power: BoolProperty(
        name=tr.add('Randomize Power', 'パワーをランダム化'),
        description=tr.add('Randomize generated light energy between Power Min and Power Max.', '生成ライトのエネルギーを最小パワーから最大パワーの間でランダム化します。'),
        default=True,
    )
    light_seed: IntProperty(
        name=tr.add('Random Seed', 'ランダムシード'),
        description=tr.add('Seed used to make generated light placement and power deterministic.', '生成ライトの配置とパワーを決定論的にするためのシード値です。'),
        default=17,
    )
    distribution: EnumProperty(
        name=tr.add('Distribution', '分布'),
        description=tr.add('Placement pattern used by the light generator.', 'ライト生成で使用する配置パターンです。'),
        items=LIGHT_DISTRIBUTION_ITEMS,
        default='CIRCLE',
    )
    use_target_object: BoolProperty(
        name=tr.add('Use Target Object', 'ターゲットオブジェクトを使用'),
        description=tr.add('Aim generated lights at the chosen target object instead of the world origin.', '生成ライトをワールド原点ではなく指定ターゲットオブジェクトへ向けます。'),
        default=False,
    )
    target_object: PointerProperty(
        name=tr.add('Target Object', 'ターゲットオブジェクト'),
        description=tr.add('Object used as the center and aim target for generated lights.', '生成ライトの中心および照準ターゲットとして使うオブジェクトです。'),
        type=bpy.types.Object,
        poll=_light_object_poll,
    )
    spot_size: FloatProperty(
        name=tr.add('Spot Size', 'スポットサイズ'),
        description=tr.add('Cone angle used for generated spot lights.', '生成スポットライトで使用するコーン角です。'),
        default=0.785398,
        min=0.01,
        max=3.14159,
        subtype='ANGLE',
    )
    spot_blend: FloatProperty(
        name=tr.add('Spot Blend', 'スポットブレンド'),
        description=tr.add('Softness of generated spot light edges.', '生成スポットライトのエッジの柔らかさです。'),
        default=0.3,
        min=0.0,
        max=1.0,
    )
    studio_preset: EnumProperty(
        name=tr.add('Studio Preset', 'スタジオプリセット'),
        description=tr.add('Prebuilt lighting layout created by the Smart CamLight studio preset operator.', 'Smart CamLight のスタジオプリセットオペレーターで作成する既定照明レイアウトです。'),
        items=STUDIO_PRESET_ITEMS,
        default='THREE_POINT',
    )
    sky_strength: FloatProperty(
        name=tr.add('Sky Strength', 'スカイ強度'),
        description=tr.add('World background strength used when creating or refreshing the procedural dynamic sky.', 'プロシージャルダイナミックスカイを作成または更新するときに使うワールド背景強度です。'),
        default=0.8,
        min=0.0,
        max=20.0,
        update=_update_dynamic_sky_value,
    )
    sky_turbidity: FloatProperty(
        name=tr.add('Sky Turbidity', 'スカイ濁度'),
        description=tr.add('Turbidity value assigned to Blender Sky Texture nodes when the property is available.', 'BlenderのSky Textureノードでプロパティが利用できる場合に割り当てる濁度値です。'),
        default=2.0,
        min=1.0,
        max=10.0,
        update=_update_dynamic_sky_value,
    )
    sky_sun_energy: FloatProperty(
        name=tr.add('Sun Energy', 'サン強度'),
        description=tr.add('Energy value used by the sun light created with the dynamic sky workflow.', 'ダイナミックスカイワークフローで作成するサンライトのエネルギー値です。'),
        default=2.0,
        min=0.0,
        max=100.0,
        update=_update_dynamic_sky_value,
    )
    sky_create_sun: BoolProperty(
        name=tr.add('Create Sun Light', 'サンライトを作成'),
        description=tr.add('Create or refresh a companion sun light when building the dynamic sky world.', 'ダイナミックスカイのワールドを構築するときに、連動するサンライトを作成または更新します。'),
        default=True,
        update=_update_dynamic_sky_value,
    )
    show_camera_utilities: BoolProperty(
        name=tr.add('Show Camera Utilities', 'カメラユーティリティを表示'),
        description=tr.add('Compatibility state retained for Smart CamLight files that stored a camera-utilities foldout.', 'カメラユーティリティの折りたたみ状態を保存していたSmart CamLight ファイルとの互換性用に保持します。'),
        default=False,
    )
    show_light_utilities: BoolProperty(
        name=tr.add('Show Light Generator', 'ライト生成を表示'),
        description=tr.add('Expand the scene-level studio preset, softbox, and procedural light generator child section.', 'シーン単位のスタジオプリセット、ソフトボックス、プロシージャルライト生成の子セクションを展開します。'),
        default=False,
    )
    show_dynamic_sky: BoolProperty(
        name=tr.add('Show Dynamic Sky', 'ダイナミックスカイを表示'),
        description=tr.add('Expand the scene-level procedural sky and companion sun child section.', 'シーン単位のプロシージャルスカイと連動サンの子セクションを展開します。'),
        default=False,
    )


def _install_setting_updates() -> None:
    """Attach atomic JSON updates without mutating deferred RNA in place.

    Blender 5.1 freezes the keyword mapping when a deferred property is
    created.  Rebuilding the definition is required for the callback to become
    part of the registered RNA; changing ``keywords`` alone only appeared to
    work and delayed persistence until add-on shutdown.
    """
    for settings_cls in (
        SCLSCameraSettings,
        SCLSObjectSettings,
        SCLSLightSettings,
        SCLSSceneSettings,
    ):
        annotations = getattr(settings_cls, '__annotations__', {}) or {}
        for name, prop_def in tuple(annotations.items()):
            if str(name) in settings_store.NON_PERSISTED_PROPERTIES:
                continue
            factory = getattr(prop_def, 'function', None)
            keywords = getattr(prop_def, 'keywords', None)
            if not callable(factory) or not isinstance(keywords, dict):
                continue
            rebuilt = dict(keywords)
            rebuilt['update'] = settings_store.make_update(rebuilt.get('update'), str(name))
            annotations[name] = factory(**rebuilt)


_install_setting_updates()


def get_settings(context=None):
    try:
        scene = getattr(context, 'scene', None) if context is not None else bpy.context.scene
        return getattr(scene, 'smart_camlight_suite', None)
    except Exception:
        return None


CLASSES = (
    SCLSCameraSettings,
    SCLSObjectSettings,
    SCLSLightSettings,
    SCLSSceneSettings,
)


def register() -> None:
    for cls in CLASSES:
        lifecycle.register_class(cls, resource_key=f"property_class:{cls.__name__}")
    lifecycle.register_pointer_property(
        bpy.types.Camera,
        'smart_camlight_settings',
        PointerProperty(
            name=tr.add('Smart CamLight Camera Settings', 'Smart CamLight カメラ設定'),
            description=tr.add('Per-camera Smart CamLight N-panel settings stored with this Camera datablock.', 'このCameraデータブロックと共に保存されるカメラ別Smart CamLight Nパネル設定です。'),
            type=SCLSCameraSettings,
        ),
        property_group=SCLSCameraSettings,
    )
    lifecycle.register_pointer_property(
        bpy.types.Object,
        'smart_camlight_object',
        PointerProperty(
            name=tr.add('Smart CamLight Object Settings', 'Smart CamLight オブジェクト設定'),
            description=tr.add('Smart CamLight ownership and lock metadata stored with this Object datablock.', 'このObjectデータブロックと共に保存されるSmart CamLight 所有・ロックメタデータです。'),
            type=SCLSObjectSettings,
        ),
        property_group=SCLSObjectSettings,
    )
    lifecycle.register_pointer_property(
        bpy.types.Light,
        'smart_camlight_light',
        PointerProperty(
            name=tr.add('Smart CamLight Light Settings', 'Smart CamLight ライト設定'),
            description=tr.add('Per-light Smart CamLight N-panel settings stored with this Light datablock.', 'このLightデータブロックと共に保存されるライト別Smart CamLight Nパネル設定です。'),
            type=SCLSLightSettings,
        ),
        property_group=SCLSLightSettings,
    )
    lifecycle.register_pointer_property(
        bpy.types.Scene,
        'smart_camlight_suite',
        PointerProperty(
            name=tr.add('Smart CamLight Scene Settings', 'Smart CamLight シーン設定'),
            description=tr.add('Scene-level Smart CamLight N-panel state, persistence controls, and optional event-driven services.', 'シーン単位のSmart CamLight Nパネル状態、永続化操作、任意イベント駆動サービスです。'),
            type=SCLSSceneSettings,
        ),
        property_group=SCLSSceneSettings,
    )


def unregister() -> None:
    # Exact reverse release is centralized in lifecycle.unregister_generation().
    return None
