# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Custom icon assets for Smart Shader.

The PNG assets are bundled with the extension and loaded through Blender's
preview API.  The loader is intentionally self-contained so the icons resolve
correctly from Blender Extension installs under ``bl_ext.user_default`` and from
legacy local add-on folders.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

try:
    import bpy.utils.previews as _previews
except Exception:  # pragma: no cover - Blender-only module
    _previews = None  # type: ignore[assignment]

_PACKAGE_DIR = Path(__file__).resolve().parent
_ICON_ROOT = _PACKAGE_DIR / "icons"
_SMART_ICON_DIR = _ICON_ROOT

_PREVIEW_COLLECTION = None
_LAST_LOAD_COUNT = 0
_LAST_MISSING: tuple[str, ...] = ()

ICON_FILES: dict[str, str] = {
    # Custom-only icons.  Blender standard icons remain preferred via fallback_icon().
    "quality_upgrade": "quality_upgrade.png",
    "pbr_import_set": "pbr_import_set.png",
    "smart_material_create": "smart_material_create.png",
    "smart_weathering": "smart_weathering.png",
    "material_capsule_save": "material_capsule_save.png",
    "material_capsule_restore": "material_capsule_restore.png",
    "supreme_finish": "supreme_finish.png",
    "node_layout_auto": "node_layout_auto.png",
    "bridge_transfer": "bridge_transfer.png",
    "photo_to_pbr": "photo_to_pbr.png",
    "toon_shader_create": "toon_shader_create.png",
    "npr_polish": "npr_polish.png",
    "precision_upgrade": "precision_upgrade.png",
    "ref_pbr_pipeline": "ref_pbr_pipeline.png",
    "ref_npr_pipeline": "ref_npr_pipeline.png",
    "ref_asset_pipeline": "ref_asset_pipeline.png",
}

ALIASES: dict[str, str] = {
    "quality_upgrade_scene": "quality_upgrade",
    "quality_finish": "quality_upgrade",
    "supreme": "supreme_finish",
    "weathering": "smart_weathering",
    "capsule": "material_capsule_save",
    "restore_capsule": "material_capsule_restore",
    "pbr_set": "pbr_import_set",
    "pbr_texture_import": "pbr_import_set",
    "smart_material": "smart_material_create",
    "smart_shader": "smart_material_create",
    "shader_studio": "smart_material_create",
    "material": "smart_material_create",
    "shader": "smart_material_create",
    "node_layout": "node_layout_auto",
    "layout": "node_layout_auto",
    "exchange": "bridge_transfer",
    "bridge": "bridge_transfer",
    "toon": "toon_shader_create",
    "pencil_shader": "toon_shader_create",
    "npr_shader": "toon_shader_create",
    "reference_pbr": "ref_pbr_pipeline",
    "reference_npr": "ref_npr_pipeline",
    "reference_asset": "ref_asset_pipeline",
}


ICON_RENAME_ALIASES: dict[str, str] = {
    # Legacy bundled icon keys kept for existing user preferences and reloads.
    "quality": "quality_upgrade",
    "weathering": "smart_weathering",
    "capsule": "material_capsule_save",
    "restore_capsule": "material_capsule_restore",
    "supreme": "supreme_finish",
    "node_layout": "node_layout_auto",
    "exchange": "bridge_transfer",
    "pbr_import": "pbr_import_set",
    "smart_material": "smart_material_create",
    "pencil_line": "toon_shader_create",
    "ref_pbr_pipeline": "ref_pbr_pipeline",
    "ref_npr_pipeline": "ref_npr_pipeline",
    "ref_asset_pipeline": "ref_asset_pipeline",
}

_FALLBACKS: dict[str, str] = {
    # Standard Blender icons: use these instead of custom assets when the standard
    # symbol already matches the operation.
    "quality": "CHECKMARK",
    "audit": "VIEWZOOM",
    "pbr_import": "TEXTURE",
    "import": "IMPORT",
    "smart_material": "MATERIAL",
    "pencil_line": "GREASEPENCIL",
    "library": "ASSET_MANAGER",
    "relink": "FILE_REFRESH",
    "cleanup": "TRASH",
    "exchange": "EXPORT",
    "hdri": "WORLD_DATA",
    "decal": "IMAGE_DATA",
    "node_layout": "NODETREE",
    "line_set": "GREASEPENCIL",
    "render_preview": "RENDER_STILL",
    "palette": "COLOR",
    "variant": "FILE_REFRESH",
    "guide": "QUESTION",
    "help": "QUESTION",
    "ref_pbr_pipeline": "NONE",
    "ref_npr_pipeline": "NONE",
    "ref_asset_pipeline": "NONE",
    # Custom-only keys.
    "quality_upgrade": "NONE",
    "pbr_import_set": "NONE",
    "smart_material_create": "NONE",
    "smart_weathering": "NONE",
    "material_capsule_save": "NONE",
    "material_capsule_restore": "NONE",
    "supreme_finish": "NONE",
    "node_layout_auto": "NONE",
    "bridge_transfer": "NONE",
    "photo_to_pbr": "NONE",
    "toon_shader_create": "NONE",
    "npr_polish": "NONE",
    "precision_upgrade": "NONE",
}

def normalize_key(value: str | None) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    text = text.replace("sss.", "").replace("sss_", "")
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in text)
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_")


def _candidate_keys(name: str | None) -> Iterable[str]:
    raw = str(name or "").strip()
    norm = normalize_key(raw)
    seen: set[str] = set()
    pending = [raw, norm, ALIASES.get(raw), ALIASES.get(norm)]
    while pending:
        key = str(pending.pop(0) or "").strip()
        if not key or key in seen:
            continue
        seen.add(key)
        yield key
        mapped = ICON_RENAME_ALIASES.get(key)
        if mapped and mapped not in seen:
            pending.append(mapped)


def _candidate_dirs() -> Iterable[Path]:
    # Primary Blender Extension layout first, then compatibility fallbacks for
    # older local add-on structures and accidental icon/icons directory names.
    seen: set[str] = set()
    for base in (
        _ICON_ROOT,
        _PACKAGE_DIR / "icon",
        _PACKAGE_DIR / "icon" / "shader_studio",
        _PACKAGE_DIR / "icons" / "shader_studio",
        _PACKAGE_DIR.parent / "icons",
        _PACKAGE_DIR.parent / "icon",
        _PACKAGE_DIR.parent / "icon" / "shader_studio",
        _PACKAGE_DIR.parent / "icons" / "shader_studio",
    ):
        try:
            resolved = base.resolve()
        except Exception:
            resolved = base
        key = str(resolved)
        if key in seen:
            continue
        seen.add(key)
        yield resolved


def _icon_paths(filename: str) -> Iterable[Path]:
    for base in _candidate_dirs():
        path = base / filename
        if path.exists() and path.is_file():
            yield path


def _remove_collection() -> None:
    global _PREVIEW_COLLECTION
    if _previews is not None and _PREVIEW_COLLECTION is not None:
        try:
            _previews.remove(_PREVIEW_COLLECTION)
        except Exception:
            pass
    _PREVIEW_COLLECTION = None


def register(force: bool = False) -> None:
    """Load all bundled custom icons into one preview collection."""
    global _PREVIEW_COLLECTION, _LAST_LOAD_COUNT, _LAST_MISSING
    if _previews is None:
        _PREVIEW_COLLECTION = None
        _LAST_LOAD_COUNT = 0
        _LAST_MISSING = tuple(ICON_FILES)
        return
    if _PREVIEW_COLLECTION is not None and not force:
        return
    if force:
        _remove_collection()
    try:
        pcoll = _previews.new()
    except Exception:
        _PREVIEW_COLLECTION = None
        _LAST_LOAD_COUNT = 0
        _LAST_MISSING = tuple(ICON_FILES)
        return

    loaded_keys: set[str] = set()
    for folder in _candidate_dirs():
        if not folder.exists() or not folder.is_dir():
            continue
        for path in sorted(folder.glob("*.png")):
            key = path.stem
            if key in loaded_keys:
                continue
            try:
                pcoll.load(key, str(path), "IMAGE")
                loaded_keys.add(key)
            except Exception:
                continue

    required = {Path(filename).stem for filename in ICON_FILES.values()}
    required.update(ICON_RENAME_ALIASES.values())
    missing = sorted(key for key in required if key not in loaded_keys)
    _PREVIEW_COLLECTION = pcoll
    _LAST_LOAD_COUNT = len(loaded_keys)
    _LAST_MISSING = tuple(missing)


def unregister() -> None:
    global _LAST_LOAD_COUNT, _LAST_MISSING
    _remove_collection()
    _LAST_LOAD_COUNT = 0
    _LAST_MISSING = ()


def _lookup_icon_id(key: str) -> int:
    pcoll = _PREVIEW_COLLECTION
    if pcoll is None:
        return 0
    try:
        item = pcoll.get(key)
    except Exception:
        item = None
    return int(getattr(item, "icon_id", 0) or 0)


def _custom_icon_keys() -> set[str]:
    keys = {Path(filename).stem for filename in ICON_FILES.values()}
    keys.update(ICON_FILES.keys())
    keys.update(ICON_RENAME_ALIASES.values())
    return {str(key or "").strip() for key in keys if str(key or "").strip()}


def has_custom_icon_name(name: str | None) -> bool:
    known = _custom_icon_keys()
    return any(key in known for key in _candidate_keys(name))


def icon_value(name: str | None) -> int:
    # Do not remove/recreate Blender preview collections from inside a panel draw
    # or hover-driven redraw.  Blender's C UI can still hold an icon pointer from
    # the current preview collection; replacing it while ui_handler_panel is
    # active can become an access violation.  Unknown/custom-missing icons simply
    # fall back to Blender standard icons until the add-on registration phase.
    if not has_custom_icon_name(name):
        return 0
    if _PREVIEW_COLLECTION is None:
        register()
    for key in _candidate_keys(name):
        icon_id = _lookup_icon_id(key)
        if icon_id:
            return icon_id
    return 0


def fallback_icon(name: str | None) -> str:
    for key in _candidate_keys(name):
        value = _FALLBACKS.get(key)
        if value:
            return value
    return "NONE"


def has_icon(name: str | None) -> bool:
    return icon_value(name) > 0


def loaded_count() -> int:
    if _PREVIEW_COLLECTION is None:
        register()
    return int(_LAST_LOAD_COUNT)


def missing_icons() -> tuple[str, ...]:
    if _PREVIEW_COLLECTION is None:
        register()
    return tuple(_LAST_MISSING)
